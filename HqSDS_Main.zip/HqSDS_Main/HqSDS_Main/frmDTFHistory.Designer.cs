﻿namespace HqSDS_Main
{
    partial class frmDTFHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDTFHistory));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblTotalItems = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOutwards = new System.Windows.Forms.Button();
            this.btnInwards = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdoHQOutwards = new System.Windows.Forms.RadioButton();
            this.rdoHQInwards = new System.Windows.Forms.RadioButton();
            this.cboVesselFilter = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNoOfDays = new System.Windows.Forms.TextBox();
            this.cboNoOfDays = new System.Windows.Forms.ComboBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.btnExportXL = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlProcessing = new System.Windows.Forms.Panel();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.fpSpreadDTF = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadDTF_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsMnuSendDTFToVsl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuReSendDTF = new System.Windows.Forms.ToolStripMenuItem();
            this.cboCompany_Filter = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlProcessing.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF_Sheet1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(659, 612);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblTotalItems});
            this.statusStrip1.Location = new System.Drawing.Point(0, 592);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(659, 20);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblTotalItems
            // 
            this.tsLblTotalItems.Name = "tsLblTotalItems";
            this.tsLblTotalItems.Size = new System.Drawing.Size(22, 15);
            this.tsLblTotalItems.Text = "     ";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cboCompany_Filter);
            this.panel1.Controls.Add(this.btnOutwards);
            this.panel1.Controls.Add(this.btnInwards);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.cboVesselFilter);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.btnGo);
            this.panel1.Controls.Add(this.btnExportXL);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.groupBox9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(659, 107);
            this.panel1.TabIndex = 1;
            // 
            // btnOutwards
            // 
            this.btnOutwards.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnOutwards.Location = new System.Drawing.Point(507, 59);
            this.btnOutwards.Name = "btnOutwards";
            this.btnOutwards.Size = new System.Drawing.Size(87, 40);
            this.btnOutwards.TabIndex = 62;
            this.btnOutwards.Text = "DTF to VSL";
            this.btnOutwards.UseVisualStyleBackColor = false;
            this.btnOutwards.Click += new System.EventHandler(this.btnOutwards_Click);
            // 
            // btnInwards
            // 
            this.btnInwards.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnInwards.Location = new System.Drawing.Point(507, 12);
            this.btnInwards.Name = "btnInwards";
            this.btnInwards.Size = new System.Drawing.Size(87, 40);
            this.btnInwards.TabIndex = 61;
            this.btnInwards.Text = "DTF from VSL";
            this.btnInwards.UseVisualStyleBackColor = false;
            this.btnInwards.Click += new System.EventHandler(this.btnInwards_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdoHQOutwards);
            this.groupBox2.Controls.Add(this.rdoHQInwards);
            this.groupBox2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(6, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(261, 47);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Option";
            // 
            // rdoHQOutwards
            // 
            this.rdoHQOutwards.AutoSize = true;
            this.rdoHQOutwards.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoHQOutwards.ForeColor = System.Drawing.Color.Black;
            this.rdoHQOutwards.Location = new System.Drawing.Point(132, 16);
            this.rdoHQOutwards.Name = "rdoHQOutwards";
            this.rdoHQOutwards.Size = new System.Drawing.Size(108, 22);
            this.rdoHQOutwards.TabIndex = 2;
            this.rdoHQOutwards.TabStop = true;
            this.rdoHQOutwards.Text = "HQ Outwards";
            this.rdoHQOutwards.UseVisualStyleBackColor = true;
            this.rdoHQOutwards.CheckedChanged += new System.EventHandler(this.rdoHQOutwards_CheckedChanged);
            // 
            // rdoHQInwards
            // 
            this.rdoHQInwards.AutoSize = true;
            this.rdoHQInwards.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoHQInwards.ForeColor = System.Drawing.Color.Black;
            this.rdoHQInwards.Location = new System.Drawing.Point(14, 16);
            this.rdoHQInwards.Name = "rdoHQInwards";
            this.rdoHQInwards.Size = new System.Drawing.Size(97, 22);
            this.rdoHQInwards.TabIndex = 1;
            this.rdoHQInwards.TabStop = true;
            this.rdoHQInwards.Text = "HQ Inwards";
            this.rdoHQInwards.UseVisualStyleBackColor = true;
            this.rdoHQInwards.CheckedChanged += new System.EventHandler(this.rdoHQOutwards_CheckedChanged);
            // 
            // cboVesselFilter
            // 
            this.cboVesselFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVesselFilter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboVesselFilter.FormattingEnabled = true;
            this.cboVesselFilter.Location = new System.Drawing.Point(326, 32);
            this.cboVesselFilter.MaxDropDownItems = 15;
            this.cboVesselFilter.Name = "cboVesselFilter";
            this.cboVesselFilter.Size = new System.Drawing.Size(178, 23);
            this.cboVesselFilter.TabIndex = 43;
            this.cboVesselFilter.SelectedIndexChanged += new System.EventHandler(this.cboVesselFilter_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtNoOfDays);
            this.groupBox1.Controls.Add(this.cboNoOfDays);
            this.groupBox1.Location = new System.Drawing.Point(326, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(127, 52);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 14);
            this.label1.TabIndex = 46;
            this.label1.Text = "Acked in No. days";
            // 
            // txtNoOfDays
            // 
            this.txtNoOfDays.Location = new System.Drawing.Point(42, 27);
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.Size = new System.Drawing.Size(52, 20);
            this.txtNoOfDays.TabIndex = 48;
            this.txtNoOfDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNoOfDays_KeyPress);
            // 
            // cboNoOfDays
            // 
            this.cboNoOfDays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNoOfDays.FormattingEnabled = true;
            this.cboNoOfDays.Items.AddRange(new object[] {
            "=",
            ">"});
            this.cboNoOfDays.Location = new System.Drawing.Point(9, 27);
            this.cboNoOfDays.Name = "cboNoOfDays";
            this.cboNoOfDays.Size = new System.Drawing.Size(31, 21);
            this.cboNoOfDays.TabIndex = 47;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(459, 58);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(45, 21);
            this.btnClear.TabIndex = 50;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Calibri", 9.75F);
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(603, 59);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 40);
            this.btnClose.TabIndex = 58;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnGo
            // 
            this.btnGo.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btnGo.Location = new System.Drawing.Point(459, 80);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(45, 23);
            this.btnGo.TabIndex = 49;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = false;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // btnExportXL
            // 
            this.btnExportXL.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportXL.ForeColor = System.Drawing.Color.Black;
            this.btnExportXL.Image = ((System.Drawing.Image)(resources.GetObject("btnExportXL.Image")));
            this.btnExportXL.Location = new System.Drawing.Point(603, 12);
            this.btnExportXL.Margin = new System.Windows.Forms.Padding(0);
            this.btnExportXL.Name = "btnExportXL";
            this.btnExportXL.Size = new System.Drawing.Size(50, 40);
            this.btnExportXL.TabIndex = 48;
            this.btnExportXL.Text = "Export";
            this.btnExportXL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportXL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExportXL.UseVisualStyleBackColor = false;
            this.btnExportXL.Click += new System.EventHandler(this.btnExportXL_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 9F);
            this.label20.Location = new System.Drawing.Point(18, 52);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 14);
            this.label20.TabIndex = 45;
            this.label20.Text = "Trans Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9F);
            this.label9.Location = new System.Drawing.Point(271, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 14);
            this.label9.TabIndex = 42;
            this.label9.Text = "Vsl Filter";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label31);
            this.groupBox9.Controls.Add(this.dtpTo);
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.dtpFrom);
            this.groupBox9.Location = new System.Drawing.Point(6, 52);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(261, 47);
            this.groupBox9.TabIndex = 44;
            this.groupBox9.TabStop = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 9F);
            this.label31.Location = new System.Drawing.Point(3, 24);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(34, 14);
            this.label31.TabIndex = 8;
            this.label31.Text = "From";
            // 
            // dtpTo
            // 
            this.dtpTo.CustomFormat = "dd-MMM-yyyy";
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTo.Location = new System.Drawing.Point(157, 21);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(99, 20);
            this.dtpTo.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 9F);
            this.label15.Location = new System.Drawing.Point(139, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(19, 14);
            this.label15.TabIndex = 6;
            this.label15.Text = "To";
            // 
            // dtpFrom
            // 
            this.dtpFrom.CustomFormat = "dd-MMM-yyyy";
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFrom.Location = new System.Drawing.Point(38, 21);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(99, 20);
            this.dtpFrom.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pnlProcessing);
            this.panel2.Controls.Add(this.fpSpreadDTF);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 107);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(659, 485);
            this.panel2.TabIndex = 2;
            // 
            // pnlProcessing
            // 
            this.pnlProcessing.BackColor = System.Drawing.Color.White;
            this.pnlProcessing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlProcessing.Controls.Add(this.label55);
            this.pnlProcessing.Controls.Add(this.label56);
            this.pnlProcessing.Location = new System.Drawing.Point(239, 72);
            this.pnlProcessing.Name = "pnlProcessing";
            this.pnlProcessing.Size = new System.Drawing.Size(156, 62);
            this.pnlProcessing.TabIndex = 171;
            this.pnlProcessing.Visible = false;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(8, 35);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(99, 17);
            this.label55.TabIndex = 1;
            this.label55.Text = "Please wait ...";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.DarkGreen;
            this.label56.Location = new System.Drawing.Point(7, 8);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(141, 22);
            this.label56.TabIndex = 0;
            this.label56.Text = "Processing...  ";
            // 
            // fpSpreadDTF
            // 
            this.fpSpreadDTF.AccessibleDescription = "fpSpreadDTF, Sheet1, Row 0, Column 0, ";
            this.fpSpreadDTF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadDTF.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadDTF.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadDTF.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadDTF.HorizontalScrollBar.Name = "";
            this.fpSpreadDTF.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpreadDTF.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadDTF.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadDTF.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadDTF.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpreadDTF.Name = "fpSpreadDTF";
            this.fpSpreadDTF.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadDTF_Sheet1});
            this.fpSpreadDTF.Size = new System.Drawing.Size(659, 485);
            this.fpSpreadDTF.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadDTF.TabIndex = 117;
            this.fpSpreadDTF.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadDTF.VerticalScrollBar.Name = "";
            this.fpSpreadDTF.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpreadDTF.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadDTF.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadDTF.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpreadDTF.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpreadDTF_CellClick);
            this.fpSpreadDTF.AutoSortingColumn += new FarPoint.Win.Spread.AutoSortingColumnEventHandler(this.fpSpreadDTF_AutoSortingColumn);
            this.fpSpreadDTF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpreadDTF_MouseDown);
            // 
            // fpSpreadDTF_Sheet1
            // 
            this.fpSpreadDTF_Sheet1.Reset();
            this.fpSpreadDTF_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadDTF_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadDTF_Sheet1.ColumnCount = 3;
            this.fpSpreadDTF_Sheet1.RowCount = 10;
            this.fpSpreadDTF_Sheet1.AllowNoteEdit = false;
            this.fpSpreadDTF_Sheet1.AutoCalculation = false;
            this.fpSpreadDTF_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadDTF_Sheet1.AutoSortFrozenRows = false;
            this.fpSpreadDTF_Sheet1.AutoSortTrailingFrozenRows = false;
            this.fpSpreadDTF_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadDTF_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadDTF_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadDTF_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadDTF_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadDTF_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadDTF_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), System.Drawing.SystemColors.ControlLightLight, System.Drawing.SystemColors.ControlDark, 1);
            this.fpSpreadDTF_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadDTF_Sheet1.RowHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Blank;
            this.fpSpreadDTF_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadDTF_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadDTF_Sheet1.SelectionFont = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadDTF_Sheet1.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors;
            this.fpSpreadDTF_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadDTF_Sheet1.ShowRowSelector = true;
            this.fpSpreadDTF_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), System.Drawing.SystemColors.ControlLightLight, System.Drawing.SystemColors.ControlDark, 1);
            this.fpSpreadDTF_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuSendDTFToVsl,
            this.toolStripMenuItem1,
            this.tsMnuReSendDTF});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(137, 54);
            // 
            // tsMnuSendDTFToVsl
            // 
            this.tsMnuSendDTFToVsl.Name = "tsMnuSendDTFToVsl";
            this.tsMnuSendDTFToVsl.Size = new System.Drawing.Size(136, 22);
            this.tsMnuSendDTFToVsl.Text = "DTF to VSL";
            this.tsMnuSendDTFToVsl.Click += new System.EventHandler(this.tsMnuSendDTFToVsl_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(133, 6);
            // 
            // tsMnuReSendDTF
            // 
            this.tsMnuReSendDTF.Name = "tsMnuReSendDTF";
            this.tsMnuReSendDTF.Size = new System.Drawing.Size(136, 22);
            this.tsMnuReSendDTF.Text = "ReSend DTF";
            this.tsMnuReSendDTF.Click += new System.EventHandler(this.tsMnuReSendDTF_Click);
            // 
            // cboCompany_Filter
            // 
            this.cboCompany_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompany_Filter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCompany_Filter.FormattingEnabled = true;
            this.cboCompany_Filter.Location = new System.Drawing.Point(326, 6);
            this.cboCompany_Filter.MaxDropDownItems = 15;
            this.cboCompany_Filter.Name = "cboCompany_Filter";
            this.cboCompany_Filter.Size = new System.Drawing.Size(94, 23);
            this.cboCompany_Filter.TabIndex = 63;
            this.cboCompany_Filter.SelectedIndexChanged += new System.EventHandler(this.cboCompany_Filter_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F);
            this.label2.Location = new System.Drawing.Point(270, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 14);
            this.label2.TabIndex = 64;
            this.label2.Text = "Company";
            // 
            // frmDTFHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 612);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmDTFHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DTF History";
            this.Load += new System.EventHandler(this.frmDTFHistory_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.pnlProcessing.ResumeLayout(false);
            this.pnlProcessing.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF_Sheet1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private FarPoint.Win.Spread.FpSpread fpSpreadDTF;
        private FarPoint.Win.Spread.SheetView fpSpreadDTF_Sheet1;
        private System.Windows.Forms.ComboBox cboVesselFilter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboNoOfDays;
        private System.Windows.Forms.TextBox txtNoOfDays;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Button btnExportXL;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnlProcessing;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblTotalItems;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdoHQOutwards;
        private System.Windows.Forms.RadioButton rdoHQInwards;
        private System.Windows.Forms.Button btnOutwards;
        private System.Windows.Forms.Button btnInwards;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSendDTFToVsl;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuReSendDTF;
        private System.Windows.Forms.ComboBox cboCompany_Filter;
        private System.Windows.Forms.Label label2;
    }
}