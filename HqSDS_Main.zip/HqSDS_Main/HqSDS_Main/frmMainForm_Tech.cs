﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using FlexCel.Core;
using FlexCel.Report;
using FlexCel.XlsAdapter;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMainForm_Tech : Form
    {
        public string vslFilter = "", companyID = "";
        public bool isToShowSQEDashboard = true, isToShowCREWDashboard = true;
        Common common = null;
        PMS pms = null;
        bool isFormInitialised = false, isExpanded = false;
        string calledFrom = "", excludeColList = "";

        #region Column ID
        const int
            COL_COMPANYCODE = 0,
            COL_VSLCODE = 1,
            COL_INDICATOR = 2,
            COL_VSLNAME = 3,
            COL_OPERATEBY = 4,
            COL_LAST_DATA_TO_VSL = 5,
            COL_LAST_DATA_FROM_VSL = 6,
            COL_SEPARATOR_1 = 7,

            COL_SUPT_MNTQ = 8,
            COL_SUPT_TOAPPROVEMNT = 9,
            COL_ODUESVY = 10,
            COL_ALLOSTNDGMAINT = 11,
            COL_OSTDNGNONCRITICALMAINTITEMS = 12,
            COL_OSTDNGMAINTITEMSCRITICAL = 13,
            COL_OSTNDGNONCRITICALEQPMAINT = 14,
            COL_OSTDNGCRITICALEQPMAINTITEMS = 15,
            COL_CRITICALSPBELOWMINQTY = 16,
            COL_CRITICALSPRQNS = 17,
            COL_SEPARATOR_SPARES = 18,

            COL_SUPT_DF_ACK = 19,
            COL_DF_ACTIVEITEMS = 20,
            COL_DF_TOHQAPPROVE = 21,
            COL_DF_EXTENDED = 22,
            COL_DF_ODUEITEMS = 23,
            COL_SEPARATOR_DF = 24,
            
            COL_FORMS_ODUE = 25,
            COL_FORMS_VSL_PENDING = 26,
            COL_FORMS_VSL_TO_FINALISE = 27,
            COL_FORMS_VSL_TO_APPR = 28,
            COL_FORMS_VSL_TO_AMEND = 29,
            COL_FORMS_HQ_PENDING = 30,
            COL_FORMS_HQ_TO_AMEND = 31,
            COL_FORMS_TO_APPR = 32,
            COL_FORMS_SUPT_TO_FINALISE = 33,
            COL_FORMS_MGR_TO_FINALISE = 34,
            COL_FORMS_GENMGR_TO_FINALISE = 35,
            COL_FORMS_DIR_TO_FINALISE = 36,
            COL_FORMS_TA_TO_APPR = 37,
            COL_FORMS_SUPT_TO_APPR = 38,
            COL_FORMS_MGR_TO_APPR = 39,
            COL_FORMS_SENMGR_TO_APPR = 40,
            COL_FORMS_GENMGR_TO_APPR = 41,
            COL_FORMS_DIR_TO_APPR = 42,
            COL_FORMS_RECENTLY_CLOSED = 43,
            COL_SEPARATOR_FORMS = 44,

            COL_NCR_TOEXTEND_TOAPPROVE = 45,
            COL_NCR_EXTENDED = 46,
            COL_NCR_OVERDUE = 47,
            COL_NCR_HQUNDERPREP = 48,
            COL_NCR_HQ_TO_AMEND = 49,
            COL_NCR_TECH_TO_FINALISE = 50,
            COL_NCR_UNDERACTION = 51,
            COL_NCR_CLOSEOUT_TO_REVIEW_HQ = 52,
            COL_NCR_CLOSEOUT_TO_REVIEW_VSL = 53,
            COL_NCR_TECH_PENDING = 54,
            COL_NCR_MGR_TO_APPR = 55,
            COL_NCR_CREW_PENDING = 56,
            COL_NCR_RECENTLY_CLOSED = 57,
            COL_SEPARATOR_NCR = 58,

            COL_AUDITINSPECTION_DONE = 59,
            COL_AUDITINSPECTION_DUE = 60,
            COL_AUDITINSPECTION_RESCHEDULED_TOAPPR = 61,
            COL_AUDITINSPECTION_NOOFWINDOWPERIOD = 62,
            COL_AUDITINSPECTION_NOOFDUE = 63,
            COL_AUDITINSPECTION_NOOFOVERDUE = 64,
            COL_AUDITINSPECTION_DRAFTREPORT = 65,
            COL_AUDITINSPECTION_DRAFT_TOAMEND = 66,
            COL_AUDITINSPECTION_DRAFTMGRTOAPROVE = 67,
            COL_AUDITINSPECTION_DRAFTSRMGRTOAPROVE = 68,
            COL_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE = 69,
            COL_AUDITINSPECTION_UNDERACTION = 70,
            COL_AUDITINSPECTION_CLOSEOUTTOREVIEW = 71,
            COL_AUDITINSPECTION_MGRTOAPPROVE = 72,
            COL_AUDITINSPECTION_GENMGRTOAPPROVE = 73,
            COL_AUDITINSPECTION_DIRECTOR_TO_APPROVE = 74,
            COL_AUDITINSPECTION_VSL_AMEND_ACK = 75,
            COL_AUDITINSPECTION_AMENDREPORTTOAPPROVE = 76,
            COL_AUDITINSPECTION_RECENTLY_CLOSED = 77,
            COL_AUDITINSPECTION_DAYSDUE = 78,
            COL_AUDITINSPECTION_DAYSINWINDOWPERIOD = 79,
            COL_AUDITINSPECTION_ISRESCHEDULED = 80,
            COL_SEPARATOR_AUDITINSPECTION = 81,

            COL_TASKLIST_OVERDUE = 82,
            COL_TASKLIST_HQUNDERPREP =83,
            COL_TASKLIST_HQTOSUBMIT = 84,
            COL_TASKLIST_PURCHASERACTION = 85, 

            COL_TASKLIST_VSLUNDERPREP = 86,
            COL_TASKLIST_INPROGRESS = 87,
            COL_TASKLIST_VSL_TO_ACK = 88,
            COL_TASKLIST_DPA_PENDING = 89,
            COL_TASKLIST_CREW_PENDING = 90,
            COL_TASKLIST_TECH_PENDING = 91,
            COL_TASKLIST_VSL_AMEND_ACK = 92,
            COL_TASKLIST_RECENTLY_CLOSED = 93,
            COL_SEPARATOR_TASK = 94,

            COL_INCIDENT_REPORT_OVERDUE = 95,
            COL_INCIDENT_REPORT_HQUNDERPREP = 96,
            COL_INCIDENT_REPORT_HQ_TO_AMEND = 97,
            COL_INCIDENT_REPORT_VSL_AMEND = 98,
            COL_INCIDENT_REPORT_DPA_PENDING = 99,
            COL_INCIDENT_REPORT_TECH_PENDING = 100,
            COL_INCIDENT_REPORT_CREW_PENDING = 101,
            COL_INCIDENT_REPORT_MGR_TO_APPR = 102,
            COL_INCIDENT_REPORT_SR_MGR_TO_APPR = 103,
            COL_INCIDENT_REPORT_RECENTLY_FINALISED =104,
            COL_SEPARATOR_INCIDENT_REPORT = 105,

            COL_INVESTIGATION_REPORT_OVERDUE = 106,
            COL_INVESTIGATION_REPORT_HQTOFILLUP_UNDERPREP = 107,
            COL_INVESTIGATION_REPORT_HQTOFILLUP = 108,
            COL_INVESTIGATION_REPORT_HQUNDERPREP = 109,
            COL_INVESTIGATION_REPORT_HQ_TO_AMEND = 110,
            COL_INVESTIGATION_REPORT_DPA_PENDING_DRAFT = 111,
            COL_INVESTIGATION_REPORT_MGR_TO_APPR_DRAFT = 112,
            COL_INVESTIGATION_REPORT_UNDERACTION = 113,
            COL_INVESTIGATION_REPORT_CLOSEOUT = 114,
            COL_INVESTIGATION_REPORT_MGR_TO_APPR = 115,
            COL_INVESTIGATION_REPORT_SR_MGR_TO_APPR = 116,
            COL_INVESTIGATION_REPORT_VSLTOFILLUP = 117,
            COL_INVESTIGATION_REPORT_VSL_AMEND_ACK = 118,
            COL_INVESTIGATION_REPORT_RECENTLY_CLOSED = 119,
            COL_SEPARATOR_INVESTIGATION_REPORT = 120,

            COL_MINUTES_OF_SAFETY_OVERDUE = 121,
            COL_MINUTES_OF_SAFETY_HQUNDERPREP = 122,
            COL_MINUTES_OF_SAFETY_HQ_TO_AMEND = 123,
            COL_MINUTES_OF_SAFETY_TECH_PENDING = 124,
            COL_MINUTES_OF_SAFETY_MGR_TO_APPR = 125,
            COL_MINUTES_OF_SAFETY_CREW_PENDING = 126,
            COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED = 127,
            COL_SEPARATOR_MINUTES_OF_SAFETY = 128,

            COL_AWARENESS_REPORT_OVERDUE = 129,
            COL_AWARENESS_REPORT_HQUNDERPREP = 130,
            COL_AWARENESS_REPORT_HQ_TO_AMEND = 131,
            COL_AWARENESS_REPORT_TECH_PENDING = 132,
            COL_AWARENESS_REPORT_MGR_TO_APPR = 133,
            COL_AWARENESS_REPORT_CREW_PENDING = 134,
            COL_AWARENESS_REPORT_RECENTLY_CLOSED = 135,
            COL_SEPARATOR_AWARENESS_REPORT = 136,

            COL_MASTERS_REVIEW_OVERDUE = 137,
            COL_MASTERS_REVIEW_HQUNDERPREP = 138,
            COL_MASTERS_REVIEW_HQ_TO_AMEND = 139,
            COL_MASTERS_REVIEW_TECH_PENDING = 140,
            COL_MASTERS_REVIEW_MGR_TO_APPR = 141,
            COL_MASTERS_REVIEW_CREW_PENDING = 142,
            COL_MASTERS_REVIEW_RECENTLY_CLOSED = 143,
            COL_SEPARATOR_MASTERS_REVIEW = 144,

            COL_CORRECTIVE_HQTOAPPROVE = 145,
            COL_CORRECTIVE_DUE = 146,
            COL_SEPARATOR_CORRECTIVE = 147,
            
            COL_RISKASSEMENTS_TASK_ODUE = 148,
            COL_RISKASSEMENTS_REPORT_ODUE = 149,
            COL_RISKASSEMENTS_ACTIVEITEMS = 150,
            COL_RISKASSEMENTS_VSL_PENDING = 151,
            COL_RISKASSEMENTS_VSL_TO_AMEND = 152,
            COL_RISKASSEMENTS_HQ_PENDING = 153,
            COL_RISKASSEMENTS_HQ_TO_AMEND = 154,
            COL_RISKASSEMENTS_VSL_TO_ACK = 155,
            COL_RISKASSEMENTS_TO_APPR = 156,
            COL_RISKASSEMENTS_TA_TO_APPR = 157,
            COL_RISKASSEMENTS_SUPT_TO_APPR = 158,
            COL_RISKASSEMENTS_MGR_TO_APPR = 159,
            COL_RISKASSEMENTS_SENMGR_TO_APPR= 160,
            COL_RISKASSEMENTS_GENMGR_TO_APPR = 161,
            COL_RISKASSEMENTS_DIR_TO_APPR = 162,
            COL_RISKASSEMENTS_RECENTLY_CLOSED = 163,
            COL_RISKASSEMENTS_HQ_REVIEW = 164,
            COL_RISKASSEMENTS_VSLTASKTOMOVE = 165,
            COL_SEPARATOR_RISKASSEMENTS = 166,

            COL_MONTHENDDOC_OVERDUE = 167,
            COL_SEPARATOR_MONTHENDDOC = 168,

            COL_CERTIFICATE_OVERDUE = 169,
            COL_CERTIFICATE_WINDOW = 170,
            COL_CERTIFICATE_PENDING = 171,
            COL_CERTIFICATE_HQTOUPDATE = 172,
            COL_CERTIFICATE_VSLTOUPDATE = 173,
            COL_CERTIFICATE_TORENEW = 174,
            COL_CERTIFICATE_RENEWALINPROGRESS = 175,
            COL_SEPARATOR_CERTIFICATE = 176,

            COL_MASTERNAME = 177,
            COL_CENAME = 178,
            COL_IMONO = 179,
            COL_BUILDER = 180,
            COL_HULLNO = 181,
            COL_DELIVDATEDISPLAY = 182,
            COL_DWT = 183,
            COL_GRT = 184,
            COL_NRT = 185,
            COL_CALLSIGN = 186,
            COL_CLASSNO = 187,
            COL_OFFICIALNO = 188,
            COL_OWNER = 189,
            COL_VSLTYPE = 190,
            COL_FLEET_VESSELID = 191,
            COL_ISUSERVESSEL = 192,
            COL_ISOFFICEVSL = 193;




        #endregion

        bool isToEnableNCR = false, isToEnableDefects = false, isToEnableAuditInspection = false, isToEnableTask = false, isToEnableRiskAssements = false, isToEnableAwarenessReport = false, isToEnableMasterReview = false,
             isToEnableSafetyMeeting = false, isToEnableIncidentReport = false, isToEnableInvestigationReport = false, isToEnableMonthEndDoc = false, isToEnableCertificate = false, isToEnableAlert_Circulars = false, isQuarterlyStoresReports=false;

        public frmMainForm_Tech()
        {
            InitializeComponent();
        }

        private void frmMainForm_Tech_Load(object sender, EventArgs e)
        {
            this.Text = " HQ Dashboard";

            common = new Common();
            pms = new PMS();

            DesignParticularsGridDetails();

            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, false);

            FocusCompany();
            timer1.Enabled = true;

            tsLblSvrName.Text = PG.Gb.User.CurrentUserRole;
            isFormInitialised = true;

            PG.SetFormWidthAndHeight(this, 10, 10, 900, 1400);

            if (PG.Gb.IsToConnecDirectDB)
                tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else
                tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();

            tsLblUserId.Text = "User: " + PG.Gb.User.CurUserName + "    Role: " + PG.Gb.User.CurUserDesignation;

            btnNcr.Visible = false;
            btnSQEDashboard.Visible = false;
            btnCrewDashboard.Visible = false;

            excludeColList = COL_SUPT_MNTQ + "," + COL_FORMS_TO_APPR +
                             "," + COL_FORMS_ODUE + "," + COL_DF_ODUEITEMS + "," + COL_SEPARATOR_DF + "," + COL_NCR_OVERDUE + "," + COL_SEPARATOR_NCR +
                             "," + COL_AUDITINSPECTION_NOOFWINDOWPERIOD + "," + COL_AUDITINSPECTION_NOOFOVERDUE + "," + COL_SEPARATOR_AUDITINSPECTION +
                             "," + COL_TASKLIST_OVERDUE + "," + COL_SEPARATOR_TASK +
                             "," + COL_MINUTES_OF_SAFETY_TECH_PENDING + "," + COL_SEPARATOR_MINUTES_OF_SAFETY +
                             "," + COL_MASTERS_REVIEW_TECH_PENDING + "," + COL_SEPARATOR_MASTERS_REVIEW +
                             "," + COL_INCIDENT_REPORT_TECH_PENDING + "," + COL_SEPARATOR_INCIDENT_REPORT +
                             "," + COL_MONTHENDDOC_OVERDUE + "," + COL_SEPARATOR_MONTHENDDOC +
                             "," + COL_CERTIFICATE_OVERDUE + "," + COL_SEPARATOR_CERTIFICATE +
                             "," + COL_RISKASSEMENTS_HQ_REVIEW + "," + COL_SEPARATOR_RISKASSEMENTS +
                             "," + COL_MASTERNAME + "," + COL_CENAME + "," + COL_BUILDER + "," + COL_HULLNO + "," + COL_DELIVDATEDISPLAY + "," + COL_DWT +
                             "," + COL_GRT + "," + COL_NRT + "," + COL_CALLSIGN + "," + COL_CLASSNO + "," + COL_OFFICIALNO + "," + COL_OWNER + "," + COL_VSLTYPE + "," + COL_FLEET_VESSELID;
            timer1_Tick(null, null);
        }

        protected void DesignParticularsGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();

            try
            {
                Color rowHeaderForeColor = Color.Blue;
                particularsColList.Add(new DgvInits("CompanyCode", "Company", 60, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Indicatort", "", 15, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 160, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OperateBy", "Operate By", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("HQtoVsl", "HQ to Vsl Data Transfer", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VsltoHQ", "Vsl to HQ Data Transfer", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("PMS_MaintRepotsToRvw", "Maint Repots To Rvw", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PMS_ToApprvPostpnmtMaint", "To Apprv Postpnmt Maint", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PMS_OStdng_SvyItems", "O’stndg Survey", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PMS_OStdng_All_MaintItems", "All O’stndg Maint %", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("PMS_OStdng_NonCritical_MaintItems", "O’stndg Non Critical Maint % ", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PMS_OStdng_Critical_MaintItems", "O’stndg Critical Maint % ", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PMS_OStdng_NonCriticalEqp_MaintItems", "O’stndg Non Critical Eqp Maint % ", 61, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PMS_Ostdng_CriticalEqp_MaintItems", "O’stndg Critical Eqp Maint % ", 61, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("SP_CriticalSPBelowMinQty", "Critical Spares < MinQty", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("SP_CriticalSpRqns", "Critical Spares Reqn", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("DF_SUPT_ACK", "Supt Defect Items Ack", 58, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_ActiveItems", "Active Defect Items", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_TOHQApprove", "To Extend DF Items", 58, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_Extended", "Extended DF Items", 58, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_ODueItems", "O'Due Defect Items", 53, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Forms_ODue", "ODue", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_Pending", "Vsl To Fill", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_To_Finalise", "Vsl To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_To_Appr", "Vsl To Approve", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_to_Amend", "Vsl To Amend", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Hq_Pending", "HQ Pending", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Hq_to_Amend", "HQ To Amend", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_To_Appr", "Forms\nTo Appr", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));                
                particularsColList.Add(new DgvInits("Forms_Supt_To_Finalise", "Supt To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Mgr_To_Finalise", "Mgr To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_GenMgr_To_Finalise", "GenMgr To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Dir_To_Finalise", "Dir To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_TA_To_Appr", "TA To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Supt_To_Appr", "Supt To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Mgr_To_Appr", "Mgr To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_SenMgr_To_Appr", "SenMgr To Appr", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_GenMgr_To_Appr", "GenMgr To Appr", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Dir_To_Appr", "Dir To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("NCR_ToExtend_ToApprove", "To Extend NCR Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Extended", "Extended NCR Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Tech_ToFinalise", "Tech \nTo \nFinalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_UnderAction", "Under Action", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_CloseOut_to_Review", "Close Out To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_CloseOut_to_Review_VSL", "Close Out To Review Vsl", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Tech_Pending", "Tech To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Mgr_To_Appr", "Mgr To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Crew_Pending", "Crew To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Recently_Closed", "Recently Closed", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("AuditInspection_Done", "Last Done", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Due", "Next Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_ReScheduled_ToAppr", "Re-Sched.\n To Appr", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_NoofWindowPeriod", "Sched. Window\n Period", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_NoofDue", "Due", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_NoofOverDue", "Sched. O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_DraftReport", "Draft Report", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Draft_ToAmend", "Report To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Mgr_to_Approve_Draft", "Mgr To Appr Report", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_SeniorMgr_to_Approve_Draft", "Senior Mgr To Appr Report", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Director_to_Approve_Draft", "Director To Appr Report", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_UnderAction", "Under Action", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_CloseOut_to_Review", "Close Out To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Mgr_to_Approve", "Mgr\n To Appr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_SeniorMgr_to_Approve", "Senior Mgr To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Director_to_Approve", "Director To Appr", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Vsl_Amend_Ack", "Vsl To Amend & Ack", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_AmendReportToApprove", "Amend Report to Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Recently_Closed", "Recently Closed", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_DaysDue", "AuditInspection_DaysDue", 60, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("AuditInspection_DaysInWindowPeriod", "AuditInspection_DaysInWindowPeriodd", 60, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("AuditInspection_IsReScheduled", "AuditInspection_IsReScheduled", 60, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("TaskList_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_HQUnderPrep", "HQ Under Prep", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_HQToSubmit", "HQ To\nSubmit /\nReSubmit", 57, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_PurchaserAction", "Purchaser \nAction", 57, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_VslUnderPrep", "Vsl Under Prep", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_InProgress", "Vsl To\n Submit", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Vsl_to_Ack", "Vsl To Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_DPA_Pending", "To Appr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Crew_Pending", "Crew\n To Appr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Tech_Pending", "Tech\n To Appr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("IncidentReport_OverDue", "O’Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_HQ_ToAmend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Vsl_ToAmend", "Vsl To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_DPA_to_Approve", "DPA \nTo \nAppr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Tech_to_Approve", "Tech \nTo \nAppr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Crew_to_Approve", "Crew \nTo \nAppr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Mgr_to_Approve", "Mgr \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_SeniorMgr_to_Approve", "Senior Mgr \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Recently_Finalised", "Recently Finalised", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("InvestigationReport_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQFillup_UnderPrep", "HQ To Fillup  / Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQFillupReport", "HQ To Fillup Report", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQ_ToAmend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_DPA_to_Approve_Draft", "DPA\nTo Appr Report", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Mgr_to_Approve_Draft", "Mgr\nTo Appr Report", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_UnderAction", "Under Action", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_CloseOut_to_Review", "Close Out To Review", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Mgr_to_Approve", "Mgr \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_SeniorMgr_to_Approve", "Senior Mgr \nTo \nAppr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_VSlFillupReport", "Vsl To Fillup Report", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Minutes_of_Safety_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Tech_Pending", "Tech To Appr", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Mgr_To_Appr", "Mgr To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Crew_Pending", "Crew To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Recently_Closed", "Recently Closed", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Awareness_Report_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Tech_Pending", "Tech To Appr", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Mgr_To_Appr", "Mgr To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Crew_Pending", "Crew To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Recently_Closed", "Recently Closed", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Masters_Review_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Tech_Pending", "Tech To Appr", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Mgr_To_Appr", "Mgr To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Crew_Pending", "Crew To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Recently_Closed", "Recently Closed", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("WO_HqToApprove", "To Appr", 65, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("WO_Due", "Due", 83, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("RiskAssements_Task_ODue", "Task O'Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Report_ODue", "Report O'Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_ActiveItems", "Active Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_VSL_Pending", "Vsl Pending", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_to_Amend", "Vsl To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Hq_Pending", "HQ Pending", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Hq_to_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_To_Ack", "Vsl To Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_To_Appr", "To Review", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_TA_To_Appr", "TA To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Supt_To_Appr", "Tech Supt To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Mgr_To_Appr", "Mgr To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_SenMgr_To_Appr", "SenMgr To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_GenMgr_To_Appr", "GenMgr To Review", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Dir_To_Appr", "Dir To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Recently_Closed", "Recently Closed", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_HQReview", "HQ Review", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_VslTaskToMove", "Recom. to move to all vsl", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("MonthEndDoc_OverDue", "O'Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, false, true));

                particularsColList.Add(new DgvInits("Certificate_OverDue", "O'Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_Window", "Window", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_Pending", "Pending", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_HQToUpdate", "HQ To Update", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_VSLToUpdate", "VSL To Update", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_ToRenew", "To Renew", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_RenewalInProgress", "Renewal In Progress", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("MASTERNAME", "Master Name", 110, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CENAME", "CE Name", 110, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("ImoNo", "IMO Number", 80, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("BUILDER", "Builder", 150, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("HullNo", "Hull No", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DelivDateDisplay", "Deliv Date", 70, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DWT", "DWT", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("GRT", "GRT", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NRT", "NRT", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CallSign", "Call Sign", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("ClassNo", "Class No", 85, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OfficialNo", "Official No", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Owner", "Owner", 200, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslType", "Vessel Type", 130, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("userVsl", "userVsl", 130, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("IsOffice", "IsOffice", 130, rowHeaderForeColor, SystemColors.ButtonFace, false, true));

                fpSpread_Particulars.SuspendLayout();

                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Particulars, particularsColList, null, false, false, false);

                fpSpread_Particulars.ActiveSheet.ColumnHeader.RowCount = 2;
                fpSpread_Particulars.Sheets[0].FrozenColumnCount = COL_OPERATEBY + 1;

                #region Row Span
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_VSLCODE].ColumnSpan = 2;

                for (int col = COL_COMPANYCODE; col <= COL_SEPARATOR_1; col++)
                {
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, col].RowSpan = 2;
                }

                for (int col = COL_MASTERNAME; col < fpSpread_Particulars.ActiveSheet.ColumnCount; col++)
                {
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, col].RowSpan = 2;
                }

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_SPARES].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_DF].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_FORMS].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_NCR].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_AUDITINSPECTION].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_TASK].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_INCIDENT_REPORT].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_INVESTIGATION_REPORT].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MINUTES_OF_SAFETY].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_AWARENESS_REPORT].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MASTERS_REVIEW].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_CORRECTIVE].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_RISKASSEMENTS].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MONTHENDDOC].RowSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_CERTIFICATE].RowSpan = 2;
                #endregion

                for (int col = 0; col < fpSpread_Particulars.ActiveSheet.ColumnCount; col++)
                {
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, col].Text = fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, col].Text;
                }

                fpSpread_Particulars.ActiveSheet.Columns[0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Resizable = false;

                Font headerFont = new Font("Verdana", 8, FontStyle.Bold);

                fpSpread_Particulars.ActiveSheet.Columns[COL_INDICATOR].ForeColor = Color.Red;
                fpSpread_Particulars.ActiveSheet.Columns[COL_INDICATOR].Font = new Font("Verdana", 8, FontStyle.Regular);

                fpSpread_Particulars.ActiveSheet.Columns[COL_LAST_DATA_FROM_VSL].ForeColor = Color.Fuchsia;
                fpSpread_Particulars.ActiveSheet.Columns[COL_LAST_DATA_TO_VSL].ForeColor = Color.Blue;

                #region Header
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SUPT_MNTQ].ColumnSpan = 10;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SUPT_MNTQ].Text = "PMS Items";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SUPT_MNTQ].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SUPT_DF_ACK].ColumnSpan = 5;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SUPT_DF_ACK].Text = "Defect Items";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SUPT_DF_ACK].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].ColumnSpan = 19;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].Text = "Forms";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].ColumnSpan = 13;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].Text = "NCR";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_DONE].ColumnSpan = 22;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_DONE].Text = "Audit / Inspection";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_DONE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].ColumnSpan = 12;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].Text = "Task";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].ColumnSpan = 10;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].Text = "Incidnt Report";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].ColumnSpan = 13;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].Text = "Invest \nReport";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].ColumnSpan = 7;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].Text = "Aware. Report";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].ColumnSpan = 7;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].Text = "Master Review";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].ColumnSpan = 7;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].Text = "Safety Meeting";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_CORRECTIVE_HQTOAPPROVE].ColumnSpan = 2;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_CORRECTIVE_HQTOAPPROVE].Text = "Corrective Maint";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_CORRECTIVE_HQTOAPPROVE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_CORRECTIVE_DUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE].ColumnSpan = 18;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE].Text = "Risk Asses";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MONTHENDDOC_OVERDUE].ColumnSpan = 1;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MONTHENDDOC_OVERDUE].Text = "Month End Doc";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MONTHENDDOC_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].ColumnSpan = 7;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].Text = "Certificates";
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                #endregion

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_SUPT_MNTQ, 1, COL_CRITICALSPRQNS].Font = new Font("Microsoft sans serif", 7.5f, FontStyle.Regular);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_SUPT_MNTQ, 1, COL_CRITICALSPRQNS].CellPadding = new FarPoint.Win.Spread.CellPadding(0, 0, 0, 0);

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_1, 0, COL_SEPARATOR_CERTIFICATE].Font = headerFont;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].ForeColor = Color.Blue;
                fpSpread_Particulars.ActiveSheet.Columns[COL_OPERATEBY, COL_SEPARATOR_CERTIFICATE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                Color sepColBkColor = Color.FromArgb(217, 255, 228);
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_1].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_SPARES].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_DF].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_FORMS].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_NCR].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_TASK].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_AUDITINSPECTION].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_CORRECTIVE].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_INCIDENT_REPORT].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_INVESTIGATION_REPORT].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_AWARENESS_REPORT].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_MASTERS_REVIEW].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_MINUTES_OF_SAFETY].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_RISKASSEMENTS].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_MONTHENDDOC].BackColor = sepColBkColor;
                fpSpread_Particulars.ActiveSheet.Columns[COL_SEPARATOR_CERTIFICATE].BackColor = sepColBkColor;

                fpSpread_Particulars.ActiveSheet.Columns[COL_SUPT_DF_ACK, COL_DF_ODUEITEMS].BackColor = Color.MintCream;
                fpSpread_Particulars.ActiveSheet.Columns[COL_MASTERNAME, COL_FLEET_VESSELID].BackColor = Color.WhiteSmoke;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].Height = 40;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[1].Height = 50;

                fpSpread_Particulars.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread_Particulars.ActiveSheet.VerticalGridLine = gdln;
                fpSpread_Particulars.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                fpSpread_Particulars.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread_Particulars.ActiveSheet.DisplayZero = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "DesignParticularsGridDetails", er.Message);
                Gfn.Mb("Failed to initilize Particulars Tab");
            }
            finally
            {
                fpSpread_Particulars.ResumeLayout();
                particularsColList = null;
            }
        }

        private void InitialiseHQDashboardFieldSetup()
        {
            try
            {
                fpSpread_Particulars.ActiveSheet.RowCount = 0;

                PG.isToEnableForms = false; isToEnableDefects = false; isToEnableNCR = false; isToEnableTask = false; isToEnableRiskAssements = false; isToEnableSafetyMeeting = false;
                isToEnableMasterReview = false; isToEnableAwarenessReport = false; isToEnableAuditInspection = false; isToEnableIncidentReport = false; isToEnableInvestigationReport = false;
                isToEnableMonthEndDoc = false; isToEnableCertificate = false; isToEnableAlert_Circulars = false; isQuarterlyStoresReports = false;

                int awarenessColCnt = 0, masterRevwCnt = 0, safetymettingCnt = 0, incidentReportCnt = 0, investigationReportCnt = 0, certificateCnt = 0;

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string addlCond = "  ";
                if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";

                string script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways, GroupName " +
                                " from Dashboard_HQ_Main_Tech_Setup " + Environment.NewLine +
                                " where 1=1 " +
                                addlCond +
                                " order by ColumnNo";
                DataTable dt = PG.Gb.DBFn.DbRecords(script);
                if (dt != null)
                {
                    foreach (DataRow dr1 in dt.Rows)
                    {
                        int columnNo = Convert.ToInt32(dr1["ColumnNo"]);
                        int isToHide = Convert.ToInt32(dr1["IsToHide"].ToString());
                        int isToShowAlways = Convert.ToInt32(dr1["isToShowAlways"].ToString());

                        fpSpread_Particulars.ActiveSheet.Columns[columnNo].Visible = (isToHide == 0 && isToShowAlways == 1);
                    }

                    DataRow[] dr;
                    dr = dt.Select("IsToHide = 0 and GroupName='Forms'");
                    PG.isToEnableForms = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='Defect Items'");
                    isToEnableDefects = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='NCR'");
                    isToEnableNCR = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='Task'");
                    isToEnableTask = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='Aware. Report'");
                    if (dr != null) awarenessColCnt = dr.Length;
                    isToEnableAwarenessReport = (awarenessColCnt > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='Master Review'");
                    if (dr != null) masterRevwCnt = dr.Length;
                    isToEnableMasterReview = (masterRevwCnt > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName in ('Safety Meeting','Safety Meetng')");
                    if (dr != null) safetymettingCnt = dr.Length;
                    isToEnableSafetyMeeting = (safetymettingCnt > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='Risk Assements'");
                    isToEnableRiskAssements = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName in('AI Sched / Report','AI Approval','Audit / Inspection')");
                    isToEnableAuditInspection = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName in ('Incident Report','Incidnt Report')");
                    if (dr != null) incidentReportCnt = dr.Length;
                    isToEnableIncidentReport = (incidentReportCnt > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName in ('Investigation Report','Invest Report')");
                    if (dr != null) investigationReportCnt = dr.Length;
                    isToEnableInvestigationReport = (investigationReportCnt > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName in ('Certificates')");
                    if (dr != null) certificateCnt = dr.Length;
                    isToEnableCertificate = (certificateCnt > 0);
                }

                script = " select count(*) from VUI_GroupItems " +
                         " where Prg='MonthEndDocMgmtCaller' and IsPrgDisabled = 0" +
                         addlCond;
                isToEnableMonthEndDoc = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);

                isQuarterlyStoresReports = (PG.categoriesFeedBackFormRequired.Trim().Length > 0);

                script = " select count(*) from VUI_GroupItems " +
                         " where Prg='Circulars_Vsl' and IsPrgDisabled = 0" +
                         addlCond;
                isToEnableAlert_Circulars = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);

                if (awarenessColCnt == 1) fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].Font = new Font("Verdana", 7, FontStyle.Bold);
                if (masterRevwCnt == 1) fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].Font = new Font("Verdana", 7, FontStyle.Bold);
                if (safetymettingCnt <= 2) fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].Font = new Font("Verdana", 7, FontStyle.Bold);
                if (incidentReportCnt <= 2) fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].Font = new Font("Verdana", 7, FontStyle.Bold);
                if (investigationReportCnt <= 2) fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].Font = new Font("Verdana", 7, FontStyle.Bold);

                if (PG.currentUserDept == "CREW")
                {
                    fpSpread_Particulars.ActiveSheet.Columns[COL_NCR_CREW_PENDING].Visible = isToEnableNCR;
                    fpSpread_Particulars.ActiveSheet.Columns[COL_TASKLIST_CREW_PENDING].Visible = isToEnableTask;
                    fpSpread_Particulars.ActiveSheet.Columns[COL_INCIDENT_REPORT_CREW_PENDING].Visible = isToEnableIncidentReport;
                    fpSpread_Particulars.ActiveSheet.Columns[COL_AWARENESS_REPORT_CREW_PENDING].Visible = isToEnableAwarenessReport;
                    fpSpread_Particulars.ActiveSheet.Columns[COL_MASTERS_REVIEW_CREW_PENDING].Visible = isToEnableMasterReview;
                    fpSpread_Particulars.ActiveSheet.Columns[COL_MINUTES_OF_SAFETY_CREW_PENDING].Visible = isToEnableSafetyMeeting;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "InitialiseHQDashboardFieldSetup", err.Message);
                Gfn.Mb("Failed to initilize Particulars Tab");
            }
        }

        private void EnabledAndDisabledApplication()
        {
            btnProcurement.Visible = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_ProcurementWeb);

            tsMnuSetup_StoresItemMaster.Visible = PG.allowTochangeLubOPaintSetup;
            toolStripSeparator2.Visible = PG.allowTochangeLubOPaintSetup;

            // Enable / Disable Right click Menu              
            tsMnuSplitterB4EquipmentManager.Visible = PG.allowedUserToAccess_FleetEqpmtManager;
            tsMnuEquipmentManager.Visible = (PG.allowedUserToAccess_FleetEqpmtManager && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_EquipmentManager));

            tsMnuAll_HQ_VSLSettings.Visible = PG.allowToAddEditDeleteSettings;
            tsMnuUserSignManagement.Visible = PG.allowToAddEditDeleteSettings;
            tsMnuUserAppRestrictions.Visible = PG.allowToAddEditDeleteSettings;
            toolStripSeparator14.Visible = PG.allowToAddEditDeleteSettings;

            tsMnuForms.Visible = (PG.isToEnableForms);
            tsMnuDefects.Visible = (isToEnableDefects);

            tsMnuFormsVesselSelection.Visible = (PG.isToEnableForms);
            tlsStripFormsVesselSelection.Visible = (PG.isToEnableForms);

            tsMnuFormsVesselSelection.Visible = (PG.isToEnableForms);
            tlsStripFormsVesselSelection.Visible = (PG.isToEnableForms);

            tsMnuNCR.Visible = ((isToEnableNCR && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_NCR)) ||
                                (PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_MARINEDASHBOARD) && isToShowSQEDashboard));
            tsMnuTaskList.Visible = (isToEnableTask);
            tsMnuIncidentReport.Visible = (isToEnableIncidentReport);
            tsMnuAuditInspection.Visible = (isToEnableAuditInspection);
            tsMnuVslAlerts_Circulars.Visible = isToEnableAlert_Circulars;
            toolStripMenuItem13.Visible = isToEnableAlert_Circulars;
            tsMnuVslRiskAssements.Visible = isToEnableRiskAssements;
            tsMnuAwarenessReport.Visible = isToEnableAwarenessReport;
            tsMnuMastersReview.Visible = isToEnableMasterReview;
            tsMnuMinutesOfSafety.Visible = isToEnableSafetyMeeting;

            btnNcr.Visible = (isToEnableNCR && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_NCR));
            btnSQEDashboard.Visible = (PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_MARINEDASHBOARD));
            btnCrewDashboard.Visible = (PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_CREWDASHBOARD));
            btnSQEDashboard.Enabled = isToShowSQEDashboard;
            btnCrewDashboard.Enabled = isToShowCREWDashboard;
            btnDMS.Visible = (PG.isToEnableDocMgmt && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DocMgmt_Cef));

            tsMnuForms.Enabled = (PG.isToEnableForms && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_Forms));
            tsMnuDefects.Enabled = (isToEnableDefects && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_Defects));
            tsMnuRiskAssements.Visible = (isToEnableRiskAssements && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_RISKASSEMENTS));
            tsMnuMonthEndDoc.Visible = (isToEnableMonthEndDoc && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_MONTHENDDOC));
            tsMnuQuarterlyStoresReports.Visible = false;
            if (isQuarterlyStoresReports && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_QUARTERLYSTORESREPORT)) tsMnuQuarterlyStoresReports.Visible = true;
            tsMnuMonthEndDocumentReport.Visible = (isToEnableMonthEndDoc && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_MONTHENDDOC));
            tsMnuVslCertificate.Visible = (isToEnableCertificate && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_CERTIFICATE));

            tsMnuExportEquipmentParticulars.Visible = PG.isToEnableExportEquipmentParticulars && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_ExportEquipmentParticulars);
            tsMnuExportEquipmentUnitParticulars.Visible = PG.isToEnableExportEquipmentUnitParticulars && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_ExportEquipmentUnitParticulars);
            tsMnupmsReports.Visible = PG.isToEnableExportPMSReport && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_ExportPMSItems);
            tsMnuCriticalSparesList.Visible = PG.isToEnableExportCriticalSparesList && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_CriticalSparesList);
            tsMnuExportPMSItems.Visible = false;
            toolStripSeparator9.Visible = (tsMnuExportEquipmentParticulars.Visible || tsMnuExportEquipmentUnitParticulars.Visible || tsMnupmsReports.Visible || tsMnuCriticalSparesList.Visible);

            tsMnuRepairsPurchase.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_RepairsPurchase);

            //File Report Menu
            tsMnuDefectsReports.Visible = (isToEnableDefects && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DefectsReports));

            tsMnuDTFDataTransferToolStripMenuItem.Visible = (PG.isAllowedUserToDoDTF && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DTFDataTransferToolStripMenuItem));
            toolStripSeparator_DTF.Visible = (PG.isAllowedUserToDoDTF && tsMnuDTFDataTransferToolStripMenuItem.Visible);

            tsMnuVslUserManagement.Visible = (PG.isAllowedUserToSetupVslUserMgmt);

            lnkRefresh.Visible = (PG.isAllowedUserRoleToRefreshHQDashboard);
            tsMnuRefreshforSelectedVessel.Visible = (PG.isAllowedUserRoleToRefreshHQDashboard);

            tsMnuSeparator5.Visible = (PG.isAllowedUserToRe_interfacePO2Agresso || PG.isAllowedUserRoleToGetVendorLink);
            tsMnuAgressoReinterface.Visible = PG.isAllowedUserToRe_interfacePO2Agresso;
            tsMnuVendorLinks.Visible = PG.isAllowedUserRoleToGetVendorLink;

            tsMnuKPITrendingForFleet_NonCriticalMaint.Visible = (PG.isToShowKPITrending_NonCriticalMaint_Fleet && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForFleet_NonCriticalMaint));
            tsMnuKPITrendingForFleet_CriticalMaint.Visible = (PG.isToShowKPITrending_CriticalMaint_Fleet && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForFleet_CriticalMaint));
            tsMnuKPITrendingForFleet_NonCriticalEqp.Visible = (PG.isToShowKPITrending_NonCriticalEqp_Fleet && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForFleet_NonCriticalEqp));
            tsMnuKPITrendingForFleet_CriticalEqp.Visible = (PG.isToShowKPITrending_CriticalEqp_Fleet && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForFleet_CriticalEqp));
            tsMnukPITrendingForFleet_All.Visible = (PG.isToShowKPITrending_All_Fleet && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForFleet_All));

            toolStripMenuItem3.Visible = ((PG.isToShowKPITrending_NonCriticalMaint_Fleet || PG.isToShowKPITrending_CriticalMaint_Fleet ||
                                           PG.isToShowKPITrending_NonCriticalEqp_Fleet || PG.isToShowKPITrending_CriticalEqp_Fleet) && (PG.isToShowKPITrending_All_Fleet));

            tsMnuKPITrendingForFleet.Visible = ((PG.isToShowKPITrending_NonCriticalMaint_Fleet || PG.isToShowKPITrending_CriticalMaint_Fleet ||
                                                PG.isToShowKPITrending_NonCriticalEqp_Fleet || PG.isToShowKPITrending_CriticalEqp_Fleet || PG.isToShowKPITrending_All_Fleet)
                                               );
            toolStripMenuItem4.Visible = (PG.isToShowKPITrending_NonCriticalMaint_Fleet || PG.isToShowKPITrending_CriticalMaint_Fleet ||
                                          PG.isToShowKPITrending_NonCriticalEqp_Fleet || PG.isToShowKPITrending_CriticalEqp_Fleet || PG.isToShowKPITrending_All_Fleet);

            tsMnuKPITrendingForVsl_NonCriticalMaint.Visible = (PG.isToShowKPITrending_NonCriticalMaint_Vsl);
            tsMnuKPITrendingForVsl_CriticalMaint.Visible = (PG.isToShowKPITrending_CriticalMaint_Vsl);
            tsMnuKPITrendingForVsl_NonCriticalEqp.Visible = (PG.isToShowKPITrending_NonCriticalEqp_Vsl);
            tsMnuKPITrendingForVsl_CriticalEqp.Visible = (PG.isToShowKPITrending_CriticalEqp_Vsl);
            tsMnukPITrendingForVsl_All.Visible = (PG.isToShowKPITrending_All_VSL);

            tsMnuNCRTrending.Visible = (PG.isToShowNCRTrending);

            tsMnuKPITrending_Vsl.Visible = (PG.isToShowKPITrending_NonCriticalMaint_Vsl || PG.isToShowKPITrending_CriticalMaint_Vsl ||
                                            PG.isToShowKPITrending_NonCriticalEqp_Vsl || PG.isToShowKPITrending_CriticalEqp_Vsl || PG.isToShowKPITrending_All_VSL
                                             && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrending_Vsl));
            toolStripSeparator18.Visible = ((PG.isToShowKPITrending_NonCriticalMaint_Vsl || PG.isToShowKPITrending_CriticalMaint_Vsl ||
                                            PG.isToShowKPITrending_NonCriticalEqp_Fleet || PG.isToShowKPITrending_CriticalEqp_Vsl) && (PG.isToShowKPITrending_All_VSL)
                                              && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrending_Vsl));

            tsMnuProcurement.Visible = (PG.isToShowKPITrending_ProcurementKPIData && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_Procurement));
            tsMnuSparesPOsNotSubmitForRFQMoreThan3Days.Visible = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_SparesPOsNotSubmitForRFQMoreThan3Days);
            tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays.Visible = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_SparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays);

            tsMnuDefectTrending_AllVsls.Visible = (isToEnableDefects && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DefectTrending_AllVsls));
            tsMnuDefectTrendingEquipmentWise_SingleVsl.Visible = (isToEnableDefects && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DefectTrendingEquipmentWise_SingleVsl));
            tsMnuDefectsVestsMnuDelAvailabilityKPI.Visible = (PG.isToShowKPITrending_DefectsVesselAvailability && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DefectsVestsMnuDelAvailabilityKPI));

            toolStripMenuItem5.Visible = (tsMnuDefectTrending_AllVsls.Visible && PG.isToEnableDTFReports);
            tsMnuDTF.Visible = PG.isToEnableDTFReports;
            tsMnuDTFCurrentStatus.Enabled = (PG.isToEnableDTFReports && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DTFCurrentStatus));
            tsMnuDTFHistory.Enabled = (PG.isToEnableDTFReports && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DTFHistory));
            tsMnuDTFTrending.Enabled = (PG.isToEnableDTFReports && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DTFTrending));

            toolStripMenuItem8.Visible = PG.isAllowedUserToClearCefCache;
            tsMnuClearCefCache.Visible = PG.isAllowedUserToClearCefCache;

            tlsMnuRootCauseAnalysisChartSetup.Visible = (PG.isAllowedUserIDToSetupMSCAT);
            tlsMnuAuditInspectionSetup.Visible = (PG.isAllowedUserIDToSetupAI);

            tsMnuFormsDesigner.Visible = PG.isAllowedToFormsDesigner;
            tsMnuHQCirculars.Visible = PG.isAllowedToHQCircularsMgmt;
            tsMnuSettingManagement.Visible = PG.isAllowedToSetupSettingsManagement;
            tsMnuManualSync_BigBlobs.Visible = PG.isAllowedUserToDoBlobManualSync;
            tsMnuVslCrewAddNewController.Visible = PG.isAllowedAddEditVslCrewAddNewController;
            tsMnuApplicationChangeDetails.Visible = PG.isAllowedAddEditApplicationChangeDetails;

            tsMnuUpdateDMSCompany.Visible = (PG.Gb.User.CurUserID.ToUpper() == "SDSADMIN");
            tsMnuVesselOperationModeSetup.Visible = (PG.Gb.User.CurUserID.ToUpper() == "SDSADMIN");            
            tsMnuSetupProcurementInterface.Visible = (PG.Gb.User.CurUserID.ToUpper() == "SDSADMIN");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            try
            {
                cboCompany_Filter_SelectedIndexChanged(null, null);
                chkShowOnlyActionColumns.Checked = true;

                if (PG.CheckAppUnderMaintenance(this.Text))
                {
                    DialogResult = DialogResult.OK;
                    this.Close();
                }

                string fileName = PG.Gb.WinSDSrootDir + "Images\\" + PG.hqAppFolder + "HQ_SDS.ico";
                if (File.Exists(fileName))
                {
                    Icon ic = new Icon(fileName);
                    this.Icon = ic;
                }
                PG.DownloadStarter();
            }
            finally
            {
                pictureBox1.Visible = false;
            }
        }

        protected void FocusCompany()
        {
            try
            {
                if (companyID.Trim().Length > 0 && companyID != "-1" && companyID != "-99")
                {
                    cboCompany_Filter.SelectedValue = companyID;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "FocusCompany", err.Message);
            }
        }

        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            try
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
                Application.DoEvents();

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (!PG.InitialiseCommonSettings(companyID)) return;

                PG.Initialise_AllowedUserForAccessRights(companyID);
                isFormInitialised = false;
                chkShowOnlyActionColumns.Checked = true;

                InitialiseHQDashboardFieldSetup();

                PG.IsUserExistsinApp_SplFunctionalityCtrl();

                EnabledAndDisabledApplication();

                if (common != null) common.BindVslDropDownList(cboVslFilter, companyID, true);

                if (vslFilter.Trim().Length > 0 && cboVslFilter.FindString(vslFilter) >= 0) cboVslFilter.SelectedIndex = cboVslFilter.FindString(vslFilter);
                isFormInitialised = true;

                cboVslFilter_SelectedIndexChanged(null, null);
                this.Text = cboCompany_Filter.Text.ToUpper() + " HQ ";
                chkShowOnlyActionColumns_CheckedChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "cboCompany_Filter_SelectedIndexChanged", err.Message);
            }
            finally
            {
                pictureBox1.Visible = false;
                isFormInitialised = true;
            }
        }


        private void cboVslFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;
            try
            {
                fpSpread_Particulars.SuspendLayout();

                //Clear Grid
                tlsStatuslblTotalVessels.Text = "Total Vessel(s): 0";
                fpSpread_Particulars.ActiveSheet.RowCount = 0;
                if (cboVslFilter.SelectedValue == null) return;

                if (common == null) return;

                string vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                fpSpread_Particulars.ActiveSheet.DataSource = common.GetDashBoardDataTable_Tech(vslFilter, companyID);

                fpSpread_Particulars.ActiveSheet.Columns[COL_COMPANYCODE].Visible = (cboCompany_Filter.SelectedValue != null && cboCompany_Filter.SelectedValue.ToString() == "-99");

                if (fpSpread_Particulars.ActiveSheet.RowCount > 0 && fpSpread_Particulars.ActiveSheet.ColumnCount > 0)
                {
                    int rowCount = fpSpread_Particulars.ActiveSheet.RowCount - 1;
                    fpSpread_Particulars.ActiveSheet.Cells[0, 0, rowCount, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.DarkSeaGreen, 1, false, false, true, true);
                    fpSpread_Particulars.ActiveSheet.Cells[0, COL_VSLCODE, rowCount, COL_VSLCODE].Border = new FarPoint.Win.LineBorder(Color.DarkSeaGreen, 1, false, false, false, true);

                    fpSpread_Particulars.ActiveSheet.Cells[0, COL_COMPANYCODE, rowCount, COL_OPERATEBY].BackColor = Color.FromArgb(244, 248, 220);

                    tlsStatuslblTotalVessels.Text = "Total Vessel(s):" + fpSpread_Particulars.ActiveSheet.RowCount;

                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_SUPT_MNTQ, 1, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Tag = null;

                    DataTable dt = GetTechDashboardSetupDataTable();

                    DateTime todayDate = PG.GetDbServerDate();

                    for (int row = 0; row < fpSpread_Particulars.ActiveSheet.RowCount; row++)
                    {
                        string isUserVsl = fpSpread_Particulars.ActiveSheet.Cells[row, COL_ISUSERVESSEL].Text.Trim();
                        fpSpread_Particulars.ActiveSheet.Cells[row, COL_INDICATOR].Text = "";
                        if (isUserVsl == "1") fpSpread_Particulars.ActiveSheet.Cells[row, COL_INDICATOR].Text = "*";

                        if (fpSpread_Particulars.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value != null && fpSpread_Particulars.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value.ToString() == "1")
                        {
                            fpSpread_Particulars.ActiveSheet.Cells[row, COL_COMPANYCODE, row, COL_LAST_DATA_FROM_VSL].BackColor = Color.FromArgb(192, 241, 184);
                        }

                        for (int col = COL_SEPARATOR_1; col < COL_MASTERNAME; col++)
                        {
                            #region cell style
                            if (col == COL_SEPARATOR_1 || col == COL_SEPARATOR_SPARES || col == COL_SEPARATOR_DF || col == COL_SEPARATOR_FORMS || col == COL_SEPARATOR_NCR ||
                                col == COL_SEPARATOR_AWARENESS_REPORT || col == COL_SEPARATOR_MASTERS_REVIEW || col == COL_SEPARATOR_MINUTES_OF_SAFETY ||
                                col == COL_SEPARATOR_INCIDENT_REPORT || col == COL_SEPARATOR_INVESTIGATION_REPORT || col == COL_SEPARATOR_AUDITINSPECTION ||
                                col == COL_SEPARATOR_TASK || col == COL_SEPARATOR_MONTHENDDOC || col == COL_SEPARATOR_CERTIFICATE)
                            {
                                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, col].Tag = "-1";
                                continue;
                            }

                            bool isToHide = true;
                            DataRow[] dr = dt.Select("ColumnNo=" + col);
                            if (dr != null && dr.Length > 0)
                            {
                                isToHide = (dr[0]["IsToHide"].ToString() == "1");
                            }

                            AssignCellStyle(row, col, todayDate, isToHide);
                            bool isToExcludeFromShowUserActionColumnList = Gfn.IsStringExistsCommaSeparatedString(PG.isToExcludeFromShowUserActionColumnList, col.ToString());

                            if (!isToExcludeFromShowUserActionColumnList && col == COL_OSTDNGNONCRITICALMAINTITEMS
                                && fpSpread_Particulars.ActiveSheet.Cells[row, col].Value != null && fpSpread_Particulars.ActiveSheet.Cells[row, col].Value.ToString() !="0")
                            {
                                fpSpread_Particulars.ActiveSheet.Cells[row, col].ForeColor = Color.Red;
                            }

                            if (col == COL_OSTDNGCRITICALEQPMAINTITEMS && fpSpread_Particulars.ActiveSheet.Cells[row, col].Value != null && fpSpread_Particulars.ActiveSheet.Cells[row, col].Value.ToString() != "0")
                            {
                                fpSpread_Particulars.ActiveSheet.Cells[row, col].ForeColor = Color.Red;
                            }
                            #endregion
                        }
                    }

                    if (chkShowOnlyActionColumns.Checked) chkShowOnlyActionColumns_CheckedChanged(null, null);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "cboVslFilter_SelectedIndexChanged", err.Message);
                Gfn.Eb("Failed to refresh Particulars");
            }
            finally
            {
                fpSpread_Particulars.ResumeLayout();
            }
        }

        private void AssignCellStyle(int row, int col, DateTime todayDate, bool isToHide)
        {
            string cellValue = ""; bool isToExcludeFromShowUserActionColumnList = false;
            if (fpSpread_Particulars.ActiveSheet.Cells[row, col].Value != null) cellValue = fpSpread_Particulars.ActiveSheet.Cells[row, col].Text.ToString().Trim();

            fpSpread_Particulars.ActiveSheet.Cells[row, col].ForeColor = Color.Black;

            isToExcludeFromShowUserActionColumnList = Gfn.IsStringExistsCommaSeparatedString(PG.isToExcludeFromShowUserActionColumnList, col.ToString());

            if (cellValue == "0" || cellValue == "")
            {
                if (col != COL_AUDITINSPECTION_DUE && col != COL_AUDITINSPECTION_DONE && col < COL_MASTERNAME)
                {
                    fpSpread_Particulars.ActiveSheet.Cells[row, col].ForeColor = Color.DarkGray;
                }
            }
            else if (col >= COL_SUPT_MNTQ && col <= COL_SEPARATOR_CERTIFICATE && cellValue.Trim().Length > 0 &&
                     fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, col].Tag == null)
            {
                if (!isToExcludeFromShowUserActionColumnList)
                {
                    if (!isToHide)
                    {
                        fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, col].Tag = fpSpread_Particulars.ActiveSheet.Cells[row, col].Text;
                    }
                    else
                    {
                        excludeColList = excludeColList.Replace("," + col.ToString() + ",", ",-1,");
                    }
                }
                
            }

            if (col == COL_AUDITINSPECTION_DUE)
            {
                string dueValue = "";
                if (fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].Value != null) dueValue = fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].Value.ToString();

                if (fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DAYSDUE].Value != null &&
                    Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DAYSDUE].Value) < 0)
                {
                    fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].Font = new Font("Arial", 9, FontStyle.Regular);
                    fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].ForeColor = Color.Red;// Color.FromArgb(227, 6, 45);
                    fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].ForeColor = Color.Red;
                }
                else if (dueValue != "0" && dueValue.Length > 0)
                {
                    if (dueValue.ToUpper().Trim() == todayDate.ToString("MMM yy"))
                    {
                        fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].Font = new Font("Arial", 9, FontStyle.Regular);
                        fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].BackColor = Color.FromArgb(255, 207, 170);  //Color.Orange;
                        fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].ForeColor = Color.Black;
                    }
                    else if (fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DAYSINWINDOWPERIOD].Value != null &&
                             Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DAYSINWINDOWPERIOD].Value) > 0)
                    {
                        fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].Font = new Font("Arial", 9, FontStyle.Regular);
                        fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].BackColor = Color.FromArgb(255, 255, 148); // Color.Yellow;
                    }
                }

                if (fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_ISRESCHEDULED].Value != null && Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_ISRESCHEDULED].Value) > 0 &&
                    dueValue.Trim().Length > 0)
                {
                    fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].Font = new Font("Arial", 9, FontStyle.Regular);
                    fpSpread_Particulars.ActiveSheet.Cells[row, COL_AUDITINSPECTION_DUE].BackColor = Color.LightBlue;
                }
            }
        }

        private void chkShowOnlyActionColumns_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = GetTechDashboardSetupDataTable();

                if (chkShowOnlyActionColumns.Checked)
                {
                   string xExcludeColList = "," + excludeColList + ",";
                    for (int colHeaderIndex = COL_SUPT_MNTQ; colHeaderIndex < fpSpread_Particulars.ActiveSheet.ColumnCount; colHeaderIndex++)
                    {
                        string sx1 = "," + colHeaderIndex + ",";
                        if (fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, colHeaderIndex].Tag == null
                             && (xExcludeColList.IndexOf(sx1) < 0))
                        {
                            fpSpread_Particulars.ActiveSheet.Columns[colHeaderIndex].Visible = false;
                        }
                        else
                        {
                            DataRow[] dr = dt.Select("ColumnNo=" + colHeaderIndex);
                            if (dr != null && dr.Length > 0)
                            {
                                if (dr[0]["IsToHide"].ToString() == "0")
                                {
                                    fpSpread_Particulars.ActiveSheet.Columns[colHeaderIndex].Visible = true;
                                }
                            }
                        }
                    }

                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Columns[COL_SEPARATOR_AWARENESS_REPORT].Visible = (fpSpread_Particulars.ActiveSheet.ColumnHeader.Columns[COL_AWARENESS_REPORT_TECH_PENDING].Visible);
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Columns[COL_SEPARATOR_MASTERS_REVIEW].Visible = (fpSpread_Particulars.ActiveSheet.ColumnHeader.Columns[COL_MASTERS_REVIEW_TECH_PENDING].Visible);
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Columns[COL_SEPARATOR_MINUTES_OF_SAFETY].Visible = (fpSpread_Particulars.ActiveSheet.ColumnHeader.Columns[COL_MINUTES_OF_SAFETY_TECH_PENDING].Visible);
                }
                else
                {
                    for (int colHeaderIndex = COL_SUPT_MNTQ; colHeaderIndex < fpSpread_Particulars.ActiveSheet.ColumnCount; colHeaderIndex++)
                    {
                        DataRow[] dr = dt.Select("ColumnNo=" + colHeaderIndex);
                        if (dr != null && dr.Length > 0)
                        {
                            fpSpread_Particulars.ActiveSheet.Columns[colHeaderIndex].Visible = (dr[0]["IsToHide"].ToString() == "0");
                        }
                    }
                }

                ShowMyApproveColumns();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "chkShowOnlyActionColumns_CheckedChanged", err.Message);
                Gfn.Eb("Failed to refresh Particulars");
            }
        }

        private void chkShowMyApproveColumn_CheckedChanged(object sender, EventArgs e)
        {
            //if (chkShowMyApproveColumn.Checked)
            //{
            //    ShowMyApproveColumns();
            //}
            //else
            //{
            //    chkShowOnlyActionColumns_CheckedChanged(null, null);
            //}
            chkShowOnlyActionColumns_CheckedChanged(null, null);
        }

        private void ShowMyApproveColumns()
        {
            if (chkShowMyApproveColumn.Checked)
            {
                string colList = "";
                string[] colToHide = PG.showOnlySuptApproveColumns_Tech.Trim().Split(',');
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SUPT" && PG.showOnlySuptApproveColumns_Tech.Trim().Length > 0) colList = colList + "," + PG.showOnlySuptApproveColumns_Tech.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "MANAGER" && PG.showOnlyMgrApproveColumns_Tech.Trim().Length > 0) colList = colList + "," + PG.showOnlyMgrApproveColumns_Tech.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "GENERALMANAGER" && PG.showOnlyGenMgrApproveColumns_Tech.Trim().Length > 0) colList = colList + "," + PG.showOnlyGenMgrApproveColumns_Tech.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SENIORMANAGER" && PG.showOnlySenMgrApproveColumns_Tech.Trim().Length > 0) colList = colList + "," + PG.showOnlySenMgrApproveColumns_Tech.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "DIRECTOR" && PG.showOnlyDirApproveColumns_Tech.Trim().Length > 0) colList = colList + "," + PG.showOnlyDirApproveColumns_Tech.Trim();
                if (colList.Trim().Length > 0)
                {
                    fpSpread_Particulars.ActiveSheet.Columns[COL_LAST_DATA_TO_VSL, COL_ISOFFICEVSL].Visible = false;
                    colToHide = colList.Trim().Split(',');
                    DataTable dt = GetTechDashboardSetupDataTable();
                    string xExcludeColList = "," + excludeColList + ",";
                    foreach (string str in colToHide)
                    {
                        if (str.Trim().Length > 0)
                        {
                            int col = Convert.ToInt32(str);
                            DataRow[] dr = dt.Select("columnno = " + col + " and istohide =0");
                            if (dr.Length > 0)
                            {
                                if (chkShowOnlyActionColumns.Checked && fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, col].Tag == null
                                && (xExcludeColList.IndexOf(col.ToString()) < 0))
                                {
                                    fpSpread_Particulars.ActiveSheet.Columns[col].Visible = false;
                                }
                                else
                                {
                                    fpSpread_Particulars.ActiveSheet.Columns[col].Visible = true;
                                }
                            }

                        }
                    }
                }
            }
        }

        private DataTable GetTechDashboardSetupDataTable()
        {
            string companyID = "-99";
            if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

            string addlCond = "  ";
            if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";

            string script = " select Distinct ColumnNo, ColumnName, IsToHide, isToShowAlways, GroupName " +
                            " from Dashboard_HQ_Main_Tech_Setup " + Environment.NewLine +
                            " where ColumnNo>=0 " +
                             addlCond +
                            " order by ColumnNo";
            DataTable dt = PG.Gb.DBFn.DbRecords(script);

            return (dt);
        }


        private void lnkRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
                Application.DoEvents();

                calledFrom = "";
                RefreshHQDashboard(-1, -1, -1, false, true);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "RefreshPMSStatus", err.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
                pictureBox1.Visible = false;
            }
        }

        private void RefreshHQDashboard(int selectedVesselID, int rowNo, int colNo, bool isToRefreshOnlySpecifiedCol, bool isToRefreshEntireGrid)
        {
            string script = "";
            DataTable dt = null;
            try
            {
                this.Cursor = Cursors.WaitCursor;
                panelLoading.Visible = true;
                panelLoading.BringToFront();
                Application.DoEvents();

                //Refresh - SP
                if (isToRefreshEntireGrid)
                {
                    #region All vessels refresh
                    string companyID = "-99";
                    if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                    string addlCond = "";
                    if (PG.laidupVessels.Trim().Length > 0)
                    {
                        addlCond = addlCond + "   and V.VslCode not in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                    }
                    if (companyID != "-99") addlCond = addlCond + " and V.C_CompanyID='" + companyID + "'";

                    script = " Select V.VesselID from Dashboard_HQ_Main_Tech_Status S, V_Vessels V " +
                             " Where S.VesselID=V.VesselID " +
                             "   and V.VesselID<>-1" +
                             addlCond;
                    dt = PG.Gb.DBFn.DbRecords(script);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        progressBarRefresh.Visible = true;
                        if (progressBarRefresh.Value > 0) progressBarRefresh.Value = 1;
                        progressBarRefresh.Step = 1;
                        progressBarRefresh.Minimum = 0;
                        progressBarRefresh.Maximum = dt.Rows.Count;
                        Application.DoEvents();

                        foreach (DataRow dr in dt.Rows)
                        {
                            int vesselID = Convert.ToInt32(dr["VesselID"].ToString());

                            RefreshHQDashboardForThisVessel(vesselID);

                            Application.DoEvents();
                            progressBarRefresh.PerformStep();
                        }
                    }
                    #endregion
                }
                else
                {
                    int laidupVessel_Cnt = 0;
                    if (PG.laidupVessels.Trim().Length > 0)
                    {
                        script = " Select count(*) from V_Vessels V " +
                                 " Where VesselID = " + selectedVesselID + " and VslCode in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                        laidupVessel_Cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                    }

                    if (laidupVessel_Cnt == 0)
                    {
                        RefreshHQDashboardForThisVessel(selectedVesselID);
                    }
                }

                //Fill up Grid
                if (isToRefreshEntireGrid)
                {
                    // Load the full grid 
                    cboVslFilter_SelectedIndexChanged(null, null);

                    // Reset and show only action columns ( Hide / unhide columns)
                    chkShowOnlyActionColumns.Checked = true;
                    chkShowOnlyActionColumns_CheckedChanged(null, null);
                }
                else
                {
                    string companyID = "-1";
                    if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                    DataTable dtDashboard = common.GetDashBoardDataTable_Tech_SingleVsl(selectedVesselID);

                    script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways, GroupName " +
                             " from Dashboard_HQ_Main_Tech_Setup  " +
                             " where C_CompanyID = " + companyID + " and ColumnNo>=0 " +
                             "    and GroupName = (select GroupName from  Dashboard_HQ_Main_Tech_Setup where C_CompanyID = " + companyID + " and ColumnNo = " + colNo + ") " +
                             "    and IsToHide=0 and (ColumnName not like 'Separator%' and ColumnNameDisplay not like 'Separator%') " +
                             " order by ColumnNo";
                    if (isToRefreshOnlySpecifiedCol)
                    {
                        script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways, GroupName " +
                                 " from Dashboard_HQ_Main_Tech_Setup  " +
                                 " where C_CompanyID = " + companyID + " and ColumnNo = " + colNo;
                    }
                    DataTable dtSetup = PG.Gb.DBFn.DbRecords(script);

                    if (dtDashboard != null && dtSetup != null)
                    {
                        DateTime todayDate = DateTime.Now;
                        if (colNo >= COL_AUDITINSPECTION_DONE && colNo <= COL_AUDITINSPECTION_RECENTLY_CLOSED) todayDate = PG.GetDbServerDate();

                        foreach (DataRow dr in dtSetup.Rows)
                        {
                            int columnNo = Convert.ToInt32(dr["ColumnNo"].ToString());
                            string columnName = dr["ColumnName"].ToString();
                            bool isToHide = (dr["IsToHide"].ToString() == "1");

                            string cellValue = dtDashboard.Rows[0][columnName].ToString();
                            if (fpSpread_Particulars.ActiveSheet.Cells[rowNo, columnNo].Value != null) fpSpread_Particulars.ActiveSheet.Cells[rowNo, columnNo].Value = cellValue.ToString();
                            else fpSpread_Particulars.ActiveSheet.Cells[rowNo, columnNo].Text = cellValue;

                            if (cellValue.Trim().Length > 0 && cellValue != "0" && fpSpread_Particulars.ActiveSheet.Columns[columnNo].Visible == false)
                            {
                                if (!isToHide) fpSpread_Particulars.ActiveSheet.Columns[columnNo].Visible = true;
                            }

                            AssignCellStyle(rowNo, columnNo, todayDate, isToHide);
                        }
                    }
                }

                //if (selectedVesselID > 0) FocusSelectedVessel(selectedVesselID);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "RefreshHQDashboard", err.Message);
            }
            finally
            {
                panelLoading.Visible = false;
                progressBarRefresh.Visible = false;
                this.Cursor = Cursors.Default;
            }
        }

        private void RefreshHQDashboardForThisVessel(int vesselID)
        {
            try
            {
                switch (calledFrom.ToString().Trim())
                {
                    case "SUPT_MNTQ":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_SUPT_MNTQ, vesselID);
                        break;
                    case "SUPT_TOAPPROVEMNT":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_SUPT_TOAPPROVEMNT, vesselID);
                        break;
                    case "CRITICALSPARES":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_CRITICALSPARES, vesselID);
                        break;
                    case "DEFECTS":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_DEFECTS, vesselID);
                        break;
                    case "SUPT_FORMS_APPR":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_SUPT_FORMS_APPR, vesselID);
                        break;
                    case "NCR":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_NCR, vesselID);
                        break;
                    case "AWARENESS_REPORT":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_AWARENESS_REPORT, vesselID);
                        break;
                    case "MASTERS_REVIEW":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_MASTERS_REVIEW, vesselID);
                        break;
                    case "MINUTES_OF_SAFETY":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_MINUTES_OF_SAFETY, vesselID);
                        break;
                    case "CORRECTIVEMAINTENANCE":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_CORRECTIVEMAINTENANCE, vesselID);
                        break;
                    case "RISKASSEMENTS":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_RISKASSEMENTS, vesselID);
                        break;
                    case "AUDITINSPECTION":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_AUDITINSPECTION, vesselID);
                        break;
                    case "TASK":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_TASK, vesselID);
                        break;
                    case "MONTHENDDOC":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_MONTHENDDOC, vesselID);
                        break;
                    case "CERTIFICATES":
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_CERTIFICATE, vesselID);
                        break;
                    default:
                        PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_ALL, vesselID);
                        break;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "RefreshHQDashboardForThisVessel", err.Message);
            }
        }


        private void fpSpread_Particulars_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                tsmnSparesPurchase.Enabled = false;
                tsmnuStoresPurchase.Enabled = false;

                tsMnuVslAppplication.Enabled = false;
                fpSpread_Particulars.ContextMenuStrip = null;
                if (fpSpread_Particulars.ActiveSheet.RowCount > 0)
                {
                    fpSpread_Particulars.ActiveSheet.Rows[0, fpSpread_Particulars.ActiveSheet.RowCount - 1].ResetBackColor();
                }


                if (e.Button == MouseButtons.Right)
                {
                    if (fpSpread_Particulars.HitTest(e.X, e.Y).ViewportInfo == null) return;

                    int row = fpSpread_Particulars.HitTest(e.X, e.Y).ViewportInfo.Row;
                    int col = fpSpread_Particulars.HitTest(e.X, e.Y).ViewportInfo.Column;
                    if (row < 0 || col < 0) return;

                    fpSpread_Particulars.ActiveSheet.SetActiveCell(row, col);
                    fpSpread_Particulars.ActiveSheet.Rows[row].BackColor = fpSpread_Particulars.ActiveSheet.SelectionBackColor;

                    int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[row, COL_FLEET_VESSELID].Value);
                    string operateby = fpSpread_Particulars.ActiveSheet.Cells[row, COL_OPERATEBY].Value.ToString().ToUpper();
                    tsMnuVslAppplication.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_VslAppplication);

                    tsMnuVslAppplication.Enabled = (fpSpread_Particulars.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value.ToString() == "0");

                    tsmnSparesPurchase.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_SparesPurchase);
                    tsmnuStoresPurchase.Enabled = tsmnSparesPurchase.Enabled;

                    tsmnSparesInventory.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_SparesInventory);
                    tsmnStoresInventory.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_StoresInventory);

                    tsm_VslDefects.Visible = (isToEnableDefects && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_VslAppplication));
                    toolStripSeparator7.Visible = (isToEnableDefects && tsm_VslDefects.Visible);

                    tsMnuKPITrendingForVsl_NonCriticalMaint.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForVsl_NonCriticalMaint);
                    tsMnuKPITrendingForVsl_CriticalMaint.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForVsl_CriticalMaint);
                    tsMnuKPITrendingForVsl_NonCriticalEqp.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForVsl_NonCriticalEqp);
                    tsMnuKPITrendingForVsl_CriticalEqp.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForVsl_CriticalEqp);
                    tsMnukPITrendingForVsl_All.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_KPITrendingForVsl_All);

                    tsMnuDefectTrendingEquipmentWise_SingleVsl.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DefectTrendingEquipmentWise_SingleVsl);
                    tsMnuRefreshforSelectedVessel.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_RefreshforSelectedVessel);
                    tsMnuHQPMS.Visible = (Gfn.IsStringExistsCommaSeparatedString(PG.allowedVsl_HQPMS, vesselID.ToString()) && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_HQPMS));

                    //Vessel Applications in View Mode
                    string script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='CorrMaint' and IsPrgDisabled = 0";
                    bool isToEnableCorrectiveMaint = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                    tsm_CorrectiveMaintenance.Visible = (isToEnableCorrectiveMaint && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_CorrectiveMaintenance));
                    toolStripSeparator16.Visible = (isToEnableCorrectiveMaint && tsm_CorrectiveMaintenance.Visible);

                    tsmu_VslDashBoard.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_VslDashBoard);
                    tsm_VslSpares.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_SparesPurchase);
                    tsm_VslStores.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_StoresPurchase);
                    tsm_VslPMS.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_VslPMS);
                    tsm_VslDefects.Enabled = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_Defects);

                    script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='VslFormsCaller' and IsPrgDisabled = 0";
                    tsm_VslForms.Visible = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0 && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_Forms));
                    tsMnuVslFormsSeparater.Visible = (tsm_VslForms.Visible && tsm_VslForms.Visible);

                    script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='DocMgmt' and IsPrgDisabled = 0";
                    bool isToEnableDocMgmt = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                    tsMnuDocumentManagement.Visible = (isToEnableDocMgmt && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DocMgmt));
                    toolStripMenuItem6.Visible = (isToEnableDocMgmt && tsMnuDocumentManagement.Visible);

                    script = " Select count(*) from V_Settings where SettingName='IsToEnableFleet_Crew' and SettingValue='Yes' and VesselID = " + vesselID;
                    int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                    bool isAllowedUserToSetupVslUserMgmt = (PG.isAllowedUserToSetupVslUserMgmt && cnt > 0);
                    tsMnuVslUserManagement.Visible = (isAllowedUserToSetupVslUserMgmt);

                    script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='Circulars_Vsl' and IsPrgDisabled = 0";
                    bool isToEnableAlerts_Circulars = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                    tsMnuVslAlerts_Circulars.Visible = isToEnableAlerts_Circulars;

                    if (cntxtMnuStrip_Fleet != null) fpSpread_Particulars.ContextMenuStrip = cntxtMnuStrip_Fleet;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "RightClickSettings", err.Message);
            }
        }

        private void fpSpread_Particulars_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0) return;

            if (e.ColumnHeader)
            {
                if (e.Row != 0) return;

                string groupName = fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[e.Row, e.Column].Text;
                ExpandCollapseColumn(groupName);
                if (isExpanded)
                {
                    chkShowOnlyActionColumns_CheckedChanged(null, null);
                    isExpanded = false;
                }
                else isExpanded = true;

                return;
            }

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;
            this.Cursor = Cursors.WaitCursor;

            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                this.Cursor = Cursors.Default;
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            int cnt = 0;
            if (e.Column == COL_SUPT_MNTQ)
            {
                if (!PG.CheckIsUserAccountExpired())
                {
                    this.Close();
                    return;
                }

                #region Supt Maintenance Reports for review.
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_SUPT_MNTQ].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_SUPT_MNTQ].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Supt Maintenance Reports for review.");
                    return;
                }

                bool result = pms.CallSuptQPage(vesselID, "");

                if (result)
                {
                    calledFrom = "SUPT_MNTQ";
                    RefreshHQDashboard(vesselID, rowIndex, COL_SUPT_MNTQ, true, false);
                }
                #endregion
            }
            else if (e.Column == COL_SUPT_TOAPPROVEMNT)
            {
                if (!PG.CheckIsUserAccountExpired())
                {
                    this.Close();
                    return;
                }

                #region Supt Postponment Maintenance Reports for review.
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_SUPT_TOAPPROVEMNT].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_SUPT_TOAPPROVEMNT].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Postponement Maintenance Reports for Supt to approve.");
                    return;
                }

                bool result = pms.CallSuptToApproveMaintPage(vesselID);

                if (result)
                {
                    calledFrom = "SUPT_TOAPPROVEMNT";
                    RefreshHQDashboard(vesselID, rowIndex, COL_SUPT_TOAPPROVEMNT, true, false);
                }
                #endregion
            }
            else if (e.Column == COL_ODUESVY)
            {
                #region Survey Overdue
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_ODUESVY].Value != null)
                {
                    double cnt1 = Convert.ToDouble(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_ODUESVY].Value.ToString());
                    if (cnt1 == 0)
                    {
                        this.Cursor = Cursors.Default;
                        Gfn.Mb("There is no Survey Overdue items.");
                        return;
                    }
                }

                pms.CallPmsandSvyPage(vesselID, "ODUESVY");
                #endregion
            }
            else if (e.Column == COL_OSTDNGNONCRITICALMAINTITEMS)
            {
                #region Maintenance Overdue
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTDNGNONCRITICALMAINTITEMS].Value != null)
                {
                    double cnt1 = Convert.ToDouble(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTDNGNONCRITICALMAINTITEMS].Value.ToString());
                    if (cnt1 == 0)
                    {
                        this.Cursor = Cursors.Default;
                        Gfn.Mb("There is no Maintenance Overdue items.");
                        return;
                    }
                }

                pms.CallPmsandSvyPage(vesselID, "OStdngMaintItemsNonCritical");
                #endregion
            }
            else if (e.Column == COL_OSTDNGCRITICALEQPMAINTITEMS)
            {
                #region Overdue for Critical Equipment Maintenance
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTDNGCRITICALEQPMAINTITEMS].Value != null)
                {
                    double cnt1 = Convert.ToDouble(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTDNGCRITICALEQPMAINTITEMS].Value.ToString());
                    if (cnt1 == 0)
                    {
                        this.Cursor = Cursors.Default;
                        Gfn.Mb("There is no Maintenance Overdue for Critical Equipment Maintenance.");
                        return;
                    }
                }

                pms.CallPmsandSvyPage(vesselID, "OstdngCriticalEqpMaintItems");
                #endregion
            }
            else if (e.Column == COL_OSTDNGMAINTITEMSCRITICAL)
            {
                #region Overdue for Critical Maintenance
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTDNGMAINTITEMSCRITICAL].Value != null)
                {
                    double cnt1 = Convert.ToDouble(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTDNGMAINTITEMSCRITICAL].Value.ToString());
                    if (cnt1 == 0)
                    {
                        this.Cursor = Cursors.Default;
                        Gfn.Mb("There is no Maintenance Overdue for Critical Maintenance.");
                        return;
                    }
                }

                pms.CallPmsandSvyPage(vesselID, "OStdngMaintItemsCritical");
                #endregion
            }
            else if (e.Column == COL_ALLOSTNDGMAINT)
            {
                #region Overdue for All Maintenance
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_ALLOSTNDGMAINT].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_ALLOSTNDGMAINT].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Maintenance Overdue for Critical Maintenance.");
                    return;
                }

                pms.CallPmsandSvyPage(vesselID, "AllOstndgMaint");
                #endregion
            }
            else if (e.Column == COL_OSTNDGNONCRITICALEQPMAINT)
            {
                #region Overdue for Non Critical Eqp Maintenance
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTNDGNONCRITICALEQPMAINT].Value != null)
                {
                    double cnt1 = Convert.ToDouble(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OSTNDGNONCRITICALEQPMAINT].Value.ToString());
                    if (cnt1 == 0)
                    {
                        this.Cursor = Cursors.Default;
                        Gfn.Mb("There is no Maintenance Overdue for Critical Maintenance.");
                        return;
                    }
                }
                pms.CallPmsandSvyPage(vesselID, "OstdngNonCriticalEqpMaintItems");
                #endregion
            }
            else if (e.Column == COL_CRITICALSPBELOWMINQTY)
            {
                #region Critical Spares Below Min Qty
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_CRITICALSPBELOWMINQTY].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_CRITICALSPBELOWMINQTY].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Critical Spares Below Min Qty.");
                    return;
                }

                pms.CallCriticalSPPage(vesselID, "CriticalSPBelowMinQty");
                #endregion
            }
            else if (e.Column == COL_CRITICALSPRQNS)
            {
                #region Critical Spares Requisitions
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_CRITICALSPRQNS].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_CRITICALSPRQNS].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Critical Spares Requisitions.");
                    return;
                }

                pms.CallCriticalSPPage(vesselID, "CriticalSpRqns");
                #endregion
            }
            else if (e.Column == COL_SUPT_DF_ACK)
            {
                #region Defects for Supt to ACK
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_SUPT_DF_ACK].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_SUPT_DF_ACK].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Defects for Supt to ACK.");
                    return;
                }

                string addlParameter = "SUPTREVIEW|YES";
                CallDefectsApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column == COL_DF_ACTIVEITEMS)
            {
                #region Active Defects
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_ACTIVEITEMS].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_ACTIVEITEMS].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Active Defects.");
                    return;
                }

                string addlParameter = "ACTIVEITEMS|YES";
                CallDefectsApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column == COL_DF_ODUEITEMS)
            {
                #region Active OverDue Defects
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_ODUEITEMS].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_ODUEITEMS].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no OverDue Defects.");
                    return;
                }

                string addlParameter = "OVERDUEITEMS|YES";
                CallDefectsApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column == COL_DF_TOHQAPPROVE)
            {
                #region HQ To Approve Defects
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_TOHQAPPROVE].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_TOHQAPPROVE].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no HQ To Approve Defects.");
                    return;
                }

                string addlParameter = "HQToApprove|YES";
                CallDefectsApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column == COL_DF_EXTENDED)
            {
                #region Defects Extended
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_EXTENDED].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_DF_EXTENDED].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Defects Extended.");
                    return;
                }

                string addlParameter = "ExtendedDefects|YES";
                CallDefectsApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column >= COL_FORMS_ODUE && e.Column <= COL_FORMS_RECENTLY_CLOSED)
            {
                #region Forms for Supt to APPR                
                string addlParameter = "", msg = "";
                if (e.Column == COL_FORMS_ODUE) { addlParameter = "OverDue|TECH"; msg = "Forms Over Due"; }
                else if (e.Column == COL_FORMS_TO_APPR) { addlParameter = "HQTOAPPR|Tech"; msg = "Forms to Approve"; }
                else if (e.Column == COL_FORMS_VSL_PENDING) { addlParameter = "VslPending|TECH"; msg = "VSL Pending Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_FINALISE) { addlParameter = "VslToFinalise|"; msg = "VSL To Finalise Forms"; } //VslToFinalise
                else if (e.Column == COL_FORMS_VSL_TO_APPR) { addlParameter = "VslToAppr|TECH"; msg = "VSL To Approve Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_AMEND) { addlParameter = "VSLTOAMENDMNTS|TECH"; msg = "Forms for Vsl Amend"; }
                else if (e.Column == COL_FORMS_HQ_PENDING) { addlParameter = "HQPending|TECH"; msg = "HQ Pending Forms"; }
                else if (e.Column == COL_FORMS_HQ_TO_AMEND) { addlParameter = "HQAmend|TECH"; msg = "Forms for HQ Amend"; }
                else if (e.Column == COL_FORMS_SUPT_TO_FINALISE) { addlParameter = "FILLED|TECH|Supt"; msg = "Forms for Supt to finalise"; }
                else if (e.Column == COL_FORMS_MGR_TO_FINALISE) { addlParameter = "FILLED|TECH|Manager"; msg = "Forms for Manager to finalise"; }
                else if (e.Column == COL_FORMS_GENMGR_TO_FINALISE) { addlParameter = "FILLED|TECH|GeneralManager"; msg = "Forms for General Manager to finalise"; }
                else if (e.Column == COL_FORMS_DIR_TO_FINALISE) { addlParameter = "FILLED|TECH|Director"; msg = "Forms for Director to finalise"; }

                else if (e.Column == COL_FORMS_TA_TO_APPR) { addlParameter = "HQTOAPPR|TECH|T.A"; msg = "Forms for T.A to Approve"; }
                else if (e.Column == COL_FORMS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|TECH|Supt"; msg = "Forms for Supt to Approve"; }
                else if (e.Column == COL_FORMS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|Manager"; msg = "Forms for Manager to Approve"; }
                else if (e.Column == COL_FORMS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|GeneralManager"; msg = "Forms for General Manager to Approve"; }
                else if (e.Column == COL_FORMS_SENMGR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|SeniorManager"; msg = "Forms for Senior Manager to Approve"; }
                else if (e.Column == COL_FORMS_DIR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|Director"; msg = "Forms for Director to Approve"; }
                else if (e.Column == COL_FORMS_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED|TECH"; msg = "Recently Closed Forms"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }


                CallFormsApplication(vesselID, addlParameter, true, false, "SUPT_FORMS_APPR", rowIndex);

                #endregion
            }
            else if (e.Column >= COL_NCR_TOEXTEND_TOAPPROVE && e.Column <= COL_NCR_RECENTLY_CLOSED)
            {
                #region NCR to APPR
                string addlParameter = "", msg = "";
                if (e.Column == COL_NCR_OVERDUE) { addlParameter = "ODue"; msg = "NCR Over Due"; }
                else if (e.Column == COL_NCR_TOEXTEND_TOAPPROVE) { addlParameter = "ToExtendToApprove"; msg = "NCR To Extend To Approve"; }
                else if (e.Column == COL_NCR_EXTENDED) { addlParameter = "ExtendedNCR"; msg = "NCR for Extended"; }
                else if (e.Column == COL_NCR_CREW_PENDING) { addlParameter = "CrewPending"; msg = "NCR for Crew Supt to Approve"; }
                else if (e.Column == COL_NCR_TECH_PENDING) { addlParameter = "TechPending"; msg = "NCR for Tech Supt to Approve"; }
                else if (e.Column == COL_NCR_MGR_TO_APPR) { addlParameter = "MgrToAppr"; msg = "NCR for Mgr to Approve"; }
                else if (e.Column == COL_NCR_HQUNDERPREP) { addlParameter = "HQUNDERPREP"; msg = "NCR for Tech HQ Under Prep"; }
                else if (e.Column == COL_NCR_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; msg = "HQ To Amend NCR"; }
                else if (e.Column == COL_NCR_TECH_TO_FINALISE) { addlParameter = "TechToFinalise"; msg = "Tech To Finalise NCR"; }                
                else if (e.Column == COL_NCR_UNDERACTION) { addlParameter = "UnderAction"; msg = "NCR for Tech Approval"; }
                else if (e.Column == COL_NCR_CLOSEOUT_TO_REVIEW_HQ) { addlParameter = "CloseOutToReview_HQ"; msg = "NCR for Close out to Approve"; }
                else if (e.Column == COL_NCR_CLOSEOUT_TO_REVIEW_VSL) { addlParameter = "CloseOutToReview_VSL"; msg = "NCR for VSL Close out to Approve"; }
                else if (e.Column == COL_NCR_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED"; msg = "Recently Closed NCR"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + " .");
                    return;
                }

                CallNCRApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
            else if (e.Column >= COL_AUDITINSPECTION_DONE && e.Column <= COL_AUDITINSPECTION_RECENTLY_CLOSED)
            {
                #region Audit Inspection

                string addlParameter = "", msg = "";
                if (e.Column == COL_AUDITINSPECTION_DUE) { addlParameter = "ALL|-1"; msg = "Due"; }
                else if (e.Column == COL_AUDITINSPECTION_DONE) { addlParameter = "ALL|-1"; msg = "Done"; }
                else if (e.Column == COL_AUDITINSPECTION_NOOFDUE) { addlParameter = "DUE|-1"; msg = "Due"; }
                else if (e.Column == COL_AUDITINSPECTION_NOOFOVERDUE) { addlParameter = "ODUE|-1"; msg = "Over Due"; }
                else if (e.Column == COL_AUDITINSPECTION_NOOFWINDOWPERIOD) { addlParameter = "ActionRequired|-1"; msg = "Window Period"; }
                else if (e.Column == COL_AUDITINSPECTION_RESCHEDULED_TOAPPR) { addlParameter = "RESCHEDULEHQTOAPPROVE|-1"; msg = "Re -Scheduled To Appr"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTREPORT) { addlParameter = "DraftReport|-1"; msg = "Draft Report"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFT_TOAMEND) { addlParameter = "ToAmend|-1"; msg = "Audit / Inspection To Amend"; }
                else if (e.Column == COL_AUDITINSPECTION_AMENDREPORTTOAPPROVE) { addlParameter = "AmendedReportToApprove|-1"; msg = "Audit / Amend Report to Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTMGRTOAPROVE) { addlParameter = "DraftMgrToAprove|-1"; msg = "Audit / Inspection for Manager to approve (Draft) Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTSRMGRTOAPROVE) { addlParameter = "DraftSrMgrToAprove|-1"; msg = "Audit / Inspection for Senior Mgr to approve (Draft) Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE) { addlParameter = "DraftDirectorToAprove|-1"; msg = "Audit / Inspection for Director to approve (Draft) Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_UNDERACTION) { addlParameter = "UNDERACTION|-1"; msg = "Audit / Inspection for Tech Approval"; }
                else if (e.Column == COL_AUDITINSPECTION_CLOSEOUTTOREVIEW) { addlParameter = "CloseOutToReview|-1"; msg = "Audit / Inspection for Close out to Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_MGRTOAPPROVE) { addlParameter = "MgrToApprove|-1"; msg = "Audit / Inspection for Manager Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_GENMGRTOAPPROVE) { addlParameter = "GenMgrToApprove|-1"; msg = "Audit / Inspection for Senior Manager Approve"; }
                else if (e.Column == COL_AUDITINSPECTION_DIRECTOR_TO_APPROVE) { addlParameter = "DirectorToApprove|-1"; msg = "Audit / Inspection for Director Approve"; }

                else if (e.Column == COL_AUDITINSPECTION_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED|-1"; msg = "Recently Closed Audit / Inspection"; }

                if (e.Column == COL_AUDITINSPECTION_DONE || e.Column == COL_AUDITINSPECTION_DUE)
                {
                    if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Text.Trim().Length > 0) cnt = 1;
                }
                else if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + " .");
                    return;
                }

                CallAuditInspectionApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column >= COL_AWARENESS_REPORT_OVERDUE && e.Column <= COL_AWARENESS_REPORT_RECENTLY_CLOSED)
            {
                #region Awareness Report
                string addlParameter = "", msg = "";
                if (e.Column == COL_AWARENESS_REPORT_OVERDUE) { addlParameter = "ODue"; msg = "Awareness Report Over Due"; }
                else if (e.Column == COL_AWARENESS_REPORT_CREW_PENDING) { addlParameter = "CrewPending"; msg = "Awareness Report for Crew Supt to Approve"; }
                else if (e.Column == COL_AWARENESS_REPORT_TECH_PENDING) { addlParameter = "TechPending"; msg = "Awareness Report for Tech Supt to Approve"; }
                else if (e.Column == COL_AWARENESS_REPORT_MGR_TO_APPR) { addlParameter = "MgrToAppr"; msg = "Awareness Report for Mgr to Approve"; }
                else if (e.Column == COL_AWARENESS_REPORT_HQUNDERPREP) { addlParameter = "HQUNDERPREP"; msg = "Awareness Report for Tech HQ Under Prep"; }
                else if (e.Column == COL_AWARENESS_REPORT_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; msg = "HQ To Amend Awareness Report"; }
                else if (e.Column == COL_AWARENESS_REPORT_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED"; msg = "Recently Closed Awareness Report"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + " .");
                    return;
                }

                CallAwarenessReportApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
            else if (e.Column >= COL_MASTERS_REVIEW_OVERDUE && e.Column <= COL_MASTERS_REVIEW_RECENTLY_CLOSED)
            {
                #region Masters Review
                string addlParameter = "", msg = "";
                if (e.Column == COL_MASTERS_REVIEW_OVERDUE) { addlParameter = "ODue"; msg = "Masters Review Over Due"; }
                else if (e.Column == COL_MASTERS_REVIEW_CREW_PENDING) { addlParameter = "CrewPending"; msg = "Masters Review for Crew Supt to Approve"; }
                else if (e.Column == COL_MASTERS_REVIEW_TECH_PENDING) { addlParameter = "TechPending"; msg = "Masters Review for Tech Supt to Approve"; }
                else if (e.Column == COL_MASTERS_REVIEW_MGR_TO_APPR) { addlParameter = "MgrToAppr"; msg = "Masters Review for Mgr to Approve"; }
                else if (e.Column == COL_MASTERS_REVIEW_HQUNDERPREP) { addlParameter = "HQUNDERPREP"; msg = "Masters Review for Tech HQ Under Prep"; }
                else if (e.Column == COL_MASTERS_REVIEW_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; msg = "HQ To Amend Masters Review"; }
                else if (e.Column == COL_MASTERS_REVIEW_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED"; msg = "Recently Closed Masters Review"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + " .");
                    return;
                }

                CallMastersReviewReportCallerApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
            else if (e.Column >= COL_MINUTES_OF_SAFETY_OVERDUE && e.Column <= COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED)
            {
                #region Safety Meeting Report
                string addlParameter = "", msg = "";
                if (e.Column == COL_MINUTES_OF_SAFETY_OVERDUE) { addlParameter = "ODue"; msg = "Safety Meeting Report Over Due"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_CREW_PENDING) { addlParameter = "CrewPending"; msg = "Safety Meeting Report for Crew Supt to Approve"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_TECH_PENDING) { addlParameter = "TechPending"; msg = "Safety Meeting Report for Tech Supt to Approve"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_MGR_TO_APPR) { addlParameter = "MgrToAppr"; msg = "Safety Meeting Report for Mgr to Approve"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_HQUNDERPREP) { addlParameter = "HQUNDERPREP"; msg = "Safety Meeting Report for Tech HQ Under Prep"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; msg = "HQ To Amend Safety Meeting Report"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED"; msg = "Recently Closed Safety Meeting Report"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + " .");
                    return;
                }

                CallMinutesOfSafetyReportCallerApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
            else if (e.Column == COL_CORRECTIVE_HQTOAPPROVE)
            {
                #region Corrective Maintenance To Approve
                string cellValue = "";
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cellValue = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString();

                if (cellValue.Trim().Length <= 0 || cellValue == "0")
                {
                    string msg = "no Corrective Maintenance To Approve";
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is " + msg + ".");
                    return;
                }
                string addlParameter = "";
                addlParameter = " HQTOAPPROVE";
                CallCorrectiveMaintenanceApplication(vesselID, addlParameter, false, true, rowIndex);
                #endregion
            }
            else if (e.Column >= COL_TASKLIST_OVERDUE && e.Column <= COL_TASKLIST_RECENTLY_CLOSED)
            {
                #region Task to APPR

                string addlParameter = "", msg = "";

                if (e.Column == COL_TASKLIST_OVERDUE) { addlParameter = "OverDue"; msg = "Task  over due"; }
                else if (e.Column == COL_TASKLIST_DPA_PENDING) { addlParameter = "DPAPending_ToApprove"; msg = "Task for DPA Supt to Approve"; }
                else if (e.Column == COL_TASKLIST_CREW_PENDING) { addlParameter = "CrewPending_ToApprove"; msg = "Task for Crew Supt to Approve"; }
                else if (e.Column == COL_TASKLIST_TECH_PENDING) { addlParameter = "TechPending_ToApprove"; msg = "Task for Tech Supt to Approve"; }
                else if (e.Column == COL_TASKLIST_HQUNDERPREP) { addlParameter = "HQUNDERPREP"; msg = "Task for Tech HQ Under Prep"; }
                else if (e.Column == COL_TASKLIST_PURCHASERACTION) { addlParameter = "PURCHASERACTION"; msg = "Task for Purchaser Action"; }
                else if (e.Column == COL_TASKLIST_HQTOSUBMIT) { addlParameter = "HQToSubmit_Resubmit"; msg = "Task for Tech HQ to Submit"; }
                else if (e.Column == COL_TASKLIST_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed"; msg = "Task for Tech HQ to Submit"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + " .");
                    return;
                }

                CallTaskListApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
            else if (e.Column >= COL_INCIDENT_REPORT_OVERDUE && e.Column <= COL_INCIDENT_REPORT_RECENTLY_FINALISED)
            {
                #region Incident Report
                string addlParameter = "";
                if (e.Column == COL_INCIDENT_REPORT_OVERDUE) { addlParameter = "Incident_ODue"; }
                else if (e.Column == COL_INCIDENT_REPORT_HQUNDERPREP) { addlParameter = "Incident_HQUnderPrep"; }
                else if (e.Column == COL_INCIDENT_REPORT_HQ_TO_AMEND) { addlParameter = "Incident_HQToAmend"; }
                else if (e.Column == COL_INCIDENT_REPORT_DPA_PENDING) { addlParameter = "Incident_DPAPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_CREW_PENDING) { addlParameter = "Incident_CrewPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_TECH_PENDING) { addlParameter = "Incident_TechPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_MGR_TO_APPR) { addlParameter = "Incident_MgrToApprove"; }
                else if (e.Column == COL_INCIDENT_REPORT_SR_MGR_TO_APPR) { addlParameter = "Incident_GenMgrToApprove"; }
                else if (e.Column == COL_INCIDENT_REPORT_VSL_AMEND) { addlParameter = "Incident_VslToAmend"; }
                else if (e.Column == COL_INCIDENT_REPORT_RECENTLY_FINALISED) { addlParameter = "Incident_RecentlyClosed"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallIncidentReportApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column >= COL_INVESTIGATION_REPORT_OVERDUE && e.Column <= COL_INVESTIGATION_REPORT_RECENTLY_CLOSED)
            {
                #region Investigation Report
                string addlParameter = "";
                if (e.Column == COL_INVESTIGATION_REPORT_OVERDUE) { addlParameter = "Investigation_ODue"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_HQUNDERPREP) { addlParameter = "Investigation_HQUnderPrep"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_HQ_TO_AMEND) { addlParameter = "Investigation_HQToAmend"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_DPA_PENDING_DRAFT) { addlParameter = "Investigation_DPAToApproveDraft"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_MGR_TO_APPR_DRAFT) { addlParameter = "Investigation_MgrToApproveDraft"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_UNDERACTION) { addlParameter = "Investigation_UnderAction"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_CLOSEOUT) { addlParameter = "Investigation_CloseOut"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_MGR_TO_APPR) { addlParameter = "Investigation_MgrToApprove"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_SR_MGR_TO_APPR) { addlParameter = "Investigation_GenMgrToApprove"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_VSL_AMEND_ACK) { addlParameter = "Investigation_VslToAmend_Ack"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_RECENTLY_CLOSED) { addlParameter = "Investigation_RecentlyClosed"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallInvestigationtReportApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column == COL_CORRECTIVE_DUE)
            {
                #region Corrective Maintenance in Due
                string cellValue = "";
                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cellValue = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString();

                if (cellValue.Trim().Length <= 0 || cellValue == "0")
                {
                    string msg = "no Corrective Maintenance in Due";
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is " + msg + ".");
                    return;
                }
                string addlParameter = "";
                addlParameter = " DUE";
                CallCorrectiveMaintenanceApplication(vesselID, addlParameter, false, true, rowIndex);
                #endregion
            }
            else if (e.Column >= COL_RISKASSEMENTS_TASK_ODUE && e.Column <= COL_RISKASSEMENTS_VSLTASKTOMOVE)
            {
                #region Risk Assements              
                string addlParameter = "", msg = "";
                if (e.Column == COL_RISKASSEMENTS_TASK_ODUE) { addlParameter = "Task_ODUE"; msg = " Task OverDue Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_REPORT_ODUE) { addlParameter = "Report_ODUE"; msg = "Report OverDue Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_ACTIVEITEMS) { addlParameter = "ActiveItems"; msg = "Active Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_PENDING) { addlParameter = "VslPending"; msg = "VSL Pending Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_TO_AMEND) { addlParameter = "VslAmend"; msg = "Risk Assements for Vsl Amend"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_PENDING) { addlParameter = "HQPending|TECH"; msg = "HQ Pending Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_TO_AMEND) { addlParameter = "HQAmend|TECH"; msg = "Risk Assements for HQ Amend"; }
                else if (e.Column == COL_RISKASSEMENTS_TO_APPR) { addlParameter = "HQTOAPPR|TECH"; msg = "Risk Assements for Review"; }
                else if (e.Column == COL_RISKASSEMENTS_TA_TO_APPR) { addlParameter = "HQTOAPPR|TECH|T.A"; msg = "Risk Assements for T.A to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_SUPT_TO_APPR) { addlParameter = "TechSuptToAppr|TECH|Supt"; msg = "Risk Assements for Supt to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|Manager"; msg = "Risk Assements for Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|GeneralManager"; msg = "Risk Assements for General Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_SENMGR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|SeniorManager"; msg = "Risk Assements for Senior Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_DIR_TO_APPR) { addlParameter = "HQTOAPPR|TECH|Director"; msg = "Risk Assements for Director to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_TO_ACK) { addlParameter = "VslToAck|Tech"; msg = "Risk Assements for Vsl to Ack"; }
                else if (e.Column == COL_RISKASSEMENTS_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED"; msg = "Recently Closed Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_REVIEW) { addlParameter = "HQReview"; msg = "HQ Review Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSLTASKTOMOVE) { addlParameter = "VslTaskToMove"; msg = "HQ Review Risk Assements"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallRiskMgmtApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
            else if (e.Column == COL_MONTHENDDOC_OVERDUE)
            {
                #region Month End Doc
                string addlParameter = "";
                if (e.Column == COL_MONTHENDDOC_OVERDUE) { addlParameter = "OverDue"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallMonthEndDocApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }
            else if (e.Column >= COL_CERTIFICATE_OVERDUE && e.Column < COL_SEPARATOR_CERTIFICATE)
            {
                #region Certificate
                string addlParameter = "";
                if (e.Column == COL_CERTIFICATE_OVERDUE) { addlParameter = "OverDue"; }
                else if (e.Column == COL_CERTIFICATE_WINDOW) { addlParameter = "Window"; }
                else if (e.Column == COL_CERTIFICATE_PENDING) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_CERTIFICATE_HQTOUPDATE) { addlParameter = "HQToUpdate"; }
                else if (e.Column == COL_CERTIFICATE_VSLTOUPDATE) { addlParameter = "VSLToUpdate"; }
                else if (e.Column == COL_CERTIFICATE_TORENEW) { addlParameter = "ToRenew"; }
                else if (e.Column == COL_CERTIFICATE_RENEWALINPROGRESS) { addlParameter = "RenewalInProgress"; }

                if (fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallCertificateApplication(vesselID, addlParameter, true, false, rowIndex);
                #endregion
            }

            this.Cursor = Cursors.Default;
            panelLoading.Visible = false;
        }

        private void ExpandCollapseColumn(string groupName)
        {
            DataTable dt;
            try
            {
                if (groupName.ToUpper() == "Audit / Inspection(AI)".ToUpper()) groupName = "Audit / Inspection";
                if (groupName.ToUpper() == "Risk Asses".ToUpper()) groupName = "Risk Assements";

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways " +
                                " from Dashboard_HQ_Main_Tech_Setup " + Environment.NewLine +
                                " where ColumnNo>=0 and GroupName=" + Gfn.Qss(groupName) +
                                "   and C_CompanyID = " + companyID +
                                " order by ColumnNo";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                    if (columnNo >= fpSpread_Particulars.ActiveSheet.ColumnCount) break;

                    int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                    int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());
                    if (isToHide == 1) continue;

                    if (isToShowAlways == 1) fpSpread_Particulars.ActiveSheet.Columns[columnNo].Visible = true;
                    else fpSpread_Particulars.ActiveSheet.Columns[columnNo].Visible = (!fpSpread_Particulars.ActiveSheet.Columns[columnNo].Visible);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "ExpandCollapseColumn", err.Message);
            }
        }

        private void fpSpread_Particulars_TextTipFetch(object sender, FarPoint.Win.Spread.TextTipFetchEventArgs e)
        {
            if (e.View.TextTipAppearance.BackColor != SystemColors.Info)
            {
                e.View.TextTipAppearance.BackColor = SystemColors.Info;
                e.View.TextTipAppearance.ForeColor = Color.Black;
            }

            if (e.ColumnHeader && e.Row == 0)
            {
                if ((e.Column >= COL_AUDITINSPECTION_DONE && e.Column <= COL_AUDITINSPECTION_RECENTLY_CLOSED) ||
                    (e.Column >= COL_NCR_OVERDUE && e.Column <= COL_NCR_RECENTLY_CLOSED) ||
                    (e.Column >= COL_TASKLIST_OVERDUE && e.Column <= COL_TASKLIST_RECENTLY_CLOSED))
                {
                    e.WrapText = false;
                    e.ShowTip = true;
                    e.TipText = "Double click to Show / Hide Columns";
                    e.View.TextTipAppearance.BackColor = Color.LightYellow;
                    e.View.TextTipAppearance.ForeColor = Color.Red;
                    e.View.TextTipAppearance.Font = new Font("Arial", 9, FontStyle.Bold);
                }
            }
        }

        private void CallDefectsApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";

            VslDefects.DFStartup vslDefects = new VslDefects.DFStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!vslDefects.isVslInitSuccessfully)
                {
                    return;
                }

                vslDefects.CallDefectRegisterMainPage();
                isDoneAnyChanges = vslDefects.isDoneAnyChanges;
            }
            finally
            {
                vslDefects = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = "DEFECTS";
                RefreshHQDashboard(vesselID, rowNo, COL_SUPT_DF_ACK, false, false);
            }
        }

        private void CallCorrectiveMaintenanceApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string exeName = "CorrMaint";
            string param = GetParam(vesselID, false);
            param = param + addlParameter;
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }

        private void CallFormsApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, string xCalledFrom, int rowNo)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = " " + cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + vslFilter;

            //string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim();
            VslForms.FormsStartup formsStartup = new VslForms.FormsStartup(arg.Split(' '));

            bool isChangesDone = false;
            try
            {
                if (!formsStartup.isVslInitSuccessfully)
                {
                    return;
                }

                formsStartup.CallFormsListMainPage(arg.Split(' '));
                isChangesDone = formsStartup.isChangesDone;
            }
            finally
            {
                formsStartup = null;
            }

            if (isToRefresh && isChangesDone)
            {
                calledFrom = xCalledFrom;
                RefreshHQDashboard(vesselID, rowNo, COL_FORMS_ODUE, false, false);
            }
        }

        private void CallRiskMgmtApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            RiskMgmt.RMStartup rmStartup;
            bool isDoneAnyChanges = false;

            try
            {
                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim();
                rmStartup = new RiskMgmt.RMStartup(arg.Split(' '));

                if (addlParameter.Trim().ToUpper() == "VslTaskToMove".ToUpper())
                {
                    rmStartup.CallHQReviewPage();
                }
                else
                {
                    rmStartup.CallRMRegisterPage();
                }
                isDoneAnyChanges = rmStartup.isDoneAnyChanges;
            }
            finally
            {
                rmStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_RISKASSEMENTS;
                RefreshHQDashboard(vesselID, rowNo, COL_RISKASSEMENTS_REPORT_ODUE, false, false);
            }
            isDoneAnyChanges = false;
        }

        private void CallNCRApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|Tech";
            NCR.NCRstartup ncrStartup = new NCR.NCRstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!ncrStartup.isVslInitSuccessfully)
                {
                    return;
                }

                ncrStartup.CallNCRRegisterMainPage();
                isDoneAnyChanges = ncrStartup.isDoneAnyChanges;
            }
            finally
            {
                ncrStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_NCR;
                RefreshHQDashboard(vesselID, rowNo, COL_NCR_OVERDUE, false, false);
            }
        }

        private void CallAuditInspectionApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            AuditInspection.AuditInspectionStartup aiStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";
                aiStartup = new AuditInspection.AuditInspectionStartup(arg.Split(' '));

                if (!aiStartup.isVslInitSuccessfully)
                {
                    return;
                }

                aiStartup.CallVslAuditInspectionMainPage();
                isDoneAnyChanges = aiStartup.isDoneAnyChanges;
            }
            finally
            {
                aiStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_AUDITINSPECTION;
                RefreshHQDashboard(vesselID, rowNo, COL_AUDITINSPECTION_DONE, false, false);
            }
            isDoneAnyChanges = false;
        }

        private void CallTaskListApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            TaskList.Taskstartup taskStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "-1";
                if (cboVslFilter.SelectedValue != null) vslFilter = "|" + cboVslFilter.SelectedValue.ToString();

                string sx = "|Tech";
                if (addlParameter.ToUpper() == "CrewPending".ToUpper() || addlParameter.ToUpper() == "CrewPending_ToApprove".ToUpper())
                {
                    sx = "|Crew";
                }

                if (addlParameter.ToUpper()== "PURCHASERACTION") sx = "|Purchase";

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + vslFilter + sx;
                taskStartup = new TaskList.Taskstartup(arg.Split(' '));

                taskStartup.CallTaskRegisterMainPage();
                isDoneAnyChanges = taskStartup.isDoneAnyChanges;
            }
            finally
            {
                taskStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_TASK;
                RefreshHQDashboard(vesselID, rowNo, COL_TASKLIST_OVERDUE, false, false);
            }
        }

        private void CallIncidentReportApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            string vslFilter = "-1";
            if (cboVslFilter.SelectedValue != null) vslFilter = "|" + cboVslFilter.SelectedValue.ToString();

            string sx = "";
            if (addlParameter.ToUpper() != "Incident_VslToAmend".ToUpper() && addlParameter.ToUpper() != "Incident_TechPending".ToUpper() &&
                addlParameter.ToUpper() != "Incident_DPAPending".ToUpper() && addlParameter.ToUpper() != "Incident_CrewPending".ToUpper() && addlParameter.ToUpper() != "Investigation_DPAToApproveDraft".ToUpper())
            {
                sx = "|Tech";
            }

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + "|" + vslFilter + sx;

            IncidentReport.IncidentReportStartup incidentReportStartup = new IncidentReport.IncidentReportStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!incidentReportStartup.isVslInitSuccessfully)
                {
                    return;
                }

                incidentReportStartup.CallVslIncidentReportMainPage();
                isDoneAnyChanges = incidentReportStartup.isDoneAnyChanges;
            }
            finally
            {
                incidentReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_INCIDENTREPORT;
                RefreshHQDashboard(vesselID, rowNo, COL_INCIDENT_REPORT_OVERDUE, false, false);
            }

            isDoneAnyChanges = false;
        }

        private void CallInvestigationtReportApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            string vslFilter = "-1";
            if (cboVslFilter.SelectedValue != null) vslFilter = "|" + cboVslFilter.SelectedValue.ToString();

            string sx = "";
            if (addlParameter.ToUpper() != "Incident_VslToAmend".ToUpper() && addlParameter.ToUpper() != "Incident_TechPending".ToUpper() &&
                addlParameter.ToUpper() != "Incident_DPAPending".ToUpper() && addlParameter.ToUpper() != "Incident_CrewPending".ToUpper() && addlParameter.ToUpper() != "Investigation_DPAToApproveDraft".ToUpper())
            {
                sx = "|Tech";
            }

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + "|" + vslFilter + sx;

            IncidentReport.IncidentReportStartup incidentReportStartup = new IncidentReport.IncidentReportStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!incidentReportStartup.isVslInitSuccessfully)
                {
                    return;
                }

                incidentReportStartup.CallVslIncidentReportMainPage();
                isDoneAnyChanges = incidentReportStartup.isDoneAnyChanges;
            }
            finally
            {
                incidentReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_INVESTIGATIONREPORT;
                RefreshHQDashboard(vesselID, rowNo, COL_INVESTIGATION_REPORT_OVERDUE, false, false);
            }

            isDoneAnyChanges = false;
        }

        private void CallAwarenessReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";

            AwarenessReport.AwarenessReportstartup awarenessReportStartup = new AwarenessReport.AwarenessReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!awarenessReportStartup.isVslInitSuccessfully)
                {
                    return;
                }

                awarenessReportStartup.CallAwarenessReportRegisterMainPage();
                isDoneAnyChanges = awarenessReportStartup.isDoneAnyChanges;
            }
            finally
            {
                awarenessReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_AWARENESS_REPORT;
                RefreshHQDashboard(vesselID, rowNo, COL_AWARENESS_REPORT_OVERDUE, false, false);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallMinutesOfSafetyReportCallerApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";
            MinutesofSafetyReport.MinutesofSafetyReportstartup minutesofSafetyReportstartup = new MinutesofSafetyReport.MinutesofSafetyReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!minutesofSafetyReportstartup.isVslInitSuccessfully)
                {
                    return;
                }

                minutesofSafetyReportstartup.CallMinutesofSafetyReportRegisterMainPage();
                isDoneAnyChanges = minutesofSafetyReportstartup.isDoneAnyChanges;
            }
            finally
            {
                minutesofSafetyReportstartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_MINUTES_OF_SAFETY;
                RefreshHQDashboard(vesselID, rowNo, COL_MINUTES_OF_SAFETY_OVERDUE, false, false);
            }
            isDoneAnyChanges = false;
        }

        private void CallMastersReviewReportCallerApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";
            MastersReviewReport.MastersReviewReportstartup mastersReviewReportstartup = new MastersReviewReport.MastersReviewReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!mastersReviewReportstartup.isVslInitSuccessfully)
                {
                    return;
                }

                mastersReviewReportstartup.CallMastersReviewRegisterMainPage();
                isDoneAnyChanges = mastersReviewReportstartup.isDoneAnyChanges;
            }
            finally
            {
                mastersReviewReportstartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_MINUTES_OF_SAFETY;
                RefreshHQDashboard(vesselID, rowNo, COL_MASTERS_REVIEW_OVERDUE, false, false);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallMonthEndDocApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";
            MonthEndDocMgmt.MonthEndDocStartup monthEndDocStartup = new MonthEndDocMgmt.MonthEndDocStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!monthEndDocStartup.isVslInitSuccessfully)
                {
                    return;
                }

                monthEndDocStartup.CallMonthEndDocMainPage();
                isDoneAnyChanges = monthEndDocStartup.isDoneAnyChanges;
            }
            finally
            {
                monthEndDocStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_MONTHENDDOC;
                RefreshHQDashboard(vesselID, rowNo, COL_MONTHENDDOC_OVERDUE, false, false);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallCertificateApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string hqDept = "Common_Tech";
            if (!PG.isCert_FilterOdueDeptwise && addParam.ToUpper() == "OVERDUE") hqDept = "";
            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|" + hqDept;

            VslCertificates.VslCertificatesStartup vslCertificate = new VslCertificates.VslCertificatesStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!vslCertificate.isVslInitSuccessfully)
                {
                    return;
                }

                vslCertificate.CallVslCertificatesMainPage();
                isDoneAnyChanges = vslCertificate.isDoneAnyChanges;
            }
            finally
            {
                vslCertificate = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_CERTIFICATE;
                RefreshHQDashboard(vesselID, rowNo, COL_CERTIFICATE_OVERDUE, false, false);
            }
            isDoneAnyChanges = false;
        }
        

        private void btnProcurement_Click(object sender, EventArgs e)
        {
            string exeName = PG.default_ProcAppToCall;
            string param = "";
            if (PG.isDirectAppCall)
            {
                param = "DirectAppCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd;
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                param = "RemoteWebSvc " + URLString;
            }

            PG.ExecuteApp(exeName, param);
        }

        private void btnSQEDashboard_Click(object sender, EventArgs e)
        {
            frmMainForm_Marine objMainFormMarine = new frmMainForm_Marine();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objMainFormMarine.companyID = companyID;
                objMainFormMarine.isToShowTECHDashboard = false;
                objMainFormMarine.isToShowCREWDashboard = isToShowCREWDashboard;
                objMainFormMarine.Show();

                if (!PG.InitialiseCommonSettings(companyID)) return;
            }
            finally
            {
                objMainFormMarine = null;
            }
        }

        private void btnCrewDashboard_Click(object sender, EventArgs e)
        {
            frmMainForm_Crew objMainFormCrew = new frmMainForm_Crew();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objMainFormCrew.companyID = companyID;
                objMainFormCrew.isToShowTECHDashboard = false;
                objMainFormCrew.isToShowSQEDashboard = isToShowSQEDashboard;
                objMainFormCrew.ShowDialog();

                if (!PG.InitialiseCommonSettings(companyID)) return;
            }
            finally
            {
                objMainFormCrew = null;
            }
        }

        private void btnDMS_Click(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Visible = true; pictureBox1.Left = btnDMS.Left - pictureBox1.Width - 10; pictureBox1.Top = 0;
                PG.CallDMS(cboCompany_Filter.Text );
            }
            finally
            {
                pictureBox1.Visible = false;
                pictureBox1.Left = panelLoading.Left; pictureBox1.Top = panelLoading.Top - 10;
            }
        }


        private void tsMnuEquipmentManager_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string param = "";
            if (PG.isDirectAppCall)
            {
                param = PG.hqAppFolder + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|NO|NO|HqAsVslMode HQSDS_MAIN";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                param = PG.hqAppFolder + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|NO|NO|HqAsVslMode HQSDS_MAIN";
            }

            string exeName = "FleetEqpmtManager";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }

        private void tsmnSparesInventory_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string exeName = "Spares";
            string param = GetParam(vesselID, false);
            param = param + " SPINVENTORY NO";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }
               
        private void tsmnStoresInventory_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string exeName = "Stores";
            string param = GetParam(vesselID, false);
            param = param + " CATALOGDETAILS NO";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }

        private void tsmnSparesPurchase_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string exeName = "Spares";
            string param = GetParam(vesselID, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }

        private void tsmnuStoresPurchase_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;


            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string exeName = "Stores";
            string param = GetParam(vesselID, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }

        private void tsMnuHQPMS_Click(object sender, EventArgs e)
        {
             int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            //string opsby = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OPERATEBY].Value.ToString();
            //if (opsby.ToUpper() == "VSL")
            //{
            //    Gfn.Mb("This feature is only available for operate by HQ Vessels." + Environment.NewLine);
            //}

            string exeName = "VslDashBoard";
            string param = GetParam(vesselID, false);
            param = param + " PmsMain";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }


        private void tsMnuDefects_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallDefectsApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuRepairsPurchase_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            string exeName = "RepairsAndSvc";
            string param = GetParam(vesselID, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
        }

        private void tsMnuForms_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallFormsApplication(vesselID, "All|Tech", true, false, "SUPT_FORMS_APPR", rowIndex);
        }

        private void tsMnuRiskAssements_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallRiskMgmtApplication(vesselID, "Register", true, false, rowIndex);
        }

        private void tsMnuVslRiskAssements_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallRiskMgmtApplication(vesselID, "Register", false, true, rowIndex);
        }

        private void tsMnuVslAlerts_Circulars_Click(object sender, EventArgs e)
        {
            CallVslApplication("Circulars_Vsl");
        }


        private void tsMnuAuditInspection_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            string addlParameter = "ALL|-1";
            CallAuditInspectionApplication(vesselID, addlParameter, true, false, rowIndex);
        }

        private void tsMnuNCR_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallNCRApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuTaskList_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallTaskListApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuIncidentReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }
            int colIndex = fpSpread_Particulars.ActiveSheet.ActiveColumnIndex;
            if (colIndex>=COL_INVESTIGATION_REPORT_OVERDUE) CallInvestigationtReportApplication(vesselID, "", true, false, rowIndex);
            else CallIncidentReportApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuAwarenessReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallAwarenessReportApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuMastersReview_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMastersReviewReportCallerApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuMinutesOfSafety_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMinutesOfSafetyReportCallerApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuMonthEndDoc_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMonthEndDocApplication(vesselID, "", true, false, rowIndex);
        }

        private void tsMnuQuarterlyStoresReports_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("QUARTERLYSTORESREPORTS", -1, "");
        }
        private void tsMnuVslCertificate_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallCertificateApplication(vesselID, "", true, false, rowIndex);
        }

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = cboCompany_Filter.Text.ToUpper() + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = cboCompany_Filter.Text.ToUpper() + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            return param;
        }


        private void tsMnuVslUserManagement_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            VslUserMgmt.VslUserMgmtStartup vslUserMgmtStartup;
            try
            {
                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, false);
                vslUserMgmtStartup = new VslUserMgmt.VslUserMgmtStartup(arg.Split(' '));

                if (!vslUserMgmtStartup.isVslInitSuccessfully)
                {
                    return;
                }

                vslUserMgmtStartup.CallUserListPage();
            }
            finally
            {
                vslUserMgmtStartup = null;
            }
        }


        private void CallVslApplication(string exeName)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            string param = GetParam(vesselID, true);

            if (exeName.ToUpper() == "VslForms".ToUpper())
            {
                CallFormsApplication(vesselID, " All|Tech", true, true, "SUPT_FORMS_APPR", rowIndex);
            }
            else if (exeName.ToUpper() == "VslDefects".ToUpper())
            {
                CallDefectsApplication(vesselID, "", false, true, rowIndex);
            }
            else
            {
                if (exeName.ToUpper() == "PmsMain".ToUpper())
                {
                    exeName = "VslDashBoard";
                    param = param + " PmsMain";
                }

                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
            }            
        }

        private void tsmu_VslDashBoard_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            CallVslApplication("VslDashBoard");
        }

        private bool MoveBasicData(int vesselID)
        {
            string[] tableNameToMoveList = new string[] { "V_Staff", "V_Settings", "VUI_GroupItems" };
            bool result = false;
            string script = "";
            try
            {
                // VUI_GroupItems
                script = " select count(*) from VUI_GroupItems  Where VesselID = " + vesselID;
                int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                if (cnt == 0)
                {
                    long VUI_GroupItemsID = PG.GetNextTableId_HQ("VUI_GroupItems");
                    script = " Insert  into VUI_GroupItems( VUI_GroupItemsID, Origin, vesselid, VUI_GroupsID " + Environment.NewLine +
                            "  , RefNo, IsPrgDisabled, ItemDesc, StatusValue, StatusValueColor, ActionButtonColor" + Environment.NewLine +
                            " , V_VslProgsID, Prg, Arg, UserList, Type, MergeItemDescAndStatusValue, SortOrder, zChkNo, ToTrf) " + Environment.NewLine +
                            " select " + VUI_GroupItemsID + " + Row_number() over (order by VUI_GroupItemsID) as VUI_GroupItemsID " + Environment.NewLine +
                            " , 'HQ', " + vesselID + ", VUI_GroupsID, RefNo,IsPrgDisabled,ItemDesc,StatusValue,StatusValueColor,ActionButtonColor " + Environment.NewLine +
                            " ,V_VslProgsID,Prg,Arg,UserList,Type,MergeItemDescAndStatusValue,SortOrder,0 zChkNo,0 ToTrf " + Environment.NewLine +
                            " from VUI_GroupItems V " + Environment.NewLine +
                            " where V.vesselid = -9" + Environment.NewLine +
                            "    and not exists (select * from VUI_GroupItems where vesselid = " + vesselID + " and RefNo = V.RefNo)";
                    PG.Gb.DBFn.Xqry(script);
                }

                // V_Staff
                script = " select count(*) from V_Staff_V  Where IsDisabled=0 and VesselID = " + vesselID;
                cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                if (cnt == 0)
                {
                    long V_StaffID = PG.GetNextTableId_HQ("V_Staff");
                    script = " Insert  into V_Staff( V_StaffID, Origin, VesselID, UserID, UserRank ,UserName, UserDept, JoiningDate, " + Environment.NewLine +
                            "  LeavingDate, CrewID, Password, SortOrder, IsDisabled, zChkNo, ToTrf)" + Environment.NewLine +
                            " select " + V_StaffID + " + Row_number() over (order by V_StaffID) as V_StaffID " + Environment.NewLine +
                            " , 'HQ', " + vesselID + ",UserID, UserRank ,UserName, UserDept, JoiningDate" + Environment.NewLine +
                            " , LeavingDate, CrewID, Password, SortOrder, IsDisabled, 0 zChkNo,0 ToTrf " + Environment.NewLine +
                            " from V_Staff_V V " + Environment.NewLine +
                            " where V.IsDisabled=0 and  V.vesselid = -9" + Environment.NewLine +
                            "    and not exists (select * from V_Staff_V where vesselid = " + vesselID + " and UserRank = V.UserRank)";
                    PG.Gb.DBFn.Xqry(script);
                }

                //  V_Settings
                script = " select count(*) from V_Settings  Where VesselID = " + vesselID;
                cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                if (cnt == 0)
                {
                    long V_SettingsID = PG.GetNextTableId_HQ("V_Settings");
                    script = " Insert  into V_Settings( V_SettingsID,Origin,VesselID,SettingName,Description,SettingType,SettingValue,DefaultValue,SortOrder,zChkNo,ToTrf)" + Environment.NewLine +
                            " select " + V_SettingsID + " + Row_number() over (order by V_SettingsID) as V_SettingsID " + Environment.NewLine +
                            " , 'HQ', " + vesselID + ", SettingName,Description,SettingType,SettingValue,DefaultValue,SortOrder,0 zChkNo,0 ToTrf" + Environment.NewLine +
                            " from V_Settings V " + Environment.NewLine +
                            " where V.vesselid = -9" + Environment.NewLine +
                            "    and not exists (select * from V_Settings where vesselid = " + vesselID + " and SettingName = V.SettingName)";
                    PG.Gb.DBFn.Xqry(script);
                }

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "MoveBasicDataFromHQTableToNewDB", " Error:" + err.Message);
            }
            finally
            {
            }
            return (result);
        }

        private void tsm_VslSpares_Click(object sender, EventArgs e)
        {
            CallVslApplication("Spares");
        }

        private void tsm_VslStores_Click(object sender, EventArgs e)
        {
            CallVslApplication("Stores");
        }

        private void tsm_VslPMS_Click(object sender, EventArgs e)
        {
            CallVslApplication("PMSmain");
        }

        private void tsm_VslDefects_Click(object sender, EventArgs e)
        {
            CallVslApplication("VslDefects");
        }

        private void tsm_VslEngineData_Click(object sender, EventArgs e)
        {
            Gfn.Mb("Not yet implemented");
            CallVslApplication("");
        }

        private void btnNcr_Click(object sender, EventArgs e)
        {
            frmMainForm_NCR objMainFormNCR = new frmMainForm_NCR();
            try
            {
                objMainFormNCR.formLeft = btnNcr.Left - 380 - 150 + 50;
                objMainFormNCR.formTop = btnNcr.Top + 50;
                objMainFormNCR.ShowDialog();

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                PG.InitialiseCommonSettings(companyID);
            }
            finally
            {
                objMainFormNCR = null;
            }
        }

        private void tsm_VslNoonLog_Click(object sender, EventArgs e)
        {
            Gfn.Mb("Not yet implemented");
            CallVslApplication("");
        }

        private void tsm_VslForms_Click(object sender, EventArgs e)
        {
            calledFrom = "";
            CallVslApplication("VslForms");
        }

        private void tsm_CorrectiveMaintenance_Click(object sender, EventArgs e)
        {
            CallVslApplication("CorrMaint");
        }

        private void tsMnuDocumentManagement_Click(object sender, EventArgs e)
        {
            CallVslApplication("DocMgmt");
        }

        private void tsMnuKPITrendingForVsl_NonCriticalMaint_Click(object sender, EventArgs e)
        {
            CallKPITrendingForSingleVessel("MENU_NONCRITICAL_MAINT");
        }

        private void tsMnuKPITrendingForVsl_CriticalMaint_Click(object sender, EventArgs e)
        {
            CallKPITrendingForSingleVessel("MENU_CRITICAL_MAINT");
        }

        private void tsMnuKPITrendingForVsl_CriticalEqp_Click(object sender, EventArgs e)
        {
            CallKPITrendingForSingleVessel("MENU_CRITICAL_EQP");
        }

        private void tsMnuKPITrendingForVsl_NonCriticalEqp_Click(object sender, EventArgs e)
        {
            CallKPITrendingForSingleVessel("MENU_NONCRITICAL_EQP");
        }

        private void tsMnukPITrendingForVsl_All_Click(object sender, EventArgs e)
        {
            CallKPITrendingForSingleVessel("MENU_ALL");
        }

        private void CallKPITrendingForSingleVessel(string calledMode)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());

            CallKPITrendingPage(calledMode, vesselID);
        }


        private void tsMnuDefectTrendingEquipmentWise_SingleVsl_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());

            CallHQTrendingApplication("DFTrending", vesselID, "MENU_VESSELSPECIFIC");
        }

        private void tsMnuRefreshforSelectedVessel_Click(object sender, EventArgs e)
        {
            int vesselID = -1;
            try
            {
                int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                if (fpSpread_Particulars.ActiveSheet.ActiveCell == null) return;

                vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
                calledFrom = "";

                RefreshHQDashboardForThisVessel(vesselID);
                cboVslFilter_SelectedIndexChanged(null, null);

                FocusSelectedVessel(vesselID);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "tsMnuRefreshforSelectedVessel_Click", " Error:" + err.Message);
            }
            finally
            {
                panelLoading.Visible = false;
                Application.DoEvents();
            }
        }


        private void FocusSelectedVessel(int vesselID)
        {
            for (int row = 0; row < fpSpread_Particulars.ActiveSheet.RowCount; row++)
            {
                int curVesselID = -1;
                if (fpSpread_Particulars.ActiveSheet.Cells[row, COL_FLEET_VESSELID].Value != null) curVesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[row, COL_FLEET_VESSELID].Value);
                if (curVesselID == vesselID)
                {
                    fpSpread_Particulars.ActiveSheet.SetActiveCell(row, 0);
                    int topRow = row;
                    if (topRow > 10) topRow = topRow - 10;
                    fpSpread_Particulars.SetViewportTopRow(0, topRow);

                    fpSpread_Particulars.ActiveSheet.Rows[row].BackColor = fpSpread_Particulars.ActiveSheet.SelectionBackColor;
                    fpSpread_Particulars.ActiveSheet.Cells[row, COL_FLEET_VESSELID].BackColor = fpSpread_Particulars.ActiveSheet.SelectionBackColor;
                    break;
                }
            }
        }

       

        private void tsMnuExportXLParticulars_Click(object sender, EventArgs e)
        {
            if (fpSpread_Particulars.ActiveSheet.RowCount <= 0)
            {
                Gfn.Mb("No records to export");
                return;
            }

            DateTime todaysDate = PG.GetDbServerDate();
            string fileName = PG.xlsOutputFolderPath + "\\Particulars_" + todaysDate.ToString("ddMMMyyyy_hhmmssff") + ".xls";
            if (!Gfn.DeleteFileIfExists(fileName)) return;

            fpSpread_Particulars.ActiveSheet.Protect = false;
            try
            {
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].Add();
                fpSpread_Particulars.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fpSpread_Particulars.ActiveSheet.ColumnCount);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0].Text = PG.companyName;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 14, FontStyle.Bold);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].ForeColor = Color.Black;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[1].Add();
                DictionaryEntry dictionary = (DictionaryEntry)cboVslFilter.SelectedItem;
                string companyText = "Company : " + ((DictionaryEntry)cboVslFilter.SelectedItem).Key.ToString();
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, 0].Text = "Vessel Particulars      (" + dictionary.Key.ToString() + ")    " + companyText;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, 0].ForeColor = Color.Blue;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 12, FontStyle.Bold);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, 0].ColumnSpan = COL_SEPARATOR_SPARES;// fpSpread_Particulars.ActiveSheet.ColumnCount - 1;

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_SEPARATOR_SPARES].ColumnSpan = fpSpread_Particulars.ActiveSheet.ColumnCount - COL_SEPARATOR_SPARES;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_SEPARATOR_SPARES].Text = "Date: " + todaysDate.ToString("dd-MMM-yyyy");
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[1, COL_SEPARATOR_SPARES].Font = new Font("Arial", 12, FontStyle.Bold);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[1].Height = 30;

                bool hasExportedSuccessfully = (fpSpread_Particulars.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to export  -- " + err.Message);
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "ExportParticulars()", err.Message);
            }
            finally
            {
                if (fpSpread_Particulars.ActiveSheet.ColumnHeader.RowCount > 2) fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows.Remove(0, 1);
                if (fpSpread_Particulars.ActiveSheet.ColumnHeader.RowCount > 2) fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows.Remove(0, 1);
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].Height = 35;
                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[1].Height = 55;
            }
            fpSpread_Particulars.ActiveSheet.Protect = true;
        }

        private void templatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("Templates", -1, "");
        }

        private void tsMnuCurrenctXRate_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("CurrenctXRate", -1, "");
        }

        private void tsMnuUOMList_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("UOMLIST", -1, "");
        }

        private void tsMnuManageUserAndVsls_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("USERVESSELSELECTION", -1, "");
        }

        private void tsMnuFormsVesselSelection_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("FORMSVESSELSELECTION", -1, "");            
        }

        private void tsMnuFormsDesigner_Click(object sender, EventArgs e)
        {
            CallFormsDesignerApplication("", -1, "");
        }

        private void tsMnuSetup_StoresItemMaster_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("STORESITEMMASTER", -1, "");
        }

        private void tsMnuDelivLocationsManagement_Click(object sender, EventArgs e)
        { 
            CallSettingMgmtApplication("DELIVLOCATION", -1, "");
        }

        private void tsMnuClients_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("CLIENTS", -1, "");
        }

        private void tsMnuLegalEntity_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("LEGALENTITY", -1, "");
        }

        private void tsMnuCurrencyManagement_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("CURRENCYMGMT", -1, "");
        }

        private void tsMnuAll_HQ_VSLSettings_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("ALLSETTING", -1, "");
        }

        private void tsMnuUserSignManagement_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("USERSIGNATUREMGMT", -1, "");
        }

        private void tsMnuUserAppRestrictions_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("USERAPPRESTRICTION", -1, "");
        }

        private void tsMnuHoliDaysManagement_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("HOLIDAYMGMT", -1, "");
        }

        private void tsMnuAgressoReinterface_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("AGRESSOREINTERFACE", -1, "");
        }

        private void tsMnuVendorLinks_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("VENDORLINKS", -1, "");
        }

        private void tsMnuApplicationChangeDetails_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("APPLICATIONCHANGEDETAILS ", -1, "");
        }

        private void tsMnuUpdateDMSCompany_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("UPDATEDMSCOMPANY", -1, "");
        }

        private void tsMnuVesselOperationModeSetup_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("UPDATEOPSMODE", -1, "");
        }

        private void tsMnuSetupProcurementInterface_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("PROCUREMENTINTERFACE", -1, "");
        }

        private void tsMnuClearCefCache_Click(object sender, EventArgs e)
        {
            try
            {
                string script = " Update HQ_UserUID set ClearCefCache=1 where isnull(ClearCefCache,0)=0 ";
                PG.Gb.DBFn.Xqry(script);

                Gfn.Mb("Cache cleared successfully");
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "tsMnuClearCefCache_Click", err.Message);
            }
        }


        private void tlsMnuRootCauseAnalysisChartSetup_Click(object sender, EventArgs e)
        {
            string exeName = "MSCat_SetUp";
            string param = GetParam(-1, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tlsMnuAuditInspectionSetup_Click(object sender, EventArgs e)
        {
            string exeName = "AuditInspectionSetUp";
            string param = GetParam(-1, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tsSparesBlankTemplateMnu_Click(object sender, EventArgs e)
        {
            PG.ViewProc_TemplateFile("Template_SP_Creating_Reqn", "SP", "Spares");
        }

        private void tsStoresBlankTemplateMnu_Click(object sender, EventArgs e)
        {
            PG.ViewProc_TemplateFile("Template_ST_Creating_Reqn", "ST", "Stores");
        }

        private void tsRRBlankTemplateMnu_Click(object sender, EventArgs e)
        {
            PG.ViewProc_TemplateFile("Template_RR_Creating_Reqn", "RR", "Service");
        }


        private void tsMnuKPITrendingForFleet_NonCriticalMaint_Click(object sender, EventArgs e)
        {
            CallKPITrendingPage("NONCRITICAL_MAINT", -1);
        }

        private void tsMnuKPITrendingForFleet_CriticalMaint_Click(object sender, EventArgs e)
        {
            CallKPITrendingPage("CRITICAL_MAINT", -1);
        }

        private void tsMnuKPITrendingForFleet_NonCriticalEqp_Click(object sender, EventArgs e)
        {
            CallKPITrendingPage("NONCRITICAL_EQP", -1);
        }

        private void tsMnuKPITrendingForFleet_CriticalEqp_Click(object sender, EventArgs e)
        {
            CallKPITrendingPage("CRITICAL_EQP", -1);
        }

        private void mnukPITrendingForFleet_All_Click(object sender, EventArgs e)
        {
            CallKPITrendingPage("ALL", -1);
        }

        private void CallKPITrendingPage(string addlCalledMode, int vesselID)
        {
            CallHQTrendingApplication("KPITrending", vesselID, addlCalledMode);
        }

        private void tsMnuDefectTrending_AllVsls_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("DFTrending", -1, "MENU_ALLVESSEL");
        }

        private void tsMnuDefectsVestsMnuDelAvailabilityKPI_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("DFVesselAvailabilityTrending", -1, "MENU_ALLVESSEL");
        }

        private void tsMnuDTFCurrentStatus_Click(object sender, EventArgs e)
        {
            frmDTFCurrentStatus objDTFCurrentStatus = new frmDTFCurrentStatus();
            try
            {
                objDTFCurrentStatus.ShowDialog();
            }
            finally
            {
                objDTFCurrentStatus = null;
            }
        }

        private void tsMnuDTFHistory_Click(object sender, EventArgs e)
        {
            frmDTFHistory objDTFHistory = new frmDTFHistory();
            try
            {
                objDTFHistory.ShowDialog();
            }
            finally
            {
                objDTFHistory = null;
            }
        }

        private void tsMnuDTFTrending_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("DTFTrending", -1, "");
        }

        private void tsMnuSparesPOsNotSubmitForRFQMoreThan3Days_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("ProcurementKPI", -1, "NOTSUBMITFORRFQ");
        }

        private void tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("ProcurementKPI", -1, "NOTSUBMITFORSUPT");
        }

        private void tsMnuNCRTrending_Click(object sender, EventArgs e)
        {
            CallHQTrendingApplication("NCRTrending", -1, "");
        }

        private void CallHQTrendingApplication(string trendingCalledMode, int vesselID, string addlCalledMode)
        {
            string exeName = "HQ_Trendings";
            string param = GetParam(-1, false);
            string addlParam = trendingCalledMode + "|" + vesselID.ToString();
            if (addlCalledMode.Trim().Length > 0) addlParam = addlParam + "|" + addlCalledMode;
            param = param + " " + addlParam;
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void CallFormsDesignerApplication(string FormsDesignerCalledMode, int vesselID, string addlCalledMode)
        {
            string exeName = "FarPoint_Designer";
            string param = GetParam(-1, false);
            string addlParam = FormsDesignerCalledMode + "|" + vesselID.ToString();
            if (addlCalledMode.Trim().Length > 0) addlParam =  addlParam + "|" + addlCalledMode;
            param = param + " AUTO" + " " + addlParam;
            Gfn.ExecuteApp(@"C:\WinSDS\Common\HQFormsDesigner", exeName, param, -1, PG.Gb.DBFn);
        }

        private void CallSettingMgmtApplication(string settingCalledMode, int vesselID, string addlCalledMode)
        {
            string exeName = "SettingsManagement";
            string param = GetParam(-1, false);
            string addlParam = settingCalledMode + "|" + vesselID.ToString();
            if (addlCalledMode.Trim().Length > 0) addlParam =  addlParam + "|" + addlCalledMode;
            param = param + " AUTO" + " " + addlParam;
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void ExportXL(int vesselId, string calledMode)
        {
            XlsFile xls = null;
            FlexCelReport report = new FlexCelReport();
            DataSet ds = new DataSet();
            DataTable dtQueryResults;
            string script, addlFields;

            try
            {
                addlFields = "    , isnull(( select case when (IsForNoGroup =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsCriticalSpares " +
                             "    , 0 as IsForSafety, 0 as IsForOperational, 0 as IsForEnvironment " + Environment.NewLine;
                if (PG.isCriticalSparesGroups)
                {
                    addlFields = "    , 0 as IsCriticalSpares, isnull(( select  case when (IsForSafety =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForSafety " + Environment.NewLine +
                                 "    , isnull(( select case when (IsForOperational =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForOperational " + Environment.NewLine +
                                 "    , isnull(( select case when (IsForEnvironment =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForEnvironment " + Environment.NewLine;
                }

                script = " select distinct 0 as LineItemNo, E.GroupName, E.GroupSortOrder, E.SortCode, EqpName  " + Environment.NewLine +
                         "    , AssemblyName, ItemDetail, MakerCode, M.DwgNo, UOM, ROB, WkgQty, MinQty, MaxQty, M.Origin, ItemCode, M.Proc_ItemMasterID, Location, LocationDetails, M.Maker, M.Model, M.SerialNo, M.Unique_Name " +
                         addlFields +
                         " from EQ_Equipment_V E, EQ_Units U, Proc_ItemMaster_V M, Proc_Inventory I " + Environment.NewLine +
                         " where E.EQ_EquipmentID=U.EQ_EquipmentID " + Environment.NewLine +
                         "    and U.IsDisabled=0 and U.VesselID = M.VesselID and U.EqpType=M.EqpType and U.EqpSubType=M.EqpSubType and U.EQ_ModelsID=M.EQ_ModelsID " + Environment.NewLine +
                         "    and M.VesselID = I.VesselID and M.Proc_ItemMasterID=I.Proc_ItemMasterID" + Environment.NewLine +
                         "    and E.GroupType=" + Gfn.Qss(PG.defaultEqpGroup) + Environment.NewLine +
                         "    and I.VesselID=" + vesselId + Environment.NewLine +
                         "    and M.IsCritical=1  " +
                         "     and (Case when (E.GroupCode='" + PG.EQUIPMENT_GROUPCODE_CRITICAL + "') then (select COUNT(*) from Eq_Equipment_V where EQ_EquipmentID=E.EQ_EquipmentID " +
                         "            and GroupType=E.GroupType and GroupCode<>E.GroupCode) else 0 end)=0 " +
                         " Order by E.GroupSortOrder, E.SortCode, M.Proc_ItemMasterID";
                dtQueryResults = PG.Gb.DBFn.DbRecords(script);

                if (dtQueryResults == null)
                {
                    Gfn.nMbwithAlignAndCentrePosn("There is no records to Export.", ContentAlignment.MiddleCenter, 110, 250);
                    return;
                }
                if (dtQueryResults.Rows.Count == 0)
                {
                    Gfn.nMbwithAlignAndCentrePosn("There is no records to Export.", ContentAlignment.MiddleCenter, 110, 250);
                    return;
                }

                for (int i = 0; i < dtQueryResults.Rows.Count; i++)
                {
                    dtQueryResults.Rows[i]["LineItemNo"] = i + 1;
                }
                dtQueryResults.TableName = "DT";

                //Load template
                string rptName = "SP_Critical_Flat_SparesList_Template.xls";

                string strFileDir = PG.Gb.WinSdsTempDir + "\\Templates\\";
                if (!Directory.Exists(strFileDir)) { Directory.CreateDirectory(strFileDir); }

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string templateFileName = PG.DownloadApp_Template(rptName, companyID);

                DateTime todayDate = PG.GetDbServerDate();
                xls = new XlsFile(templateFileName, true);

                string companyName = PG.companyName;
                string title1 = PG.Gb.DBFn.Aqr("Select VslName from V_Vessels where vesselID=" + vesselId).ToString();
                string title2 = "List of Critical Spares";
                title1 = title1 + " - Critical Spares List";

                report.SetValue("CompanyName", companyName);
                report.SetValue("Title1", title1);
                report.SetValue("Title2", title2);
                report.SetValue("TotalItems", "Total Spare Part(s): " + dtQueryResults.Rows.Count);
                report.SetValue("Date", "Date: " + todayDate.ToString("dd-MMM-yyyy"));

                if (calledMode.Trim().ToUpper() == "CRITICAL")
                {
                    if (PG.enableCriticalSparesFeature)
                    {
                        if (!PG.isCriticalSparesGroups)
                        {
                            xls.SetColHidden(4, false);
                            xls.SetColHidden(5, true);
                            xls.SetColHidden(6, true);
                            xls.SetColHidden(7, true);
                        }
                        else
                        {
                            xls.SetColHidden(4, true);
                            xls.SetColHidden(5, false);
                            xls.SetColHidden(6, false);
                            xls.SetColHidden(7, false);
                        }
                    }
                    xls.SetColHidden(8, (PG.isToHideEquipmentAssembly));
                    xls.SetColHidden(14, (PG.isToHideSparesWkg_Qty));
                    xls.SetColHidden(15, (PG.isToHideSparesMinQty));
                    xls.SetColHidden(16, (PG.isToHideSparesMaxQty));
                }
                else
                {
                    xls.SetColHidden(4, (PG.isToHideEquipmentAssembly));
                    xls.SetColHidden(10, (PG.isToHideSparesWkg_Qty));
                    xls.SetColHidden(11, (PG.isToHideSparesMinQty));
                    xls.SetColHidden(12, (PG.isToHideSparesMaxQty));
                }

                ds.Tables.Add(dtQueryResults.Copy());
                report.AddTable(ds);
                report.Run(xls);

                TSheetProtectionOptions SheetProtectionOptions = new TSheetProtectionOptions(false);
                SheetProtectionOptions.SelectLockedCells = true;
                SheetProtectionOptions.SelectUnlockedCells = true;
                xls.Protection.SetSheetProtection(null, SheetProtectionOptions);

                // save xls 
                string sx = "Critical_Spares_List";
                if (calledMode.Trim().ToUpper() == "ALL") sx = "Equipment_Spares_List";
                string outputFileName = PG.xlsOutputFolderPath + "\\" + PG.Gb.Companycode + "_" + sx + "_" + PG.Gb.Vsl.CurVslCode + "_" + todayDate.ToString("ddMMMyy_HHmmssff") + ".xls";

                try
                {
                    xls.Save(outputFileName);

                    System.Diagnostics.Process.Start(outputFileName);
                }
                catch (Exception err)
                {
                    Gfn.Eb(err.Message);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "ExportXL", err.Message);
                Gfn.Eb(err.Message);
            }
            finally
            {
                dtQueryResults = null;
                xls = null;
            }
        }

        private void ExportXL_EquipmentWise(int vesselId)
        {
            XlsFile xls = null;
            FlexCelReport report = new FlexCelReport();
            DataSet ds = new DataSet();
            DataTable dtEquipment, dtQueryResults, dtMakerModel;
            string script;
            try
            {
                string script1 = " Select distinct U.EQ_EquipmentID,  E.EqpName " + Environment.NewLine +
                                 "  ,  (select top 1 GroupSortOrder from EQ_Equipment_V  where EQ_EquipmentID=U.EQ_EquipmentID) as GroupSortOrder  " + Environment.NewLine +
                                 " from EQ_Equipment_V E, EQ_Units U, Proc_ItemMaster_V M, Proc_Inventory I  " + Environment.NewLine +
                                 " where E.EQ_EquipmentID=U.EQ_EquipmentID  " + Environment.NewLine +
                                 "    and U.IsDisabled=0 and U.VesselID = M.VesselID and U.EqpType=M.EqpType and U.EqpSubType=M.EqpSubType and U.EQ_ModelsID=M.EQ_ModelsID  " + Environment.NewLine +
                                 "    and M.VesselID = I.VesselID and M.Proc_ItemMasterID=I.Proc_ItemMasterID " + Environment.NewLine +
                                 "    and U.EQ_ModelsID > 0 " + Environment.NewLine +
                                 "    and I.VesselID=" + vesselId + Environment.NewLine +
                                 "    and M.IsCritical=1   " + Environment.NewLine +
                                 "    and E.GroupType=" + Gfn.Qss(PG.defaultEqpGroup) + Environment.NewLine +
                                 " order by 3 ";
                dtEquipment = PG.Gb.DBFn.DbRecords(script1);

                if (dtEquipment == null)
                {
                    Gfn.nMbwithAlignAndCentrePosn("There is no records to Export.", ContentAlignment.MiddleCenter, 110, 250);
                    return;
                }
                if (dtEquipment.Rows.Count == 0)
                {
                    Gfn.nMbwithAlignAndCentrePosn("There is no records to Export.", ContentAlignment.MiddleCenter, 110, 250);
                    return;
                }

                string addlFields = "";
                DateTime todayDate = PG.GetDbServerDate();

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                // Load template
                string rptName = "SP_Critical_SparesList_Template.xls";
                string templateFileName = PG.DownloadApp_Template(rptName, companyID);

                xls = new XlsFile(templateFileName, true);

                if (!PG.isCriticalSparesGroups)
                {
                    addlFields = "    ,  isnull(( select  case when (IsForNoGroup =1) then 'Yes' else ' ' end   from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsCriticalSpares " + Environment.NewLine +
                                 "    ,  0 as IsForSafety , 0 as IsForOperational ,  0 as IsForEnvironment " + Environment.NewLine;
                }
                else
                {
                    addlFields = "    ,  0 as IsCriticalSpares , isnull(( select  case when (IsForSafety =1) then 'Yes' else ' ' end  from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForSafety " + Environment.NewLine +
                                 "    ,  isnull(( select case when (IsForOperational =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForOperational " + Environment.NewLine +
                                 "    ,  isnull(( select case when (IsForEnvironment =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForEnvironment " + Environment.NewLine;
                }

                script = " select distinct 0 as LineItemNo, U.Eq_EquipmentID, U.EQ_ModelsID, E.EqpName " + Environment.NewLine +
                         "    , E.GroupName, E.GroupSortOrder, E.SortCode " + Environment.NewLine +
                         "    , AssemblyName, ItemDetail, MakerCode, M.DwgNo, UOM, ROB, WkgQty, MinQty, MaxQty, M.Origin, ItemCode, M.Proc_ItemMasterID, Location, LocationDetails, M.Maker, M.Model, M.SerialNo, M.Unique_Name " + Environment.NewLine +
                         addlFields +
                         " from EQ_Equipment_V E, EQ_Units U, Proc_ItemMaster_V M, Proc_Inventory I " + Environment.NewLine +
                         " where E.EQ_EquipmentID=U.EQ_EquipmentID " + Environment.NewLine +
                         "    and U.IsDisabled=0 and U.VesselID = M.VesselID and U.EqpType=M.EqpType and U.EqpSubType=M.EqpSubType and U.EQ_ModelsID=M.EQ_ModelsID " + Environment.NewLine +
                         "    and M.VesselID = I.VesselID and M.Proc_ItemMasterID=I.Proc_ItemMasterID" + Environment.NewLine +
                         "    and I.VesselID=" + vesselId + Environment.NewLine +
                         "    and E.GroupType = " + Gfn.Qss(PG.defaultEqpGroup) + Environment.NewLine +
                         "    and M.IsCritical=1  " + Environment.NewLine +
                         "    and U.EQ_ModelsID > 0 " + Environment.NewLine +
                         "     and (Case when (E.GroupCode='" + PG.EQUIPMENT_GROUPCODE_CRITICAL + "') then (select COUNT(*) from Eq_Equipment_V where EQ_EquipmentID=E.EQ_EquipmentID " +
                         "            and GroupType=E.GroupType and GroupCode<>E.GroupCode) else 0 end)=0 " +
                         " order by  E.GroupSortOrder, E.SortCode,  U.EQ_ModelsID, M.Proc_ItemMasterID ";
                dtQueryResults = PG.Gb.DBFn.DbRecords(script);

                string prevEqpModelID = "";
                if (dtQueryResults != null && dtQueryResults.Rows.Count > 0)
                {
                    int lineNum = 0;
                    foreach (DataRow dr in dtQueryResults.Rows)
                    {
                        string sx = dr["EQ_EquipmentID"] + " " + dr["EQ_ModelsID"].ToString();
                        if (prevEqpModelID.Trim() != sx.Trim())
                        {
                            lineNum = 1;
                            prevEqpModelID = sx;
                        }
                        dr["LineItemNo"] = lineNum;
                        lineNum = lineNum + 1;
                    }
                }

                script = " select Distinct (E.EqpName + ',Maker: ' + MR.Maker +',Model: '  + ML.Model) as EqpModelMaker, U.Eq_EquipmentID, U.EQ_ModelsID " + Environment.NewLine +
                         " from EQ_Equipment_V E, EQ_Units U, EQ_Models ML, EQ_Makers MR, Proc_ItemMaster_V M " + Environment.NewLine +
                         " where E.EQ_EquipmentID=U.EQ_EquipmentID  and U.EQ_ModelsID = ML.EQ_ModelsID " + Environment.NewLine +
                         "    and ML.EQ_MakersID = MR.EQ_MakersID " + Environment.NewLine +
                         "    and U.IsDisabled=0 and U.VesselID = M.VesselID and U.EqpType=M.EqpType and U.EqpSubType=M.EqpSubType and U.EQ_ModelsID=M.EQ_ModelsID  " + Environment.NewLine +
                         "    and E.GroupType = " + Gfn.Qss(PG.defaultEqpGroup) + Environment.NewLine +
                         "    and U.VesselID= " + vesselId + Environment.NewLine +
                         "    and E.IsTitle = 0 " + Environment.NewLine +
                         "    and M.IsCritical=1   " + Environment.NewLine +
                         "    and U.EQ_ModelsID > 0 " + Environment.NewLine +
                         "  order by U.EQ_EquipmentID, U.EQ_ModelsID ";
                dtMakerModel = PG.Gb.DBFn.DbRecords(script);

                dtEquipment.TableName = "EquipmentName";
                dtMakerModel.TableName = "DTModel";
                dtQueryResults.TableName = "DT";

                ds.Tables.Add(dtEquipment.Copy());
                ds.Tables.Add(dtQueryResults.Copy());
                ds.Tables.Add(dtMakerModel.Copy());

                DataRelation relationMasterDetails1, relationMasterDetails2, relationMasterDetails3;
                relationMasterDetails1 = new DataRelation("EquipmenModel", ds.Tables["EquipmentName"].Columns["Eq_EquipmentID"], ds.Tables["DTModel"].Columns["Eq_EquipmentID"], false);
                ds.Relations.Add(relationMasterDetails1);

                relationMasterDetails3 = new DataRelation("ModelSpares", ds.Tables["EquipmentName"].Columns["Eq_EquipmentID"], ds.Tables["DT"].Columns["Eq_EquipmentID"], false);
                ds.Relations.Add(relationMasterDetails3);

                relationMasterDetails2 = new DataRelation("EquipmentSpares",
                        new DataColumn[] { ds.Tables["DTModel"].Columns["Eq_EquipmentID"], ds.Tables["DTModel"].Columns["EQ_ModelsID"] },
                        new DataColumn[] { ds.Tables["DT"].Columns["Eq_EquipmentID"], ds.Tables["DT"].Columns["EQ_ModelsID"] }, false);
                ds.Relations.Add(relationMasterDetails2);

                string companyName = PG.companyName;
                string title1 = PG.Gb.DBFn.Aqr("Select VslName from V_Vessels where vesselID=" + vesselId).ToString();
                title1 = title1 + " - Critical Spares List";

                report.SetValue("CompanyName", companyName);
                report.SetValue("Title1", title1);
                report.SetValue("Date", "Date: " + todayDate.ToString("dd-MMM-yyyy"));

                if (PG.enableCriticalSparesFeature)
                {
                    if (!PG.isCriticalSparesGroups)
                    {
                        xls.SetColHidden(4, false);
                        xls.SetColHidden(5, true);
                        xls.SetColHidden(6, true);
                        xls.SetColHidden(7, true);
                    }
                    else
                    {
                        xls.SetColHidden(4, true);
                        xls.SetColHidden(5, false);
                        xls.SetColHidden(6, false);
                        xls.SetColHidden(7, false);
                    }
                }

                xls.SetColHidden(14, (PG.isToHideSparesWkg_Qty));
                xls.SetColHidden(15, (PG.isToHideSparesMinQty));
                xls.SetColHidden(16, (PG.isToHideSparesMaxQty));

                report.AddTable(ds);
                report.Run(xls);

                TSheetProtectionOptions SheetProtectionOptions = new TSheetProtectionOptions(false);
                SheetProtectionOptions.SelectLockedCells = true;
                SheetProtectionOptions.SelectUnlockedCells = true;
                xls.Protection.SetSheetProtection(null, SheetProtectionOptions);


                if (xls.SheetCount <= 0)
                {
                    Gfn.nMb("There is no records to Export.");
                    return;
                }

                xls.Save(templateFileName);
                System.Diagnostics.Process.Start(templateFileName);
            }
            catch (Exception err)
            {
                Gfn.Eb(err.Message);
                PG.AddToGenErrorLog("frmMainForm_Tech.cs", "ExportXL_EquipmentWise", err.Message);
            }
            finally
            {
                dtQueryResults = null;
                dtMakerModel = null;
                dtEquipment = null;
            }
        }

        private void tsMnuEquipmentSparesList_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            PG.InitialiseVesselSettings(vesselID);
            ExportXL(vesselID, "ALL");
        }

        private void tsMnuAllCriticalSparesItems_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            PG.InitialiseVesselSettings(vesselID);
            ExportXL(vesselID, "CRITICAL");
        }

        private void tsMnuEquipmentWiseCriticalSparesItems_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            PG.InitialiseVesselSettings(vesselID);
            ExportXL_EquipmentWise(vesselID);
        }

        private void tsMnuExportEquipmentParticulars_Click(object sender, EventArgs e)
        {
            frmExportEquipmentList exportEqp = new frmExportEquipmentList();
            try
            {
                int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
                string vslName = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_VSLNAME].Value.ToString();
                string groupType = PG.GetDefaultGroupType(vesselID);

                exportEqp.groupType = groupType.ToUpper();
                exportEqp.calledMode = "PARTICULARS";
                exportEqp.vesselID = vesselID;
                exportEqp.vslName = vslName.ToString();
                exportEqp.btnEqpParticulars_SaveToXL_Click(null, null);
            }
            finally
            {
                exportEqp = null;
            }
        }

        private void tsMnuExportEquipmentUnitParticulars_Click(object sender, EventArgs e)
        {
            frmExportEquipmentList exportEqp = new frmExportEquipmentList();
            try
            {
                int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
                string vslName = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_VSLNAME].Value.ToString();
                string groupType = PG.GetDefaultGroupType(vesselID);

                exportEqp.groupType = groupType.ToUpper();
                exportEqp.vesselID = vesselID;
                exportEqp.vslName = vslName.ToString();
                exportEqp.btnEqpUnit_SaveToXL_Click(null, null);
            }
            finally
            {
                exportEqp = null;
            }
        }

        private void tsMnuWithoutCheckList_Click(object sender, EventArgs e)
        {
            frmExportEquipmentList exportEqp = new frmExportEquipmentList();
            try
            {
                int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
                string vslName = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_VSLNAME].Value.ToString();
                string groupType = PG.GetDefaultGroupType(vesselID);

                exportEqp.groupType = groupType.ToUpper();
                exportEqp.calledMode = "PMSITEMS";
                exportEqp.vesselID = vesselID;
                exportEqp.vslName = vslName.ToString();
                exportEqp.btnSaveToXL_Click(null, null);
            }
            finally
            {
                exportEqp = null;
            }
        }

        private void tsMnuPMSItemsWithCheckList_Click(object sender, EventArgs e)
        {
            frmExportEquipmentList exportEqp = new frmExportEquipmentList();
            try
            {
                int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
                string vslName = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_VSLNAME].Value.ToString();
                string groupType = PG.GetDefaultGroupType(vesselID);

                exportEqp.groupType = groupType.ToUpper();
                exportEqp.calledMode = "PMSITEMSWITHCHECKLIST";
                exportEqp.vesselID = vesselID;
                exportEqp.vslName = vslName.ToString();
                exportEqp.btnSaveToXL_Click(null, null);
            }
            finally
            {
                exportEqp = null;
            }
        }

        private void tsMnupmsReports_Click(object sender, EventArgs e)
        {
            frmPMSReports exportEqp = new frmPMSReports();
            try
            {
                int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
                string vslName = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_VSLNAME].Value.ToString();
                string groupType = PG.GetDefaultGroupType(vesselID);

                exportEqp.groupType = groupType.ToUpper();
                exportEqp.vesselID = vesselID;
                exportEqp.vslName = vslName.ToString();
                exportEqp.ShowDialog();
            }
            finally
            {
                exportEqp = null;
            }
        }

        private void tsMnuDTFDataTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread_Particulars.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            int vesselID = Convert.ToInt32(fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_FLEET_VESSELID].Value.ToString());
            string opsby = fpSpread_Particulars.ActiveSheet.Cells[rowIndex, COL_OPERATEBY].Value.ToString();
            if (opsby == "HQ")
            {
                Gfn.Mb("This vessel is operate by HQ" + Environment.NewLine);
                return;
            }

            frmDTFHistory objDTFHistory = new frmDTFHistory();
            try
            {
                objDTFHistory.callMode = "DTF";
                objDTFHistory.vslId = vesselID;
                objDTFHistory.companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) objDTFHistory.companyID = cboCompany_Filter.SelectedValue.ToString();
                objDTFHistory.operateBy = opsby;

                objDTFHistory.ShowDialog();
            }
            finally
            {
                objDTFHistory = null;
            }
        }

        private void tsMnuSettingManagement_Click(object sender, EventArgs e)
        {
            string exeName = "SettingsManagement";
            string param = GetParam(-1, false);
            param = param + " AUTO";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

       

        private void tsMnuMonthEndDocumentReport_Click(object sender, EventArgs e)
        {
            frmMonthEndDoc obj = new frmMonthEndDoc();
            try
            {
                obj.ShowDialog();
            }
            finally
            {
                obj = null;
            }
        }


        private void tsMnuManualSync_BigBlobs_Click(object sender, EventArgs e)
        {
            frmManualSync obj = new frmManualSync();
            try
            {
                obj.ShowDialog();
            }
            finally
            {
                obj = null;
            }
        }

        private void tsMnuHQCirculars_Click(object sender, EventArgs e)
        {
            string calledMode = "", addlCalledMode = "", vesselID = "-1";
            string exeName = "Circulars_Mgmt";
            string param = GetParam(-1, false);
            string addlParam = calledMode + "|" + vesselID.ToString();
            if (addlCalledMode.Trim().Length > 0) addlParam = addlParam + "|" + addlCalledMode;
            param = param + " AUTO" + " " + addlParam;
            Gfn.ExecuteApp(@"C:\WinSds\!!!AppOutput\HQApps", exeName, param, -1, PG.Gb.DBFn);
        }

        private void tsMnuVslCrewAddNewController_Click(object sender, EventArgs e)
        {
            CallSettingMgmtApplication("VSLFLEETCREWCONTROLLER", -1, "");
        }


        private void tsMnuAbout_Click(object sender, EventArgs e)
        {
            frmAboutBox objAboutBox = new frmAboutBox();
            try
            {
                objAboutBox.ShowDialog();
            }
            finally
            {
                objAboutBox = null;
            }
        }


        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmMainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (isFormInitialised && (isToShowSQEDashboard && isToShowCREWDashboard))
            //{
            //    string msg = "Are you sure you want to exit " + cboCompany_Filter.Text.ToUpper() + "_HqSDS ?";
            //    if (!Gfn.nConfBox(msg))
            //    {
            //        e.Cancel = true;
            //        return;
            //    }
            //}
            common = null;
        }
    }
}