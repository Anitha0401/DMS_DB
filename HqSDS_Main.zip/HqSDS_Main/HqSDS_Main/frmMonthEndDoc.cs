﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMonthEndDoc : Form
    {
        public int formLeft = 20, formTop = 20;
        Common common = null;
        bool isFormInitialised = false;

        const int COL_COMPANYCODE = 0,
                  COL_VSLCODE = 1,
                  COL_VSLNAME = 2,
                  COL_OPERATEBY = 3,
                  COL_MONTHEND_DUE = 4,
                  COL_VESSELID = 5;

        public frmMonthEndDoc()
        {
            InitializeComponent();
        }

        private void frmMonthEndDoc_Load(object sender, EventArgs e)
        {
            PG.SetFormWidthAndHeight(this, formLeft, formTop, 650, 410);

            common = new Common();

            if (PG.Gb.IsToConnecDirectDB) tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();
            tsLblUserId.Text = "User: " + PG.Gb.User.CurUserName;

            string fileName = PG.Gb.WinSDSrootDir + "\\Images\\" + PG.Gb.Companycode + "HQ_SDS.ico";
            if (File.Exists(fileName))
            {
                Icon ic = new Icon(fileName);
                this.Icon = ic;
            }

            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, false);

            DesignMonthEndDocGridDetails();

            isFormInitialised = true;

            cboCompany_Filter_SelectedIndexChanged(null, null);
        }

        protected void DesignMonthEndDocGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();
            try
            {
                Color rowHeaderForeColor = Color.Blue;
                particularsColList.Add(new DgvInits("CompanyCode", "Company", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 190, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OperateBy", "Operate By", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("MonthEndDoc_OverDue", "Over Due", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, false, true));

                fpSpread1.SuspendLayout();

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, particularsColList, null, false, false, false);

                if (fpSpread1.ActiveSheet.ColumnCount > 0)
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread1.ActiveSheet.ColumnCount - 1].ForeColor = Color.Black;
                    fpSpread1.ActiveSheet.Columns[COL_MONTHEND_DUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                    fpSpread1.ActiveSheet.ColumnHeader.Columns[COL_MONTHEND_DUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                }
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MONTHEND_DUE].ForeColor = Color.Blue;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 40;

                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;
                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread1.ActiveSheet.DisplayZero = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMonthEndDoc.cs", "DesignMonthEndDocGridDetails", er.Message);
                Gfn.Mb("Failed to design month End Grid");
            }
            finally
            {
                fpSpread1.ResumeLayout();
                particularsColList = null;
            }
        }

        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (!PG.InitialiseCommonSettings(companyID)) return;

                common.BindVslDropDownList(cboVslFilter, companyID, true);

                cboVslFilter_SelectedIndexChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMonthEndDoc.cs", "cboCompany_Filter_SelectedIndexChanged", err.Message);
            }
        }

        private void cboVslFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            try
            {
                fpSpread1.SuspendLayout();

                tlsStatuslblTotalVessels.Text = "Total Vessel(s): 0";
                fpSpread1.ActiveSheet.RowCount = 0;

                if (cboVslFilter.SelectedValue == null || common == null) return;

                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                fpSpread1.ActiveSheet.DataSource = common.GetDashBoardDataTable_MonthEnd(vslFilter, companyID, -1);

                fpSpread1.ActiveSheet.Columns[COL_COMPANYCODE].Visible = (cboCompany_Filter.SelectedValue != null && cboCompany_Filter.SelectedValue.ToString() == "-99");

                if (fpSpread1.ActiveSheet.RowCount > 0 && fpSpread1.ActiveSheet.ColumnCount > 0)
                {
                    int rowCount = fpSpread1.ActiveSheet.RowCount - 1;
                    fpSpread1.ActiveSheet.Cells[0, 0, rowCount, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.FromArgb(244,164,96), 1, false, false, true, true);
                    fpSpread1.ActiveSheet.Cells[0, COL_COMPANYCODE, rowCount, COL_OPERATEBY].BackColor = Color.FromArgb(245,222,179);
                    fpSpread1.ActiveSheet.Cells[0, COL_COMPANYCODE, rowCount, COL_OPERATEBY].ForeColor = Color.Black;
                    
                    tlsStatuslblTotalVessels.Text = "Total Vessel(s): " + fpSpread1.ActiveSheet.RowCount;

                    for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
                    {
                        if ((fpSpread1.ActiveSheet.Cells[row, COL_MONTHEND_DUE].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_MONTHEND_DUE].Value.ToString() == "0") || 
                             fpSpread1.ActiveSheet.Cells[row, COL_MONTHEND_DUE].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_MONTHEND_DUE].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_MONTHEND_DUE].Text = "0";
                        }
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMonthEndDoc.cs", "cboVslFilter_SelectedIndexChanged", err.Message);
                Gfn.Eb("Failed to refresh grid");
            }
            finally
            {
                fpSpread1.ResumeLayout();
            }
        }
        
        private void fpSpread1_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0 || e.ColumnHeader) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                this.Cursor = Cursors.Default;
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            int cnt = 0;
            if (e.Column == COL_MONTHEND_DUE)
            {
                #region Month End Doc
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_MONTHEND_DUE].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_MONTHEND_DUE].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no Month End Doc due.");
                    return;
                }

                string addlParameter = "OverDue";
                CallMonthEndDocApplication(vesselID, addlParameter, true, false, rowIndex);

                #endregion
            }
        }

        private void fpSpread1_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread1.ContextMenuStrip = null;
            if (fpSpread1.ActiveSheet.RowCount > 0) fpSpread1.ActiveSheet.Rows[0, fpSpread1.ActiveSheet.RowCount - 1].ResetBackColor();

            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread1.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;

                fpSpread1.ActiveSheet.SetActiveCell(row, col);
                fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;

                fpSpread1.ContextMenuStrip = contextMenuStrip1;
            }
        }

        private void tsmu_VslDashBoard_Click(object sender, EventArgs e)
        {
            CallVslApplication("VslDashBoard");
        }

        private void tsMnuVslMonthEndDoc_Click(object sender, EventArgs e)
        {
            CallVslApplication("MonthEndDoc");
        }

        private void btnMonthEndDocument_Click(object sender, EventArgs e)
        {
            CallMonthEndDocApplication(-1, "", true, false, -1);
        }

        private void CallVslApplication(string exeName)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            string param = GetParam(vesselID, true);

            if (exeName.ToUpper() == "MonthEndDoc".ToUpper())
            {
                CallMonthEndDocApplication(vesselID, "", false, true, rowIndex);
            }
            else
            {
                if (exeName.ToUpper() == "PmsMain".ToUpper())
                {
                    exeName = "VslDashBoard";
                    param = param + " PmsMain";
                }
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
            }
            FocusSelectedVessel(vesselID);
        }

        private void CallMonthEndDocApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess, int rowNo)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Tech";
            MonthEndDocMgmt.MonthEndDocStartup monthEndDocStartup = new MonthEndDocMgmt.MonthEndDocStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!monthEndDocStartup.isVslInitSuccessfully)
                {
                    return;
                }

                monthEndDocStartup.CallMonthEndDocMainPage();
                isDoneAnyChanges = monthEndDocStartup.isDoneAnyChanges;
            }
            finally
            {
                monthEndDocStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_MONTHENDDOC, vesselID);

                if (vesselID > 0)
                {
                    DataTable dtDashboard = common.GetDashBoardDataTable_MonthEnd("", "", vesselID);

                    if (dtDashboard != null)
                    {
                        string cellValue = dtDashboard.Rows[0]["MonthEndDoc_OverDue"].ToString();
                        if (fpSpread1.ActiveSheet.Cells[rowNo, COL_MONTHEND_DUE].Value != null) fpSpread1.ActiveSheet.Cells[rowNo, COL_MONTHEND_DUE].Value = cellValue.ToString();
                        else fpSpread1.ActiveSheet.Cells[rowNo, COL_MONTHEND_DUE].Text = cellValue;

                    }
                }
                else {
                    cboVslFilter_SelectedIndexChanged(null, null);
                }
            }
            isDoneAnyChanges = false;
            */
        }

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = cboCompany_Filter.Text.ToUpper() + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = cboCompany_Filter.Text.ToUpper() + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            return param;
        }


        private void FocusSelectedVessel(int vesselID)
        {
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                int curVesselID = -1;
                if (fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value != null) curVesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value);
                if (curVesselID == vesselID)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(row, 0);
                    int topRow = row;
                    if (topRow > 10) topRow = topRow - 10;
                    fpSpread1.SetViewportTopRow(0, topRow);

                    fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    break;
                }
            }
        }

        private void lnkRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string addlCond = "";
                if (PG.laidupVessels.Trim().Length > 0)
                {
                    addlCond = addlCond + "   and V.VslCode not in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                }
                string script = " Select V.VesselID from Dashboard_HQ_Main_Marine_Status S, V_Vessels V " +
                                " Where S.VesselID=V.VesselID " +
                                "   and V.VesselID<>-1" +
                                addlCond;
                DataTable dt = PG.Gb.DBFn.DbRecords(script);

                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_MONTHENDDOC, Convert.ToInt32(dr["VesselID"].ToString()));
                }

                cboVslFilter_SelectedIndexChanged(null, null);
                Gfn.Mb("Refresh Completed");
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMonthEndDoc.cs", "lnkRefresh_LinkClicked", err.Message);
            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
