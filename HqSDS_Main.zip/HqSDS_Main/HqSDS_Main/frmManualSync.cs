﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;
using Microsoft.WindowsAzure.StorageClient;

namespace HqSDS_Main
{
    public partial class frmManualSync : Form
    {
        bool isFormInitialised = false;

        public frmManualSync()
        {
            InitializeComponent();
        }

        private void frmManualSync_Load(object sender, EventArgs e)
        {
            Gfn.SetFormWidthAndHeight(this, 50, 30, 750, 1200);

            InitialiseDetails();

            DesignUploadGrid();
            DesignDownloadGrid();
            BindVslDropDownList();

            isFormInitialised = true;

            cboVslFilter_SelectedIndexChanged(null, null);
        }

        private void InitialiseDetails()
        {
            try
            {
                tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "InitialiseDetails", err.Message);
            }
        }

        private void DesignUploadGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {                
                colList.Add(new DgvInits("VslCode", "Vsl Code", 50, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("TableDescription", "Application Name", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FileName", "File Name", 230, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FileSize", "File Size(KB)", 90, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("AddedOnDisplay", "Added On", 120, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("SyncType", "Sync Type", 90, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("TableName", "TableName", 335, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("TableKeyId", "TableKeyId", 335, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("VesselID", "VesselID", 335, Color.Black, SystemColors.ButtonFace, false, true));
                Dgv.GenerateDataGridView(dgvUpload, colList, null, false);
            }
            catch (Exception ex)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "DesignUploadGrid", ex.Message);
            }
            finally
            {
                colList = null;
            }
        }

        private void DesignDownloadGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                colList.Add(new DgvInits("VslCode", "Vsl Code", 50, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("TableDescription", "Application Name", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FileName", "File Name", 230, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FileSizeDisplay", "File Size(KB)", 90, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FileSize", "File Size(KB)", 100, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("AddedOnDisplay", "Added On", 120, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("SyncType", "Sync Type", 90, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FileNameFormatToImport", "FileNameFormatToImport", 80, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("VesselID", "VesselID", 80, Color.Black, SystemColors.ButtonFace, false, true));
                Dgv.GenerateDataGridView(dgvDownload, colList, null, false);
            }
            catch(Exception err) 
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "DesignDownloadGrid", err.Message);
            }
            finally
            {
                colList = null;
            }
        }

        public void BindVslDropDownList()
        {
            ArrayList objArrLst = new ArrayList();
            try
            {
                objArrLst = GetVslFilterArrayList();
                cboVslFilter.DisplayMember = "Key";
                cboVslFilter.ValueMember = "Value";
                cboVslFilter.DataSource = objArrLst;

                // Note :Default to CurrentUser - Vsl Selection 
                if (cboVslFilter.Items.Count > 0)
                {
                   cboVslFilter.SelectedIndex = 0;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "BindVslDropDownList", err.Message);
            }
            finally
            {
                objArrLst = null;
            }
        }

        public ArrayList GetVslFilterArrayList()
        {
            DataTable dt = null;
            ArrayList objArr = new ArrayList();
            try
            {
                // Add Vsl Groups in operation
                string script = " select distinct G.GroupCode, GroupName, G.V_Op_GroupsID, G.SortOrder " +
                                " from V_Vessels V, V_Op_Groups_VSL_I I, V_Op_Groups G " +
                                " where V.VesselID=I.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID " +
                                "    and V.C_CompanyID = G.C_CompanyID" +
                                "    and V.OperateBy='VSL' " +
                                " order by G.SortOrder, GroupName, G.V_Op_GroupsID";
                dt = PG.Gb.DBFn.DbRecords(script);

                objArr.Insert(0, new DictionaryEntry("All Vessels", "-1"));

                if (dt != null)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string svsl = dt.Rows[i]["GroupName"].ToString();
                        objArr.Add(new DictionaryEntry("Group - " + dt.Rows[i]["GroupName"].ToString(), dt.Rows[i]["V_Op_GroupsID"].ToString()));
                    }
                }

                script = " select distinct V.VesselId, V.VslName " +
                         " from V_Vessels V " +
                         " where V.OperateBy='VSL' " +
                         " order by V.VslName ";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt != null)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        objArr.Add(new DictionaryEntry(dt.Rows[i]["VslName"].ToString(), "VSL-" + dt.Rows[i]["VesselId"].ToString()));
                    }
                }
            }
            catch (Exception err)
            {
                objArr = null;
                PG.AddToGenErrorLog("frmManualSync.cs", "GetVslFilterArrayList", err.Message);
            }
            finally
            {
                dt = null;
            }
            return (objArr);
        }


        private void cboVslFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            FillUp_UploadAndDownalod_Details();
        }

        public string GetVslFilterAddlCondition()
        {
            bool isVesselSelected = false, isGroupVsl = false;
            string selectedGroupID = "-1";
            int selectedVesselID = -1;

            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            if (vslFilter != "-1")
            {
                string[] vslType = vslFilter.Split('-');
                if (vslType.Length > 1)
                {
                    isVesselSelected = (vslType[0].ToString().Trim().ToUpper() == "VSL");
                    if (isVesselSelected) selectedVesselID = Convert.ToInt32(vslType[1].ToString());
                }
                else if (vslType.Length == 1)
                {
                    isGroupVsl = true;
                    if (isGroupVsl) selectedGroupID = vslType[0].ToString();
                }
            }

            string addlCond = "";

            if (isGroupVsl)
            {
                string groupList = Gfn.GetCommaTxtWithsingleQuotes(vslFilter, ",", -1, PG.Gb.DBFn);
                addlCond = addlCond + " and exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (" + groupList + "))" + Environment.NewLine;
            }
            else if (isVesselSelected)
            {
                addlCond = addlCond + " and V.VesselID = " + selectedVesselID + Environment.NewLine;
            }

            return (addlCond);
        }

        private void FillUp_UploadAndDownalod_Details()
        {
            try
            {
                string vslfilterAddlCond = GetVslFilterAddlCondition();

                string script = " select UploadTo " +
                                " from DTF_BigBlobs_Q Q, V_Vessels V " +
                                " where Q.VesselID=V.VesselID " +
                                "   and Q.IsUploaded = 0 " +
                                vslfilterAddlCond;
                DataTable dt = PG.Gb.DBFn.DbRecords(script);

                int toUploadCnt = 0, toDownloadCnt = 0;
                if (dt != null)
                {
                    DataRow[] dr = dt.Select(" UploadTo = 'VSL' ");
                    if (dr != null) toUploadCnt = dr.Length;

                    dr = dt.Select(" UploadTo = 'HQ' ");
                    if (dr != null) toDownloadCnt = dr.Length;
                }

                btnExport.Enabled = (toUploadCnt > 0);
                btnImport.Enabled = (toDownloadCnt > 0);

                lblToDownload.Text = toDownloadCnt.ToString();
                lblToUpload.Text = toUploadCnt.ToString();

                tabControl1.TabPages[0].Text = "Export big files to VSL ( " + toUploadCnt + " ) ";
                tabControl1.TabPages[1].Text = "Import big files from VSL ( " + toDownloadCnt + " ) ";

                BindDownloadGrid();
                BindUploadGrid();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "FillUp_UploadAndDownalod_Details", err.Message);
            }
        }

        private void BindUploadGrid()
        {
            string script = "";
            DataTable dtUpload = null;
            double totalFileSize = 0;
            try
            {
                string vslfilterAddlCond = GetVslFilterAddlCondition();

                script = " select Distinct Q.TableName, Q.TableKeyID, V.VslCode, V.VesselId " + Environment.NewLine +
                		 "    , Replace(CONVERT(varchar(15),AddedOn,106),' ','-') + ' '+ CONVERT(varchar(5),AddedOn,108) AddedOnDisplay " + Environment.NewLine +
                         "    , (select TableDescription from DTF_TableSetup where TableName=Q.TableName) as TableDescription " + Environment.NewLine +
                         "    , '' FileName, '' FileSize " +
                         "    , Case When (Select count(*) from DTF_Tables_DirectSync_Q where TableName = Q.TableName and TableKeyID = Q.TableKeyID and Processed = 0 and ToUpload=1)>0 then 'Direct / Manual' else 'Manual' end as SyncType " +
                         " from DTF_BigBlobs_Q Q, V_Vessels V " + Environment.NewLine +
                         " where Q.VesselID=V.VesselID " + Environment.NewLine +
                         "   and Q.IsUploaded = 0 " + Environment.NewLine +
                         "   and Q.UploadTo = 'VSL' " + Environment.NewLine +
                         vslfilterAddlCond +
                         " Order by Q.TableName, V.VslCode ";
                dtUpload = PG.Gb.DBFn.DbRecords(script);

                if (dtUpload != null)
                {
                    foreach (DataRow dr in dtUpload.Rows)
                    {
                        string tableName = dr["TableName"].ToString();
                        string tableKeyID = dr["TableKeyId"].ToString();

                        script = " Select FileName+FileType as FileName, BlobSize/1024 as FileSize " +
                                 "    , Cast(BlobSize/1024 as varchar) + Case when (BlobSize/1024/1024>1) then '(' + Cast(Round(Cast(BlobSize as float)/1024/1024,2) as varchar) + 'MB)' else '' end as FileSizeDisplay " +
                                 " from " + tableName +
                                 " where " + tableName + "ID = '" + tableKeyID + "'";
                        DataTable dtRec = PG.Gb.DBFn.DbRecords(script);

                        if (dtRec != null && dtRec.Rows.Count > 0)
                        {
                            dr["FileName"] = dtRec.Rows[0]["FileName"].ToString();
                            dr["FileSize"] = dtRec.Rows[0]["FileSizeDisplay"].ToString();

                            totalFileSize = totalFileSize + Convert.ToInt32(dtRec.Rows[0]["FileSize"].ToString());
                        }
                    }
                }

                dgvUpload.DataSource = dtUpload;
                lblTotalFilesSize.Text = totalFileSize.ToString() + " KB ";
                if (totalFileSize > 1024) lblTotalFilesSize.Text = lblTotalFilesSize.Text + " / " + (totalFileSize / 1024).ToString("N2") + " MB";

                if (dgvUpload.RowCount > 0)
                {
                    dgvUpload.Rows[dgvUpload.RowCount - 1].Selected = true;
                    dgvUpload.FirstDisplayedScrollingRowIndex = dgvUpload.RowCount - 1;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "BindUploadGrid", err.Message);
            }
        }

        private void BindDownloadGrid()
        {
            string script = "";
            DataTable dtDownload=null;
            try
            {
                string vslfilterAddlCond = GetVslFilterAddlCondition();

                script = " select Distinct Q.TableName, Q.TableKeyID, V.VslCode, V.VesselId " + Environment.NewLine + 
                         "    , Replace(CONVERT(varchar(15),AddedOn,106),' ','-') + ' '+ CONVERT(varchar(5),AddedOn,108) AddedOnDisplay " + 
                         "    , (Select TableID from DTF_TableSetup where TableName = Q.Tablename) as TableID " + Environment.NewLine +
                         "    , (select TableDescription from DTF_TableSetup where TableName=Q.TableName) as TableDescription  " + Environment.NewLine +
                         "    , '' FileName, '' FileSize, '' FileSizeDisplay, '' FileNameFormatToImport " +
                         "    , Case When (Select count(*) from DTF_Tables_DirectSync_Q where TableName = Q.TableName and TableKeyID = Q.TableKeyID and Processed = 0 and ToDownload=1)>0 then 'Direct / Manual' else 'Manual' end as SyncType " +
                         " from DTF_BigBlobs_Q Q, V_Vessels V " + Environment.NewLine +
                         " where Q.VesselID=V.VesselID " + Environment.NewLine +
                         "   and Q.IsUploaded = 0 " + Environment.NewLine +
                         "   and Q.UploadTo = 'HQ' " + Environment.NewLine +
                             vslfilterAddlCond +
                         " Order by Q.TableName, V.VslCode ";
                dtDownload = PG.Gb.DBFn.DbRecords(script);

                if (dtDownload != null)
                {
                    foreach (DataRow dr in dtDownload.Rows)
                    {
                        string vslCode = dr["VslCode"].ToString();
                        string tableName = dr["TableName"].ToString();
                        string tableKeyID = dr["TableKeyId"].ToString();
                        string tableID = dr["TableID"].ToString();

                        script = " Select FileName+FileType as FileName, FileType, BlobSize/1024 as FileSize " +
                                 "    , Cast(BlobSize/1024 as varchar) + Case when (BlobSize/1024/1024>1) then '(' + Cast(Round(Cast(BlobSize as float)/1024/1024,2) as varchar) + 'MB)' else '' end as FileSizeDisplay " +
                                 " from " + tableName +
                                 " where " + tableName + "ID = '" + tableKeyID + "'";
                        DataTable dtRec = PG.Gb.DBFn.DbRecords(script);

                        if (dtRec != null && dtRec.Rows.Count > 0)
                        {
                            dr["FileName"] = dtRec.Rows[0]["FileName"].ToString();
                            dr["FileSizeDisplay"] = dtRec.Rows[0]["FileSizeDisplay"].ToString();
                            dr["FileSize"] = dtRec.Rows[0]["FileSize"].ToString();
                            dr["FileNameFormatToImport"] = vslCode + "@" + tableID + "@" + tableKeyID + dtRec.Rows[0]["FileType"].ToString();
                        }
                    }
                }

                dgvDownload.DataSource = dtDownload;

                if (dgvDownload.RowCount > 0)
                {
                    dgvDownload.Rows[dgvDownload.RowCount - 1].Selected = true;
                    dgvDownload.FirstDisplayedScrollingRowIndex = dgvDownload.RowCount - 1;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "BindDownloadGrid", err.Message);
            }
        }


        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            try
            {
                Font f;
                Brush backBrush;
                Brush foreBrush;

                if (e.Index == this.tabControl1.SelectedIndex)
                {
                    f = new Font("Calibri", 12, FontStyle.Regular);
                    backBrush = new System.Drawing.SolidBrush(Color.Orange);
                    foreBrush = Brushes.Black;
                }
                else
                {
                    f = new Font("Calibri", 11, FontStyle.Regular);
                    backBrush = new SolidBrush(e.BackColor);
                    foreBrush = new SolidBrush(e.ForeColor);
                }

                string tabName = this.tabControl1.TabPages[e.Index].Text;
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;

                e.Graphics.FillRectangle(backBrush, e.Bounds);
                Rectangle r = e.Bounds;
                r = new Rectangle(r.X, r.Y + 3, r.Width, r.Height + 10);
                e.Graphics.DrawString(tabName, f, foreBrush, r, sf);

                sf.Dispose();
                if (e.Index == this.tabControl1.SelectedIndex)
                {
                    f.Dispose();
                    backBrush.Dispose();
                }
                else
                {
                    backBrush.Dispose();
                    foreBrush.Dispose();
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "tabControl1_DrawItem", err.Message);
            }
        }
        
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblExportNotice.Visible = (tabControl1.SelectedIndex == 0);
        }


        private void dgvUpload_MouseClick(object sender, MouseEventArgs e)
        {
            DataGridView.HitTestInfo GridhitTestInfo;
            if (e.Button == MouseButtons.Right)
            {
                GridhitTestInfo = dgvUpload.HitTest(e.X, e.Y);
                int rowindex = GridhitTestInfo.RowIndex;
                int columnindex = GridhitTestInfo.ColumnIndex;
                if (columnindex >= 0 && rowindex >= 0)
                {
                    dgvUpload.Rows[rowindex].Cells[columnindex].Selected = true;
                    ctxMenuExport.Show(dgvUpload, new Point(e.X, e.Y));
                }
            }
        }

        private void mnuExportSelectedFile_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvUpload.SelectedRows.Count <= 0)
                {
                    Gfn.nMb("There is no record in the grid");
                    return;
                }

                FolderBrowserDialog folderDialog = new FolderBrowserDialog();
                if (folderDialog.ShowDialog() == DialogResult.Cancel) return;

                string outputFolder = folderDialog.SelectedPath;

                UpdateStatusWindow("Following files exported to Folder: " + outputFolder, Color.Green, false);

                string tableName = dgvUpload.SelectedRows[0].Cells["TableName"].Value.ToString();
                string tableKeyID = dgvUpload.SelectedRows[0].Cells["TableKeyId"].Value.ToString();
                string vesselID = dgvUpload.SelectedRows[0].Cells["VesselID"].Value.ToString();
                string vslCode = dgvUpload.SelectedRows[0].Cells["VslCode"].Value.ToString();

                string category = "";
                string script = "select Count(*) from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='" + tableName + "' and COLUMN_NAME = 'Category' ";
                int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                if (cnt > 0)
                {
                    script = " Select Category from " + tableName + " where " + tableName + "ID = " + tableKeyID;
                    category = PG.Gb.DBFn.Aqr(script).ToString();
                }

                string fileName = DownloadFileFrom_DB_or_AzureStorage_or_LocalFolder_WithKeyIDFileName(vesselID, vslCode, tableName, tableKeyID, category, outputFolder);
                UpdateStatusWindow(" >> " + Path.GetFileName(fileName), Color.Black);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "mnuExportSelectedFile_Click", err.Message);
                UpdateStatusWindow("Error: " + err.Message, Color.Red);
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateStatusWindow("Export big files started", Color.Fuchsia);

                string script = " select Distinct Q.TableName, Q.TableKeyID, V.VslCode, V.VesselId " +
                                " from DTF_BigBlobs_Q Q, V_Vessels V " +
                                " where Q.VesselID=V.VesselID " +
                                "   and Q.IsUploaded = 0 " +
                                "   and Q.UploadTo = 'VSL' ";
                DataTable dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null)
                {
                    UpdateStatusWindow("There is no files to export", Color.Black);
                    return;
                }

                script = " Select * from DTF_Settings " +
                         " Where VesselId=-1 " +
                         //"   and C_CompanyID=" + PG.companyID +
                         "   and SettingName ='DEFAULT_OUTWARDS_FOLDER' ";
                string baseOutputFolder = PG.Gb.DBFn.Aqr(script).ToString();//PG.outwardsFolder;

                UpdateStatusWindow("Following files exported to Folder: " + baseOutputFolder, Color.Green, false);

                DataView view = new DataView(dt);
                DataTable distinctValues = view.ToTable(true, "VslCode");

                if (distinctValues != null)
                {
                    foreach (DataRow drVslCode in distinctValues.Rows)
                    {
                        string vslCode = drVslCode["VslCode"].ToString();

                        string outputFolder = baseOutputFolder + "\\" + vslCode;

                        if (Directory.Exists(outputFolder)) Directory.Delete(outputFolder, true);

                        Directory.CreateDirectory(outputFolder);
                    }
                }

                foreach (DataRow dr in dt.Rows)
                {
                    string tableName = dr["TableName"].ToString();
                    string tableKeyID = dr["TableKeyID"].ToString();
                    string vesselId = dr["VesselId"].ToString();
                    string vslCode = dr["VslCode"].ToString();
                    string outputFolder = baseOutputFolder + "\\" + vslCode;

                    string category = "";
                    script = "select Count(*) from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='" + tableName + "' and COLUMN_NAME = 'Category' ";
                    int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                    if (cnt > 0)
                    {
                        script = " Select Category from " + tableName + " where " + tableName + "ID = " + tableKeyID;
                        category = PG.Gb.DBFn.Aqr(script).ToString();
                    }
 
                    string fileName = DownloadFileFrom_DB_or_AzureStorage_or_LocalFolder_WithKeyIDFileName(vesselId, vslCode, tableName, tableKeyID, category, outputFolder);
                    UpdateStatusWindow(" >> " + Path.GetFileName(fileName), Color.Black);
                }

                UpdateStatusWindow("Total files exported = " + dt.Rows.Count, Color.Green, false);
                UpdateStatusWindow("Total files size = " + lblTotalFilesSize.Text, Color.Green, false);

                Process.Start(baseOutputFolder);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "btnExport_Click", err.Message);
                UpdateStatusWindow("Failed to export files", Color.Red);
            }
            finally
            {
                UpdateStatusWindow("Export big files ended" + Environment.NewLine + Environment.NewLine, Color.Fuchsia);
            }
        }


        public static string DownloadFileFrom_DB_or_AzureStorage_or_LocalFolder_WithKeyIDFileName(string vesselID, string vslCode, string tableName, string tableKeyID, string category, string outputFolder)
        {
            string fileName = ""; DataTable dt;
            try
            {
                string storageOption = "", cloud_AccountName = "", cloud_AccountKey = "", cloud_ContainerName = "", cloud_Directory = "", local_folder = "", databaseName = "";
                PG.attachment.GetStorageDetailsForRead(vesselID, tableName, tableKeyID, category, ref storageOption, ref cloud_AccountName, ref cloud_AccountKey, ref cloud_ContainerName, ref cloud_Directory, ref local_folder, ref databaseName);

                string script = " Select * from " + tableName +
                                " where VesselId in (-1, " + vesselID + ") and " + tableName + "ID='" + tableKeyID + "'";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (!(dt != null && dt.Rows.Count > 0)) return ("");

                string dbFileName = dt.Rows[0]["Filename"].ToString();
                string fileType = dt.Rows[0]["FileType"].ToString();
                if (fileType.Trim().Length <= 0) fileType = Path.GetExtension(dbFileName);

                script = " Select TableID from DTF_TableSetup where TableName = " + Gfn.Qss(tableName);
                string tableID = PG.Gb.DBFn.Aqr(script).ToString();

                dbFileName = vslCode + "@" + tableID + "@" + tableKeyID + fileType;

                fileName = outputFolder + "\\" + Path.GetFileName(dbFileName);
                fileName = fileName.Replace("&amp;", "&");

                if (PG.attachment.CheckFileInUse(fileName)) return ("");

                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                bool isBlobFound = false;
                if (storageOption.ToUpper() == PG.attachment.StorageType_CLOUD.ToUpper())
                {
                    string blobName = cloud_Directory + tableName + "_" + tableKeyID + Path.GetExtension(fileName);

                    CloudBlobContainer container = PG.attachment.GetAzureStorageContainterInLoop(cloud_AccountName, cloud_AccountKey, cloud_ContainerName);
                    if (container == null)
                    {
                        return ("");
                    }

                    CloudBlockBlob blockblob = container.GetBlockBlobReference(blobName);
                    try
                    {
                        blockblob.FetchAttributes();

                        blockblob.DownloadToFile(fileName);
                        isBlobFound = true;
                    }
                    catch (StorageClientException err)
                    {
                        PG.AddToGenErrorLog("frmManualSync.cs", "DownloadFileFrom_DB_or_AzureStorage_or_LocalFolder_WithKeyIDFileName", err.Message);
                    }
                }
                else if (storageOption.ToUpper() == PG.attachment.StorageType_LOCALFOLDER.ToUpper())
                {
                    string blobName = local_folder + tableName + "_" + tableKeyID + Path.GetExtension(fileName);
                    if (File.Exists(blobName))
                    {
                        File.Copy(blobName, fileName, true);
                        isBlobFound = true;
                    }
                }
                else if (storageOption.ToUpper() == PG.attachment.StorageType_DATABASE.ToUpper())
                {
                    if (!PG.attachment.CheckThisDatabaseSameWithCurrentDatabase(databaseName))
                    {
                        try
                        {
                            string extTableName = PG.attachment.GetExtTableName(tableName);
                            script = " Select * from " + extTableName +
                                     " where VesselId='" + vesselID + "' and " + tableName + "ID='" + tableKeyID + "' " +
                                     "    and BlobContents is not null and BlobSize>0 ";
                            dt = PG.attachment.GetDataTable4ThisScript(script, databaseName);
                        }
                        catch (Exception err)
                        {
                            PG.AddToGenErrorLog("frmManualSync.cs", "DownloadFileFrom_DB_or_AzureStorage_or_LocalFolder_WithKeyIDFileName", "External DB - " + err.Message);
                            return ("");
                        }
                    }
                }

                if (!isBlobFound)
                {
                    double blobSize = 0;
                    string blobSizeStr = dt.Rows[0]["BlobSize"].ToString();
                    if (blobSizeStr.Length > 0) blobSize = Convert.ToDouble(blobSizeStr);
                    if (dt.Rows[0]["BlobContents"] != DBNull.Value && dt.Rows[0]["BlobContents"] != null && blobSize > 0)
                    {
                        byte[] fileData = (byte[])dt.Rows[0]["BlobContents"];
                        PG.attachment.CreateFile(fileName, fileData);
                        isBlobFound = true;
                    }
                    else
                    {
                        fileName = "";
                    }
                }

                if (!isBlobFound) fileName = "";

            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "DownloadFileFrom_DB_or_AzureStorage_or_LocalFolder_WithKeyIDFileName", err.Message);
                fileName = "";
            }
            return (fileName);
        }


        private void btnImport_Click(object sender, EventArgs e)
        {
            string script, remarks = "";
            try
            {
                UpdateStatusWindow("Import big files started", Color.Fuchsia);

                script = " Select * from DTF_Settings " +
                         " Where VesselId=-1 " +
                         //"   and C_CompanyID=" + PG.companyID +
                         "   and SettingName ='DEFAULT_INWARDS_FOLDER' ";
                string folder = PG.Gb.DBFn.Aqr(script).ToString();// PG.inwardsFolder;

                string[] fileListToImport = null;

                string fileNameList = ""; FileInfo fi = null; long totalDbFileSize = 0;
                for (int row = 0; row < dgvDownload.Rows.Count; row++)
                {
                    fi = null;
                    long dbFileSize = Convert.ToInt32(dgvDownload.Rows[row].Cells["fileSize"].Value.ToString());
                    string fileName = folder + "\\" + dgvDownload.Rows[row].Cells["FileNameFormatToImport"].Value.ToString();
                    fi = new FileInfo(fileName);
                    if (File.Exists(fileName))
                    {
                        long fileSize = fi.Length / 1024;
                        if (fileSize == dbFileSize) fileNameList = fileNameList + fileName + ",";
                        totalDbFileSize = totalDbFileSize + dbFileSize;
                    }
                }
                fi = null;

                fileListToImport = fileNameList.Trim().Split(',');
                if (fileListToImport.Length == 1)
                {
                    UpdateStatusWindow("Expected files not found in folder: " + folder, Color.Green);
                    return;
                }

                UpdateStatusWindow("Following files imported from folder: " + folder, Color.Green, false);

                string fileSizeStr = totalDbFileSize + " KB";
                if (totalDbFileSize / 1024 > 0) fileSizeStr = fileSizeStr + "( " + (totalDbFileSize / 1024).ToString("N2") + " MB)";
                UpdateStatusWindow("Total Imported Files Size: " + totalDbFileSize.ToString(), Color.Green);

                foreach (string fileName in fileListToImport)
                {
                    string sourceFileName = Path.GetFileNameWithoutExtension(fileName);

                    string[] splitFileNameList = sourceFileName.Split(new string[] { "@" }, StringSplitOptions.RemoveEmptyEntries);

                    if (splitFileNameList.Length != 3) continue;

                    string vslCode = splitFileNameList[0];
                    int tableID = Convert.ToInt32(splitFileNameList[1]);
                    long tableKeyId = Convert.ToInt64(splitFileNameList[2]);

                    script = " Select TableName from DTF_TableSetup where TableID = " + tableID;
                    string tableName = PG.Gb.DBFn.Aqr(script).ToString();

                    script = "Select vesselID from V_Vessels where VslCode = " + Gfn.Qss(vslCode);
                    string vesselIDStr = PG.Gb.DBFn.Aqr(script).ToString();
                    int vesselID = -1;
                    if (vesselIDStr.Trim().Length > 0) vesselID = Convert.ToInt32(vesselIDStr);

                    if (vesselID <= 0)
                    {
                        UpdateStatusWindow(" >> " + tableName + " >> Vessel - " + vslCode + " not exists", Color.Black);
                        remarks = " Vessel - " + vslCode + " not exists";
                        AddToDTF_DirectSync_Log(PG.Gb.Vsl.CurVesselID, PG.Gb.Origin, "Import", remarks, tableName, tableKeyId);
                        continue;
                    }

                    script = " Select count(*) from sys.objects where type='u' and name = " + Gfn.Qss(tableName);
                    int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

                    if (cnt == 0)
                    {
                        UpdateStatusWindow(" >> " + tableName + " >> Table not exists", Color.Black);
                        remarks = tableName + " Table not exists";
                        AddToDTF_DirectSync_Log(PG.Gb.Vsl.CurVesselID, PG.Gb.Origin, "Import", remarks, tableName, tableKeyId);
                        continue;
                    }

                    script = " select fileName + fileType as FileName " +
                             " from " + tableName + " where " + tableName + "ID = " + tableKeyId;
                    DataTable dt = PG.Gb.DBFn.DbRecords(script);

                    cnt = 0;
                    if (dt != null) cnt = dt.Rows.Count;
                    if (cnt == 0)
                    {
                        UpdateStatusWindow(" >>  Record not exists for file: ", Color.Red);
                        remarks = "Record not exists for file:" + fileName;
                        AddToDTF_DirectSync_Log(PG.Gb.Vsl.CurVesselID, PG.Gb.Origin, "Import", remarks, tableName, tableKeyId);
                        continue;
                    }

                    string dbFilename = dt.Rows[0]["FileName"].ToString();

                    byte[] fileData = PG.attachment.GetByteArray(fileName);

                    bool result = PG.attachment.UpdateAttachmentToThisTable(vesselID.ToString(), tableName, tableKeyId, fileName, -1);

                    if (result)
                    {
                        UpdateStatusWindow(" >> " + dbFilename, Color.Green);

                        Gfn.DeleteFileIfExists(fileName);

                        script = " Update DTF_BigBlobs_Q set IsUploaded = 1, UploadedBy_HQ = 'Manual Sync', UploadedDateTime_HQ = DATEADD (hh , " + PG.timeToAdd + " ,getdate()) " +
                                 " where TableName = " + Gfn.Qss(tableName) + " and TableKeyId = '" + tableKeyId + "' and UploadTo = 'HQ' and IsUploaded = 0 ";
                        PG.Gb.DBFn.Xqry(script);

                        script = " Update DTF_Tables_DirectSync_Q set Processed = 1, ErrorMessage = ErrorMessage + ', Manual Sync'  " +
                                 " where TableName = " + Gfn.Qss(tableName) + " and TableKeyId = '" + tableKeyId + "' and ToUpload = 1 and Processed = 0 ";
                        PG.Gb.DBFn.Xqry(script);

                        if (IsUploadedColumnExists(tableName))
                        {
                            script = " Update " + tableName + " set IsUploaded = 3 " +
                                     " where " + tableName + "ID = " + tableKeyId;
                            PG.Gb.DBFn.Xqry(script);
                        }
                    }
                    else
                    {
                        UpdateStatusWindow(" >> " + dbFilename + " >> file failed to imported", Color.Red);
                        remarks = "File failed to imported:" + dbFilename;
                        AddToDTF_DirectSync_Log(PG.Gb.Vsl.CurVesselID, PG.Gb.Origin, "Import", remarks, tableName, tableKeyId);
                    }
                }

                FillUp_UploadAndDownalod_Details();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "btnImport_Click", err.Message);
                UpdateStatusWindow("Failed to import HQ files ", Color.Red);
            }
            finally
            {
                UpdateStatusWindow("Import big files ended" + Environment.NewLine + Environment.NewLine, Color.Fuchsia);
            }
        }

        public static bool AddToDTF_DirectSync_Log(int vesselId, string origin, string logType, string remarks, string tabelName, long tabelKeyID)
        {
            bool result = false;
            string script;
            string machineName = Environment.MachineName;
            if (machineName.Length > 80) machineName = machineName.Substring(0, 80);
            if (remarks.Length > 5000)
            {
                remarks = remarks.Substring(0, 5000);
            }

            if (logType.Length > 10)
            {
                logType = logType.Substring(0, 10);
            }

            try
            {
                long nextLogId = PG.GetNextTableId_HQ("DTF_DirectSync_Log");
                if (nextLogId != -1)
                {
                    script = " Insert into DTF_DirectSync_Log(DTF_DirectSync_LogID, VesselId, Origin, LogDate, LogType, Remarks, Machine_WinLogin_Name, TableName, TableKeyID) " +
                             " values(" + nextLogId + ", " + vesselId + ", " + Gfn.Qss(origin) + ", GetDate(), " + Gfn.Qss(logType) +
                             "  , " + Gfn.Qss(remarks) + ", " + Gfn.Qss(machineName) + ",  " + Gfn.Qss(tabelName) + ", " + tabelKeyID + ")";
                    PG.Gb.DBFn.Xqry(script);
                }
                else
                {
                    PG.AddToGenErrorLog("frmManualSync.cs", "AddToDTF_DirectSync_Log", "Failed to get AddToDTF_DirectSync_Log next ID");
                }
                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "AddToDTF_DirectSync_Log", err.Message);
            }
            return result;
        }

        public static bool IsUploadedColumnExists(string tableName)
        {
            string script = " Select count(*) from sys.objects o, sys.columns c" +
                            " where o.object_id=c.object_id and o.type='u' " +
                            "   and c.name='IsUploaded'" +
                            "   and o.name = '" + tableName + "'";
            int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

            return (cnt > 0);
        }



        private void btnSaveToTextFile_Click(object sender, EventArgs e)
        {
            try
            {
                string msg = richTxtStatus.Text.Trim();
                if (msg.Length <= 0)
                {
                    Gfn.Wb("No data to save");
                    return;
                }

                FolderBrowserDialog folderDialog = new FolderBrowserDialog();
                if (folderDialog.ShowDialog() == DialogResult.Cancel) return;

                string outputFolder = folderDialog.SelectedPath;

                string filename = outputFolder + "\\HQ_ManualSync_Status_" + DateTime.Now.ToString("ddMMMyyyyHHmm") + ".txt";

                System.IO.File.WriteAllText(filename, msg.Replace("\n", Environment.NewLine));

                Process.Start(filename);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmManualSync.cs", "btnSaveToTextFile_Click", err.Message);
                UpdateStatusWindow("Failed to export files", Color.Red);
            }
        }

        public void UpdateStatusWindow(string msg, Color c)
        {
            UpdateStatusWindow(msg, c, true);
        }

        public void UpdateStatusWindow(string msg, Color c, bool isToAddTime)
        {
            if (isToAddTime) msg = DateTime.Now.ToString("ddMMMyy hh:mm:ss") + " - " + msg;

            richTxtStatus.SelectionColor = c;
            richTxtStatus.AppendText(msg + Environment.NewLine);
            richTxtStatus.Refresh();

            richTxtStatus.SelectionStart = richTxtStatus.TextLength;
            richTxtStatus.Focus();
            richTxtStatus.ScrollToCaret();
        }

        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}