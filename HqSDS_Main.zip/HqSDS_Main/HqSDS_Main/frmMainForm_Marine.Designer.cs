﻿namespace HqSDS_Main
{
    partial class frmMainForm_Marine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.CellType.ColumnHeaderRenderer columnHeaderRenderer1 = new FarPoint.Win.Spread.CellType.ColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.RowHeaderRenderer rowHeaderRenderer1 = new FarPoint.Win.Spread.CellType.RowHeaderRenderer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainForm_Marine));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle5 = new FarPoint.Win.Spread.NamedStyle("HeaderDefault");
            FarPoint.Win.Spread.NamedStyle namedStyle6 = new FarPoint.Win.Spread.NamedStyle("RowHeaderDefault");
            FarPoint.Win.Spread.NamedStyle namedStyle7 = new FarPoint.Win.Spread.NamedStyle("CornerDefault");
            FarPoint.Win.Spread.CellType.CornerRenderer cornerRenderer2 = new FarPoint.Win.Spread.CellType.CornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle8 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType2 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.SpreadSkin spreadSkin2 = new FarPoint.Win.Spread.SpreadSkin();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer10 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer2 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer5 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer6 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.LineBorder lineBorder10 = new FarPoint.Win.LineBorder(System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(160)))), ((int)(((byte)(181))))));
            FarPoint.Win.LineBorder lineBorder11 = new FarPoint.Win.LineBorder(System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(160)))), ((int)(((byte)(181))))));
            FarPoint.Win.LineBorder lineBorder12 = new FarPoint.Win.LineBorder(System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(160)))), ((int)(((byte)(181))))));
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer7 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer8 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkShowMyApproveColumn = new System.Windows.Forms.CheckBox();
            this.btnCrewDashboard = new System.Windows.Forms.Button();
            this.btnProcurement = new System.Windows.Forms.Button();
            this.btnTechDashboard = new System.Windows.Forms.Button();
            this.chkShowDashboard = new System.Windows.Forms.CheckBox();
            this.cboCompany_Filter = new System.Windows.Forms.ComboBox();
            this.chkShowOnlyActionColumns = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboVslFilter = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnDMS = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsMnuSetUp = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsMnuRootCauseAnalysisChartSetup = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsMnuAuditInspectionSetup = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuNCRTrending = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuAwarenessReportTrending = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4 = new System.Windows.Forms.Panel();
            this.progressBarRefresh = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblSvrName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblUserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tlsStatuslblTotalVessels = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.fpSpread_TopPanel = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_TopPanel_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lnkReset = new System.Windows.Forms.LinkLabel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelLoading = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.fpSpread_Particulars = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_Particulars_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.lnkRefresh = new System.Windows.Forms.LinkLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.VslApps_toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmu_VslDashBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuVslForms = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslNCR = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslTaskList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslIncidentReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslMinutesOfSafety = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslAwarenessReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslMastersReview = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDocumentManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslAlerts_Circulars = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslRiskAssements = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuForms = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuAuditInspection = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuNCR = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDefects = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuTaskList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuIncidentReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuMinutesOfSafety = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuAwarenessReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuMastersReview = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuRiskAssements = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslCertificate = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tsMnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_TopPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_TopPanel_Sheet1)).BeginInit();
            this.panel3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelLoading.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars_Sheet1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            columnHeaderRenderer1.Name = "columnHeaderRenderer1";
            columnHeaderRenderer1.TextRotationAngle = 0D;
            rowHeaderRenderer1.Name = "rowHeaderRenderer1";
            rowHeaderRenderer1.TextRotationAngle = 0D;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1370, 749);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel1.Controls.Add(this.chkShowMyApproveColumn);
            this.panel1.Controls.Add(this.btnCrewDashboard);
            this.panel1.Controls.Add(this.btnProcurement);
            this.panel1.Controls.Add(this.btnTechDashboard);
            this.panel1.Controls.Add(this.chkShowDashboard);
            this.panel1.Controls.Add(this.cboCompany_Filter);
            this.panel1.Controls.Add(this.chkShowOnlyActionColumns);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cboVslFilter);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.btnDMS);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 32);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1364, 30);
            this.panel1.TabIndex = 23;
            // 
            // chkShowMyApproveColumn
            // 
            this.chkShowMyApproveColumn.BackColor = System.Drawing.Color.Green;
            this.chkShowMyApproveColumn.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowMyApproveColumn.ForeColor = System.Drawing.Color.White;
            this.chkShowMyApproveColumn.Location = new System.Drawing.Point(675, 4);
            this.chkShowMyApproveColumn.Name = "chkShowMyApproveColumn";
            this.chkShowMyApproveColumn.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.chkShowMyApproveColumn.Size = new System.Drawing.Size(153, 23);
            this.chkShowMyApproveColumn.TabIndex = 61;
            this.chkShowMyApproveColumn.Text = "My Approval Columns";
            this.chkShowMyApproveColumn.UseVisualStyleBackColor = false;
            this.chkShowMyApproveColumn.CheckedChanged += new System.EventHandler(this.chkShowMyApproveColumn_CheckedChanged);
            // 
            // btnCrewDashboard
            // 
            this.btnCrewDashboard.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnCrewDashboard.Location = new System.Drawing.Point(1081, 2);
            this.btnCrewDashboard.Name = "btnCrewDashboard";
            this.btnCrewDashboard.Size = new System.Drawing.Size(110, 26);
            this.btnCrewDashboard.TabIndex = 59;
            this.btnCrewDashboard.Text = "Crew Dashboard";
            this.btnCrewDashboard.UseVisualStyleBackColor = true;
            this.btnCrewDashboard.Click += new System.EventHandler(this.btnCrewDashboard_Click);
            // 
            // btnProcurement
            // 
            this.btnProcurement.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnProcurement.Location = new System.Drawing.Point(838, 2);
            this.btnProcurement.Name = "btnProcurement";
            this.btnProcurement.Size = new System.Drawing.Size(86, 26);
            this.btnProcurement.TabIndex = 58;
            this.btnProcurement.Text = "Procurement";
            this.btnProcurement.UseVisualStyleBackColor = true;
            this.btnProcurement.Click += new System.EventHandler(this.btnProcurement_Click);
            // 
            // btnTechDashboard
            // 
            this.btnTechDashboard.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnTechDashboard.Location = new System.Drawing.Point(971, 2);
            this.btnTechDashboard.Name = "btnTechDashboard";
            this.btnTechDashboard.Size = new System.Drawing.Size(110, 26);
            this.btnTechDashboard.TabIndex = 57;
            this.btnTechDashboard.Text = "Tech Dashboard";
            this.btnTechDashboard.UseVisualStyleBackColor = true;
            this.btnTechDashboard.Click += new System.EventHandler(this.btnTechDashboard_Click);
            // 
            // chkShowDashboard
            // 
            this.chkShowDashboard.BackColor = System.Drawing.Color.Green;
            this.chkShowDashboard.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowDashboard.ForeColor = System.Drawing.Color.White;
            this.chkShowDashboard.Location = new System.Drawing.Point(359, 4);
            this.chkShowDashboard.Name = "chkShowDashboard";
            this.chkShowDashboard.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.chkShowDashboard.Size = new System.Drawing.Size(126, 23);
            this.chkShowDashboard.TabIndex = 56;
            this.chkShowDashboard.Text = "Show Dashboard";
            this.chkShowDashboard.UseVisualStyleBackColor = false;
            this.chkShowDashboard.CheckedChanged += new System.EventHandler(this.chkShowDashboard_CheckedChanged);
            // 
            // cboCompany_Filter
            // 
            this.cboCompany_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompany_Filter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCompany_Filter.FormattingEnabled = true;
            this.cboCompany_Filter.Location = new System.Drawing.Point(69, 4);
            this.cboCompany_Filter.MaxDropDownItems = 15;
            this.cboCompany_Filter.Name = "cboCompany_Filter";
            this.cboCompany_Filter.Size = new System.Drawing.Size(66, 23);
            this.cboCompany_Filter.TabIndex = 55;
            this.cboCompany_Filter.SelectedIndexChanged += new System.EventHandler(this.cboCompany_Filter_SelectedIndexChanged);
            // 
            // chkShowOnlyActionColumns
            // 
            this.chkShowOnlyActionColumns.BackColor = System.Drawing.Color.Green;
            this.chkShowOnlyActionColumns.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowOnlyActionColumns.ForeColor = System.Drawing.Color.White;
            this.chkShowOnlyActionColumns.Location = new System.Drawing.Point(492, 4);
            this.chkShowOnlyActionColumns.Name = "chkShowOnlyActionColumns";
            this.chkShowOnlyActionColumns.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.chkShowOnlyActionColumns.Size = new System.Drawing.Size(176, 23);
            this.chkShowOnlyActionColumns.TabIndex = 4;
            this.chkShowOnlyActionColumns.Text = "All User Action Columns";
            this.chkShowOnlyActionColumns.UseVisualStyleBackColor = false;
            this.chkShowOnlyActionColumns.CheckedChanged += new System.EventHandler(this.chkShowOnlyActionColumns_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.5F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(0, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 54;
            this.label1.Text = "Company: ";
            // 
            // cboVslFilter
            // 
            this.cboVslFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVslFilter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboVslFilter.FormattingEnabled = true;
            this.cboVslFilter.Location = new System.Drawing.Point(181, 4);
            this.cboVslFilter.MaxDropDownItems = 15;
            this.cboVslFilter.Name = "cboVslFilter";
            this.cboVslFilter.Size = new System.Drawing.Size(175, 23);
            this.cboVslFilter.TabIndex = 49;
            this.cboVslFilter.SelectedIndexChanged += new System.EventHandler(this.cboVslFilter_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.5F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(139, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 16);
            this.label9.TabIndex = 48;
            this.label9.Text = "Filter:";
            // 
            // btnDMS
            // 
            this.btnDMS.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnDMS.Location = new System.Drawing.Point(927, 2);
            this.btnDMS.Name = "btnDMS";
            this.btnDMS.Size = new System.Drawing.Size(43, 26);
            this.btnDMS.TabIndex = 60;
            this.btnDMS.Text = "DMS";
            this.btnDMS.UseVisualStyleBackColor = true;
            this.btnDMS.Click += new System.EventHandler(this.btnDMS_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.tlsMnuSetUp,
            this.reportsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(3, 3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1364, 24);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "Set ";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuAbout,
            this.toolStripSeparator1,
            this.mnuExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(92, 22);
            this.mnuExit.Text = "Exit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // tlsMnuSetUp
            // 
            this.tlsMnuSetUp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlsMnuRootCauseAnalysisChartSetup,
            this.tlsMnuAuditInspectionSetup});
            this.tlsMnuSetUp.Name = "tlsMnuSetUp";
            this.tlsMnuSetUp.Size = new System.Drawing.Size(50, 20);
            this.tlsMnuSetUp.Text = "SetUp";
            // 
            // tlsMnuRootCauseAnalysisChartSetup
            // 
            this.tlsMnuRootCauseAnalysisChartSetup.Name = "tlsMnuRootCauseAnalysisChartSetup";
            this.tlsMnuRootCauseAnalysisChartSetup.Size = new System.Drawing.Size(245, 22);
            this.tlsMnuRootCauseAnalysisChartSetup.Text = "Root Cause Analysis Chart Setup";
            this.tlsMnuRootCauseAnalysisChartSetup.Click += new System.EventHandler(this.tlsMnuRootCauseAnalysisChartSetup_Click);
            // 
            // tlsMnuAuditInspectionSetup
            // 
            this.tlsMnuAuditInspectionSetup.Name = "tlsMnuAuditInspectionSetup";
            this.tlsMnuAuditInspectionSetup.Size = new System.Drawing.Size(245, 22);
            this.tlsMnuAuditInspectionSetup.Text = "Audit / Inspection Setup";
            this.tlsMnuAuditInspectionSetup.Click += new System.EventHandler(this.tlsMnuAuditInspectionSetup_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuNCRTrending,
            this.tsMnuAwarenessReportTrending});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // tsMnuNCRTrending
            // 
            this.tsMnuNCRTrending.Name = "tsMnuNCRTrending";
            this.tsMnuNCRTrending.Size = new System.Drawing.Size(218, 22);
            this.tsMnuNCRTrending.Text = "NCR Trending";
            this.tsMnuNCRTrending.Click += new System.EventHandler(this.tsMnuNCRTrending_Click);
            // 
            // tsMnuAwarenessReportTrending
            // 
            this.tsMnuAwarenessReportTrending.Name = "tsMnuAwarenessReportTrending";
            this.tsMnuAwarenessReportTrending.Size = new System.Drawing.Size(218, 22);
            this.tsMnuAwarenessReportTrending.Text = "Awareness Report Trending";
            this.tsMnuAwarenessReportTrending.Click += new System.EventHandler(this.tsMnuAwarenessReportTrending_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.progressBarRefresh);
            this.panel4.Controls.Add(this.statusStrip1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 726);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1364, 20);
            this.panel4.TabIndex = 46;
            // 
            // progressBarRefresh
            // 
            this.progressBarRefresh.Location = new System.Drawing.Point(868, 2);
            this.progressBarRefresh.Name = "progressBarRefresh";
            this.progressBarRefresh.Size = new System.Drawing.Size(245, 16);
            this.progressBarRefresh.TabIndex = 45;
            this.progressBarRefresh.Visible = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblSvrName,
            this.tsLblUserId,
            this.toolStripStatusLabel2,
            this.tlsStatuslblTotalVessels});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1364, 20);
            this.statusStrip1.TabIndex = 25;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblSvrName
            // 
            this.tsLblSvrName.AutoSize = false;
            this.tsLblSvrName.Margin = new System.Windows.Forms.Padding(3, 3, 0, 2);
            this.tsLblSvrName.Name = "tsLblSvrName";
            this.tsLblSvrName.Size = new System.Drawing.Size(300, 15);
            this.tsLblSvrName.Text = "Svr                            ";
            this.tsLblSvrName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tsLblUserId
            // 
            this.tsLblUserId.AutoSize = false;
            this.tsLblUserId.Name = "tsLblUserId";
            this.tsLblUserId.Size = new System.Drawing.Size(300, 15);
            this.tsLblUserId.Text = "User";
            this.tsLblUserId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.AutoSize = false;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(10, 15);
            this.toolStripStatusLabel2.Text = "                                             ";
            // 
            // tlsStatuslblTotalVessels
            // 
            this.tlsStatuslblTotalVessels.AutoSize = false;
            this.tlsStatuslblTotalVessels.ForeColor = System.Drawing.Color.Blue;
            this.tlsStatuslblTotalVessels.Name = "tlsStatuslblTotalVessels";
            this.tlsStatuslblTotalVessels.Size = new System.Drawing.Size(200, 15);
            this.tlsStatuslblTotalVessels.Text = "Total Vessel(s):";
            this.tlsStatuslblTotalVessels.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 354F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 65);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1364, 658);
            this.tableLayoutPanel2.TabIndex = 47;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.tabControl2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(354, 658);
            this.panel2.TabIndex = 26;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(354, 658);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.fpSpread_TopPanel);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(346, 629);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Dashboard";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // fpSpread_TopPanel
            // 
            this.fpSpread_TopPanel.AccessibleDescription = "fpSpread_TopPanel, Sheet1, Row 0, Column 0, ";
            this.fpSpread_TopPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(250)))), ((int)(((byte)(234)))));
            this.fpSpread_TopPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fpSpread_TopPanel.BackgroundImage")));
            this.fpSpread_TopPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_TopPanel.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_TopPanel.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_TopPanel.HorizontalScrollBar.Name = "";
            this.fpSpread_TopPanel.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.fpSpread_TopPanel.HorizontalScrollBar.TabIndex = 0;
            this.fpSpread_TopPanel.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread_TopPanel.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_TopPanel.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpread_TopPanel.Name = "fpSpread_TopPanel";
            namedStyle5.BackColor = System.Drawing.SystemColors.Control;
            namedStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle5.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle5.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle5.Renderer = columnHeaderRenderer1;
            namedStyle5.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle6.BackColor = System.Drawing.SystemColors.Control;
            namedStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle6.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle6.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle6.Renderer = rowHeaderRenderer1;
            namedStyle6.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle7.BackColor = System.Drawing.SystemColors.Control;
            namedStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle7.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle7.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle7.Renderer = cornerRenderer2;
            namedStyle7.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle8.BackColor = System.Drawing.SystemColors.Window;
            namedStyle8.CellType = generalCellType2;
            namedStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle8.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle8.Renderer = generalCellType2;
            this.fpSpread_TopPanel.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle5,
            namedStyle6,
            namedStyle7,
            namedStyle8});
            this.fpSpread_TopPanel.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.None;
            this.fpSpread_TopPanel.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_TopPanel_Sheet1});
            this.fpSpread_TopPanel.Size = new System.Drawing.Size(346, 629);
            spreadSkin2.ColumnFooterDefaultStyle = namedStyle5;
            spreadSkin2.ColumnHeaderDefaultStyle = namedStyle5;
            spreadSkin2.CornerDefaultStyle = namedStyle7;
            spreadSkin2.DefaultStyle = namedStyle8;
            spreadSkin2.FocusRenderer = defaultFocusIndicatorRenderer1;
            spreadSkin2.Name = "CustomSkin1";
            spreadSkin2.RowHeaderDefaultStyle = namedStyle6;
            spreadSkin2.ScrollBarRenderer = defaultScrollBarRenderer4;
            spreadSkin2.SelectionRenderer = new FarPoint.Win.Spread.DefaultSelectionRenderer();
            this.fpSpread_TopPanel.Skin = spreadSkin2;
            this.fpSpread_TopPanel.TabIndex = 3;
            this.fpSpread_TopPanel.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_TopPanel.VerticalScrollBar.Name = "";
            this.fpSpread_TopPanel.VerticalScrollBar.Renderer = defaultScrollBarRenderer10;
            this.fpSpread_TopPanel.VerticalScrollBar.TabIndex = 1;
            this.fpSpread_TopPanel.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread_TopPanel.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpread_TopPanel_HyperLinkClicked);
            this.fpSpread_TopPanel.TextTipFetch += new FarPoint.Win.Spread.TextTipFetchEventHandler(this.fpSpread_TopPanel_TextTipFetch);
            this.fpSpread_TopPanel.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread_TopPanel_CellClick);
            this.fpSpread_TopPanel.ButtonClicked += new FarPoint.Win.Spread.EditorNotifyEventHandler(this.fpSpread_TopPanel_ButtonClicked);
            this.fpSpread_TopPanel.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpread_TopPanel_Error);
            // 
            // fpSpread_TopPanel_Sheet1
            // 
            this.fpSpread_TopPanel_Sheet1.Reset();
            this.fpSpread_TopPanel_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_TopPanel_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_TopPanel_Sheet1.ColumnCount = 1;
            this.fpSpread_TopPanel_Sheet1.RowCount = 1;
            this.fpSpread_TopPanel_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_TopPanel_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_TopPanel_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_TopPanel_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_TopPanel_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_TopPanel_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_TopPanel_Sheet1.ColumnHeader.Visible = false;
            this.fpSpread_TopPanel_Sheet1.Columns.Default.CellPadding.Bottom = 1;
            this.fpSpread_TopPanel_Sheet1.Columns.Default.CellPadding.Left = 1;
            this.fpSpread_TopPanel_Sheet1.Columns.Default.CellPadding.Right = 1;
            this.fpSpread_TopPanel_Sheet1.Columns.Default.CellPadding.Top = 1;
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.CellPadding.Bottom = 1;
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.CellPadding.Left = 1;
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.CellPadding.Right = 1;
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.CellPadding.Top = 1;
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_TopPanel_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpSpread_TopPanel_Sheet1.GrayAreaBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.fpSpread_TopPanel_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
            this.fpSpread_TopPanel_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread_TopPanel_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_TopPanel_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_TopPanel_Sheet1.RowHeader.Visible = false;
            this.fpSpread_TopPanel_Sheet1.Rows.Default.CellPadding.Bottom = 1;
            this.fpSpread_TopPanel_Sheet1.Rows.Default.CellPadding.Left = 1;
            this.fpSpread_TopPanel_Sheet1.Rows.Default.CellPadding.Right = 1;
            this.fpSpread_TopPanel_Sheet1.Rows.Default.CellPadding.Top = 1;
            this.fpSpread_TopPanel_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_TopPanel_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_TopPanel_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
            this.fpSpread_TopPanel_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.lnkReset);
            this.panel3.Controls.Add(this.tabControl1);
            this.panel3.Controls.Add(this.lnkRefresh);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(354, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1010, 658);
            this.panel3.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label3.Font = new System.Drawing.Font("Calibri", 10F);
            this.label3.Location = new System.Drawing.Point(611, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(254, 17);
            this.label3.TabIndex = 55;
            this.label3.Text = "Double Click to view all the Status / Columns";
            // 
            // lnkReset
            // 
            this.lnkReset.AutoSize = true;
            this.lnkReset.BackColor = System.Drawing.Color.LightBlue;
            this.lnkReset.Font = new System.Drawing.Font("Arial", 9F);
            this.lnkReset.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(29)))), ((int)(((byte)(248)))));
            this.lnkReset.Location = new System.Drawing.Point(302, 2);
            this.lnkReset.Name = "lnkReset";
            this.lnkReset.Padding = new System.Windows.Forms.Padding(5, 2, 5, 5);
            this.lnkReset.Size = new System.Drawing.Size(77, 22);
            this.lnkReset.TabIndex = 22;
            this.lnkReset.TabStop = true;
            this.lnkReset.Text = "Clear Filter";
            this.lnkReset.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkReset_LinkClicked);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.tabControl1.ItemSize = new System.Drawing.Size(120, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1010, 658);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 27;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.panelLoading);
            this.tabPage1.Controls.Add(this.fpSpread1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1002, 630);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dashboard Details";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(604, 93);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(126, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.WaitOnLoad = true;
            // 
            // panelLoading
            // 
            this.panelLoading.BackColor = System.Drawing.Color.White;
            this.panelLoading.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLoading.Controls.Add(this.label2);
            this.panelLoading.Controls.Add(this.label20);
            this.panelLoading.Location = new System.Drawing.Point(608, 108);
            this.panelLoading.Name = "panelLoading";
            this.panelLoading.Size = new System.Drawing.Size(121, 87);
            this.panelLoading.TabIndex = 171;
            this.panelLoading.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Please wait ...";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DarkGreen;
            this.label20.Location = new System.Drawing.Point(-1, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(136, 22);
            this.label20.TabIndex = 0;
            this.label20.Text = "Refreshing...  ";
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, test";
            this.fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FocusRenderer = defaultFocusIndicatorRenderer2;
            this.fpSpread1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.HorizontalScrollBar.Name = "";
            this.fpSpread1.HorizontalScrollBar.Renderer = defaultScrollBarRenderer5;
            this.fpSpread1.HorizontalScrollBar.TabIndex = 0;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(1002, 630);
            this.fpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread1.TabIndex = 172;
            this.fpSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.VerticalScrollBar.Name = "";
            this.fpSpread1.VerticalScrollBar.Renderer = defaultScrollBarRenderer6;
            this.fpSpread1.VerticalScrollBar.TabIndex = 21;
            this.fpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread1.TextTipFetch += new FarPoint.Win.Spread.TextTipFetchEventHandler(this.fpSpread1_TextTipFetch);
            this.fpSpread1.CellDoubleClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread1_CellDoubleClick);
            this.fpSpread1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread1_MouseDown);
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 3;
            this.fpSpread1_Sheet1.RowCount = 10;
            this.fpSpread1_Sheet1.AutoGenerateColumns = false;
            this.fpSpread1_Sheet1.AutoUpdateNotes = false;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.fpSpread1_Sheet1.Cells.Get(0, 0).Value = "test";
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.Columns.Get(0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(223)))), ((int)(((byte)(230)))));
            this.fpSpread1_Sheet1.Columns.Get(0).Border = lineBorder10;
            this.fpSpread1_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 296F;
            this.fpSpread1_Sheet1.Columns.Get(1).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Columns.Get(1).Border = lineBorder11;
            this.fpSpread1_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 48F;
            this.fpSpread1_Sheet1.Columns.Get(2).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Columns.Get(2).Border = lineBorder12;
            this.fpSpread1_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 48F;
            this.fpSpread1_Sheet1.DisplayZero = false;
            this.fpSpread1_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))));
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 33F;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.SandyBrown);
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.fpSpread_Particulars);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1002, 630);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Vessel Details";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // fpSpread_Particulars
            // 
            this.fpSpread_Particulars.AccessibleDescription = "fpSpread_Particulars, Sheet1, Row 0, Column 0, ";
            this.fpSpread_Particulars.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
            this.fpSpread_Particulars.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_Particulars.FocusRenderer = defaultFocusIndicatorRenderer2;
            this.fpSpread_Particulars.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_Particulars.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Particulars.HorizontalScrollBar.Name = "";
            this.fpSpread_Particulars.HorizontalScrollBar.Renderer = defaultScrollBarRenderer7;
            this.fpSpread_Particulars.HorizontalScrollBar.TabIndex = 16;
            this.fpSpread_Particulars.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_Particulars.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpread_Particulars.Name = "fpSpread_Particulars";
            this.fpSpread_Particulars.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_Particulars_Sheet1});
            this.fpSpread_Particulars.Size = new System.Drawing.Size(1002, 630);
            this.fpSpread_Particulars.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_Particulars.TabIndex = 23;
            this.fpSpread_Particulars.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Particulars.VerticalScrollBar.Name = "";
            this.fpSpread_Particulars.VerticalScrollBar.Renderer = defaultScrollBarRenderer8;
            this.fpSpread_Particulars.VerticalScrollBar.TabIndex = 17;
            this.fpSpread_Particulars.VisualStyles = FarPoint.Win.VisualStyles.Off;
            // 
            // fpSpread_Particulars_Sheet1
            // 
            this.fpSpread_Particulars_Sheet1.Reset();
            this.fpSpread_Particulars_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_Particulars_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_Particulars_Sheet1.ColumnCount = 4;
            this.fpSpread_Particulars_Sheet1.RowCount = 10;
            this.fpSpread_Particulars_Sheet1.AutoGenerateColumns = false;
            this.fpSpread_Particulars_Sheet1.AutoUpdateNotes = false;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 0).Font = new System.Drawing.Font("Calibri", 9F);
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 0).ForeColor = System.Drawing.Color.Black;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 0).Font = new System.Drawing.Font("Calibri", 9F);
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 0).ForeColor = System.Drawing.Color.Maroon;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread_Particulars_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Particulars_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Particulars_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Particulars_Sheet1.Columns.Get(0).BackColor = System.Drawing.SystemColors.ControlLight;
            this.fpSpread_Particulars_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.Black;
            this.fpSpread_Particulars_Sheet1.Columns.Get(0).Width = 160F;
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.Black;
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).Width = 48F;
            this.fpSpread_Particulars_Sheet1.Columns.Get(2).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.Black;
            this.fpSpread_Particulars_Sheet1.Columns.Get(2).Width = 48F;
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).ForeColor = System.Drawing.Color.Black;
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).Width = 48F;
            this.fpSpread_Particulars_Sheet1.DisplayZero = false;
            this.fpSpread_Particulars_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))));
            this.fpSpread_Particulars_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread_Particulars_Sheet1.RowHeader.Columns.Get(0).Width = 33F;
            this.fpSpread_Particulars_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_Particulars_Sheet1.RowHeader.Visible = false;
            this.fpSpread_Particulars_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Particulars_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.SandyBrown);
            this.fpSpread_Particulars_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // lnkRefresh
            // 
            this.lnkRefresh.AutoSize = true;
            this.lnkRefresh.Font = new System.Drawing.Font("Arial", 9.5F, System.Drawing.FontStyle.Bold);
            this.lnkRefresh.ForeColor = System.Drawing.Color.Black;
            this.lnkRefresh.LinkColor = System.Drawing.Color.Black;
            this.lnkRefresh.Location = new System.Drawing.Point(546, 4);
            this.lnkRefresh.Name = "lnkRefresh";
            this.lnkRefresh.Size = new System.Drawing.Size(56, 16);
            this.lnkRefresh.TabIndex = 50;
            this.lnkRefresh.TabStop = true;
            this.lnkRefresh.Text = "Refresh";
            this.lnkRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRefresh_LinkClicked);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.VslApps_toolStripMenuItem1,
            this.toolStripSeparator13,
            this.tsMnuForms,
            this.tsMnuAuditInspection,
            this.tsMnuNCR,
            this.tsMnuDefects,
            this.tsMnuTaskList,
            this.tsMnuIncidentReport,
            this.tsMnuMinutesOfSafety,
            this.tsMnuAwarenessReport,
            this.tsMnuMastersReview,
            this.tsMnuRiskAssements,
            this.tsMnuVslCertificate});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(235, 274);
            // 
            // VslApps_toolStripMenuItem1
            // 
            this.VslApps_toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmu_VslDashBoard,
            this.toolStripSeparator3,
            this.tsMnuVslForms,
            this.tsMnuVslNCR,
            this.tsMnuVslTaskList,
            this.tsMnuVslIncidentReport,
            this.tsMnuVslMinutesOfSafety,
            this.tsMnuVslAwarenessReport,
            this.tsMnuVslMastersReview,
            this.tsMnuDocumentManagement,
            this.tsMnuVslAlerts_Circulars,
            this.tsMnuVslRiskAssements});
            this.VslApps_toolStripMenuItem1.Name = "VslApps_toolStripMenuItem1";
            this.VslApps_toolStripMenuItem1.Size = new System.Drawing.Size(234, 22);
            this.VslApps_toolStripMenuItem1.Text = "Vsl Applications ( View Only )";
            // 
            // tsmu_VslDashBoard
            // 
            this.tsmu_VslDashBoard.Name = "tsmu_VslDashBoard";
            this.tsmu_VslDashBoard.Size = new System.Drawing.Size(234, 22);
            this.tsmu_VslDashBoard.Text = "Vsl Dashboard";
            this.tsmu_VslDashBoard.Click += new System.EventHandler(this.tsmu_VslDashBoard_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(231, 6);
            // 
            // tsMnuVslForms
            // 
            this.tsMnuVslForms.Name = "tsMnuVslForms";
            this.tsMnuVslForms.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslForms.Text = "Vsl Forms";
            this.tsMnuVslForms.Click += new System.EventHandler(this.tsMnuVslForms_Click);
            // 
            // tsMnuVslNCR
            // 
            this.tsMnuVslNCR.Name = "tsMnuVslNCR";
            this.tsMnuVslNCR.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslNCR.Text = "NCR";
            this.tsMnuVslNCR.Click += new System.EventHandler(this.tsMnuVslNCR_Click);
            // 
            // tsMnuVslTaskList
            // 
            this.tsMnuVslTaskList.Name = "tsMnuVslTaskList";
            this.tsMnuVslTaskList.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslTaskList.Text = "Task List";
            this.tsMnuVslTaskList.Click += new System.EventHandler(this.tsMnuVslTaskList_Click);
            // 
            // tsMnuVslIncidentReport
            // 
            this.tsMnuVslIncidentReport.Name = "tsMnuVslIncidentReport";
            this.tsMnuVslIncidentReport.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslIncidentReport.Text = "Incident / Investigation Report";
            this.tsMnuVslIncidentReport.Click += new System.EventHandler(this.tsMnuVslIncidentReport_Click);
            // 
            // tsMnuVslMinutesOfSafety
            // 
            this.tsMnuVslMinutesOfSafety.Name = "tsMnuVslMinutesOfSafety";
            this.tsMnuVslMinutesOfSafety.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslMinutesOfSafety.Text = "Safety Committee Meeting";
            this.tsMnuVslMinutesOfSafety.Click += new System.EventHandler(this.tsMnuVslMinutesOfSafety_Click);
            // 
            // tsMnuVslAwarenessReport
            // 
            this.tsMnuVslAwarenessReport.Name = "tsMnuVslAwarenessReport";
            this.tsMnuVslAwarenessReport.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslAwarenessReport.Text = "Awareness Report";
            this.tsMnuVslAwarenessReport.Click += new System.EventHandler(this.tsMnuVslAwarenessReport_Click);
            // 
            // tsMnuVslMastersReview
            // 
            this.tsMnuVslMastersReview.Name = "tsMnuVslMastersReview";
            this.tsMnuVslMastersReview.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslMastersReview.Text = "Master\'s Review";
            this.tsMnuVslMastersReview.Click += new System.EventHandler(this.tsMnuVslMastersReview_Click);
            // 
            // tsMnuDocumentManagement
            // 
            this.tsMnuDocumentManagement.Name = "tsMnuDocumentManagement";
            this.tsMnuDocumentManagement.Size = new System.Drawing.Size(234, 22);
            this.tsMnuDocumentManagement.Text = "Document Management";
            this.tsMnuDocumentManagement.Click += new System.EventHandler(this.tsMnuDocumentManagement_Click);
            // 
            // tsMnuVslAlerts_Circulars
            // 
            this.tsMnuVslAlerts_Circulars.Name = "tsMnuVslAlerts_Circulars";
            this.tsMnuVslAlerts_Circulars.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslAlerts_Circulars.Text = "Alerts / Circulars";
            this.tsMnuVslAlerts_Circulars.Click += new System.EventHandler(this.tsMnuVslAlerts_Circulars_Click);
            // 
            // tsMnuVslRiskAssements
            // 
            this.tsMnuVslRiskAssements.Name = "tsMnuVslRiskAssements";
            this.tsMnuVslRiskAssements.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslRiskAssements.Text = "Risk Assessments";
            this.tsMnuVslRiskAssements.Click += new System.EventHandler(this.tsMnuVslRiskAssements_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(231, 6);
            // 
            // tsMnuForms
            // 
            this.tsMnuForms.Name = "tsMnuForms";
            this.tsMnuForms.Size = new System.Drawing.Size(234, 22);
            this.tsMnuForms.Text = "Forms";
            this.tsMnuForms.Click += new System.EventHandler(this.tsMnuForms_Click);
            // 
            // tsMnuAuditInspection
            // 
            this.tsMnuAuditInspection.Name = "tsMnuAuditInspection";
            this.tsMnuAuditInspection.Size = new System.Drawing.Size(234, 22);
            this.tsMnuAuditInspection.Text = "Audit / Inspection";
            this.tsMnuAuditInspection.Click += new System.EventHandler(this.tsMnuAuditInspection_Click);
            // 
            // tsMnuNCR
            // 
            this.tsMnuNCR.Name = "tsMnuNCR";
            this.tsMnuNCR.Size = new System.Drawing.Size(234, 22);
            this.tsMnuNCR.Text = "NCR";
            this.tsMnuNCR.Click += new System.EventHandler(this.tsMnuNCR_Click);
            // 
            // tsMnuDefects
            // 
            this.tsMnuDefects.Name = "tsMnuDefects";
            this.tsMnuDefects.Size = new System.Drawing.Size(234, 22);
            this.tsMnuDefects.Text = "Defects";
            this.tsMnuDefects.Click += new System.EventHandler(this.tsMnuDefects_Click);
            // 
            // tsMnuTaskList
            // 
            this.tsMnuTaskList.Name = "tsMnuTaskList";
            this.tsMnuTaskList.Size = new System.Drawing.Size(234, 22);
            this.tsMnuTaskList.Text = "Task List";
            this.tsMnuTaskList.Click += new System.EventHandler(this.tsMnuTaskList_Click);
            // 
            // tsMnuIncidentReport
            // 
            this.tsMnuIncidentReport.Name = "tsMnuIncidentReport";
            this.tsMnuIncidentReport.Size = new System.Drawing.Size(234, 22);
            this.tsMnuIncidentReport.Text = "Incident / Investigation Report";
            this.tsMnuIncidentReport.Click += new System.EventHandler(this.tsMnuIncidentReport_Click);
            // 
            // tsMnuMinutesOfSafety
            // 
            this.tsMnuMinutesOfSafety.Name = "tsMnuMinutesOfSafety";
            this.tsMnuMinutesOfSafety.Size = new System.Drawing.Size(234, 22);
            this.tsMnuMinutesOfSafety.Text = "Safety Committee Meeting";
            this.tsMnuMinutesOfSafety.Click += new System.EventHandler(this.tsMnuMinutesOfSafety_Click);
            // 
            // tsMnuAwarenessReport
            // 
            this.tsMnuAwarenessReport.Name = "tsMnuAwarenessReport";
            this.tsMnuAwarenessReport.Size = new System.Drawing.Size(234, 22);
            this.tsMnuAwarenessReport.Text = "Awareness Report";
            this.tsMnuAwarenessReport.Click += new System.EventHandler(this.tsMnuAwarenessReport_Click);
            // 
            // tsMnuMastersReview
            // 
            this.tsMnuMastersReview.Name = "tsMnuMastersReview";
            this.tsMnuMastersReview.Size = new System.Drawing.Size(234, 22);
            this.tsMnuMastersReview.Text = "Master\'s Review";
            this.tsMnuMastersReview.Click += new System.EventHandler(this.tsMnuMastersReview_Click);
            // 
            // tsMnuRiskAssements
            // 
            this.tsMnuRiskAssements.Name = "tsMnuRiskAssements";
            this.tsMnuRiskAssements.Size = new System.Drawing.Size(234, 22);
            this.tsMnuRiskAssements.Text = "Risk Assessments";
            this.tsMnuRiskAssements.Click += new System.EventHandler(this.tsMnuRiskAssements_Click);
            // 
            // tsMnuVslCertificate
            // 
            this.tsMnuVslCertificate.Name = "tsMnuVslCertificate";
            this.tsMnuVslCertificate.Size = new System.Drawing.Size(234, 22);
            this.tsMnuVslCertificate.Text = "Vsl Certificates";
            this.tsMnuVslCertificate.Click += new System.EventHandler(this.tsMnuVslCertificate_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tsMnuAbout
            // 
            this.tsMnuAbout.Name = "tsMnuAbout";
            this.tsMnuAbout.Size = new System.Drawing.Size(152, 22);
            this.tsMnuAbout.Text = "About";
            this.tsMnuAbout.Click += new System.EventHandler(this.tsMnuAbout_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // frmMainForm_Marine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmMainForm_Marine";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMainForm_Marine_FormClosing);
            this.Load += new System.EventHandler(this.frmMainForm_Marine_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_TopPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_TopPanel_Sheet1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelLoading.ResumeLayout(false);
            this.panelLoading.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars_Sheet1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cboVslFilter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem VslApps_toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmu_VslDashBoard;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslNCR;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem tsMnuNCR;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblSvrName;
        private System.Windows.Forms.ToolStripStatusLabel tsLblUserId;
        private System.Windows.Forms.ToolStripStatusLabel tlsStatuslblTotalVessels;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private FarPoint.Win.Spread.FpSpread fpSpread_Particulars;
        private FarPoint.Win.Spread.SheetView fpSpread_Particulars_Sheet1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.LinkLabel lnkRefresh;
        private System.Windows.Forms.ProgressBar progressBarRefresh;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panelLoading;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuForms;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslForms;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAwarenessReport;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMastersReview;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMinutesOfSafety;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslAwarenessReport;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslMinutesOfSafety;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslMastersReview;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private FarPoint.Win.Spread.FpSpread fpSpread_TopPanel;
        private FarPoint.Win.Spread.SheetView fpSpread_TopPanel_Sheet1;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsMnuNCRTrending;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAwarenessReportTrending;
        private System.Windows.Forms.ToolStripMenuItem tsMnuRiskAssements;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslRiskAssements;
        private System.Windows.Forms.ComboBox cboCompany_Filter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAuditInspection;
        private System.Windows.Forms.ToolStripMenuItem tsMnuTaskList;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslTaskList;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDefects;
        private System.Windows.Forms.ToolStripMenuItem tlsMnuSetUp;
        private System.Windows.Forms.ToolStripMenuItem tlsMnuRootCauseAnalysisChartSetup;
        private System.Windows.Forms.ToolStripMenuItem tlsMnuAuditInspectionSetup;
        private System.Windows.Forms.CheckBox chkShowOnlyActionColumns;
        private System.Windows.Forms.LinkLabel lnkReset;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ToolStripMenuItem tsMnuIncidentReport;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslIncidentReport;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.CheckBox chkShowDashboard;
        private System.Windows.Forms.Button btnTechDashboard;
        private System.Windows.Forms.Button btnProcurement;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCrewDashboard;
        private System.Windows.Forms.Button btnDMS;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslCertificate;
        private System.Windows.Forms.CheckBox chkShowMyApproveColumn;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslAlerts_Circulars;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDocumentManagement;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}