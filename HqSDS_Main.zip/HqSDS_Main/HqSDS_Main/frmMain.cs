﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Hide();
            Application.DoEvents();

            if (!PG.InitialiseProjectName()) return;

            if (AppInstanceControler.CheckAppRunningWithMutex(PG.projectName, true))
            {
                this.Close();
                return;
            }

            string[] defaultArgs = Environment.GetCommandLineArgs();
            if (!PG.ProjInits(defaultArgs))
            {
                this.Close();
                return;
            }
       
            try
            {
                PG.Initialise_AllowedUserForAccessRights(PG.Gb.CompanyId);

                string script = " Select HQDept from HQ_Users_V where C_CompanyID = " + PG.Gb.CompanyId + " and UserID =" + Gfn.Qss(PG.Gb.User.CurUserID);
                PG.currentUserDept = PG.Gb.DBFn.Aqr(script).ToString();

                if  ((PG.currentUserDept.ToUpper() == PG.HSQE_DeptName.ToUpper() || PG.currentUserDept.ToUpper() == "Marine".ToUpper())
                    && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_MARINEDASHBOARD))
                {
                    frmMainForm_Marine objMain = new frmMainForm_Marine();
                    try
                    {
                        objMain.ShowDialog();
                    }
                    finally
                    {
                        objMain = null;
                    }
                }
                else if (PG.currentUserDept.ToUpper() == "Crew".ToUpper()
                   && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_CREWDASHBOARD))
                {
                    frmMainForm_Crew objMain = new frmMainForm_Crew();
                    try
                    {
                        objMain.ShowDialog();
                    }
                    finally
                    {
                        objMain = null;
                    }
                }

                else
                {
                    frmMainForm_Tech objMain = new frmMainForm_Tech();
                    try
                    {
                        objMain.ShowDialog();
                    }
                    finally
                    {
                        objMain = null;
                    }
                }
            }
            finally
            {
                this.Close();
            }
        }
    }
}
