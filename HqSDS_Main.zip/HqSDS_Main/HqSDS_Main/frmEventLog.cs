﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmEventLog : Form
    {
        public string eqpNamePosn = "", mntDesc = ""; public int mReportRefNo = 0;
        public int vesselID = -1;
        const int COL_ADDEDONDISPLAY = 1,
                  COL_ACTIVITY = 2,
                  COL_ADDEDON = 6;

        public frmEventLog()
        {
            InitializeComponent();
        }

        private void frmEventLog_Load(object sender, EventArgs e)
        {
            DesignAndBindEventLogGrid();
        }

        private void DesignAndBindEventLogGrid()
        {
            DataTable dt = null;
            List<DgvInits> logColList = new List<DgvInits>();
            try
            {
                logColList.Add(new DgvInits("Origin", "Origin", 55, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("AddedOnDisplay", "Date", 135, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("Activity", "Activity", 170, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("Role", "Role", 80, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("UserName", "User Name", 100, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("Remarks", "Remarks", 220, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("AddedOn", "Date", 135, Color.Black, SystemColors.ButtonFace, false, true));

                dt = GetEventLogDataTable();
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadLog, logColList, dt, false, true, true);
                fpSpreadLog.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpreadLog.ActiveSheet.RowHeader.Visible = false;


                fpSpreadLog_ColumnWidthChanged(null, null);
            }
            finally
            {
                dt = null;
                logColList = null;
            }
        }

        private DataTable GetEventLogDataTable()
        {
            string sql = "";
            DataTable dt = null;
            try
            {
                sql = " Select *, replace(convert(varchar(12),Addedon,106),' ','-')+' '+convert(varchar, Addedon,108) as AddedonDisplay, Role" +
                      " from V_VslLog " +
                      " where VesselID = " + vesselID +
                      " order by Addedon ";
                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmEventLog.cs", "GetEventLogDataTable", err.Message);
            }
            return dt;
        }

        private void fpSpreadLog_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpreadLog.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void fpSpreadLog_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpreadLog.ActiveSheet.Columns[COL_ADDEDON].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

                if (e.Column == COL_ADDEDONDISPLAY)
                    fpSpreadLog.ActiveSheet.AutoSortColumn(COL_ADDEDON);
                else
                    fpSpreadLog.ActiveSheet.AutoSortColumn(e.Column);
                fpSpreadLog.ActiveSheet.Columns[COL_ADDEDONDISPLAY].SortIndicator = fpSpreadLog.ActiveSheet.Columns[COL_ADDEDON].SortIndicator;
            }
        }

        private void fpSpreadLog_AutoSortingColumn(object sender, FarPoint.Win.Spread.AutoSortingColumnEventArgs e)
        {
            fpSpreadLog.ActiveSheet.Columns[COL_ADDEDONDISPLAY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

            if (e.Column == COL_ADDEDONDISPLAY)
            {
                if (e.Ascending)
                {
                    fpSpreadLog.ActiveSheet.AutoSortColumn(COL_ADDEDON);
                    fpSpreadLog.ActiveSheet.Columns[COL_ADDEDONDISPLAY].SortIndicator = fpSpreadLog.ActiveSheet.Columns[COL_ADDEDON].SortIndicator;
                }
                e.Cancel = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
