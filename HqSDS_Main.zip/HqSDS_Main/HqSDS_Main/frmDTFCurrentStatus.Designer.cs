﻿namespace HqSDS_Main
{
    partial class frmDTFCurrentStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDTFCurrentStatus));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.fpSpreadDTF = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadDTF_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblTotalVessels = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExportXL = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoHQOutwards = new System.Windows.Forms.RadioButton();
            this.rdoHQInwards = new System.Windows.Forms.RadioButton();
            this.cboCompany_Filter = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF_Sheet1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.fpSpreadDTF, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(579, 612);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // fpSpreadDTF
            // 
            this.fpSpreadDTF.AccessibleDescription = "fpSpreadDTF, Sheet1, Row 0, Column 0, ";
            this.fpSpreadDTF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadDTF.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadDTF.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadDTF.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadDTF.HorizontalScrollBar.Name = "";
            this.fpSpreadDTF.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpreadDTF.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadDTF.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadDTF.Location = new System.Drawing.Point(0, 58);
            this.fpSpreadDTF.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpreadDTF.Name = "fpSpreadDTF";
            this.fpSpreadDTF.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadDTF_Sheet1});
            this.fpSpreadDTF.Size = new System.Drawing.Size(579, 534);
            this.fpSpreadDTF.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadDTF.TabIndex = 117;
            this.fpSpreadDTF.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadDTF.VerticalScrollBar.Name = "";
            this.fpSpreadDTF.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpreadDTF.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadDTF.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadDTF.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpreadDTF.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpreadDTF_CellClick);
            this.fpSpreadDTF.AutoSortingColumn += new FarPoint.Win.Spread.AutoSortingColumnEventHandler(this.fpSpreadDTF_AutoSortingColumn);
            // 
            // fpSpreadDTF_Sheet1
            // 
            this.fpSpreadDTF_Sheet1.Reset();
            this.fpSpreadDTF_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadDTF_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadDTF_Sheet1.ColumnCount = 3;
            this.fpSpreadDTF_Sheet1.RowCount = 10;
            this.fpSpreadDTF_Sheet1.AllowNoteEdit = false;
            this.fpSpreadDTF_Sheet1.AutoCalculation = false;
            this.fpSpreadDTF_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadDTF_Sheet1.AutoSortFrozenRows = false;
            this.fpSpreadDTF_Sheet1.AutoSortTrailingFrozenRows = false;
            this.fpSpreadDTF_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadDTF_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadDTF_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadDTF_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadDTF_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadDTF_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadDTF_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), System.Drawing.SystemColors.ControlLightLight, System.Drawing.SystemColors.ControlDark, 1);
            this.fpSpreadDTF_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadDTF_Sheet1.RowHeader.AutoText = FarPoint.Win.Spread.HeaderAutoText.Blank;
            this.fpSpreadDTF_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadDTF_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadDTF_Sheet1.SelectionFont = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadDTF_Sheet1.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors;
            this.fpSpreadDTF_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadDTF_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadDTF_Sheet1.ShowRowSelector = true;
            this.fpSpreadDTF_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), System.Drawing.SystemColors.ControlLightLight, System.Drawing.SystemColors.ControlDark, 1);
            this.fpSpreadDTF_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblTotalVessels});
            this.statusStrip1.Location = new System.Drawing.Point(0, 592);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(579, 20);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblTotalVessels
            // 
            this.tsLblTotalVessels.Name = "tsLblTotalVessels";
            this.tsLblTotalVessels.Size = new System.Drawing.Size(118, 15);
            this.tsLblTotalVessels.Text = "toolStripStatusLabel1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cboCompany_Filter);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnExportXL);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(579, 58);
            this.panel1.TabIndex = 1;
            // 
            // btnExportXL
            // 
            this.btnExportXL.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportXL.ForeColor = System.Drawing.Color.Black;
            this.btnExportXL.Image = ((System.Drawing.Image)(resources.GetObject("btnExportXL.Image")));
            this.btnExportXL.Location = new System.Drawing.Point(391, 12);
            this.btnExportXL.Margin = new System.Windows.Forms.Padding(0);
            this.btnExportXL.Name = "btnExportXL";
            this.btnExportXL.Size = new System.Drawing.Size(50, 40);
            this.btnExportXL.TabIndex = 49;
            this.btnExportXL.Text = "Export";
            this.btnExportXL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportXL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExportXL.UseVisualStyleBackColor = false;
            this.btnExportXL.Click += new System.EventHandler(this.btnExportXL_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Font = new System.Drawing.Font("Calibri", 9.75F);
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(474, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 40);
            this.btnClose.TabIndex = 59;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoHQOutwards);
            this.groupBox1.Controls.Add(this.rdoHQInwards);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(153, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(223, 48);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Option";
            // 
            // rdoHQOutwards
            // 
            this.rdoHQOutwards.AutoSize = true;
            this.rdoHQOutwards.ForeColor = System.Drawing.Color.Black;
            this.rdoHQOutwards.Location = new System.Drawing.Point(113, 21);
            this.rdoHQOutwards.Name = "rdoHQOutwards";
            this.rdoHQOutwards.Size = new System.Drawing.Size(96, 18);
            this.rdoHQOutwards.TabIndex = 2;
            this.rdoHQOutwards.TabStop = true;
            this.rdoHQOutwards.Text = "HQ Outwards";
            this.rdoHQOutwards.UseVisualStyleBackColor = true;
            this.rdoHQOutwards.CheckedChanged += new System.EventHandler(this.rdo_CheckedChanged);
            // 
            // rdoHQInwards
            // 
            this.rdoHQInwards.AutoSize = true;
            this.rdoHQInwards.ForeColor = System.Drawing.Color.Black;
            this.rdoHQInwards.Location = new System.Drawing.Point(14, 21);
            this.rdoHQInwards.Name = "rdoHQInwards";
            this.rdoHQInwards.Size = new System.Drawing.Size(88, 18);
            this.rdoHQInwards.TabIndex = 1;
            this.rdoHQInwards.TabStop = true;
            this.rdoHQInwards.Text = "HQ Inwards";
            this.rdoHQInwards.UseVisualStyleBackColor = true;
            this.rdoHQInwards.CheckedChanged += new System.EventHandler(this.rdo_CheckedChanged);
            // 
            // cboCompany_Filter
            // 
            this.cboCompany_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompany_Filter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCompany_Filter.FormattingEnabled = true;
            this.cboCompany_Filter.Location = new System.Drawing.Point(12, 29);
            this.cboCompany_Filter.MaxDropDownItems = 15;
            this.cboCompany_Filter.Name = "cboCompany_Filter";
            this.cboCompany_Filter.Size = new System.Drawing.Size(94, 23);
            this.cboCompany_Filter.TabIndex = 61;
            this.cboCompany_Filter.SelectedIndexChanged += new System.EventHandler(this.cboCompany_Filter_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 60;
            this.label1.Text = "Company";
            // 
            // frmDTFCurrentStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 612);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmDTFCurrentStatus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DTF Current Status";
            this.Load += new System.EventHandler(this.frmDTFCurrentStatus_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadDTF_Sheet1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoHQOutwards;
        private System.Windows.Forms.RadioButton rdoHQInwards;
        private FarPoint.Win.Spread.FpSpread fpSpreadDTF;
        private FarPoint.Win.Spread.SheetView fpSpreadDTF_Sheet1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblTotalVessels;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnExportXL;
        private System.Windows.Forms.ComboBox cboCompany_Filter;
        private System.Windows.Forms.Label label1;
    }
}