﻿using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using Microsoft.Win32;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public class PG
    {
        public static string xcompanyCode = "", hqAppFolder = "", companyName = "", servename = "", AppVersion = "1.0", projectName = "", webSvcURL = "", default_ProcAppToCall = "", curEnvironment = "", currentUserDept = "";
        public static string winSdsRootDir, winSdsBaseDir, sdsTempDir, xlsOutputFolderPath;
        public static string usersToHideShowinVslFilterList = "", pmsAllowedRolesToSuptReview = "", defaultEqpGroup = "SDS", allowedVsl_HQPMS = "", intervalsToExcludeInPMSDue = "";
        public static string dmWebSvcURL = "", dmCef32bitAppName = "", dmCef64bitAppName = "",
            showOnlySuptApproveColumns_Marine = "", showOnlyMgrApproveColumns_Marine = "", showOnlyGenMgrApproveColumns_Marine = "", showOnlySenMgrApproveColumns_Marine = "", showOnlyDirApproveColumns_Marine = "",
            showOnlySuptApproveColumns_Tech = "", showOnlyMgrApproveColumns_Tech = "", showOnlyGenMgrApproveColumns_Tech = "", showOnlySenMgrApproveColumns_Tech = "", showOnlyDirApproveColumns_Tech = "",
            showOnlySuptApproveColumns_Crew = "", showOnlyMgrApproveColumns_Crew = "", showOnlyGenMgrApproveColumns_Crew = "", showOnlySenMgrApproveColumns_Crew = "", showOnlyDirApproveColumns_Crew = "",
            isToExcludeFromShowUserActionColumnList = "", laidupVessels = "", categoriesFeedBackFormRequired ="";

        public static bool allowTochangeUserInfo = false, allowToManageUserVsls = false, allowTochangeLubOPaintSetup = false, allowedUserToEditVendor = false, isUserAllowedToSeeTestUsers = false,
                           isToEnableDocMgmt = false, allowedUserToAccess_FleetEqpmtManager = false, allowToAddEditDeleteDelivLocation = false, allowToAddEditDeleteCurrency = false, allowToAddEditDeleteSettings = false,
                           allowToAddEditDeleteLegalEntity = false, userAllowedToSeeTrainVsl = false, isAllowedUserRoleToRefreshHQDashboard = false, isAllowedUserRoleToGetVendorLink = false,
                           isAllowedUserToRe_interfacePO2Agresso = false, enableCriticalSparesFeature = false, isCriticalSparesGroups = false, allowToManageCriticalSpares = false, isEnableAlarmsAndRoutinesMaintType = false,
                           isToShowSFICode = false, isPMS_HidePMMDetails = false, isPMS_HidePMSCode = false, isPMS_HideMaintIncharge = false, isPMS_HideMaintResponsible = false, isToHideEquipmentAssembly = false,
                           isToShowSetLimits = false, isToShowRangeValue = false, isToShowSignalType = false, isToShowCurrentValue = false, isToEnableDTFReports = false, isAllowedUserToDoDTF = false, isExcludeVerificationItemsFromDueList = false,
                           isToShowKPITrending_NonCriticalMaint_Fleet = false, isToShowKPITrending_CriticalMaint_Fleet = false, isToShowKPITrending_NonCriticalEqp_Fleet = false, isToShowKPITrending_CriticalEqp_Fleet = false, isToShowKPITrending_All_Fleet = false,
                           isToShowKPITrending_NonCriticalMaint_Vsl = false, isToShowKPITrending_CriticalMaint_Vsl = false, isToShowKPITrending_NonCriticalEqp_Vsl = false, isToShowKPITrending_CriticalEqp_Vsl = false, isToShowKPITrending_All_VSL = false, isToShowKPITrending_ProcurementKPIData = false, isUsersAllowedToAddEditDeleteHolidays = false, isToShowKPITrending_DefectsVesselAvailability = false,
                           isToEnableExportEquipmentParticulars = false, isToEnableExportEquipmentUnitParticulars = false, isToEnableExportPMSReport = false, isToEnableExportCriticalSparesList = false,
                           isToEnableDefects = false, isToEnableForms = false, isAllowedUserSetupForms4Vsls = false, isAllowedUserToClearCefCache = false, isToShowNCRTrending = false, isToShowAWRTrending = false, isToEnableThirdPartyVesselsFeature = false,
                           isAllowedUserIDToSetupAI = false, isAllowedUserIDToSetupMSCAT = false, isAllowedUserToSetupVslUserMgmt = false, isCert_FilterOdueDeptwise = false,
                           isAllowedToFormsDesigner = false, isAllowedToHQCircularsMgmt = false, isAllowedToSetupSettingsManagement = false, isToHideSparesMinQty = false, isToHideSparesMaxQty = false, isToHideSparesWkg_Qty = false, isAllowedUserToDoBlobManualSync = false,
                           isAllowedAddEditApplicationChangeDetails = false, isAllowedAddEditVslCrewAddNewController = false;

        public const int generalFleetVslId = -1;
        public static int windowPeriod_OStdngEqpMaintItemsCritical = 0, windowPeriod_OStdngMaintItems = 0, windowPeriod_OStdngSvyItems = 0,
                     windowPeriod_OStdngNonCritMaintItems = 0, windowPeriod_OStdngCritMaintItems = 0,
                     windowPeriod_OStdngNonCritEqpMaintItems = 0, windowPeriod_OStdngCritEqpMaintItems = 0;

        public static int PAINT_TYPESID = 15, LUBE_TYPESID = 16, CHEMICAL_TYPESID = 13, timeToAdd = 8, delivLocation_MaximumAttachmentSizeInKb = 250, df_vesselID = -1, criticalSpAlert_NoOfQtyToAddWithMinQty = 0;
        public static string ST_CATEGORY = "ST", SP_CATEGORY = "SP", CATEGORYCODE = "SPARES";
        public static DataTable dtAllowedUserForAccessRights = null;

        #region Refresh - Called Mode
        public static readonly string REFRESH_CALLEDMODE_TECH_DEFECTS = "DEFECTS",
                                      REFRESH_CALLEDMODE_TECH_SUPT_MNTQ = "SUPT_MNTQ",
                                      REFRESH_CALLEDMODE_TECH_CRITICALSPARES = "CRITICALSPARES",
                                      REFRESH_CALLEDMODE_TECH_SUPT_TOAPPROVEMNT = "SUPT_TOAPPROVEMNT",
                                      REFRESH_CALLEDMODE_TECH_SUPT_FORMS_APPR = "SUPT_FORMS_APPR",
                                      REFRESH_CALLEDMODE_TECH_AUDITINSPECTION = "AUDITINSPECTION",
                                      REFRESH_CALLEDMODE_TECH_NCR = "NCR",
                                      REFRESH_CALLEDMODE_TECH_TASK = "TASK",
                                      REFRESH_CALLEDMODE_TECH_INCIDENTREPORT = "INCIDENT_REPORT",
                                      REFRESH_CALLEDMODE_TECH_INVESTIGATIONREPORT = "INVESTIGATION_REPORT",
                                      REFRESH_CALLEDMODE_TECH_AWARENESS_REPORT = "AWARENESS_REPORT",
                                      REFRESH_CALLEDMODE_TECH_MASTERS_REVIEW = "MASTERS_REVIEW",
                                      REFRESH_CALLEDMODE_TECH_MINUTES_OF_SAFETY = "MINUTES_OF_SAFETY",
                                      REFRESH_CALLEDMODE_TECH_CORRECTIVEMAINTENANCE = "CORRECTIVEMAINTENANCE",
                                      REFRESH_CALLEDMODE_TECH_RISKASSEMENTS = "RISKASSEMENTS",
                                      REFRESH_CALLEDMODE_TECH_MONTHENDDOC = "MONTHENDDOC",
                                      REFRESH_CALLEDMODE_TECH_CERTIFICATE = "CERTIFICATES",
                                      REFRESH_CALLEDMODE_TECH_ALL = "";

        public static readonly string REFRESH_CALLEDMODE_MARINE_FORMS = "FORMS",
                                      REFRESH_CALLEDMODE_MARINE_AUDITINSPECTION = "AUDITINSPECTION",
                                      REFRESH_CALLEDMODE_MARINE_NCR = "NCR",
                                      REFRESH_CALLEDMODE_MARINE_DEFECTS = "DEFECTS",
                                      REFRESH_CALLEDMODE_MARINE_TASK = "TASK",
                                      REFRESH_CALLEDMODE_MARINE_INCIDENTREPORT = "INCIDENT_REPORT",
                                      REFRESH_CALLEDMODE_MARINE_INVESTIGATIONREPORT = "INVESTIGATION_REPORT",
                                      REFRESH_CALLEDMODE_MARINE_AWARENESS_REPORT = "AWARENESS_REPORT",
                                      REFRESH_CALLEDMODE_MARINE_MASTERS_REVIEW = "MASTERS_REVIEW",
                                      REFRESH_CALLEDMODE_MARINE_MINUTES_OF_SAFETY = "MINUTES_OF_SAFETY",
                                      REFRESH_CALLEDMODE_MARINE_DOCMGMT = "DOCUMENT_MGMT",
                                      REFRESH_CALLEDMODE_MARINE_RISKASSEMENTS = "RISKASSEMENTS",
                                      REFRESH_CALLEDMODE_MARINE_CERTIFICATE = "CERTIFICATES",
                                      REFRESH_CALLEDMODE_MARINE_ALL = "";

        public static readonly string REFRESH_CALLEDMODE_CREW_CCMS_MODULE = "CCMS_MODULE",
                                      REFRESH_CALLEDMODE_CREW_CCMS_LEARNING = "CCMS_LEARNING",
                                      REFRESH_CALLEDMODE_CREW_CREW_RESTHOURS = "CREW_RESTHOURS",
                                      REFRESH_CALLEDMODE_CREW_FORMS = "FORMS",
                                      REFRESH_CALLEDMODE_CREW_NCR = "NCR",
                                      REFRESH_CALLEDMODE_CREW_DEFECT = "DEFECTS",
                                      REFRESH_CALLEDMODE_CREW_TASK = "TASK",
                                      REFRESH_CALLEDMODE_CREW_MINUTES_OF_SAFETY = "MINUTES_OF_SAFETY",
                                      REFRESH_CALLEDMODE_CREW_AWARENESS_REPORT = "AWARENESS_REPORT",
                                      REFRESH_CALLEDMODE_CREW_MASTERS_REVIEW = "MASTERS_REVIEW",
                                      REFRESH_CALLEDMODE_CREW_INCIDENTREPORT = "INCIDENT_REPORT",
                                      REFRESH_CALLEDMODE_CREW_INVESTIGATIONREPORT = "INVESTIGATION_REPORT",
                                      REFRESH_CALLEDMODE_CREW_CERTIFICATE = "CERTIFICATES",
                                      REFRESH_CALLEDMODE_CREW_ALL = "";
        #endregion

        #region PMS Related
        public const string MAINTTYPE_ALARMS_ROUTINE = "ALARMS_ROUTINES",
                            MAINTTYPE_PMS = "PMS",
                            MAINTTYPE_CONDN_MONITORING_ROUTINE = "CONDNMONITORINGRTNS",
                            THIRDPARTYVSL = "3RD-PARTY";

        public static string EQUIPMENT_GROUPCODE_CRITICAL = "@", EQUIPMENT_GROUPCODE_NOTASSIGNED = "#", EQUIPMENT_GROUPCODE_VSLSPECIFIC = "$";

        public static readonly string MREASON_BREAKDOWN = "BREAKDOWN",
                                      MREASON_LEAKAGES = "LEAKAGES",
                                      MREASON_POOR_EFFICIENCY = "POOR EFFICIENCY",
                                      MCOND_IN_VERY_POORSTATE = "IN VERY POOR STATE",
                                      MCOND_HEAVILY_CARBONISED = "HEAVILY CARBONISED",
                                      MCOMPL_STOPGAP_MEASUREONLY = "STOP-GAP MEASURE ONLY",
                                      MCOMPL_TOREDO_AT_DRYDOCKING = "TO REDO AT DRYDOCKING",
                                      MCOMPL_TOREDO_WHEN_SPARESRECVD = "TO REDO WHEN SPARES RECVD";
        #endregion

        #region Group Name and App Name
        public static readonly string GROUPNAME_CERTIFICATE = "CERTIFICATES",
                                      GROUPNAME_DOCUMENT = "DOCUMENT",
                                      GROUPNAME_FORMS = "FORMS",
                                      GROUPNAME_ROUTINES = "ROUTINES",
                                      GROUPNAME_RISKASSESSMENT = "RISK ASSESSMENT",
                                      GROUPNAME_RISKASSESMENT = "RISK ASSESMENT",
                                      GROUPNAME_AI_SCHED = "AI SCHED / REPORT",
                                      GROUPNAME_AI_APPROVAL = "AI APPROVAL",
                                      GROUPNAME_NCR = "NCR",
                                      GROUPNAME_DEFECTS = "DEFECTS",
                                      GROUPNAME_TASK = "TASK",
                                      GROUPNAME_INCIDENTREPORT = "INCIDENT REPORT",
                                      GROUPNAME_INCIDENTREPORT1 = "INCIDNT REPORT",
                                      GROUPNAME_INVESTIGATIONREPORT = "INVESTIGATION REPORT",
                                      GROUPNAME_INVESTIGATIONREPORT1 = "INVEST REPORT",
                                      GROUPNAME_AWARENESSREPORT = "AWARE. REPORT",
                                      GROUPNAME_MASTERSSAFETYREVIEW = "MASTER REVIEW",
                                      GROUPNAME_SAFETYCOMMITTEEMEETING = "SAFETY MEETING",
                                      GROUPNAME_SAFETYCOMMITTEEMEETING1 = "SAFETY MEETNG",
                                      GROUPNAME_CCMS_MODULE = "CCMS MODULE",
                                      GROUPNAME_CCMS_LEARNING = "CCMS TASK",
                                      GROUPNAME_CREWRESTHOURS = "CREW REST HOURS";

        public static string APPNAME_ProcurementWeb = "Procurement",
                             APPNAME_SparesInventory = "Spares - Inventory",
                             APPNAME_StoresInventory = "Stores - Inventory",
                             APPNAME_SparesPurchase = "HQ Spares - Purchase",
                             APPNAME_StoresPurchase = "HQ Stores - Purchase",

                             APPNAME_VslAppplication = "Vsl Applications ( View Only )",
                             APPNAME_VslDashBoard = "Vsl Dashboard",
                             APPNAME_VslPMS = "VslPMS",
                             APPNAME_CorrectiveMaintenance = "Corrective Maintenance",
                             APPNAME_DocMgmt = "Document Management",
                             APPNAME_DocMgmt_Cef = "DocMgmt_Cef",

                             APPNAME_Forms = "Forms",
                             APPNAME_Defects = "Defects",
                             APPNAME_NCR = "NCR",
                             APPNAME_INCIDENT = "Incident Report",
                             APPNAME_RISKASSEMENTS = "Risk Mgmt",
                             APPNAME_MARINEDASHBOARD = "Marine Dashboard",
                             APPNAME_CREWDASHBOARD = "Crew Dashboard",
                             APPNAME_MONTHENDDOC = "MonthEndDoc",
                             APPNAME_CERTIFICATE = "Certificates",
                             APPNAME_QUARTERLYSTORESREPORT = "QuarterlyStoresReports",

                             APPNAME_ExportEquipmentParticulars = "Export Equipment Particulars",
                             APPNAME_ExportEquipmentUnitParticulars = "Export Equipment Unit Particulars",
                             APPNAME_ExportPMSItems = "Export PMS Items",

                             APPNAME_CriticalSparesList = "Export Critical Spares",
                             APPNAME_HQPMS = "HQPMS",
                             APPNAME_RepairsPurchase = "Repairs and Services",
                             APPNAME_EquipmentManager = "Equipment Manager",

                             APPNAME_DefectTrendingEquipmentWise_SingleVsl = "DefectTrendingEquipmentWise_SingleVsl",
                             APPNAME_RefreshforSelectedVessel = "Refresh for Selected Vessel",
                             APPNAME_DTFDataTransferToolStripMenuItem = "DTF (Data Sync)",

                             APPNAME_KPITrending_Vsl = "KPI Trending of Outstanding Maint",
                             APPNAME_KPITrendingForVsl_NonCriticalMaint = "KPI Trending of Outstanding Maint (Critical Maintenance excluded)",
                             APPNAME_KPITrendingForVsl_CriticalMaint = "KPI Trending of Outstanding Maint (Critical Maintenance)",
                             APPNAME_KPITrendingForVsl_CriticalEqp = "KPI Trending of Outstanding Maint (Critical Eqpmt Maintenance)",
                             APPNAME_KPITrendingForVsl_NonCriticalEqp = "KPI Trending of Outstanding Maint (Non Critical Eqpmt Maintenance)",
                             APPNAME_KPITrendingForVsl_All = "kPITrendingForVsl_All",

                             //File Report Menus
                             APPNAME_KPITrendingForFleet_NonCriticalMaint = "KPI Trending for Fleet (Critical Maintenance excluded)",
                             APPNAME_KPITrendingForFleet_CriticalMaint = "KPI Trending for Fleet (Critical Maintenance)",
                             APPNAME_KPITrendingForFleet_CriticalEqp = "KPI Trending for Fleet (Critical Eqpmt Maintenance)",
                             APPNAME_KPITrendingForFleet_NonCriticalEqp = "KPI Trending for Fleet (Non Critical Eqpmt Maintenance)",
                             APPNAME_KPITrendingForFleet_All = "KPI Trending for Fleet - All",

                             APPNAME_DefectsReports = "Defects",
                             APPNAME_DefectTrending_AllVsls = "Defects Trending for Fleet (Equipment wise)",
                             APPNAME_DefectsVestsMnuDelAvailabilityKPI = "Defects Vessel Availability KPI",
                             APPNAME_DTFCurrentStatus = "Current Status",
                             APPNAME_DTFHistory = "DTF History",
                             APPNAME_DTFTrending = "DTF Trending",
                             APPNAME_Procurement = "Procurement KPI",
                             APPNAME_SparesPOsNotSubmitForRFQMoreThan3Days = "Spares POs [Not Submit for RFQ more than 3 days]",
                             APPNAME_SparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays = "Spare POs [Not Submit for Supt Approval more than 7 days]",
                             APPNAME_NCRTRENDING = "NCR Trending";
        #endregion

        public static string checkValue = "SlljjRsk";

        public static string HSQE_DeptName = "Marine";

        public static string DASHBOARDTYPE_MARINE = "Marine",
                             DASHBOARDTYPE_CREW = "Crew";

        public static DasGlobalInitsHQAndVsl Gb = null;
        public static Attachments attachment;

        public static bool isDirectAppCall = false;

        public static bool IsDotNetVersion3_5Installed()
        {
            bool result = false;
            string componentsKeyName = "";
            RegistryKey componentsKey = null;
            try
            {
                componentsKeyName = @"SOFTWARE\Microsoft\NET Framework Setup\NDP\v3.5";
                componentsKey = Registry.LocalMachine.OpenSubKey(componentsKeyName);
                if (componentsKey != null)
                {
                    // Validate framework installed is true ("1") and Service Pack Version should be 1 or above
                    result = ((Convert.ToInt32(componentsKey.GetValue("Install")) == 1) && (Convert.ToInt32(componentsKey.GetValue("SP")) >= 1));
                }
            }
            catch
            {
                result = false;
            }
            finally
            {
                componentsKey = null;
            }
            return (result);
        }

        public static bool ApplicationAlreadyRunning(string appName)
        {
            bool result = false;
            Process[] runningProcesses = null;
            Process currentProcess = null;
            try
            {
                currentProcess = Process.GetCurrentProcess();
                runningProcesses = Process.GetProcessesByName(appName);
                foreach (Process p in runningProcesses)
                {
                    if ((p.Id != currentProcess.Id) && (p.ProcessName.ToUpper() == appName.ToUpper()))
                    {
                        result = true;
                        break;
                    }
                }
            }
            catch (Exception er)
            {
                AddToGenErrorLog("PG.CS", "ApplicationAlreadyRunning", er.Message);
            }
            finally
            {
                currentProcess = null;
                runningProcesses = null;
            }
            return (result);
        }

        public static bool ProjInits(string[] CmdLineArgs)
        {
            bool result = false;
            try
            {
                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

                if (CmdLineArgs.Length <= 1)
                {
                    Gfn.Mb("Expected Parameter missing");
                    return (false);
                }

                if (!AppInits(CmdLineArgs)) return (result);

                isDirectAppCall = Gb.IsToConnecDirectDB;

                if (!isDirectAppCall)
                {
                    PG.webSvcURL = Gb.DBFn.webSvcURL;
                    PG.Encrypt(ref PG.webSvcURL, PG.checkValue);
                }

                //if (!InitialiseCommonSettings()) return (result);

                //if (!InitialiseHQAppDirectories()) return (result);

                attachment = new Attachments("", xlsOutputFolderPath, timeToAdd, Gb);

                result = true;
            }
            catch (Exception err)
            {
                result = false;
                PG.AddToGenErrorLog("PG.CS", "ProjInits", err.Message);
                Mb("Failed to initialise Project");
            }
            return (result);
        }

        public static bool AppInits(string[] args)
        {
            // UserInfo / VslStaff/ Vsl Info /Vsl owner Info / Database Connection
            Gb = new DasGlobalInitsHQAndVsl(args);
            return (Gb.HasGlobalVariablesInitialsed);
        }

        public static bool InitialiseProjectName()
        {
            bool result = false;
            try
            {
                PG.projectName = System.IO.Path.GetFileNameWithoutExtension((Environment.GetCommandLineArgs())[0].ToString().ToUpper());
                PG.projectName = PG.projectName.Replace(".VSHOST", "");
                result = true;
            }
            catch
            {
                result = false;
            }
            if (!result) Mb("Failed to Initialise Application Name");
            return (result);
        }

        public static bool InitialiseCommonSettings(string companyID)
        {
            bool result = false; string script = "", addlCompanyID = "";
            DataTable dt = null;
            try
            {
                if (companyID == "-99") addlCompanyID = " and C_CompanyID = (select Top 1 C_CompanyID from C_Company Order by C_CompanyID) ";
                else addlCompanyID = " and C_CompanyID = " + companyID;

                #region HQ Settings
                script = " select * from HQ_Settings " + Environment.NewLine +
                         " where 1=1 " + addlCompanyID + Environment.NewLine +
                         "   and SettingName in ('COMPANYCODE', 'CurEnvironment','USERSALLOWTOMANAGEHQUSERS','USERSALLOWEDTODOVSLMGMNT', 'VESSELSALLOWEDFORHQPMS', " + Environment.NewLine +
                         "                       'IsToEnableNCR', 'IsToEnableDocMgmt', 'USERSALLOWTOMANAGESETUP','USERSTOHIDEINVSLFILTER', 'ALLOWEDUSERTOACCESS_FLEETEQPMTMANAGER', " + Environment.NewLine +
                         "                       'USERSALLOWTOADDEDITDELETEDELIVLOCATION', 'USERSALLOWTOADDEDITDELETECURRENCY', 'USERSALLOWTOADDEDITDELETESETTINGS', 'UserAllowedToSeeTestUsers', " +
                         "                       'PMS_ALLOWEDROLESTOSUPTREVIEW' , 'UsersAllowToAddEditDeleteLegalEntity', 'DELIVLOCATION_MAXIMUMATTACHMENTSIZEINKB', 'DMWebSvcURL','DmCef32bitAppName','DmCef64bitAppName', " +
                         "                       'UserAllowedToSeeTrainVsl', 'AllowedUserRoleToRefreshHQDashboard', 'AllowedUserToViewDTFReport', 'AllowedUserToDoDTF', 'Default_ProcAppToCall', " +
                         "                       'IsToShowKPITrending_NonCriticalMaint_Fleet','IsToShowKPITrending_CriticalMaint_Fleet','IsToShowKPITrending_CriticalEqpMaint_Fleet','IsToShowKPITrending_NonCriticalEqpMaint_Fleet','IsToShowKPITrending_AllMaint_Fleet', " +
                         "                       'IsToShowKPITrending_NonCriticalMaint_Vsl','IsToShowKPITrending_CriticalMaint_Vsl','IsToShowKPITrending_CriticalEqpMaint_Vsl','IsToShowKPITrending_NonCriticalEqpMaint_Vsl','IsToShowKPITrending_AllMaint_Vsl' ,'ISTOSHOWKPITRENDING_PROCKPIDATA', 'USERSALLOWEDTOADDEDITDELETEHOLIDAYS','IsToShowKPITrending_DefectsVesselAvailability', " + Environment.NewLine +
                         "                       'IsToEnableExportEquipmentParticulars','IsToEnableExportEquipmentUnitParticulars','IsToEnableExportPMSReport','IsToEnableExportCriticalSparesList', 'AllowedUserSetupForms4Vsls', 'UserAllowedToClearCefCache', 'IsToShowNCRTrending', 'isToShowAWRTrending','WindowPeriod_OStdngMaintItems','WindowPeriod_OStdngEqpMaintItemsCritical','WindowPeriod_OStdngSvyItems','PMS_IntervalsToExcludeInDue', 'AllowedUserToSetupVslUserMgmt' " +
                         "                     , 'ShowOnlySuptApproveColumns_Marine', 'ShowOnlyMgrApproveColumns_Marine', 'ShowOnlyGenMgrApproveColumns_Marine', 'ShowOnlySenMgrApproveColumns_Marine', 'ShowOnlyDirApproveColumns_Marine'  " +
                         "                     , 'ShowOnlySuptApproveColumns_Tech', 'ShowOnlyMgrApproveColumns_Tech', 'ShowOnlyGenMgrApproveColumns_Tech', 'ShowOnlySenMgrApproveColumns_Tech', 'ShowOnlyDirApproveColumns_Tech' " +
                         "                     , 'ShowOnlySuptApproveColumns_Crew', 'ShowOnlyMgrApproveColumns_Crew', 'ShowOnlyGenMgrApproveColumns_Crew', 'ShowOnlySenMgrApproveColumns_Crew', 'ShowOnlyDirApproveColumns_Crew', 'IsAllowedUserToDoBlobManualSync', 'IsToExcludeFromShowUserActionColumnList', " +
                         " 'WindowPeriod_OStdngNonCritMaintItems','WindowPeriod_OStdngCritMaintItems', 'windowPeriod_OStdngNonCritEqpMaintItems','WindowPeriod_OStdngCritEqpMaintItems','LaidupVessels') " + Environment.NewLine +
                         "  order by SettingName";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string settingname = dr["SettingName"].ToString().Trim().ToUpper();
                        string settingvalue = dr["SettingValue"].ToString().Trim();
                        switch (settingname)
                        {
                            case "CURENVIRONMENT": curEnvironment = settingvalue; break;
                            case "ISTOENABLEDOCMGMT": isToEnableDocMgmt = (settingvalue.ToUpper() == "YES"); break;
                            case "USERALLOWEDTOSEETESTUSERS": isUserAllowedToSeeTestUsers = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWTOMANAGEHQUSERS": allowTochangeUserInfo = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWEDTODOVSLMGMNT": allowToManageUserVsls = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWTOMANAGESETUP": allowTochangeLubOPaintSetup = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSTOHIDEINVSLFILTER": usersToHideShowinVslFilterList = settingvalue; break;
                            case "ALLOWEDUSERTOACCESS_FLEETEQPMTMANAGER": allowedUserToAccess_FleetEqpmtManager = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWTOADDEDITDELETEDELIVLOCATION": allowToAddEditDeleteDelivLocation = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWTOADDEDITDELETECURRENCY": allowToAddEditDeleteCurrency = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWTOADDEDITDELETESETTINGS": allowToAddEditDeleteSettings = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "USERSALLOWTOADDEDITDELETELEGALENTITY": allowToAddEditDeleteLegalEntity = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "PMS_ALLOWEDROLESTOSUPTREVIEW": pmsAllowedRolesToSuptReview = settingvalue; break;
                            case "DELIVLOCATION_MAXIMUMATTACHMENTSIZEINKB": delivLocation_MaximumAttachmentSizeInKb = Convert.ToInt32(settingvalue); break;
                            case "USERALLOWEDTOSEETRAINVSL": userAllowedToSeeTrainVsl = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "ALLOWEDUSERROLETOREFRESHHQDASHBOARD": isAllowedUserRoleToRefreshHQDashboard = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurrentUserRole); break;
                            case "ALLOWEDUSERTOVIEWDTFREPORT": isToEnableDTFReports = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "ALLOWEDUSERTODODTF": isAllowedUserToDoDTF = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "DEFAULT_PROCAPPTOCALL": default_ProcAppToCall = settingvalue; break;
                            case "VESSELSALLOWEDFORHQPMS": allowedVsl_HQPMS = settingvalue; break;
                            case "ALLOWEDUSERTOSETUPVSLUSERMGMT": isAllowedUserToSetupVslUserMgmt = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;

                            case "ISTOSHOWKPITRENDING_NONCRITICALMAINT_FLEET": isToShowKPITrending_NonCriticalMaint_Fleet = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_CRITICALMAINT_FLEET": isToShowKPITrending_CriticalMaint_Fleet = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_NONCRITICALEQPMAINT_FLEET": isToShowKPITrending_NonCriticalEqp_Fleet = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_CRITICALEQPMAINT_FLEET": isToShowKPITrending_CriticalEqp_Fleet = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_ALLMAINT_FLEET": isToShowKPITrending_All_Fleet = (settingvalue.ToUpper() == "YES"); break;

                            case "ISTOSHOWKPITRENDING_NONCRITICALMAINT_VSL": isToShowKPITrending_NonCriticalMaint_Vsl = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_CRITICALMAINT_VSL": isToShowKPITrending_CriticalMaint_Vsl = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_NONCRITICALEQPMAINT_VSL": isToShowKPITrending_NonCriticalEqp_Vsl = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_CRITICALEQPMAINT_VSL": isToShowKPITrending_CriticalEqp_Vsl = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_ALLMAINT_VSL": isToShowKPITrending_All_VSL = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_PROCKPIDATA": isToShowKPITrending_ProcurementKPIData = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWKPITRENDING_DEFECTSVESSELAVAILABILITY": isToShowKPITrending_DefectsVesselAvailability = (settingvalue.ToUpper() == "YES"); break;

                            case "USERSALLOWEDTOADDEDITDELETEHOLIDAYS": isUsersAllowedToAddEditDeleteHolidays = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;

                            case "ISTOENABLEEXPORTEQUIPMENTPARTICULARS": isToEnableExportEquipmentParticulars = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOENABLEEXPORTEQUIPMENTUNITPARTICULARS": isToEnableExportEquipmentUnitParticulars = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOENABLEEXPORTPMSREPORT": isToEnableExportPMSReport = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOENABLEEXPORTCRITICALSPARESLIST": isToEnableExportCriticalSparesList = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWNCRTRENDING": isToShowNCRTrending = (settingvalue.ToUpper() == "YES"); break;
                            case "ISTOSHOWAWRTRENDING": isToShowAWRTrending = (settingvalue.ToUpper() == "YES"); break;

                            case "ALLOWEDUSERSETUPFORMS4VSLS": isAllowedUserSetupForms4Vsls = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;

                            case "DMWEBSVCURL": dmWebSvcURL = settingvalue; break;
                            case "DMCEF32BITAPPNAME": dmCef32bitAppName = settingvalue; break;
                            case "DMCEF64BITAPPNAME": dmCef64bitAppName = settingvalue; break;

                            case "USERALLOWEDTOCLEARCEFCACHE": isAllowedUserToClearCefCache = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;

                            case "WINDOWPERIOD_OSTDNGEQPMAINTITEMSCRITICAL": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngEqpMaintItemsCritical = Convert.ToInt32(settingvalue); break; }
                            case "WINDOWPERIOD_OSTDNGMAINTITEMS": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngMaintItems = Convert.ToInt32(settingvalue); break; }
                            case "WINDOWPERIOD_OSTDNGSVYITEMS": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngSvyItems = Convert.ToInt32(settingvalue); break; }
                            case "PMS_INTERVALSTOEXCLUDEINDUE": { intervalsToExcludeInPMSDue = settingvalue; break; }
                            case "SHOWONLYSUPTAPPROVECOLUMNS_MARINE": { showOnlySuptApproveColumns_Marine = settingvalue; break; }
                            case "SHOWONLYMGRAPPROVECOLUMNS_MARINE": { showOnlyMgrApproveColumns_Marine = settingvalue; break; }
                            case "SHOWONLYGENMGRAPPROVECOLUMNS_MARINE": { showOnlyGenMgrApproveColumns_Marine = settingvalue; break; }
                            case "SHOWONLYSENMGRAPPROVECOLUMNS_MARINE": { showOnlySenMgrApproveColumns_Marine = settingvalue; break; }
                            case "SHOWONLYDIRAPPROVECOLUMNS_MARINE": { showOnlyDirApproveColumns_Marine = settingvalue; break; }

                            case "SHOWONLYSUPTAPPROVECOLUMNS_TECH": { showOnlySuptApproveColumns_Tech = settingvalue; break; }
                            case "SHOWONLYMGRAPPROVECOLUMNS_TECH": { showOnlyMgrApproveColumns_Tech = settingvalue; break; }
                            case "SHOWONLYGENMGRAPPROVECOLUMNS_TECH": { showOnlyGenMgrApproveColumns_Tech = settingvalue; break; }
                            case "SHOWONLYSENMGRAPPROVECOLUMNS_TECH": { showOnlySenMgrApproveColumns_Tech = settingvalue; break; }
                            case "SHOWONLYDIRAPPROVECOLUMNS_TECH": { showOnlyDirApproveColumns_Tech = settingvalue; break; }

                            case "SHOWONLYSUPTAPPROVECOLUMNS_CREW": { showOnlySuptApproveColumns_Crew = settingvalue; break; }
                            case "SHOWONLYMGRAPPROVECOLUMNS_CREW": { showOnlyMgrApproveColumns_Crew = settingvalue; break; }
                            case "SHOWONLYGENMGRAPPROVECOLUMNS_CREW": { showOnlyGenMgrApproveColumns_Crew = settingvalue; break; }
                            case "SHOWONLYSENMGRAPPROVECOLUMNS_CREW": { showOnlySenMgrApproveColumns_Crew = settingvalue; break; }
                            case "SHOWONLYDIRAPPROVECOLUMNS_CREW": { showOnlyDirApproveColumns_Crew = settingvalue; break; }
                            case "ISTOEXCLUDEFROMSHOWUSERACTIONCOLUMNLIST": isToExcludeFromShowUserActionColumnList = (settingvalue); break;
                            case "WINDOWPERIOD_OSTDNGNONCRITMAINTITEMS": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngNonCritMaintItems = Convert.ToInt32(settingvalue); break; }
                            case "WINDOWPERIOD_OSTDNGCRITMAINTITEMS": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngCritMaintItems = Convert.ToInt32(settingvalue); break; }
                            case "WINDOWPERIOD_OSTDNGNONCRITEQPMAINTITEMS": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngNonCritEqpMaintItems = Convert.ToInt32(settingvalue); break; }
                            case "WINDOWPERIOD_OSTDNGCRITEQPMAINTITEMS": { if (settingvalue.Trim().Length > 0) windowPeriod_OStdngCritEqpMaintItems = Convert.ToInt32(settingvalue); break; }
                            case "LAIDUPVESSELS": { laidupVessels = settingvalue; break; }
                        }
                    }
                }

                if (dmWebSvcURL.Trim().Length > 0) PG.Decrypt(ref dmWebSvcURL, PG.checkValue);

                #endregion

                #region Proc Settings
                script = " select * from Proc_Settings " + Environment.NewLine +
                         " where SettingName in ('CompanyName','DEFAULTTIMETOADD','IsToHideEquipmentAssembly', 'AllowedUserToRe_interfacePO2Agresso', 'AllowedRoleToGetRFQLink', 'IsToEnableThirdPartyVesselsFeature' " +
                         " , 'CategoriesFeedBackFormRequired') " + Environment.NewLine +
                         "    and C_CompanyID = " + companyID +
                         " order by SettingName";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string settingname = dr["SettingName"].ToString().Trim().ToUpper();
                        string settingvalue = dr["SettingValue"].ToString().Trim();
                        switch (settingname.ToUpper())
                        {
                            case "COMPANYNAME": companyName = settingvalue; break;
                            case "DEFAULTTIMETOADD": timeToAdd = Convert.ToInt32(settingvalue); break;
                            case "ISTOHIDEEQUIPMENTASSEMBLY": isToHideEquipmentAssembly = (settingvalue.ToUpper() == "YES"); break;
                            case "ALLOWEDUSERTORE_INTERFACEPO2AGRESSO": isAllowedUserToRe_interfacePO2Agresso = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurUserID); break;
                            case "ALLOWEDROLETOGETRFQLINK": isAllowedUserRoleToGetVendorLink = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.User.CurrentUserRole); break;
                            case "ISTOENABLETHIRDPARTYVESSELSFEATURE": isToEnableThirdPartyVesselsFeature = (settingvalue.ToUpper() == "YES"); break;
                            case "CATEGORIESFEEDBACKFORMREQUIRED": categoriesFeedBackFormRequired = settingvalue; break;                          
                        }
                    }
                }
                #endregion


                script = " select SettingValue from AI_Settings where C_CompanyID = " + companyID + "  and SettingName = 'AllowedUserIDToSetupAI'";
                isAllowedUserIDToSetupAI = Gfn.IsStringExistsCommaSeparatedString(Gb.DBFn.Aqr(script).ToString(), PG.Gb.User.CurUserID);

                script = " select SettingValue from MSCAT_Settings where SettingName = 'AllowedUserIDToSetupMSCAT'";
                isAllowedUserIDToSetupMSCAT = Gfn.IsStringExistsCommaSeparatedString(Gb.DBFn.Aqr(script).ToString(), PG.Gb.User.CurUserID);

                script = " Select HQDept from HQ_Users_V where C_CompanyID = " + companyID + " and UserID =" + Gfn.Qss(Gb.User.CurUserID);
                currentUserDept = Gb.DBFn.Aqr(script).ToString();

                script = " Select COUNT(*) from HQ_UserDepts where DeptCode='HSQE' ";
                if (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0) HSQE_DeptName = "HSQE";

                script = " Select HQAppFolder from C_Company ";
                if (companyID.Trim() != "-99") script = script + " where C_CompanyID = " + companyID;
                hqAppFolder = Gb.DBFn.Aqr(script).ToString();

                script = " select SettingValue from Cert_Settings where C_CompanyID = " + companyID + "  and SettingName = 'FilterOdueDeptwise'";
                isCert_FilterOdueDeptwise = (Gb.DBFn.Aqr(script).ToString().ToUpper() == "YES");

                dt = null;

                PG.InitialiseHQAppDirectories();

                attachment = new Attachments("", xlsOutputFolderPath, timeToAdd, Gb);

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "InitialiseCommonSettings", err.Message);
                Mb("Failed to initialise Application Settings");
            }
            finally
            {
                dt = null;
            }
            return (result);
        }

        public static bool InitialiseHQAppDirectories()
        {
            bool result = false;
            winSdsRootDir = "C:\\WinSds\\" + hqAppFolder + Gfn.sdsLibVersion;
            winSdsBaseDir = winSdsRootDir + "\\HQ";
            sdsTempDir = winSdsBaseDir + "\\Temp";
            try
            {
                DirectoryInfo di;
                di = new DirectoryInfo(winSdsRootDir);
                if (!di.Exists)
                {
                    Directory.CreateDirectory(winSdsRootDir);
                }
                di = new DirectoryInfo(winSdsBaseDir);
                if (!di.Exists)
                {
                    Directory.CreateDirectory(winSdsBaseDir);
                }
                di = new DirectoryInfo(sdsTempDir);
                if (!di.Exists)
                {
                    Directory.CreateDirectory(sdsTempDir);
                }

                xlsOutputFolderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                xlsOutputFolderPath = xlsOutputFolderPath + "\\WinSDS";
                if (!Directory.Exists(xlsOutputFolderPath))
                {
                    Directory.CreateDirectory(xlsOutputFolderPath);
                }
                result = true;
            }
            catch (Exception err)
            {
                result = false;
                PG.AddToGenErrorLog("PG.CS", "InitialiseHQAppDirectories", err.Message);
                Mb("Failed to Initialise HQApp Directories");
            }
            return (result);
        }

        public static void BindCompany_FilterDropDown(ref ComboBox drpCompany_Filter, bool isToAddAllCompany)
        {
            ArrayList objArrLst = new ArrayList();
            try
            {
                drpCompany_Filter.Items.Clear();

                string script = " Select distinct CompanyCode, C_CompanyID from C_Company " +
                                " order by 1";
                DataTable dt = PG.Gb.DBFn.DbRecords(script);

                if (dt != null && dt.Rows.Count > 0)
                {
                    if (isToAddAllCompany && dt.Rows.Count > 1) objArrLst.Add(new DictionaryEntry("ALL", "-99"));

                    foreach (DataRow dr in dt.Rows)
                    {
                        objArrLst.Add(new DictionaryEntry(dr["CompanyCode"].ToString(), dr["C_CompanyID"].ToString()));
                    }
                }

                drpCompany_Filter.DisplayMember = "Key";
                drpCompany_Filter.ValueMember = "Value";
                drpCompany_Filter.DataSource = objArrLst;

                if (drpCompany_Filter.Items.Count > 0)
                {
                    script = " Select C_CompanyID from HQ_Users " +
                             " where HQ_UsersID='" + PG.Gb.User.CurHQ_UsersID + "' ";
                    string defaultCompany = PG.Gb.DBFn.Aqr(script).ToString();
                    if (defaultCompany == "-1") defaultCompany = "-99";

                    drpCompany_Filter.SelectedValue = defaultCompany;

                    if (drpCompany_Filter.SelectedValue == null) drpCompany_Filter.SelectedValue = PG.Gb.CompanyId;
                    if (drpCompany_Filter.SelectedIndex <= 0) drpCompany_Filter.SelectedIndex = 0;
                }

                script = " Select count(*) from HQ_Users_Company_I " +
                         " where C_CompanyID='" + PG.Gb.CompanyId + "' and HQ_UsersID='" + PG.Gb.User.CurHQ_UsersID + "' and IsToLockCompanyDropdown=1 ";
                int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

                if (cnt > 0)
                {
                    drpCompany_Filter.Enabled = false;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "BindCompany_FilterDropDown", err.Message);
            }
        }


        public static void DownloadStarter()
        {
            string starterExeName = PG.hqAppFolder + "_HqSDS";
            if (PG.curEnvironment.ToUpper() != "LIVE") starterExeName = starterExeName + "_" + PG.curEnvironment.Trim();

            PG.DownloadThisProg(starterExeName);
        }


        public static long GetNextTableId_HQ(string tableName)
        {
            return (GetNextTableId_HQ(tableName, 1));
        }

        public static long GetNextTableId_HQ(string tableName, int incrementor)
        {
            long result = -1;
            try
            {
                string spName = "Proc_NextID_" + tableName;
                string[] paramField = { "@Origin", "@VesselID", "@Incrementor" };
                object[] paramValue = { "HQ", -1, 1 };
                result = Convert.ToInt64(PG.Gb.DBFn.SpAqr(spName, paramField, paramValue, "@NewTableID"));
            }
            catch (Exception err)
            {
                Mb("Please take screenshot and send it to Admin. " + Environment.NewLine + err.Message);
                AddToGenErrorLog("Genfuncs.cs", "GetNextTableId", err.Message);

            }
            return (result);
        }

        public static void AddToGenErrorLog(string pageName, string functionName, string errMsg)
        {
            try
            {
                //applicationName
                string applicationName = PG.hqAppFolder.ToUpper() + "_HqSDS_Main";

                //pageName
                if (pageName.Length > 150) pageName = pageName.Substring(0, 150);

                //functionName
                if (functionName.Length > 150) functionName = functionName.Substring(0, 150);

                //errMsg
                errMsg = errMsg.Replace("'", "''"); //Environment.MachineName + " - " +
                if (errMsg.Length > 7000) errMsg = errMsg.Substring(0, 7000);

                // userID
                string userID = "";
                if (userID != null) userID = PG.Gb.User.CurUserID.Replace("'", "''");
                if (userID.Length > 50) userID = userID.Substring(0, 50);

                // Machine_WinLogin_Name
                string winLoginUserID = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                int posn = winLoginUserID.IndexOf("\\");
                if (posn > 0) winLoginUserID = winLoginUserID.Substring(posn + 1);
                if (winLoginUserID.Length > 29) winLoginUserID = winLoginUserID.Substring(0, 29);

                string machineName = Environment.MachineName.ToString();
                if (machineName.Length > 50) machineName = machineName.Substring(0, 50);

                machineName = machineName + "-" + winLoginUserID;

                long genErrorLogID = GetNextTableId_HQ("Gen_Error_HQ_Log");
                string sql = " insert into GEN_Error_HQ_Log (GEN_Error_HQ_LogID, VesselID, ApplicationName, PageName, FunctionName, TextContents, LoggedInUserID, AddedOn, Machine_WinLogin_Name, zChkNo, ToTrf)" +
                             " select " + genErrorLogID + " as GEN_Error_HQ_LogID ,-1, '" + applicationName + "' " +
                             "   , '" + pageName + "', '" + functionName + "', '" + errMsg + "', '" + userID + "', DATEADD(hh , " + PG.timeToAdd + " ,getdate()), '" + machineName + "', 0, 0";
                PG.Gb.DBFn.Xqry(sql);
            }
            catch
            {

            }
        }

        public static void AddToGeneralLog(string pageName, string functionName, string remarks)
        {
            try
            {
                //applicationName
                string applicationName = PG.hqAppFolder.ToUpper() + "_HqSDS_Main";

                //pageName
                if (pageName.Length > 150) pageName = pageName.Substring(0, 150);

                //functionName
                if (functionName.Length > 150) functionName = functionName.Substring(0, 150);

                //errMsg
                remarks = remarks.Replace("'", "''");
                if (remarks.Length > 7000) remarks = remarks.Substring(0, 7000);

                // userID
                string userID = "";
                if (userID != null) userID = PG.Gb.User.CurUserID.Replace("'", "''");
                if (userID.Length > 50) userID = userID.Substring(0, 50);

                string ComputerName = Environment.MachineName;
                if (ComputerName.Length > 80) ComputerName = ComputerName.Substring(0, 80);

                // Machine_WinLogin_Name
                string winLoginUserID = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                int posn = winLoginUserID.IndexOf("\\");
                if (posn > 0) winLoginUserID = winLoginUserID.Substring(posn + 1);
                if (winLoginUserID.Length > 29) winLoginUserID = winLoginUserID.Substring(0, 29);

                string machineName = Environment.MachineName.ToString();
                if (machineName.Length > 50) machineName = machineName.Substring(0, 50);

                machineName = machineName + "-" + winLoginUserID;

                long genLogID = GetNextTableId_HQ("Gen_Log");
                string sql = " insert into Gen_Log (Gen_LogID,Origin,ApplicationName, PageName, FunctionName, Remarks, LoggedInUserID, ComputerName, VesselID, AddedOn, Machine_WinLogin_Name, zChkNo, ToTrf)" +
                             " select " + genLogID + " as Gen_LogID, 'HQ' as Origin, '" + applicationName + "' " +
                             "   , '" + pageName + "' , '" + functionName + "','" + remarks + "','" + userID + "', '" + ComputerName + "', -1,  DATEADD(hh , " + PG.timeToAdd + " ,getdate()) , '" + machineName + "', 0, 0";
                PG.Gb.DBFn.Xqry(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddToGeneralLog", err.Message);
            }
        }

        public static bool Decrypt(ref string encFileStr, string key)
        {
            bool result = true;
            try
            {
                byte[] cipherBytes = Convert.FromBase64String(encFileStr);
                // Can add Password for file decryption
                PasswordDeriveBytes pdb = new PasswordDeriveBytes(key + "0x49", new byte[] {0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65,
                                                                        0x64, 0x76, 0x65, 0x64, 0x65, 0x76});
                MemoryStream ms = new MemoryStream();
                Rijndael alg = Rijndael.Create();
                alg.Key = pdb.GetBytes(32);
                alg.IV = pdb.GetBytes(16);
                CryptoStream cs = new CryptoStream(ms, alg.CreateDecryptor(), CryptoStreamMode.Write);
                cs.Write(cipherBytes, 0, cipherBytes.Length);
                cs.Close();
                byte[] decryptedData = ms.ToArray();
                encFileStr = System.Text.Encoding.Unicode.GetString(decryptedData);
            }
            catch
            {
                encFileStr = "";
                result = false;
            }
            return result;
        }

        public static bool Encrypt(ref string realFileStr, string key)
        {
            bool result = true;
            try
            {
                byte[] realFileStrBytes = System.Text.Encoding.Unicode.GetBytes(realFileStr);
                PasswordDeriveBytes pdb = new PasswordDeriveBytes(key + "0x49", new byte[] {0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d,
                                                                  0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76});
                MemoryStream ms = new MemoryStream();
                Rijndael alg = Rijndael.Create();
                alg.Key = pdb.GetBytes(32);
                alg.IV = pdb.GetBytes(16);
                CryptoStream cs = new CryptoStream(ms, alg.CreateEncryptor(), CryptoStreamMode.Write);
                cs.Write(realFileStrBytes, 0, realFileStrBytes.Length);
                cs.Close();
                byte[] encryptedData = ms.ToArray();
                realFileStr = Convert.ToBase64String(encryptedData);
            }
            catch
            {
                realFileStr = "";
                result = false;
            }
            return result;
        }

        public static void Mb(string stdMsg)
        {
            MessageBox.Show(stdMsg, "Information", MessageBoxButtons.OK, 0);
        }

        public static void SetFormWidthAndHeight(Form frm, int leftPos, int topPos, int frmHgt, int frmWidth)
        {
            //Left
            if (leftPos > 0) frm.Left = leftPos;
            else frm.Left = 0;

            //Top
            if (topPos > 0) frm.Top = topPos;
            else frm.Top = 0;

            //Height
            if (frmHgt > 0) frm.Height = frmHgt;
            else frm.Height = Screen.PrimaryScreen.WorkingArea.Height - 80;

            if (frm.Height + topPos > Screen.PrimaryScreen.WorkingArea.Height)
            {
                int hgt = (frm.Height + topPos) - Screen.PrimaryScreen.WorkingArea.Height;
                frm.Height = frm.Height - hgt;
            }

            //Width
            if (frmWidth > 0) frm.Width = frmWidth;
            else frm.Width = 800;

            if (frm.Width > Screen.PrimaryScreen.Bounds.Width)
            {
                frm.Width = Screen.PrimaryScreen.Bounds.Width - 10;
            }
        }

        public static bool ExecuteApp(string exename, string param)
        {
            bool result = false;
            string filename = "";
            try
            {
                filename = winSdsRootDir + "\\" + exename + ".exe";
                if (!File.Exists(filename))
                {
                    MessageBox.Show(exename + Environment.NewLine + " Called Module not found in " + winSdsRootDir);
                    return (result);
                }

                // Run the App with cmd line parameters if any
                if (param.Length > 0)
                {
                    ProcessStartInfo startInfo = new ProcessStartInfo();
                    startInfo.FileName = filename;
                    startInfo.Arguments = param.Trim();
                    Process.Start(startInfo);
                    startInfo = null;
                }
                else
                    Process.Start(filename);

                result = true;
            }
            catch (Exception er)
            {
                AddToGenErrorLog("PG.CS", "ExecuteApp", er.Message);
            }
            return (result);
        }


        public static void AddToHQUserLog(string activity, string remarks, string origin)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                string userName = PG.Gb.User.CurUserName;
                if (userName.Length > 30) { userName = userName.Substring(0, 30); }
                string userID = PG.Gb.User.CurUserID;
                if (userID.Length > 15) { userID = userID.Substring(0, 15); }

                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();

                script = "Select isnull(Max(LogRefNo),0)+1 from HQ_UserLog";
                int logRefNo = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());

                long HQ_UserLogID = PG.GetNextTableId_HQ("HQ_UserLog");
                script = " Insert into HQ_UserLog (HQ_UserLogID, LogRefNo, LogDate, UserID, UserName, Activity, Remarks, Origin, Machine_WinLogin_Name, ToTrf) " +
                         " SELECT " + HQ_UserLogID + ", " + logRefNo + ", DATEADD (hh , " + PG.timeToAdd + " ,getdate()) " +
                         "    ," + Gfn.Qss(userID) + ", " + Gfn.Qss(userName) + "," + Gfn.Qss(activity) + "," + Gfn.Qss(remarks) + "," + Gfn.Qss(origin) + ", " + Gfn.Qss(machine_WinLogin_Name) + ", 1";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddToHQUserLog", err.Message);
            }
        }

        public static void AddTo_Clients_LegalEntity_Log(string category, string activity, string remarks, string origin, long primeKeyID)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                //__________________________________________________________________________
                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();
                //__________________________________________________________________________

                long Proc_Clients_LegalEntityLogID = PG.GetNextTableId_HQ("Proc_Clients_LegalEntityLog");
                script = " Insert into Proc_Clients_LegalEntityLog (Proc_Clients_LegalEntityLogID,Origin,VesselID,LogDate,UserID,UserName,Category " +
                         " ,Activity,Remarks,PrimeKeyID,Machine_WinLogin_Name,zChkNo,ToTrf) " +
                         " SELECT " + Proc_Clients_LegalEntityLogID + " , " + Gfn.Qss(origin) + " , -1 , DATEADD(hh , " + PG.timeToAdd + " ,getdate()), " + Gfn.Qss(PG.Gb.User.CurUserID) + ", " + Gfn.Qss(PG.Gb.User.CurUserName) +
                         ", " + Gfn.Qss(category) + ", " + Gfn.Qss(activity) + ", " + Gfn.Qss(remarks) + ", " + primeKeyID +
                         ", " + Gfn.Qss(machine_WinLogin_Name) + ", 0 , 0";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddTo_Clients_LegalEntity_Log", err.Message);
            }
        }

        public static void AddTo_ContractVendors_Zones_Log(string category, string activity, string remarks, string origin, long primeKeyID)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                //__________________________________________________________________________
                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();
                //__________________________________________________________________________

                long proc_ContractVendors_ZonesLogID = PG.GetNextTableId_HQ("Proc_ContractVendors_ZonesLog");
                script = " Insert into Proc_ContractVendors_ZonesLog (Proc_ContractVendors_ZonesLogID,Origin,VesselID,LogDate,UserID " +
                         " ,UserName,Category,Activity,Remarks,PrimeKeyID,Machine_WinLogin_Name,zChkNo,ToTrf) " +
                         " SELECT " + proc_ContractVendors_ZonesLogID + " , " + Gfn.Qss(origin) + " , -1 , DATEADD(hh , " + PG.timeToAdd + " ,getdate()), " + Gfn.Qss(PG.Gb.User.CurUserID) + ", " + Gfn.Qss(PG.Gb.User.CurUserName) +
                         " , " + Gfn.Qss(category) + ", " + Gfn.Qss(activity) + ", " + Gfn.Qss(remarks) + ", " + primeKeyID +
                         " , " + Gfn.Qss(machine_WinLogin_Name) + ", 0 , 0";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddTo_ContractVendors_Zones_Log", err.Message);
            }
        }

        public static void AddTo_DelivLocations_Log(string activity, string remarks, string origin)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                script = "Select isnull(Max(LogRefNo),0)+1 from DelivLocationsLog";
                int logRefNo = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());

                //__________________________________________________________________________
                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();
                //__________________________________________________________________________
                long delivLocationsLogID = PG.GetNextTableId_HQ("DelivLocationsLog");
                script = " Insert into DelivLocationsLog (DelivLocationsLogID, Origin, VesselID, LogRefNo, LogDate, UserID, UserName, Activity, Remarks, Machine_WinLogin_Name, zChkNo, ToTrf) " +
                         " SELECT " + delivLocationsLogID + ", " + Gfn.Qss(origin) + " , -1 , " + logRefNo + ", DATEADD(hh , " + PG.timeToAdd + " ,getdate()), " + Gfn.Qss(PG.Gb.User.CurUserID) + ", " + Gfn.Qss(PG.Gb.User.CurUserName) + "," + Gfn.Qss(activity) + "," + Gfn.Qss(remarks) + "," + Gfn.Qss(machine_WinLogin_Name) + ", 0 , 0";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddTo_DelivLocations_Log", err.Message);
            }
        }

        public static void AddTo_Currency_Log(string activity, string remarks, string origin)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                script = "Select isnull(Max(LogRefNo),0)+1 from CurrencyLog";
                int logRefNo = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());

                //__________________________________________________________________________
                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();
                //__________________________________________________________________________

                long currencyLogID = PG.GetNextTableId_HQ("CurrencyLog");
                script = " Insert into CurrencyLog (CurrencyLogID, Origin, VesselID, LogRefNo, LogDate, UserID, UserName, Activity, Remarks, Machine_WinLogin_Name, zChkNo, ToTrf) " +
                         " SELECT " + currencyLogID + ", " + Gfn.Qss(origin) + " , -1 , " + logRefNo + ", DATEADD(hh , " + PG.timeToAdd + " ,getdate()) " +
                         "   , " + Gfn.Qss(PG.Gb.User.CurUserID) + ", " + Gfn.Qss(PG.Gb.User.CurUserName) + "," + Gfn.Qss(activity) + "," + Gfn.Qss(remarks) + "," + Gfn.Qss(machine_WinLogin_Name) + ", 0 , 0";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddTo_Currency_Log", err.Message);
            }
        }

        public static void AddTo_Holidays_Log(long holidaysID, string activity, string remarks, string origin)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                script = "Select isnull(Max(LogRefNo),0)+1 from HolidaysLog";
                int logRefNo = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());

                //__________________________________________________________________________
                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();
                //__________________________________________________________________________
                long holidaysLogID = GetNextTableId_HQ("HolidaysLog");
                script = " Insert into HolidaysLog (HolidaysLogID, Origin, VesselID, HolidaysID, LogRefNo, LogDate, UserID, UserName, Activity, Remarks, Machine_WinLogin_Name, zChkNo, ToTrf) " +
                         " SELECT " + holidaysLogID + ", " + Gfn.Qss(origin) + " , -1 ,  " + holidaysID + "," + logRefNo + ", DATEADD(hh , " + PG.timeToAdd + " ,getdate()) " +
                         "   , " + Gfn.Qss(PG.Gb.User.CurUserID) + ", " + Gfn.Qss(PG.Gb.User.CurUserName) + "," + Gfn.Qss(activity) + "," + Gfn.Qss(remarks) + "," + Gfn.Qss(machine_WinLogin_Name) + ", 0 , 0";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddTo_Holidays_Log", err.Message);
            }
        }

        public static void AddTo_ItemMaster_Log(string activity, string remarks, string origin, long eq_EquipmentID, long eq_ModelsID, long proc_ItemMasterID, int vesselID)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                //__________________________________________________________________________
                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();
                //__________________________________________________________________________

                long proc_ItemMaster_LogID = PG.GetNextTableId_HQ("Proc_ItemMaster_Log");
                script = " Insert into Proc_ItemMaster_Log (Proc_ItemMaster_LogID, Origin, VesselID, LogDate, UserID, UserName, Category, Activity, Remarks, Eq_EquipmentID, Eq_ModelsID, Proc_ItemMasterID, Role, Machine_WinLogin_Name, zChkNo, ToTrf) " +
                         " SELECT " + proc_ItemMaster_LogID + ", " + Gfn.Qss(origin) + " , " + vesselID + " , DATEADD(hh , " + PG.timeToAdd + " ,getdate()), " + Gfn.Qss(PG.Gb.User.CurUserID) + ", " + Gfn.Qss(PG.Gb.User.CurUserName) + "," + Gfn.Qss(ST_CATEGORY) + "," + Gfn.Qss(activity) + "," + Gfn.Qss(remarks) + "," + eq_EquipmentID + "," + eq_ModelsID + "," + proc_ItemMasterID + "," + Gfn.Qss(PG.Gb.User.CurrentUserRole) + "," + Gfn.Qss(machine_WinLogin_Name) + ", 0 , 0";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddTo_ItemMaster_Log", err.Message);
            }
        }

        public static void AddToFormsList_Vsl_I_Log(int vesselID, long formsListID, string activity, string remarks)
        {
            string script = "";
            try
            {
                if (remarks.Trim().Length > 500) remarks = remarks.Substring(0, 500);
                if (activity.Trim().Length > 50) activity = activity.Substring(0, 50);

                string userName = PG.Gb.User.CurUserName;
                if (userName.Length > 30) { userName = userName.Substring(0, 30); }
                string userID = PG.Gb.User.CurUserID;
                if (userID.Length > 15) { userID = userID.Substring(0, 15); }

                string machine_WinLogin_Name = GetMachineNameAndWinLoginName();

                long formsList_Vsl_I_LogID = PG.GetNextTableId_HQ("FormsList_Vsl_I_Log");
                script = " Insert into FormsList_Vsl_I_Log (FormsList_Vsl_I_LogID, Origin, VesselID, FormsListID, LogDate, UserID, UserName, Activity, Remarks, Machine_WinLogin_Name, zChkNo, ToTrf) " +
                         " SELECT " + formsList_Vsl_I_LogID + ", 'HQ', " + vesselID + ", " + formsListID + ", DATEADD (hh , " + PG.timeToAdd + " ,getdate()) " +
                         "    ," + Gfn.Qss(userID) + ", " + Gfn.Qss(userName) + "," + Gfn.Qss(activity) + "," + Gfn.Qss(remarks) + ", " + Gfn.Qss(machine_WinLogin_Name) + ", 0, 0 ";
                PG.Gb.DBFn.Xqry(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "AddToHQUserLog", err.Message);
            }
        }

        public static void ViewProc_TemplateFile(string templateName, string category, string folderName)
        {
            try
            {
                string strFileDir = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                strFileDir = strFileDir + "\\WinSDS\\" + folderName;
                if (!Directory.Exists(strFileDir)) Directory.CreateDirectory(strFileDir);

                string script = " Select Proc_TemplatesID " +
                                 " from Proc_Templates T  " +
                                 " where category =" + Gfn.Qss(category) + " and TemplateName=" + Gfn.Qss(templateName) +
                                 "       and IsForInternalUse = 0 and Version = (select max(version) from Proc_Templates where Category=T.Category and TemplateCode=T.TemplateCode ) " +
                                 " order by version desc";
                string sx = PG.Gb.DBFn.Aqr(script).ToString();
                long proc_TemplatesID = -1;
                if (sx.Trim().Length > 0) proc_TemplatesID = Convert.ToInt64(sx);

                PG.attachment.ViewFileFrom_DB_or_AzureStorage_or_LocalFolder("-1", "Proc_Templates", proc_TemplatesID.ToString(), true, false, strFileDir);
            }
            catch (Exception er)
            {
                AddToGenErrorLog("PG.CS", "Load_TemplateFile", er.Message);
            }
        }


        public static IFormatProvider culture = new System.Globalization.CultureInfo("en-US", true);
        public static string[] expectedFormats = {   // system current Default Format
                                                 CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern+" "+  CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern,
                                                 // System culture formats
                                                 "MM/dd/yyyy HH:mm:ss", "dd/MM/yy hh:mm:ss tt", "dd.M.yyyy 'г.' HH:mm:ss",
                                                 "dd/MM/yyyy HH:mm:ss", "yyyy/M/d tt hh:mm:ss", "d.M.yyyy H:mm:ss",
                                                 "dd-MM-yyyy HH:mm:ss","dd.MM.yyyy HH:mm:ss", "d/M/yyyy h:mm:ss tt",
                                                 "M/d/yyyy h:mm:ss tt", "yyyy. MM. dd. H:mm:ss", "d.M.yyyy HH:mm:ss",
                                                 "dd/MM/yyyy H.mm.ss", "yyyy/MM/dd H:mm:ss", "yyyy-MM-dd tt h:mm:ss",
                                                 "d-M-yyyy H:mm:ss", "yyyy-MM-dd HH:mm:ss", "d/M/yyyy H:mm:ss", "dd.MM.yyyy H:mm:ss",
                                                 "d. M. yyyy H:mm:ss", "yyyy-MM-dd h:mm:ss.tt", "dd/MM/yyyy h:mm:ss tt",
                                                 "dd/MM/yyyy H:mm:ss", "yyyy.MM.dd. H:mm:ss", "yyyy.MM.dd HH:mm:ss",
                                                 "M/d/yyyy hh:mm:ss tt", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd hh:mm:ss tt",
                                                 "dd-MM-yyyy HH.mm.ss", "dd.MM.yy H:mm:ss", "dd/MM yyyy HH:mm:ss",
                                                 "dd-MM-yy tt hh:mm:ss", "dd-MM-yy HH:mm:ss", "yy.MM.dd H:mm:ss",
                                                 "dd/MM/yy H:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yy HH:mm:ss",
                                                 "yyyy/M/d H:mm:ss", "dd-MM-yyyy H:mm:ss", "d/M/yyyy tt h:mm:ss",
                                                 "MM/dd/yyyy hh:mm:ss tt", "MM/dd/yyyy h:mm:ss tt",
                                              // Other cultures
                                                 "M/d/yyyy", "dd/MMM/yy hh:mm:ss tt" ,"dd/MMM/yy h:mm:ss tt", "dd-MMM-yyyy hh:mm:ss tt"
                                             };

        public static DateTime GetDbServerDate()
        {
            //return (PG.ToDate(PG.Gb.DBFn.Aqr("Select DATEADD(hh , " + PG.timeToAdd + " ,getdate())").ToString()));
            object dtStr = PG.Gb.DBFn.Aqr("Select DATEADD(hh , " + PG.timeToAdd + " ,getdate())").ToString();
            return Convert.ToDateTime(dtStr);
        }

        public static DateTime ToDate(object value)
        {
            DateTime result;
            try
            {
                result = DateTime.ParseExact(value.ToString(), expectedFormats, culture, DateTimeStyles.AllowWhiteSpaces);
            }
            catch
            {
                result = Convert.ToDateTime("1/1/0001 12:00:00 AM");
            }
            return (result);
        }

        public static bool DownloadThisProg(string prgname)
        {
            string progName, progNameWithPath, downloadPath, script;
            DateTime dbProgDate, existingAppProgdate;

            bool result = false;
            DataTable dtProgs = null;
            try
            {
                script = " select ProgName, ProgName+FileType as ProgNameWithExt, DownloadPath, Progdate, H_HQProgs_ExtID " +
                         " from H_HQProgs_Ext " +
                         " where ProgName='" + prgname + "'" +
                         " order by ProgName";
                dtProgs = PG.Gb.DBFn.DbRecords(script);

                if (dtProgs == null) return (result);

                DataRow dr = dtProgs.Rows[0];

                downloadPath = dr["downloadPath"].ToString();
                if (downloadPath.Trim().Length <= 0) downloadPath = PG.winSdsRootDir;

                progName = dr["ProgName"].ToString();
                progNameWithPath = downloadPath + "\\" + dr["ProgNameWithExt"].ToString();
                dbProgDate = Convert.ToDateTime(dr["Progdate"].ToString());

                if (File.Exists(progNameWithPath))
                {
                    existingAppProgdate = File.GetLastWriteTime(progNameWithPath); // Even if app running - can able to read Creation Date Time
                    if (existingAppProgdate < dbProgDate)
                    {
                        if (!DownLoadThisAppFile("H_HQProgs_Ext", dr["H_HQProgs_ExtID"].ToString(), progNameWithPath, dbProgDate, 10000)) return (result);
                    }
                }
                else
                {
                    if (!DownLoadThisAppFile("H_HQProgs_Ext", dr["H_HQProgs_ExtID"].ToString(), progNameWithPath, dbProgDate, 10000)) return (result);
                }

                result = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("PG.CS", "DownloadThisProg", PG.Gb.Companycode.ToUpper() + " HQ Main - " + er.Message);
            }
            finally
            {
                dtProgs = null;
            }
            return result;
        }

        public static bool DownLoadThisAppFile(string tableName, string tableKeyID, string progNameWithPath, DateTime progDate, int threadSleepTime)
        {
            bool result = false;
            try
            {
                if (threadSleepTime > 0) System.Threading.Thread.Sleep(threadSleepTime);

                string progName = Path.GetFileNameWithoutExtension(progNameWithPath);
                if (AppInstanceControler.CheckAppRunning(progName)) return (true);

                if (File.Exists(progNameWithPath)) File.Delete(progNameWithPath);

                string progFileName = PG.attachment.ViewFileFrom_DB_or_AzureStorage_or_LocalFolder("-1", tableName, tableKeyID, false, false, Path.GetDirectoryName(progNameWithPath));

                if (progFileName.Trim().Length > 0 && File.Exists(progFileName))
                {
                    File.SetLastWriteTime(progFileName, progDate);
                    PG.AddToGeneralLog("PG.CS", "DownLoadThisAppFile", PG.Gb.Companycode.ToUpper() + " HQ Main  <" + Environment.MachineName + "> - File : " + progFileName + " Downloaded successfully..");
                }
                else
                {
                    PG.AddToGeneralLog("PG.CS", "DownLoadThisProgs", PG.Gb.Companycode.ToUpper() + " HQ Main - FAILED to Load : <" + Environment.MachineName + "> - File : " + progFileName);
                }

                result = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("PG.CS", "DownLoadThisAppFile", PG.Gb.Companycode.ToUpper() + " HQ Main - " + er.Message);
            }
            return (result);
        }


        public static bool IsCategoryHaveItemGroup(long procTypesId)
        {
            bool result = false;

            DataTable dt = null;
            try
            {
                //string script = " Select Distinct G.GroupCode, Rtrim(LTrim(GroupName)) as GroupName , G.Proc_ItemGroupsId, G.SortCode " + Environment.NewLine +
                //                " from Proc_ItemMaster M, Proc_Types T, Proc_ItemMaster_Types_I I, Proc_ItemMaster_Groups_I GI, Proc_ItemGroups G  " + Environment.NewLine +
                //                " where M.Category='ST' and M.Proc_ItemMasterID=I.Proc_ItemMasterID " + Environment.NewLine +
                //                "   and I.Proc_TypesID ='" + procTypesId + "' " + Environment.NewLine +
                //                "   and I.Proc_TypesID=T.Proc_TypesID " + Environment.NewLine +
                //                "   and M.Proc_ItemMasterID=GI.Proc_ItemMasterID " +
                //                "   and GI.Proc_ItemGroupsId=G.Proc_ItemGroupsId " + Environment.NewLine +
                //                "   and G.GroupCode!='All'  " + Environment.NewLine;
                string script = " Select Distinct G.GroupCode, Rtrim(LTrim(GroupName)) as GroupName , G.Proc_ItemGroupsId, G.SortCode " + Environment.NewLine +
                                " from Proc_ItemMaster M, Proc_ItemMaster_Types_I I, Proc_ItemMaster_Groups_I GI, Proc_ItemGroups G  " + Environment.NewLine +
                                " where M.Category='ST' and M.Proc_ItemMasterID=I.Proc_ItemMasterID " + Environment.NewLine +
                                "   and I.Proc_TypesID ='" + procTypesId + "' " + Environment.NewLine +
                                "   and M.Proc_ItemMasterID=GI.Proc_ItemMasterID " +
                                "   and GI.Proc_ItemGroupsId=G.Proc_ItemGroupsId " + Environment.NewLine +
                                "   and G.GroupCode!='All'  " + Environment.NewLine;
                dt = PG.Gb.DBFn.DbRecords(script);
                result = (dt != null && dt.Rows.Count > 0);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "IsCategoryHaveItemGroup", err.Message);
                Gfn.Eb(err.Message);
            }
            finally
            {
                dt = null;
            }
            return (result);
        }


        public static void InitialiseVesselSettings(int vesselID)
        {
            DataTable dt;
            try
            {
                string script = " select SettingName, SettingValue from V_Settings " +
                                " where  VesselID=" + vesselID +
                                "   and SettingName in ('PMS_HidePMMDetails', 'PMS_HIDEPMSCODE','PMS_IsToEnableAlarmsAndRoutinesMaintType', 'DefaultEqpGroup', 'PMS_IsToShowSetLimits' " +
                                "       , 'PMS_IsToShowRangeValue', 'PMS_IsToShowSignalType', 'PMS_IsToShowCurrentValue', 'PMS_HideMaintResponsible', 'PMS_HideMaintIncharge' " +
                                "       , 'IsToShowSFICode', 'SP_EnableCriticalSparesFeature', 'SP_IsToShowCriticalSparesGroup', 'ExcludeVerificationItemsFromDueList', 'CriticalSpAlert_NoOfQtyToAddWithMinQty' " +
                                "       , 'SP_HideSparesMinQtyForOrigin','SP_HideSparesMaxQtyForOrigin','SP_HideSparesWkgQtyForOrigin')";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string settingname = dr["SettingName"].ToString().Trim();
                        string settingvalue = dr["SettingValue"].ToString().Trim();
                        switch (settingname.ToUpper())
                        {
                            case "PMS_HIDEPMMDETAILS": isPMS_HidePMMDetails = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_HIDEMAINTINCHARGE": isPMS_HideMaintIncharge = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_HIDEMAINTRESPONSIBLE": isPMS_HideMaintResponsible = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_HIDEPMSCODE": isPMS_HidePMSCode = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_ISTOENABLEALARMSANDROUTINESMAINTTYPE": isEnableAlarmsAndRoutinesMaintType = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "DEFAULTEQPGROUP": defaultEqpGroup = settingvalue; break;
                            case "PMS_ISTOSHOWSETLIMITS": isToShowSetLimits = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_ISTOSHOWRANGEVALUE": isToShowRangeValue = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_ISTOSHOWSIGNALTYPE": isToShowSignalType = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "PMS_ISTOSHOWCURRENTVALUE": isToShowCurrentValue = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "ISTOSHOWSFICODE": isToShowSFICode = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "SP_ENABLECRITICALSPARESFEATURE": enableCriticalSparesFeature = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "SP_ISTOSHOWCRITICALSPARESGROUP": isCriticalSparesGroups = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "EXCLUDEVERIFICATIONITEMSFROMDUELIST": isExcludeVerificationItemsFromDueList = (settingvalue.Trim().ToUpper() == "YES"); break;
                            case "CRITICALSPALERT_NOOFQTYTOADDWITHMINQTY": if (settingvalue.Trim().Length > 0) criticalSpAlert_NoOfQtyToAddWithMinQty = Convert.ToInt32(settingvalue); break;

                            case "SP_HIDESPARESMINQTYFORORIGIN": isToHideSparesMinQty = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.Origin); break;
                            case "SP_HIDESPARESMAXQTYFORORIGIN": isToHideSparesMaxQty = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.Origin); break;
                            case "SP_HIDESPARESWKGQTYFORORIGIN": isToHideSparesWkg_Qty = Gfn.IsStringExistsCommaSeparatedString(settingvalue, PG.Gb.Origin); break;
                        }
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "InitialiseVesselSettings", err.Message);
            }
        }

        public static string GetVslName(int vesselID)
        {
            string script = "select VslName from V_Vessels where vesselID=" + vesselID;
            string vslName = PG.Gb.DBFn.Aqr(script).ToString();
            return (vslName);
        }

        public static string GetDefaultGroupType(int vesselID)
        {
            string script = " Select SettingValue from V_Settings where VesselID = " + vesselID + " and SettingName ='DefaultEqpGroup'";
            string groupType = PG.Gb.DBFn.Aqr(script).ToString();
            if (groupType.Trim().Length <= 0) groupType = "SDS";
            return (groupType);
        }

        public static string GetHQAndVslMaintenanceInstructions(long pms_DocID, int vesselID, long eq_UnitsID)
        {
            string maintInstructions = "";
            try
            {
                string vslMaintInstructions = PG.GetMaintenanceInstructions(pms_DocID, vesselID, eq_UnitsID);

                if (vslMaintInstructions.Length > 0)
                {
                    maintInstructions = vslMaintInstructions + Environment.NewLine;
                }
            }
            catch (Exception er)
            {
                AddToGenErrorLog("PG.CS", "GetHQAndVslMaintenanceInstructions", er.Message);
            }
            return (maintInstructions);
        }

        public static string GetMaintenanceInstructions(long pms_DocID, int vesselID, long eq_UnitsID)
        {
            string maintInstructions = "";
            try
            {
                string sqlMaintInstruction = "select isnull(dbo.func_GetMaintInstruction(" + vesselID + ", " + eq_UnitsID + ", " + pms_DocID.ToString() + "), '')";
                maintInstructions = PG.Gb.DBFn.Aqr(sqlMaintInstruction).ToString();

            }
            catch (Exception er)
            {
                AddToGenErrorLog("PG.CS", "GetMaintenanceInstructions", er.Message);
            }
            return (maintInstructions);
        }

        public static bool CheckMaintProcedureOrManualRefExist(int vesselID, long pms_DocID, long eq_UnitsID)
        {
            string maintProcedure = PG.GetHQAndVslMaintenanceInstructions(pms_DocID, vesselID, eq_UnitsID);

            string script = " Select Count(*) from EQ_Maint_ManualReference " +
                            " where IsDisabled = 0 " + Environment.NewLine +
                            "    and VesselID=" + vesselID +
                            "    and PMS_DocID=" + pms_DocID;
            int manualRefCnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

            bool result = (maintProcedure.Length > 0 || manualRefCnt > 0);

            return (result);
        }

        public static DataTable GetManualReferenceList(int vesselID, long pms_DocID)
        {
            DataTable dt = null, dtMaintAttach = null;
            string script = " Select Row_Number() Over (Order by EQ_Maint_ManualReferenceID) as ManualNo " +
                            "    , ManualName + ' - ' + ManualDesc + char(13) + char(10) + Case When (PageNo>0) then 'Page No: ' + Cast(PageNo as varchar) else '' end as ManualDescription " +
                            "   , Case when (BlobSize>0) then Cast((BlobSize/1024) as varchar) + ' (KB)' else ' ' end as BlobSizeDisplay " +
                            "   , 1 IsManualRef " +
                            "   , M.VesselID,  * " +
                            " from EQ_Maint_ManualReference M " +
                            " where IsDisabled = 0 " + Environment.NewLine +
                            "    and VesselID=" + vesselID +
                            "    and PMS_DocID=" + pms_DocID;
            try
            {
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt == null) dt = PG.Gb.DBFn.GetEmptyDataStructure(script);

                script = " Select AttachRefNo as ManualNo, Description as ManualDescription " +
                         " , Case when (BlobSize>0) then Cast((BlobSize/1024) as varchar) + ' (KB)' else ' ' end as BlobSizeDisplay " +
                         " , 0 IsManualRef, A.VesselID,  *   " +
                         " from EQ_MaintAttachments A, EQ_MaintAttachments_VSL_I I " +
                         " where A.EQ_MaintAttachmentsID = I.EQ_MaintAttachmentsID " +
                         "    and I.VesselID =" + vesselID + " and PMS_DocID=" + pms_DocID + "  and IsDisabled =0 " + Environment.NewLine +
                         " order by  AttachRefNo ";

                dtMaintAttach = PG.Gb.DBFn.DbRecords(script);

                if (dtMaintAttach != null && dtMaintAttach.Rows.Count > 0)
                {
                    int manualNo = dt.Rows.Count;
                    for (int row = 0; row < dtMaintAttach.Rows.Count; row++)
                    {
                        manualNo = manualNo + 1;
                        string description = dtMaintAttach.Rows[row]["ManualDescription"].ToString();
                        string origin = dtMaintAttach.Rows[row]["Origin"].ToString();
                        string blobSizeDisplay = dtMaintAttach.Rows[row]["BlobSizeDisplay"].ToString();
                        long eq_MaintAttachmentsID = Convert.ToInt64(dtMaintAttach.Rows[row]["EQ_MaintAttachmentsID"].ToString());
                        int xvesselID = Convert.ToInt32(dtMaintAttach.Rows[row]["VesselID"].ToString());

                        DataRow dr = dt.NewRow();
                        dr["ManualNo"] = manualNo;
                        dr["ManualDescription"] = description;
                        dr["Origin"] = origin;
                        dr["BlobSizeDisplay"] = blobSizeDisplay;
                        dr["EQ_Maint_ManualReference_ExtID"] = eq_MaintAttachmentsID;
                        dr["VesselID"] = xvesselID;
                        dt.Rows.Add(dr);
                    }
                }
            }
            catch (Exception err)
            {
                AddToGenErrorLog("PG.cs", "GetManualReferenceList", err.Message);
                Gfn.Mb(err.Message);
            }
            return (dt);
        }


        public static void DisplayException(string methodName, string errMsg)
        {
            Gfn.Wb("Failed to " + methodName + Environment.NewLine +
                   //"Error - " + errMsg +
                   "Please contact Administrator");
        }

        public static string RemoveInvalidChar(string filename)
        {
            filename = filename.Replace(":", "");
            filename = filename.Replace("*", "");
            filename = filename.Replace("?", "");
            filename = filename.Replace("<", "");
            filename = filename.Replace(">", "");
            filename = filename.Replace("|", "");
            filename = filename.Replace("/", "");
            filename = filename.Replace("\\", "");
            filename = filename.Replace("\"", "");
            filename = filename.Replace("[", "");
            filename = filename.Replace("]", "");

            filename = filename.Replace("#", "");
            filename = filename.Replace("%", "");
            filename = filename.Replace("^", "");
            filename = filename.Replace("&", "");
            filename = filename.Replace("{", "");
            filename = filename.Replace("}", "");
            return filename;
        }

        public static bool IsFileExceedsLimit(string filename, int allowedAttachmentSize)
        {
            FileInfo fInfo = new FileInfo(filename);
            long currentFileSize = fInfo.Length;
            long allowedFileSize = (allowedAttachmentSize * 1024);
            double totalFileSize = Convert.ToDouble(currentFileSize / allowedFileSize);
            if (currentFileSize > allowedFileSize)
            {
                Gfn.Mb("This file size is: " + (currentFileSize / 1024) + " KB " + Environment.NewLine +
                       "Max. Allowed size is: " + allowedAttachmentSize + " KB " + Environment.NewLine + Environment.NewLine +
                       "This file cannot be attached here. ");//If it is " + Environment.NewLine + "urgent please send by email");
                return true;
            }
            return false;
        }

        public static string GetSearchCombination(string field, string searchKeywords)
        {
            string keyWords = "", result = " ";
            string[] searchList = searchKeywords.Split(' ');

            Permute(searchList, 0, searchList.Length, ref keyWords);

            if (keyWords.Length > 0) keyWords = keyWords.Substring(0, keyWords.Length - 1);

            string sx2 = "";
            string[] keyWordList = keyWords.Trim().Split('~');
            for (int i = 0; i < keyWordList.Length; i++)
            {
                if (keyWordList[i].Trim().Length > 0)
                {
                    sx2 = keyWordList[i] + "%";
                    sx2 = "%" + sx2;
                    result = result + "( " + field + " Like " + Gfn.Qss(sx2) + ")";
                    if (i != (keyWordList.Length - 1)) result = result + " OR ";
                }
            }
            return (result);
        }

        public static void Permute(string[] strings, int start, int finish, ref string keyWords)
        {
            for (int i = start; i < finish; ++i)
            {
                string temp = strings[start];
                strings[start] = strings[i];
                strings[i] = temp;

                Permute(strings, start + 1, finish, ref keyWords);
                if (start + 1 == finish)
                {
                    for (int i1 = 0; i1 < finish; ++i1)
                    {
                        if (i1 < strings.Length)
                            keyWords = keyWords + strings[i1];
                        if ((i1 + 1) != finish) keyWords = keyWords + "%";
                    }
                    keyWords = keyWords + "~";
                }
                temp = strings[start];
                strings[start] = strings[i];
                strings[i] = temp;
            }
        }

        public static bool IsToCheckFileAlreadyOpened(string fileName)
        {
            bool result = false;

            try
            {
                Gfn.GetBlobContent(fileName);
                result = true;
            }
            catch
            {
                result = false;
                Gfn.Wb("File already in use or in open ," + Environment.NewLine + " Please close the file and retry");
                return result;
            }
            return result;
        }


        public static bool CheckIsUserAccountExpired()
        {
            DataTable dt;
            try
            {
                string script = " select ExpiryDate " +
                                " from HQ_Users " +
                                " WHERE Role not in ('Vendor','VslTrainee')  " +
                                "    and UserId ='" + Gb.User.CurUserID + "'";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt != null)
                {
                    //Account Expired
                    string expiryDateStr = dt.Rows[0]["ExpiryDate"].ToString().Trim();
                    if (expiryDateStr.Trim().Length > 0)
                    {
                        DateTime expiryDate = Convert.ToDateTime(expiryDateStr);
                        DateTime todayDate = Convert.ToDateTime(PG.Gb.DBFn.Aqr("select DATEADD (hh , " + PG.timeToAdd + " ,getdate())"));
                        if (expiryDate.Date < todayDate.Date)
                        {
                            Gfn.Mb("Current Logged in User: \"" + PG.Gb.User.CurWinLoginUserID + "\"  " + Environment.NewLine +
                                   "Account Expired" + Environment.NewLine +
                                   "Cannot Continue. ");
                            return (false);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "CheckIsUserAccountExpired", err.Message);
            }
            finally
            {
                dt = null;
            }
            return (true);
        }

        public static void FileDelete(string fileName)
        {
            try
            {
                string strFilePath = PG.xlsOutputFolderPath;
                string Output_Filename = strFilePath + Path.GetFileName(fileName);

                FileInfo file = new FileInfo(Output_Filename);
                if (file.Exists)
                {
                    file.Delete();
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "FileDelete", err.Message);
            }
        }

        public static string GetMachineNameAndWinLoginName()
        {
            string machine_WinLogin_Name = "";
            string machineName = Environment.MachineName;
            if (machineName.Length > 50) machineName = machineName.Substring(0, 48);

            string winLoginName = Environment.UserName.ToString();
            if (winLoginName.Length > 29) winLoginName = winLoginName.Substring(0, 28);

            machine_WinLogin_Name = machineName + " - " + winLoginName;
            if (machine_WinLogin_Name.Length > 80) machine_WinLogin_Name = machine_WinLogin_Name.Substring(0, 80);

            return machine_WinLogin_Name;
        }


        public static int GetPmsHistAttachment(int vesselID, long pmsHistID)
        {
            string script = " select COUNT(*) from EQ_PmsHist_Attachments " +
                            " where VesselID= " + vesselID + " and EQ_PmsHistID=" + pmsHistID +
                            "    and IsDeleted=0 ";
            int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());
            return (cnt);
        }

        public static string DownloadApp_Template_HQTemplate(string appName, string rptName)
        {
            string templateFileName = "";

            string script = " Select App_Templates_HQID, DownloadPath " +
                              " from App_Templates_HQ " +
                              " where ApplicationName='" + appName + "' and TemplateName=" + Gfn.Qss(rptName) +
                              " Order by Version desc";
            DataTable dtTemplate = PG.Gb.DBFn.DbRecords(script);
            if (!(dtTemplate != null && dtTemplate.Rows.Count > 0)) return (templateFileName);

            string sx = dtTemplate.Rows[0]["App_Templates_HQID"].ToString();
            long app_Templates_HQID = -1;
            if (sx.Trim().Length > 0) app_Templates_HQID = Convert.ToInt64(sx);

            string downloadPath = dtTemplate.Rows[0]["DownloadPath"].ToString();
            if (!Directory.Exists(downloadPath)) { Directory.CreateDirectory(downloadPath); }

            templateFileName = PG.attachment.ViewFileFrom_DB_or_AzureStorage_or_LocalFolder("-1", "App_Templates_HQ", app_Templates_HQID.ToString(), false, true, downloadPath);

            return (templateFileName);
        }

        public static string DownloadApp_Template(string rptName, string companyID)
        {
            string templateFileName = "";

            string script = " Select App_TemplatesID, DownloadPath " +
                            " from App_Templates " +
                            " where ApplicationName='" + PG.CATEGORYCODE + "' and TemplateName=" + Gfn.Qss(rptName) +
                            "   and C_CompanyID = " + companyID +
                            " Order by Version desc";
            DataTable dtTemplate = PG.Gb.DBFn.DbRecords(script);
            if (!(dtTemplate != null && dtTemplate.Rows.Count > 0)) return (templateFileName);

            string sx = dtTemplate.Rows[0]["App_TemplatesID"].ToString();
            long app_TemplatesID = -1;
            if (sx.Trim().Length > 0) app_TemplatesID = Convert.ToInt64(sx);

            //string downloadPath = dtTemplate.Rows[0]["DownloadPath"].ToString();
            //if (!Directory.Exists(downloadPath)) { Directory.CreateDirectory(downloadPath); }

            string downloadPath = PG.Gb.WinSdsTempDir + "\\Templates\\";
            if (!Directory.Exists(downloadPath)) { Directory.CreateDirectory(downloadPath); }

            templateFileName = PG.attachment.ViewFileFrom_DB_or_AzureStorage_or_LocalFolder("-1", "App_Templates", app_TemplatesID.ToString(), false, true, downloadPath);

            return (templateFileName);
        }


        public static void Refresh_HQ_Dashboard_Tech(string calledMode, int vesselID)
        {
            try
            {
                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_AUDITINSPECTION || calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_NCR ||
                    calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_DEFECTS || calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_TASK || calledMode.Trim().Length <= 0)
                {
                    ChecksAndUpdate_AI_UnderActionStatus(vesselID, true);
                }

                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_INCIDENTREPORT || calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_NCR ||
                    calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_DEFECTS || calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_TASK || calledMode.Trim().Length <= 0)
                {
                    ChecksAndUpdate_Incident_UnderActionStatus(vesselID, true);
                }

                string spName = "";
                string[] paramField;
                object[] paramValue;

                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_SUPT_MNTQ || calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_SUPT_TOAPPROVEMNT)
                {
                    spName = "Refresh_HQ_Dashboard_Tech_PMS";
                    paramField = new string[] { "@VesselID", "@isToRefresh_SuptQ_ToApprvPostpnmtMaint" };
                    paramValue = new object[] { vesselID, 1 };
                    PG.RefreshHQDashboard_SP(spName, paramField, paramValue, vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_CRITICALSPARES)
                {
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_CriticalSpares", vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_DEFECTS)
                {
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Defects", vesselID);
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Defects", vesselID); 
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Defects", vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_SUPT_FORMS_APPR)
                {
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Forms", vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_AUDITINSPECTION)
                {
                    //Refresh_AuditInspection(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_INCIDENTREPORT)
                {
                    //Refresh_Incident(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_NCR)
                {
                    //Refresh_NCR(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_TASK)
                {
                    Refresh_TaskList(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_AWARENESS_REPORT)
                {
                    Refresh_Awareness_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_MASTERS_REVIEW)
                {
                    Refresh_Masters_Review_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_MINUTES_OF_SAFETY)
                {
                    Refresh_Minutes_of_Safety_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_CORRECTIVEMAINTENANCE)
                {
                    Refresh_CorrectiveMaintenance_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_RISKASSEMENTS)
                {
                    Refresh_RiskAssements(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_MONTHENDDOC)
                {
                    spName = "Refresh_HQ_Dashboard_Tech_MonthEndDoc";
                    PG.RefreshHQDashboard_SP(spName, vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_TECH_CERTIFICATE)
                {
                    spName = "Refresh_HQ_Dashboard_Tech_Certificate";
                    PG.RefreshHQDashboard_SP(spName, vesselID);
                }
                else
                {
                    paramField = new string[] { "@VesselID", "@isToRefresh_SuptQ_ToApprvPostpnmtMaint" };
                    paramValue = new object[] { vesselID, 1 };
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_PMS", paramField, paramValue, vesselID);

                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_CriticalSpares", vesselID);
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Defects", vesselID);
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Defects", vesselID);
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Defects", vesselID);

                    if (PG.isToEnableForms)
                    {
                        PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Forms", vesselID);
                    }

                    Refresh_Awareness_Report(vesselID);

                    Refresh_Masters_Review_Report(vesselID);

                    Refresh_Minutes_of_Safety_Report(vesselID);

                    Refresh_CorrectiveMaintenance_Report(vesselID);

                    Refresh_RiskAssements(vesselID);

                    Refresh_TaskList(vesselID);

                    RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_MonthEndDoc", vesselID);

                    RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Certificate", vesselID);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "Refresh_HQ_Dashboard", err.Message);
            }
        }

        public static void RefreshHQDashboard_SP(string spName, int vesselID)
        {
            string[] paramField = { "@VesselID" };
            object[] paramValue = { vesselID };

            RefreshHQDashboard_SP(spName, paramField, paramValue, vesselID);
        }

        public static void RefreshHQDashboard_SP(string spName, string[] paramField, object[] paramValue, int vesselID)
        {
            try
            {
                PG.Gb.DBFn.SpXqry(spName, paramField, paramValue);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "RefreshHQDashboard_SP - " + spName, err.Message);
            }
        }

        public static void Refresh_HQ_Dashboard_Marine(string calledMode, int vesselID)
        {
            try
            {
                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_AUDITINSPECTION || calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_NCR ||
                    calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_DEFECTS || calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_TASK || calledMode.Trim().Length <= 0)
                {
                    ChecksAndUpdate_AI_UnderActionStatus(vesselID, true);
                }

                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_INCIDENTREPORT || calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_NCR ||
                    calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_DEFECTS || calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_TASK || calledMode.Trim().Length <= 0)
                {
                    ChecksAndUpdate_Incident_UnderActionStatus(vesselID, true);
                }

                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_DOCMGMT)
                {
                    Refresh_DocMgmt(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_CERTIFICATE)
                {
                    Refresh_Marine_Certificates(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_FORMS)
                {
                    Refresh_Marine_Forms(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_AUDITINSPECTION)
                {
                    //Refresh_AuditInspection(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_INCIDENTREPORT)
                {
                    //Refresh_Incident(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_NCR)
                {
                    //Refresh_NCR(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_DEFECTS)
                {
                    RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Defects", vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_AWARENESS_REPORT)
                {
                    Refresh_Awareness_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_MASTERS_REVIEW)
                {
                    Refresh_Masters_Review_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_MINUTES_OF_SAFETY)
                {
                    Refresh_Minutes_of_Safety_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_TASK)
                {
                    Refresh_TaskList(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_RISKASSEMENTS)
                {
                    Refresh_RiskAssements(vesselID);
                }
                else
                {
                    // Refresh_AuditInspection_Report(vesselID);

                    Refresh_TaskList(vesselID);

                    Refresh_Marine_Forms(vesselID);

                    //Refresh_NCR(vesselID);

                    Refresh_Defects(vesselID);

                    Refresh_Awareness_Report(vesselID);

                    Refresh_Masters_Review_Report(vesselID);

                    Refresh_Minutes_of_Safety_Report(vesselID);

                    Refresh_RiskAssements(vesselID);

                    Refresh_Marine_Certificates(vesselID);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "Refresh_HQ_Dashboard", err.Message);
            }
        }

        public static void Refresh_HQ_Dashboard_Crew(string calledMode, int vesselID)
        {
            try
            {
                if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_CCMS_MODULE)
                {
                    //
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_CCMS_LEARNING)
                {
                    Refresh_CCMS_Learning(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_CREW_RESTHOURS)
                {
                    //
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_MARINE_CERTIFICATE)
                {
                    Refresh_Crew_Certificates(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_FORMS)
                {
                    Refresh_Crew_Forms(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_NCR)
                {
                    Refresh_NCR(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_DEFECT)
                {
                    PG.RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Defects", vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_INCIDENTREPORT)
                {
                    Refresh_Incident(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_TASK)
                {
                    Refresh_TaskList(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_MINUTES_OF_SAFETY)
                {
                    Refresh_Minutes_of_Safety_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_AWARENESS_REPORT)
                {
                    Refresh_Awareness_Report(vesselID);
                }
                else if (calledMode.ToUpper() == REFRESH_CALLEDMODE_CREW_MASTERS_REVIEW)
                {
                    Refresh_Masters_Review_Report(vesselID);
                }
                else
                {
                    Refresh_NCR(vesselID);

                    Refresh_Incident(vesselID);

                    Refresh_TaskList(vesselID);

                    Refresh_Minutes_of_Safety_Report(vesselID);

                    Refresh_Awareness_Report(vesselID);

                    Refresh_Masters_Review_Report(vesselID);

                    Refresh_CCMS_Learning(vesselID);

                    Refresh_Crew_Certificates(vesselID);

                    Refresh_Crew_Forms(vesselID);

                    Refresh_Defects(vesselID);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "Refresh_HQ_Dashboard", err.Message);
            }
        }

        private static void Refresh_DocMgmt(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_DocumentMgmt", vesselID);
        }

        private static void Refresh_Marine_Certificates(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Certificates", vesselID);
        }

        private static void Refresh_Crew_Certificates(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Certificates", vesselID);
        }

        private static void Refresh_Marine_Forms(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Forms", vesselID);
        }

        private static void Refresh_Crew_Forms(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Forms", vesselID);
        }

        private static void Refresh_AuditInspection(int vesselID)
        {
            string spName;
            string[] paramField; object[] paramValue;

            spName = "Refresh_HQ_Dashboard_Marine_AuditInspections";
            paramField = new string[] { "@vesselID", "@Origin" };
            paramValue = new object[] { vesselID, "HQ" };
            RefreshHQDashboard_SP(spName, paramField, paramValue, vesselID);

            spName = "Refresh_HQ_Dashboard_Tech_AuditInspections";
            paramField = new string[] { "@vesselID", "@Origin" };
            paramValue = new object[] { vesselID, "HQ" };
            RefreshHQDashboard_SP(spName, paramField, paramValue, vesselID);
        }

        private static void Refresh_NCR(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_NCR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_NCR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_NCR", vesselID);

            Refresh_Defects(vesselID);
            Refresh_TaskList(vesselID);
        }

        private static void Refresh_Defects(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Defects", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Defects", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Defects", vesselID);
        }

        private static void Refresh_TaskList(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_Tasks", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_Tasks", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_Tasks", vesselID);
        }

        private static void Refresh_Incident(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_IncidentReport", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_InvestigationReport", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_IncidentReport", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_InvestigationReport", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_IncidentReport", vesselID);
        }

        private static void Refresh_Minutes_of_Safety_Report(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_MSR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_MSR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_MSR", vesselID);
        }

        private static void Refresh_Awareness_Report(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_AWR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_AWR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_AWR", vesselID);
        }

        private static void Refresh_Masters_Review_Report(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_MRR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_MRR", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_MRR", vesselID);
        }

        private static void Refresh_RiskAssements(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Marine_RiskAssements", vesselID);
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_RiskAssements", vesselID);
        }

        private static void Refresh_CorrectiveMaintenance_Report(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Tech_CorrectiveMaintenance", vesselID);
        }

        private static void Refresh_CCMS_Learning(int vesselID)
        {
            RefreshHQDashboard_SP("Refresh_HQ_Dashboard_Crew_CCMSLearning", vesselID);
        }

        private static void ChecksAndUpdate_AI_UnderActionStatus(int vesselID, bool isToRefresh)
        {
            string spName;
            string[] paramField; object[] paramValue;

            NCR_CheckandUpdatUnderActionStatus.NCR_ChecksAndUpdate_UnderActionStatus(PG.Gb.Vsl.CurVesselID, PG.Gb.Origin, PG.timeToAdd, PG.Gb);

            spName = "AI_ChecksAndUpdate_AI_UnderActionStatus";
            paramField = new string[] { "@VesselID", "@Origin" };
            paramValue = new object[] { PG.Gb.Vsl.CurVesselID, PG.Gb.Origin };
            RefreshHQDashboard_SP(spName, paramField, paramValue, vesselID);

            if (isToRefresh)
            {
                Refresh_NCR(vesselID);
                Refresh_AuditInspection(vesselID);
            }
        }

        private static void ChecksAndUpdate_Incident_UnderActionStatus(int vesselID, bool isToRefresh)
        {
            string spName;
            string[] paramField; object[] paramValue;
            
            NCR_CheckandUpdatUnderActionStatus.NCR_ChecksAndUpdate_UnderActionStatus(PG.Gb.Vsl.CurVesselID, PG.Gb.Origin, PG.timeToAdd, PG.Gb);

            spName = "Incident_ChecksAndUpdate_UnderActionStatus";
            paramField = new string[] { "@VesselID", "@Origin" };
            paramValue = new object[] { PG.Gb.Vsl.CurVesselID, PG.Gb.Origin };
            RefreshHQDashboard_SP(spName, paramField, paramValue, vesselID);

            if (isToRefresh)
            {
                Refresh_NCR(vesselID);
                Refresh_Incident(vesselID);
            }
        }
        
        public static void CallDMS(string CompanyCode)
        {
            string param = PG.GetAppParam(CompanyCode, -1, true); 
            PG.ExecuteApp("PclDms_Caller", param);
        }

        public static string GetEquipmentAddlSortOrder(string groupCode, long eq_EquipmentId, string defaultEqpGroup)
        {
            string qryStr = " select AddlSortOrder from EQ_Equipment_V " +
                            " where GroupType=" + Gfn.Qs(defaultEqpGroup) + " and GroupCode='" + groupCode + "' and EQ_EquipmentID=" + eq_EquipmentId;
            string addlSortOrder = PG.Gb.DBFn.Aqr(qryStr).ToString();
            return (addlSortOrder);
        }

        public static bool CheckSelectedValueExists(string[] stringArray, string valueToCheck)
        {
            for (int i = 0; i < stringArray.Length; i++)
            {
                if (stringArray[i].ToString().ToUpper().Trim() == valueToCheck.ToUpper().Trim()) return true;
            }
            return false;
        }

        public static void Initialise_AllowedUserForAccessRights(string companyID)
        {
            string script = " select AppName, IsAllowedToAccess, UserID " +
                            " from HQ_Users U, HQ_Users_AppRestrictions A " +
                            " where U.HQ_UsersID = A.HQ_UsersID " +
                            "    and UserID= " + Gfn.Qss(PG.Gb.User.CurUserID) +
                            "    and A.C_CompanyID = '" + companyID + "'";
            PG.dtAllowedUserForAccessRights = PG.Gb.DBFn.DbRecords(script);
        }

        public static bool IsAllowedUserForAccessRightsApplication(string appName)
        {
            bool result = true;
            DataRow[] dr;
            try
            {
                if (dtAllowedUserForAccessRights == null) return (result);

                string filter = " AppName=" + Gfn.Qss(appName) + "  and UserID='" + PG.Gb.User.CurUserID + "'";
                dr = dtAllowedUserForAccessRights.Select(filter);

                if (dr.Length == 0) return (result);

                string allowedhq_UsersID = dr[0]["UserID"].ToString();
                int isAllowedToAccess = Convert.ToInt32(dr[0]["IsAllowedToAccess"].ToString());
                bool isAllowedRole = (allowedhq_UsersID == PG.Gb.User.CurUserID.ToString());

                if (isAllowedRole && isAllowedToAccess == 1) return (result);
                else result = false;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.CS", "isAllowedUserForAccessRightsApplication", err.Message);
            }
            finally
            {
                dr = null;
            }
            return (result);
        }

        public static long AddProc_DelivLocations_Attachments(long proc_DelivLocationsID, string description, int isDeleted, string fileName)
        {
            long proc_DelivLocations_AttachmentsID = -1;
            try
            {
                string script = " select isnull(max(RefNo),0) + 1 from Proc_DelivLocations_Attachments ";
                int refNo = Convert.ToInt32(Gb.DBFn.Aqr(script));

                string addlFields = " , Proc_DelivLocationsID, Refno, Description, IsDeleted, DeletedOn, AddedOn ";
                string addlFieldsValue = " , " + proc_DelivLocationsID + ", " + refNo + ", " + Gfn.Qss(description) + ", " + isDeleted + ", NULL, DATEADD (hh, " + timeToAdd + ", getdate()) ";

                proc_DelivLocations_AttachmentsID = PG.attachment.AddAttachmentToThisTable("-1", "Proc_DelivLocations_Attachments", addlFields, addlFieldsValue, fileName, -1);
            }
            catch (Exception err)
            {
                AddToGenErrorLog("PG.cs", "AddProc_DelivLocations_Attachments()", err.Message);
                proc_DelivLocations_AttachmentsID = -1;
            }

            return (proc_DelivLocations_AttachmentsID);
        }

        public long AddHQ_Management_Attachments(long tableKeyID, string category, string fileName)
        {
            long hq_Management_AttachmentsID = -1; string script;
            try
            {
                script = " Select isnull(max(RefNo),0)+1 from HQ_Management_Attachments " +
                         " where TableKeyID=" + tableKeyID + " and Category=" + Gfn.Qss(category);
                string refNo = Gb.DBFn.Aqr(script).ToString();

                string addlFields = " , TableKeyID, Category, Refno, Description, FileName, IsDeleted, DeletedOn, AddedOn ";
                string addlFieldsValue = " , " + tableKeyID + ", " + Gfn.Qss(category) + ", " + refNo + ", '', '', 0, NULL, DATEADD (hh, " + timeToAdd + ", getdate()) ";

                hq_Management_AttachmentsID = PG.attachment.AddAttachmentToThisTable("-1", "HQ_Management_Attachments", addlFields, addlFieldsValue, fileName, -1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("PG.cs", "AddHQ_Management_Attachments", err.Message);
                hq_Management_AttachmentsID = -1;
            }

            return (hq_Management_AttachmentsID);
        }

        public static string[] GetStringArray(string strText, string separator)
        {
            string[] stringSeparators = new string[] { separator };
            string[] strArr = strText.Split(stringSeparators, StringSplitOptions.None);
            stringSeparators = null;
            return strArr;
        }

        public static bool CheckIsRunningHrsEquipment(long eqEquipmentId)
        {
            string script = " select count(*) from EQ_RunHrsEquipment " +
                            " where IsDisabled=0 and EQ_EquipmentID=" + eqEquipmentId;
            bool isRunningHrsEqp = (Convert.ToInt64(PG.Gb.DBFn.Aqr(script)) > 0);
            return (isRunningHrsEqp);
        }

        public static string GetEQ_PMS_Settings(int vesselID, string settingName)
        {
            string settingValue = "";
            try
            {
                string script = " select SettingValue from EQ_PMS_Settings" +
                                " where VesselID = " + vesselID +
                                "  and SettingName = " + Gfn.Qss(settingName);
                settingValue = PG.Gb.DBFn.Aqr(script).ToString();

                return settingValue;
            }
            catch (Exception err)
            {
                AddToGenErrorLog("PG.cs", "GetEQ_PMS_Settings", err.Message);
            }
            return settingValue;
        }

        public static void IsUserExistsinApp_SplFunctionalityCtrl()
        {
            string script = " Select Functionality  from App_SplFunctionalityCtrl " +
                            " Where MachineName='" + Environment.MachineName + "' " +
                            "    and MachineLoginID= '" + Environment.UserName + "' " +
                            "    and UserID like '%" + PG.Gb.User.CurUserID + "%'";
            DataTable dt = PG.Gb.DBFn.DbRecords(script);

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    string func = dr["Functionality"].ToString();
                    if (func.ToUpper() == "FormsDesigner".ToUpper())
                    {
                        isAllowedToFormsDesigner = true;
                    }
                    else if (func.ToUpper() == "HQCircularsMgmt".ToUpper())
                    {
                        isAllowedToHQCircularsMgmt = true;
                    }
                    else if (func.ToUpper() == "SettingsManagement".ToUpper())
                    {
                        isAllowedToSetupSettingsManagement = true;
                    }
                    else if (func.ToUpper() == "HQMain_DTFManualSyc".ToUpper())
                    {
                        isAllowedUserToDoBlobManualSync = true;
                    }
                }
            }

            if (PG.Gb.User.CurUserID.ToUpper() == "SDSADMIN")
            {
                isAllowedToHQCircularsMgmt = true;
                isAllowedUserToDoBlobManualSync = true;
                isAllowedAddEditApplicationChangeDetails = true;
                isAllowedAddEditVslCrewAddNewController = true;
            }
        }


        public static string GetAppParam(string companyCODE, int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = companyCODE.ToUpper() + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = companyCODE.ToUpper() + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            return param;

        }

        public static bool CheckAppUnderMaintenance(string formTitle)
        {
            string qry = " select SettingValue from HQ_Settings where SettingName = 'IsApplicationUnderMaintenance' ";
            string sx = PG.Gb.DBFn.Aqr(qry).ToString();

            if (sx.ToUpper() == "YES")
            {
                frmUnderMaintenance objMain = new frmUnderMaintenance();
                try
                {
                    objMain.formTitle = formTitle;
                    objMain.ShowDialog();
                }
                finally
                {
                    objMain = null;
                }
                return (true);
            }

            return (false);
        }
    }
}