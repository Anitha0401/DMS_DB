﻿namespace HqSDS_Main
{
    partial class frmMainForm_Tech
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainForm_Tech));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuCurrenctXRate = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuUOMList = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuExportParticulars = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.administrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuManageUserAndVsls = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuFormsVesselSelection = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuFormsDesigner = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsStripFormsVesselSelection = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuSetup_StoresItemMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuDelivLocationsManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuClients = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuLegalEntity = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuCurrencyManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuHoliDaysManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuAll_HQ_VSLSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuUserSignManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuUserAppRestrictions = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuAgressoReinterface = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVendorLinks = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuClearCefCache = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsMnuRootCauseAnalysisChartSetup = new System.Windows.Forms.ToolStripMenuItem();
            this.tlsMnuAuditInspectionSetup = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSettingManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuManualSync_BigBlobs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuHQCirculars = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslCrewAddNewController = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuApplicationChangeDetails = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuUpdateDMSCompany = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVesselOperationModeSetup = new System.Windows.Forms.ToolStripMenuItem();
            this.templatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForFleet = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForFleet_NonCriticalMaint = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForFleet_CriticalMaint = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForFleet_CriticalEqp = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForFleet_NonCriticalEqp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnukPITrendingForFleet_All = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuDefectsReports = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDefectTrending_AllVsls = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDefectsVestsMnuDelAvailabilityKPI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuDTF = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDTFCurrentStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDTFHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDTFTrending = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuProcurement = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuNCRTrending = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuMonthEndDocumentReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuQuarterlyStoresReports = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuUserGuide = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_Fleet = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelLoading = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.fpSpread_Particulars = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_Particulars_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.chkShowMyApproveColumn = new System.Windows.Forms.CheckBox();
            this.btnCrewDashboard = new System.Windows.Forms.Button();
            this.chkShowOnlyActionColumns = new System.Windows.Forms.CheckBox();
            this.cboCompany_Filter = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDMS = new System.Windows.Forms.Button();
            this.lnkRefresh = new System.Windows.Forms.LinkLabel();
            this.btnProcurement = new System.Windows.Forms.Button();
            this.cboVslFilter = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnExportXLParticulars = new System.Windows.Forms.Button();
            this.btnNcr = new System.Windows.Forms.Button();
            this.btnSQEDashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.progressBarRefresh = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblSvrName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblUserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tlsStatuslblTotalVessels = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.cntxtMnuStrip_Fleet = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsMnuExportEquipmentParticulars = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuExportEquipmentUnitParticulars = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuExportPMSItems = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuWithoutCheckList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuPMSItemsWithCheckList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnupmsReports = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuCriticalSparesList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuAllCriticalSparesItems = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuEquipmentWiseCriticalSparesItems = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuVslAppplication = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmu_VslDashBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslSpares = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslStores = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslPMS = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslDefects = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslEngineData = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslNoonLog = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslFormsSeparater = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_VslForms = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.tsm_CorrectiveMaintenance = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuDocumentManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuVslAlerts_Circulars = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuVslRiskAssements = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmnSparesInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmnStoresInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmnSparesPurchase = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmnuStoresPurchase = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuHQPMS = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDefects = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuRepairsPurchase = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuForms = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuRiskAssements = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuAuditInspection = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuNCR = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuTaskList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuIncidentReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuAwarenessReport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuMastersReview = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuMinutesOfSafety = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuMonthEndDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslCertificate = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSplitterB4EquipmentManager = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuEquipmentManager = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuKPITrending_Vsl = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForVsl_NonCriticalMaint = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForVsl_CriticalMaint = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForVsl_CriticalEqp = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuKPITrendingForVsl_NonCriticalEqp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnukPITrendingForVsl_All = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuDefectTrendingEquipmentWise_SingleVsl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuRefreshforSelectedVessel = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator_DTF = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuDTFDataTransferToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuVslUserManagement = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tsMnuEquipmentSparesList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSetupProcurementInterface = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage_Fleet.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelLoading.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars_Sheet1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.cntxtMnuStrip_Fleet.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1268, 589);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.administrationToolStripMenuItem,
            this.templatesToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1268, 31);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuCurrenctXRate,
            this.tsMnuUOMList,
            this.toolStripMenuItem7,
            this.tsMnuExportParticulars,
            this.toolStripSeparator12,
            this.tsMnuAbout,
            this.toolStripSeparator20,
            this.mnuExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 27);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // tsMnuCurrenctXRate
            // 
            this.tsMnuCurrenctXRate.Name = "tsMnuCurrenctXRate";
            this.tsMnuCurrenctXRate.Size = new System.Drawing.Size(166, 22);
            this.tsMnuCurrenctXRate.Text = "Currency X-Rates";
            this.tsMnuCurrenctXRate.Click += new System.EventHandler(this.tsMnuCurrenctXRate_Click);
            // 
            // tsMnuUOMList
            // 
            this.tsMnuUOMList.Name = "tsMnuUOMList";
            this.tsMnuUOMList.Size = new System.Drawing.Size(166, 22);
            this.tsMnuUOMList.Text = "UOM List";
            this.tsMnuUOMList.Click += new System.EventHandler(this.tsMnuUOMList_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(163, 6);
            // 
            // tsMnuExportParticulars
            // 
            this.tsMnuExportParticulars.Name = "tsMnuExportParticulars";
            this.tsMnuExportParticulars.Size = new System.Drawing.Size(166, 22);
            this.tsMnuExportParticulars.Text = "Export Particulars";
            this.tsMnuExportParticulars.Click += new System.EventHandler(this.tsMnuExportXLParticulars_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(163, 6);
            // 
            // tsMnuAbout
            // 
            this.tsMnuAbout.Name = "tsMnuAbout";
            this.tsMnuAbout.Size = new System.Drawing.Size(166, 22);
            this.tsMnuAbout.Text = "About";
            this.tsMnuAbout.Click += new System.EventHandler(this.tsMnuAbout_Click);
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(163, 6);
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(166, 22);
            this.mnuExit.Text = "Exit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // administrationToolStripMenuItem
            // 
            this.administrationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuManageUserAndVsls,
            this.toolStripSeparator1,
            this.tsMnuFormsVesselSelection,
            this.tsMnuFormsDesigner,
            this.tlsStripFormsVesselSelection,
            this.tsMnuSetup_StoresItemMaster,
            this.toolStripSeparator2,
            this.tsMnuDelivLocationsManagement,
            this.toolStripSeparator11,
            this.tsMnuClients,
            this.tsMnuLegalEntity,
            this.toolStripSeparator15,
            this.tsMnuCurrencyManagement,
            this.toolStripSeparator14,
            this.tsMnuHoliDaysManagement,
            this.tsMnuSeparator5,
            this.tsMnuAll_HQ_VSLSettings,
            this.tsMnuUserSignManagement,
            this.tsMnuUserAppRestrictions,
            this.toolStripSeparator19,
            this.tsMnuAgressoReinterface,
            this.tsMnuVendorLinks,
            this.toolStripMenuItem8,
            this.tsMnuClearCefCache,
            this.tlsMnuRootCauseAnalysisChartSetup,
            this.tlsMnuAuditInspectionSetup,
            this.tsMnuSettingManagement,
            this.tsMnuManualSync_BigBlobs,
            this.toolStripMenuItem11,
            this.tsMnuHQCirculars,
            this.tsMnuVslCrewAddNewController,
            this.tsMnuApplicationChangeDetails,
            this.tsMnuUpdateDMSCompany,
            this.tsMnuVesselOperationModeSetup,
            this.tsMnuSetupProcurementInterface});
            this.administrationToolStripMenuItem.Name = "administrationToolStripMenuItem";
            this.administrationToolStripMenuItem.Size = new System.Drawing.Size(98, 27);
            this.administrationToolStripMenuItem.Text = "Administration";
            // 
            // tsMnuManageUserAndVsls
            // 
            this.tsMnuManageUserAndVsls.Name = "tsMnuManageUserAndVsls";
            this.tsMnuManageUserAndVsls.Size = new System.Drawing.Size(255, 22);
            this.tsMnuManageUserAndVsls.Text = "Users Vessel Selection";
            this.tsMnuManageUserAndVsls.Click += new System.EventHandler(this.tsMnuManageUserAndVsls_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuFormsVesselSelection
            // 
            this.tsMnuFormsVesselSelection.Name = "tsMnuFormsVesselSelection";
            this.tsMnuFormsVesselSelection.Size = new System.Drawing.Size(255, 22);
            this.tsMnuFormsVesselSelection.Text = "Forms Vessel Selection";
            this.tsMnuFormsVesselSelection.Click += new System.EventHandler(this.tsMnuFormsVesselSelection_Click);
            // 
            // tsMnuFormsDesigner
            // 
            this.tsMnuFormsDesigner.Name = "tsMnuFormsDesigner";
            this.tsMnuFormsDesigner.Size = new System.Drawing.Size(255, 22);
            this.tsMnuFormsDesigner.Text = "Forms Designer";
            this.tsMnuFormsDesigner.Click += new System.EventHandler(this.tsMnuFormsDesigner_Click);
            // 
            // tlsStripFormsVesselSelection
            // 
            this.tlsStripFormsVesselSelection.Name = "tlsStripFormsVesselSelection";
            this.tlsStripFormsVesselSelection.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuSetup_StoresItemMaster
            // 
            this.tsMnuSetup_StoresItemMaster.Name = "tsMnuSetup_StoresItemMaster";
            this.tsMnuSetup_StoresItemMaster.Size = new System.Drawing.Size(255, 22);
            this.tsMnuSetup_StoresItemMaster.Text = "Stores Item Master";
            this.tsMnuSetup_StoresItemMaster.Visible = false;
            this.tsMnuSetup_StoresItemMaster.Click += new System.EventHandler(this.tsMnuSetup_StoresItemMaster_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuDelivLocationsManagement
            // 
            this.tsMnuDelivLocationsManagement.Name = "tsMnuDelivLocationsManagement";
            this.tsMnuDelivLocationsManagement.Size = new System.Drawing.Size(255, 22);
            this.tsMnuDelivLocationsManagement.Text = "Delivery Locations Management";
            this.tsMnuDelivLocationsManagement.Click += new System.EventHandler(this.tsMnuDelivLocationsManagement_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuClients
            // 
            this.tsMnuClients.Name = "tsMnuClients";
            this.tsMnuClients.Size = new System.Drawing.Size(255, 22);
            this.tsMnuClients.Text = "Client Management";
            this.tsMnuClients.Click += new System.EventHandler(this.tsMnuClients_Click);
            // 
            // tsMnuLegalEntity
            // 
            this.tsMnuLegalEntity.Name = "tsMnuLegalEntity";
            this.tsMnuLegalEntity.Size = new System.Drawing.Size(255, 22);
            this.tsMnuLegalEntity.Text = "Legal Entity Management";
            this.tsMnuLegalEntity.Click += new System.EventHandler(this.tsMnuLegalEntity_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuCurrencyManagement
            // 
            this.tsMnuCurrencyManagement.Name = "tsMnuCurrencyManagement";
            this.tsMnuCurrencyManagement.Size = new System.Drawing.Size(255, 22);
            this.tsMnuCurrencyManagement.Text = "Currency Management";
            this.tsMnuCurrencyManagement.Click += new System.EventHandler(this.tsMnuCurrencyManagement_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuHoliDaysManagement
            // 
            this.tsMnuHoliDaysManagement.Name = "tsMnuHoliDaysManagement";
            this.tsMnuHoliDaysManagement.Size = new System.Drawing.Size(255, 22);
            this.tsMnuHoliDaysManagement.Text = "Holidays Management";
            this.tsMnuHoliDaysManagement.Click += new System.EventHandler(this.tsMnuHoliDaysManagement_Click);
            // 
            // tsMnuSeparator5
            // 
            this.tsMnuSeparator5.Name = "tsMnuSeparator5";
            this.tsMnuSeparator5.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuAll_HQ_VSLSettings
            // 
            this.tsMnuAll_HQ_VSLSettings.Name = "tsMnuAll_HQ_VSLSettings";
            this.tsMnuAll_HQ_VSLSettings.Size = new System.Drawing.Size(255, 22);
            this.tsMnuAll_HQ_VSLSettings.Text = "All HQ / Vsl Settings";
            this.tsMnuAll_HQ_VSLSettings.Click += new System.EventHandler(this.tsMnuAll_HQ_VSLSettings_Click);
            // 
            // tsMnuUserSignManagement
            // 
            this.tsMnuUserSignManagement.Name = "tsMnuUserSignManagement";
            this.tsMnuUserSignManagement.Size = new System.Drawing.Size(255, 22);
            this.tsMnuUserSignManagement.Text = "User Signature Management";
            this.tsMnuUserSignManagement.Click += new System.EventHandler(this.tsMnuUserSignManagement_Click);
            // 
            // tsMnuUserAppRestrictions
            // 
            this.tsMnuUserAppRestrictions.Name = "tsMnuUserAppRestrictions";
            this.tsMnuUserAppRestrictions.Size = new System.Drawing.Size(255, 22);
            this.tsMnuUserAppRestrictions.Text = "User App Restriction Management";
            this.tsMnuUserAppRestrictions.Click += new System.EventHandler(this.tsMnuUserAppRestrictions_Click);
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuAgressoReinterface
            // 
            this.tsMnuAgressoReinterface.Name = "tsMnuAgressoReinterface";
            this.tsMnuAgressoReinterface.Size = new System.Drawing.Size(255, 22);
            this.tsMnuAgressoReinterface.Text = "Agresso Re-interface";
            this.tsMnuAgressoReinterface.Click += new System.EventHandler(this.tsMnuAgressoReinterface_Click);
            // 
            // tsMnuVendorLinks
            // 
            this.tsMnuVendorLinks.Name = "tsMnuVendorLinks";
            this.tsMnuVendorLinks.Size = new System.Drawing.Size(255, 22);
            this.tsMnuVendorLinks.Text = "Vendor Links";
            this.tsMnuVendorLinks.Click += new System.EventHandler(this.tsMnuVendorLinks_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuClearCefCache
            // 
            this.tsMnuClearCefCache.Name = "tsMnuClearCefCache";
            this.tsMnuClearCefCache.Size = new System.Drawing.Size(255, 22);
            this.tsMnuClearCefCache.Text = "Clear Cef Cache";
            this.tsMnuClearCefCache.Click += new System.EventHandler(this.tsMnuClearCefCache_Click);
            // 
            // tlsMnuRootCauseAnalysisChartSetup
            // 
            this.tlsMnuRootCauseAnalysisChartSetup.Name = "tlsMnuRootCauseAnalysisChartSetup";
            this.tlsMnuRootCauseAnalysisChartSetup.Size = new System.Drawing.Size(255, 22);
            this.tlsMnuRootCauseAnalysisChartSetup.Text = "Root Cause Analysis Chart Setup";
            this.tlsMnuRootCauseAnalysisChartSetup.Click += new System.EventHandler(this.tlsMnuRootCauseAnalysisChartSetup_Click);
            // 
            // tlsMnuAuditInspectionSetup
            // 
            this.tlsMnuAuditInspectionSetup.Name = "tlsMnuAuditInspectionSetup";
            this.tlsMnuAuditInspectionSetup.Size = new System.Drawing.Size(255, 22);
            this.tlsMnuAuditInspectionSetup.Text = "Audit / Inspection Setup";
            this.tlsMnuAuditInspectionSetup.Click += new System.EventHandler(this.tlsMnuAuditInspectionSetup_Click);
            // 
            // tsMnuSettingManagement
            // 
            this.tsMnuSettingManagement.Name = "tsMnuSettingManagement";
            this.tsMnuSettingManagement.Size = new System.Drawing.Size(255, 22);
            this.tsMnuSettingManagement.Text = "Settings Management";
            this.tsMnuSettingManagement.Click += new System.EventHandler(this.tsMnuSettingManagement_Click);
            // 
            // tsMnuManualSync_BigBlobs
            // 
            this.tsMnuManualSync_BigBlobs.Name = "tsMnuManualSync_BigBlobs";
            this.tsMnuManualSync_BigBlobs.Size = new System.Drawing.Size(255, 22);
            this.tsMnuManualSync_BigBlobs.Text = "Manual Sync - Big Files";
            this.tsMnuManualSync_BigBlobs.Click += new System.EventHandler(this.tsMnuManualSync_BigBlobs_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(252, 6);
            // 
            // tsMnuHQCirculars
            // 
            this.tsMnuHQCirculars.Name = "tsMnuHQCirculars";
            this.tsMnuHQCirculars.Size = new System.Drawing.Size(255, 22);
            this.tsMnuHQCirculars.Text = "Setup Circulars Management";
            this.tsMnuHQCirculars.Click += new System.EventHandler(this.tsMnuHQCirculars_Click);
            // 
            // tsMnuVslCrewAddNewController
            // 
            this.tsMnuVslCrewAddNewController.Name = "tsMnuVslCrewAddNewController";
            this.tsMnuVslCrewAddNewController.Size = new System.Drawing.Size(255, 22);
            this.tsMnuVslCrewAddNewController.Text = "Setup Vsl Crew";
            this.tsMnuVslCrewAddNewController.Click += new System.EventHandler(this.tsMnuVslCrewAddNewController_Click);
            // 
            // tsMnuApplicationChangeDetails
            // 
            this.tsMnuApplicationChangeDetails.Name = "tsMnuApplicationChangeDetails";
            this.tsMnuApplicationChangeDetails.Size = new System.Drawing.Size(255, 22);
            this.tsMnuApplicationChangeDetails.Text = "Setup CR Details";
            this.tsMnuApplicationChangeDetails.Click += new System.EventHandler(this.tsMnuApplicationChangeDetails_Click);
            // 
            // tsMnuUpdateDMSCompany
            // 
            this.tsMnuUpdateDMSCompany.Name = "tsMnuUpdateDMSCompany";
            this.tsMnuUpdateDMSCompany.Size = new System.Drawing.Size(255, 22);
            this.tsMnuUpdateDMSCompany.Text = "Setup DMS Rights";
            this.tsMnuUpdateDMSCompany.Click += new System.EventHandler(this.tsMnuUpdateDMSCompany_Click);
            // 
            // tsMnuVesselOperationModeSetup
            // 
            this.tsMnuVesselOperationModeSetup.Name = "tsMnuVesselOperationModeSetup";
            this.tsMnuVesselOperationModeSetup.Size = new System.Drawing.Size(255, 22);
            this.tsMnuVesselOperationModeSetup.Text = "Setup Application Ops Mode";
            this.tsMnuVesselOperationModeSetup.Click += new System.EventHandler(this.tsMnuVesselOperationModeSetup_Click);
            // 
            // templatesToolStripMenuItem
            // 
            this.templatesToolStripMenuItem.Name = "templatesToolStripMenuItem";
            this.templatesToolStripMenuItem.Size = new System.Drawing.Size(72, 27);
            this.templatesToolStripMenuItem.Text = "Templates";
            this.templatesToolStripMenuItem.Click += new System.EventHandler(this.templatesToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuKPITrendingForFleet,
            this.toolStripMenuItem4,
            this.tsMnuDefectsReports,
            this.toolStripMenuItem5,
            this.tsMnuDTF,
            this.tsMnuProcurement,
            this.tsMnuNCRTrending,
            this.toolStripMenuItem10,
            this.tsMnuMonthEndDocumentReport,
            this.tsMnuQuarterlyStoresReports});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 27);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // tsMnuKPITrendingForFleet
            // 
            this.tsMnuKPITrendingForFleet.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuKPITrendingForFleet_NonCriticalMaint,
            this.tsMnuKPITrendingForFleet_CriticalMaint,
            this.tsMnuKPITrendingForFleet_CriticalEqp,
            this.tsMnuKPITrendingForFleet_NonCriticalEqp,
            this.toolStripMenuItem3,
            this.tsMnukPITrendingForFleet_All});
            this.tsMnuKPITrendingForFleet.Name = "tsMnuKPITrendingForFleet";
            this.tsMnuKPITrendingForFleet.Size = new System.Drawing.Size(230, 22);
            this.tsMnuKPITrendingForFleet.Text = "KPI Trending for Fleet";
            // 
            // tsMnuKPITrendingForFleet_NonCriticalMaint
            // 
            this.tsMnuKPITrendingForFleet_NonCriticalMaint.Name = "tsMnuKPITrendingForFleet_NonCriticalMaint";
            this.tsMnuKPITrendingForFleet_NonCriticalMaint.Size = new System.Drawing.Size(370, 22);
            this.tsMnuKPITrendingForFleet_NonCriticalMaint.Text = "KPI Trending for Fleet (Critical Maintenance excluded)";
            this.tsMnuKPITrendingForFleet_NonCriticalMaint.Click += new System.EventHandler(this.tsMnuKPITrendingForFleet_NonCriticalMaint_Click);
            // 
            // tsMnuKPITrendingForFleet_CriticalMaint
            // 
            this.tsMnuKPITrendingForFleet_CriticalMaint.Name = "tsMnuKPITrendingForFleet_CriticalMaint";
            this.tsMnuKPITrendingForFleet_CriticalMaint.Size = new System.Drawing.Size(370, 22);
            this.tsMnuKPITrendingForFleet_CriticalMaint.Text = "KPI Trending for Fleet (Critical Maintenance)";
            this.tsMnuKPITrendingForFleet_CriticalMaint.Click += new System.EventHandler(this.tsMnuKPITrendingForFleet_CriticalMaint_Click);
            // 
            // tsMnuKPITrendingForFleet_CriticalEqp
            // 
            this.tsMnuKPITrendingForFleet_CriticalEqp.Name = "tsMnuKPITrendingForFleet_CriticalEqp";
            this.tsMnuKPITrendingForFleet_CriticalEqp.Size = new System.Drawing.Size(370, 22);
            this.tsMnuKPITrendingForFleet_CriticalEqp.Text = "KPI Trending for Fleet (Critical Eqpmt Maintenance)";
            this.tsMnuKPITrendingForFleet_CriticalEqp.Click += new System.EventHandler(this.tsMnuKPITrendingForFleet_CriticalEqp_Click);
            // 
            // tsMnuKPITrendingForFleet_NonCriticalEqp
            // 
            this.tsMnuKPITrendingForFleet_NonCriticalEqp.Name = "tsMnuKPITrendingForFleet_NonCriticalEqp";
            this.tsMnuKPITrendingForFleet_NonCriticalEqp.Size = new System.Drawing.Size(370, 22);
            this.tsMnuKPITrendingForFleet_NonCriticalEqp.Text = "KPI Trending for Fleet (Non Critical Eqpmt Maintenance)";
            this.tsMnuKPITrendingForFleet_NonCriticalEqp.Click += new System.EventHandler(this.tsMnuKPITrendingForFleet_NonCriticalEqp_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(367, 6);
            // 
            // tsMnukPITrendingForFleet_All
            // 
            this.tsMnukPITrendingForFleet_All.Name = "tsMnukPITrendingForFleet_All";
            this.tsMnukPITrendingForFleet_All.Size = new System.Drawing.Size(370, 22);
            this.tsMnukPITrendingForFleet_All.Text = "KPI Trending for Fleet - All";
            this.tsMnukPITrendingForFleet_All.Click += new System.EventHandler(this.mnukPITrendingForFleet_All_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(227, 6);
            // 
            // tsMnuDefectsReports
            // 
            this.tsMnuDefectsReports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuDefectTrending_AllVsls,
            this.tsMnuDefectsVestsMnuDelAvailabilityKPI});
            this.tsMnuDefectsReports.Name = "tsMnuDefectsReports";
            this.tsMnuDefectsReports.Size = new System.Drawing.Size(230, 22);
            this.tsMnuDefectsReports.Text = "Defects";
            // 
            // tsMnuDefectTrending_AllVsls
            // 
            this.tsMnuDefectTrending_AllVsls.Name = "tsMnuDefectTrending_AllVsls";
            this.tsMnuDefectTrending_AllVsls.Size = new System.Drawing.Size(303, 22);
            this.tsMnuDefectTrending_AllVsls.Text = "Defects Trending for Fleet (Equipment wise)";
            this.tsMnuDefectTrending_AllVsls.Click += new System.EventHandler(this.tsMnuDefectTrending_AllVsls_Click);
            // 
            // tsMnuDefectsVestsMnuDelAvailabilityKPI
            // 
            this.tsMnuDefectsVestsMnuDelAvailabilityKPI.Name = "tsMnuDefectsVestsMnuDelAvailabilityKPI";
            this.tsMnuDefectsVestsMnuDelAvailabilityKPI.Size = new System.Drawing.Size(303, 22);
            this.tsMnuDefectsVestsMnuDelAvailabilityKPI.Text = "Defects Vessel Availability KPI";
            this.tsMnuDefectsVestsMnuDelAvailabilityKPI.Click += new System.EventHandler(this.tsMnuDefectsVestsMnuDelAvailabilityKPI_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(227, 6);
            // 
            // tsMnuDTF
            // 
            this.tsMnuDTF.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuDTFCurrentStatus,
            this.tsMnuDTFHistory,
            this.tsMnuDTFTrending});
            this.tsMnuDTF.Name = "tsMnuDTF";
            this.tsMnuDTF.Size = new System.Drawing.Size(230, 22);
            this.tsMnuDTF.Text = "DTF";
            // 
            // tsMnuDTFCurrentStatus
            // 
            this.tsMnuDTFCurrentStatus.Name = "tsMnuDTFCurrentStatus";
            this.tsMnuDTFCurrentStatus.Size = new System.Drawing.Size(149, 22);
            this.tsMnuDTFCurrentStatus.Text = "Current Status";
            this.tsMnuDTFCurrentStatus.Click += new System.EventHandler(this.tsMnuDTFCurrentStatus_Click);
            // 
            // tsMnuDTFHistory
            // 
            this.tsMnuDTFHistory.Name = "tsMnuDTFHistory";
            this.tsMnuDTFHistory.Size = new System.Drawing.Size(149, 22);
            this.tsMnuDTFHistory.Text = "DTF History";
            this.tsMnuDTFHistory.Click += new System.EventHandler(this.tsMnuDTFHistory_Click);
            // 
            // tsMnuDTFTrending
            // 
            this.tsMnuDTFTrending.Name = "tsMnuDTFTrending";
            this.tsMnuDTFTrending.Size = new System.Drawing.Size(149, 22);
            this.tsMnuDTFTrending.Text = "DTF Trending";
            this.tsMnuDTFTrending.Click += new System.EventHandler(this.tsMnuDTFTrending_Click);
            // 
            // tsMnuProcurement
            // 
            this.tsMnuProcurement.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days,
            this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays});
            this.tsMnuProcurement.Name = "tsMnuProcurement";
            this.tsMnuProcurement.Size = new System.Drawing.Size(230, 22);
            this.tsMnuProcurement.Text = "Procurement KPI";
            // 
            // tsMnuSparesPOsNotSubmitForRFQMoreThan3Days
            // 
            this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days.Name = "tsMnuSparesPOsNotSubmitForRFQMoreThan3Days";
            this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days.Size = new System.Drawing.Size(394, 22);
            this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days.Text = "Spares POs [Not Submit for RFQ more than 3 days]";
            this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days.Click += new System.EventHandler(this.tsMnuSparesPOsNotSubmitForRFQMoreThan3Days_Click);
            // 
            // tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays
            // 
            this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays.Name = "tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays";
            this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays.Size = new System.Drawing.Size(394, 22);
            this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays.Text = "Spares POs [Not Submit for Supt Approval more than 7 days]";
            this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays.Click += new System.EventHandler(this.tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays_Click);
            // 
            // tsMnuNCRTrending
            // 
            this.tsMnuNCRTrending.Name = "tsMnuNCRTrending";
            this.tsMnuNCRTrending.Size = new System.Drawing.Size(230, 22);
            this.tsMnuNCRTrending.Text = "NCR Trending";
            this.tsMnuNCRTrending.Click += new System.EventHandler(this.tsMnuNCRTrending_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(227, 6);
            // 
            // tsMnuMonthEndDocumentReport
            // 
            this.tsMnuMonthEndDocumentReport.Name = "tsMnuMonthEndDocumentReport";
            this.tsMnuMonthEndDocumentReport.Size = new System.Drawing.Size(230, 22);
            this.tsMnuMonthEndDocumentReport.Text = "Month End Document Report";
            this.tsMnuMonthEndDocumentReport.Click += new System.EventHandler(this.tsMnuMonthEndDocumentReport_Click);
            // 
            // tsMnuQuarterlyStoresReports
            // 
            this.tsMnuQuarterlyStoresReports.Name = "tsMnuQuarterlyStoresReports";
            this.tsMnuQuarterlyStoresReports.Size = new System.Drawing.Size(230, 22);
            this.tsMnuQuarterlyStoresReports.Text = "Quarterly Stores Reports";
            this.tsMnuQuarterlyStoresReports.Click += new System.EventHandler(this.tsMnuQuarterlyStoresReports_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuUserGuide});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 27);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Visible = false;
            // 
            // tsMnuUserGuide
            // 
            this.tsMnuUserGuide.Name = "tsMnuUserGuide";
            this.tsMnuUserGuide.Size = new System.Drawing.Size(131, 22);
            this.tsMnuUserGuide.Text = "User Guide";
            this.tsMnuUserGuide.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_Fleet);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 34);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1262, 532);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage_Fleet
            // 
            this.tabPage_Fleet.BackColor = System.Drawing.Color.Honeydew;
            this.tabPage_Fleet.Controls.Add(this.tableLayoutPanel3);
            this.tabPage_Fleet.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Fleet.Name = "tabPage_Fleet";
            this.tabPage_Fleet.Size = new System.Drawing.Size(1254, 506);
            this.tabPage_Fleet.TabIndex = 2;
            this.tabPage_Fleet.Text = "FLEET";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1254, 506);
            this.tableLayoutPanel3.TabIndex = 24;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Honeydew;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panelLoading);
            this.panel1.Controls.Add(this.fpSpread_Particulars);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1248, 469);
            this.panel1.TabIndex = 44;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(572, 121);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(121, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.WaitOnLoad = true;
            // 
            // panelLoading
            // 
            this.panelLoading.BackColor = System.Drawing.Color.White;
            this.panelLoading.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLoading.Controls.Add(this.label19);
            this.panelLoading.Controls.Add(this.label20);
            this.panelLoading.Location = new System.Drawing.Point(572, 121);
            this.panelLoading.Name = "panelLoading";
            this.panelLoading.Size = new System.Drawing.Size(154, 112);
            this.panelLoading.TabIndex = 170;
            this.panelLoading.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(9, 63);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "Please wait ...";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DarkGreen;
            this.label20.Location = new System.Drawing.Point(8, 31);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(136, 22);
            this.label20.TabIndex = 0;
            this.label20.Text = "Refreshing...  ";
            // 
            // fpSpread_Particulars
            // 
            this.fpSpread_Particulars.AccessibleDescription = "fpSpread_Particulars, Sheet1, Row 0, Column 0, ";
            this.fpSpread_Particulars.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
            this.fpSpread_Particulars.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_Particulars.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_Particulars.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_Particulars.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Particulars.HorizontalScrollBar.Name = "";
            this.fpSpread_Particulars.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread_Particulars.HorizontalScrollBar.TabIndex = 54;
            this.fpSpread_Particulars.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_Particulars.Name = "fpSpread_Particulars";
            this.fpSpread_Particulars.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_Particulars_Sheet1});
            this.fpSpread_Particulars.Size = new System.Drawing.Size(1248, 469);
            this.fpSpread_Particulars.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_Particulars.TabIndex = 21;
            this.fpSpread_Particulars.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Particulars.VerticalScrollBar.Name = "";
            this.fpSpread_Particulars.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread_Particulars.VerticalScrollBar.TabIndex = 55;
            this.fpSpread_Particulars.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread_Particulars.TextTipFetch += new FarPoint.Win.Spread.TextTipFetchEventHandler(this.fpSpread_Particulars_TextTipFetch);
            this.fpSpread_Particulars.CellDoubleClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread_Particulars_CellDoubleClick);
            this.fpSpread_Particulars.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread_Particulars_MouseDown);
            // 
            // fpSpread_Particulars_Sheet1
            // 
            this.fpSpread_Particulars_Sheet1.Reset();
            this.fpSpread_Particulars_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_Particulars_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_Particulars_Sheet1.ColumnCount = 20;
            this.fpSpread_Particulars_Sheet1.RowCount = 10;
            this.fpSpread_Particulars_Sheet1.AutoGenerateColumns = false;
            this.fpSpread_Particulars_Sheet1.AutoUpdateNotes = false;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(0, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(1, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(2, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(3, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(4, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(5, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(6, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(7, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(8, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 0).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 1).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 2).BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(248)))), ((int)(((byte)(220)))));
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 11).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 12).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 13).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 14).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 15).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 16).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 17).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 18).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.Cells.Get(9, 19).BackColor = System.Drawing.Color.WhiteSmoke;
            this.fpSpread_Particulars_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Particulars_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Particulars_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Particulars_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread_Particulars_Sheet1.Columns.Get(1).Width = 59F;
            this.fpSpread_Particulars_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(3).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread_Particulars_Sheet1.Columns.Get(4).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(4).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(4).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread_Particulars_Sheet1.Columns.Get(5).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(5).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(5).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread_Particulars_Sheet1.Columns.Get(6).Width = 9F;
            this.fpSpread_Particulars_Sheet1.Columns.Get(7).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(7).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(8).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(8).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(9).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(9).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(10).BackColor = System.Drawing.Color.White;
            this.fpSpread_Particulars_Sheet1.Columns.Get(10).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(10).Width = 7F;
            this.fpSpread_Particulars_Sheet1.Columns.Get(11).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(12).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(13).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(14).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(15).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(16).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(17).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(18).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.Columns.Get(19).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread_Particulars_Sheet1.DisplayZero = false;
            this.fpSpread_Particulars_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.DarkSeaGreen);
            this.fpSpread_Particulars_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread_Particulars_Sheet1.RowHeader.Columns.Get(0).Width = 33F;
            this.fpSpread_Particulars_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_Particulars_Sheet1.RowHeader.Visible = false;
            this.fpSpread_Particulars_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Particulars_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Particulars_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.DarkSeaGreen);
            this.fpSpread_Particulars_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Honeydew;
            this.panel3.Controls.Add(this.chkShowMyApproveColumn);
            this.panel3.Controls.Add(this.btnCrewDashboard);
            this.panel3.Controls.Add(this.chkShowOnlyActionColumns);
            this.panel3.Controls.Add(this.cboCompany_Filter);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.btnDMS);
            this.panel3.Controls.Add(this.lnkRefresh);
            this.panel3.Controls.Add(this.btnProcurement);
            this.panel3.Controls.Add(this.cboVslFilter);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.btnExportXLParticulars);
            this.panel3.Controls.Add(this.btnNcr);
            this.panel3.Controls.Add(this.btnSQEDashboard);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1254, 31);
            this.panel3.TabIndex = 22;
            // 
            // chkShowMyApproveColumn
            // 
            this.chkShowMyApproveColumn.AutoSize = true;
            this.chkShowMyApproveColumn.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowMyApproveColumn.ForeColor = System.Drawing.Color.Black;
            this.chkShowMyApproveColumn.Location = new System.Drawing.Point(536, 3);
            this.chkShowMyApproveColumn.Name = "chkShowMyApproveColumn";
            this.chkShowMyApproveColumn.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.chkShowMyApproveColumn.Size = new System.Drawing.Size(153, 25);
            this.chkShowMyApproveColumn.TabIndex = 62;
            this.chkShowMyApproveColumn.Text = "My Approval Columns";
            this.chkShowMyApproveColumn.UseVisualStyleBackColor = false;
            this.chkShowMyApproveColumn.CheckedChanged += new System.EventHandler(this.chkShowMyApproveColumn_CheckedChanged);
            // 
            // btnCrewDashboard
            // 
            this.btnCrewDashboard.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnCrewDashboard.Location = new System.Drawing.Point(858, 2);
            this.btnCrewDashboard.Name = "btnCrewDashboard";
            this.btnCrewDashboard.Size = new System.Drawing.Size(117, 26);
            this.btnCrewDashboard.TabIndex = 50;
            this.btnCrewDashboard.Text = "Crew Dashboard";
            this.btnCrewDashboard.UseVisualStyleBackColor = true;
            this.btnCrewDashboard.Click += new System.EventHandler(this.btnCrewDashboard_Click);
            // 
            // chkShowOnlyActionColumns
            // 
            this.chkShowOnlyActionColumns.AutoSize = true;
            this.chkShowOnlyActionColumns.Font = new System.Drawing.Font("Arial", 8.5F);
            this.chkShowOnlyActionColumns.Location = new System.Drawing.Point(377, 6);
            this.chkShowOnlyActionColumns.Name = "chkShowOnlyActionColumns";
            this.chkShowOnlyActionColumns.Size = new System.Drawing.Size(158, 19);
            this.chkShowOnlyActionColumns.TabIndex = 49;
            this.chkShowOnlyActionColumns.Text = "All User Action Columns";
            this.chkShowOnlyActionColumns.UseVisualStyleBackColor = true;
            this.chkShowOnlyActionColumns.CheckedChanged += new System.EventHandler(this.chkShowOnlyActionColumns_CheckedChanged);
            // 
            // cboCompany_Filter
            // 
            this.cboCompany_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompany_Filter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCompany_Filter.FormattingEnabled = true;
            this.cboCompany_Filter.Location = new System.Drawing.Point(65, 4);
            this.cboCompany_Filter.MaxDropDownItems = 15;
            this.cboCompany_Filter.Name = "cboCompany_Filter";
            this.cboCompany_Filter.Size = new System.Drawing.Size(66, 23);
            this.cboCompany_Filter.TabIndex = 48;
            this.cboCompany_Filter.SelectedIndexChanged += new System.EventHandler(this.cboCompany_Filter_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.5F);
            this.label1.Location = new System.Drawing.Point(1, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 47;
            this.label1.Text = "Company: ";
            // 
            // btnDMS
            // 
            this.btnDMS.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnDMS.Location = new System.Drawing.Point(803, 2);
            this.btnDMS.Name = "btnDMS";
            this.btnDMS.Size = new System.Drawing.Size(50, 26);
            this.btnDMS.TabIndex = 45;
            this.btnDMS.Text = "DMS";
            this.btnDMS.UseVisualStyleBackColor = true;
            this.btnDMS.Click += new System.EventHandler(this.btnDMS_Click);
            // 
            // lnkRefresh
            // 
            this.lnkRefresh.AutoSize = true;
            this.lnkRefresh.Font = new System.Drawing.Font("Arial", 8.5F);
            this.lnkRefresh.Location = new System.Drawing.Point(1108, 6);
            this.lnkRefresh.Name = "lnkRefresh";
            this.lnkRefresh.Size = new System.Drawing.Size(51, 15);
            this.lnkRefresh.TabIndex = 43;
            this.lnkRefresh.TabStop = true;
            this.lnkRefresh.Text = "Refresh";
            this.lnkRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRefresh_LinkClicked);
            // 
            // btnProcurement
            // 
            this.btnProcurement.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnProcurement.Location = new System.Drawing.Point(708, 2);
            this.btnProcurement.Name = "btnProcurement";
            this.btnProcurement.Size = new System.Drawing.Size(86, 26);
            this.btnProcurement.TabIndex = 42;
            this.btnProcurement.Text = "Procurement";
            this.btnProcurement.UseVisualStyleBackColor = true;
            this.btnProcurement.Click += new System.EventHandler(this.btnProcurement_Click);
            // 
            // cboVslFilter
            // 
            this.cboVslFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVslFilter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboVslFilter.FormattingEnabled = true;
            this.cboVslFilter.Location = new System.Drawing.Point(180, 4);
            this.cboVslFilter.MaxDropDownItems = 15;
            this.cboVslFilter.Name = "cboVslFilter";
            this.cboVslFilter.Size = new System.Drawing.Size(185, 23);
            this.cboVslFilter.TabIndex = 41;
            this.cboVslFilter.SelectedIndexChanged += new System.EventHandler(this.cboVslFilter_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.5F);
            this.label9.Location = new System.Drawing.Point(141, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 16);
            this.label9.TabIndex = 40;
            this.label9.Text = "Filter:";
            // 
            // btnExportXLParticulars
            // 
            this.btnExportXLParticulars.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportXLParticulars.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExportXLParticulars.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportXLParticulars.Image = ((System.Drawing.Image)(resources.GetObject("btnExportXLParticulars.Image")));
            this.btnExportXLParticulars.Location = new System.Drawing.Point(1238, 6);
            this.btnExportXLParticulars.Name = "btnExportXLParticulars";
            this.btnExportXLParticulars.Size = new System.Drawing.Size(13, 19);
            this.btnExportXLParticulars.TabIndex = 39;
            this.btnExportXLParticulars.Text = "Export";
            this.btnExportXLParticulars.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExportXLParticulars.UseVisualStyleBackColor = false;
            this.btnExportXLParticulars.Visible = false;
            // 
            // btnNcr
            // 
            this.btnNcr.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnNcr.Location = new System.Drawing.Point(982, 2);
            this.btnNcr.Name = "btnNcr";
            this.btnNcr.Size = new System.Drawing.Size(50, 26);
            this.btnNcr.TabIndex = 46;
            this.btnNcr.Text = "NCR";
            this.btnNcr.UseVisualStyleBackColor = true;
            this.btnNcr.Click += new System.EventHandler(this.btnNcr_Click);
            // 
            // btnSQEDashboard
            // 
            this.btnSQEDashboard.Font = new System.Drawing.Font("Arial", 8.5F);
            this.btnSQEDashboard.Location = new System.Drawing.Point(981, 2);
            this.btnSQEDashboard.Name = "btnSQEDashboard";
            this.btnSQEDashboard.Size = new System.Drawing.Size(117, 26);
            this.btnSQEDashboard.TabIndex = 44;
            this.btnSQEDashboard.Text = "SQE Dashboard";
            this.btnSQEDashboard.UseVisualStyleBackColor = true;
            this.btnSQEDashboard.Click += new System.EventHandler(this.btnSQEDashboard_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.progressBarRefresh);
            this.panel2.Controls.Add(this.statusStrip1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 569);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1268, 20);
            this.panel2.TabIndex = 5;
            // 
            // progressBarRefresh
            // 
            this.progressBarRefresh.Location = new System.Drawing.Point(827, 3);
            this.progressBarRefresh.Name = "progressBarRefresh";
            this.progressBarRefresh.Size = new System.Drawing.Size(242, 18);
            this.progressBarRefresh.TabIndex = 44;
            this.progressBarRefresh.Visible = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblSvrName,
            this.toolStripStatusLabel1,
            this.tsLblUserId,
            this.toolStripStatusLabel2,
            this.tlsStatuslblTotalVessels,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1268, 20);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblSvrName
            // 
            this.tsLblSvrName.Name = "tsLblSvrName";
            this.tsLblSvrName.Size = new System.Drawing.Size(107, 15);
            this.tsLblSvrName.Text = "Svr                            ";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(13, 15);
            this.toolStripStatusLabel1.Text = "  ";
            // 
            // tsLblUserId
            // 
            this.tsLblUserId.Name = "tsLblUserId";
            this.tsLblUserId.Size = new System.Drawing.Size(30, 15);
            this.tsLblUserId.Text = "User";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(313, 15);
            this.toolStripStatusLabel2.Text = "                                                                                 " +
    "                     ";
            // 
            // tlsStatuslblTotalVessels
            // 
            this.tlsStatuslblTotalVessels.ForeColor = System.Drawing.Color.Blue;
            this.tlsStatuslblTotalVessels.Name = "tlsStatuslblTotalVessels";
            this.tlsStatuslblTotalVessels.Size = new System.Drawing.Size(82, 15);
            this.tlsStatuslblTotalVessels.Text = "Total Vessel(s):";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(238, 15);
            this.toolStripStatusLabel3.Text = "                                                                             ";
            // 
            // cntxtMnuStrip_Fleet
            // 
            this.cntxtMnuStrip_Fleet.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.cntxtMnuStrip_Fleet.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuExportEquipmentParticulars,
            this.tsMnuExportEquipmentUnitParticulars,
            this.tsMnuExportPMSItems,
            this.tsMnupmsReports,
            this.tsMnuCriticalSparesList,
            this.toolStripSeparator9,
            this.tsMnuVslAppplication,
            this.toolStripSeparator13,
            this.tsmnSparesInventory,
            this.tsmnStoresInventory,
            this.toolStripSeparator17,
            this.tsmnSparesPurchase,
            this.tsmnuStoresPurchase,
            this.toolStripMenuItem1,
            this.tsMnuHQPMS,
            this.tsMnuDefects,
            this.tsMnuRepairsPurchase,
            this.tsMnuForms,
            this.tsMnuRiskAssements,
            this.tsMnuAuditInspection,
            this.tsMnuNCR,
            this.tsMnuTaskList,
            this.tsMnuIncidentReport,
            this.tsMnuAwarenessReport,
            this.tsMnuMastersReview,
            this.tsMnuMinutesOfSafety,
            this.tsMnuMonthEndDoc,
            this.tsMnuVslCertificate,
            this.tsMnuSplitterB4EquipmentManager,
            this.tsMnuEquipmentManager,
            this.toolStripMenuItem2,
            this.tsMnuKPITrending_Vsl,
            this.tsMnuDefectTrendingEquipmentWise_SingleVsl,
            this.toolStripSeparator5,
            this.tsMnuRefreshforSelectedVessel,
            this.toolStripSeparator_DTF,
            this.tsMnuDTFDataTransferToolStripMenuItem,
            this.tsMnuVslUserManagement});
            this.cntxtMnuStrip_Fleet.Name = "contextMenuStrip1";
            this.cntxtMnuStrip_Fleet.Size = new System.Drawing.Size(258, 712);
            // 
            // tsMnuExportEquipmentParticulars
            // 
            this.tsMnuExportEquipmentParticulars.Name = "tsMnuExportEquipmentParticulars";
            this.tsMnuExportEquipmentParticulars.Size = new System.Drawing.Size(257, 22);
            this.tsMnuExportEquipmentParticulars.Text = "Export Equipment Particulars";
            this.tsMnuExportEquipmentParticulars.Click += new System.EventHandler(this.tsMnuExportEquipmentParticulars_Click);
            // 
            // tsMnuExportEquipmentUnitParticulars
            // 
            this.tsMnuExportEquipmentUnitParticulars.Name = "tsMnuExportEquipmentUnitParticulars";
            this.tsMnuExportEquipmentUnitParticulars.Size = new System.Drawing.Size(257, 22);
            this.tsMnuExportEquipmentUnitParticulars.Text = "Export Equipment Unit Particulars";
            this.tsMnuExportEquipmentUnitParticulars.Click += new System.EventHandler(this.tsMnuExportEquipmentUnitParticulars_Click);
            // 
            // tsMnuExportPMSItems
            // 
            this.tsMnuExportPMSItems.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuWithoutCheckList,
            this.tsMnuPMSItemsWithCheckList});
            this.tsMnuExportPMSItems.Name = "tsMnuExportPMSItems";
            this.tsMnuExportPMSItems.Size = new System.Drawing.Size(257, 22);
            this.tsMnuExportPMSItems.Text = "Export PMS Items";
            this.tsMnuExportPMSItems.Visible = false;
            // 
            // tsMnuWithoutCheckList
            // 
            this.tsMnuWithoutCheckList.Name = "tsMnuWithoutCheckList";
            this.tsMnuWithoutCheckList.Size = new System.Drawing.Size(230, 22);
            this.tsMnuWithoutCheckList.Text = "PMS Items Without CheckList";
            this.tsMnuWithoutCheckList.Click += new System.EventHandler(this.tsMnuWithoutCheckList_Click);
            // 
            // tsMnuPMSItemsWithCheckList
            // 
            this.tsMnuPMSItemsWithCheckList.Name = "tsMnuPMSItemsWithCheckList";
            this.tsMnuPMSItemsWithCheckList.Size = new System.Drawing.Size(230, 22);
            this.tsMnuPMSItemsWithCheckList.Text = "PMS Items With CheckList";
            this.tsMnuPMSItemsWithCheckList.Click += new System.EventHandler(this.tsMnuPMSItemsWithCheckList_Click);
            // 
            // tsMnupmsReports
            // 
            this.tsMnupmsReports.Name = "tsMnupmsReports";
            this.tsMnupmsReports.Size = new System.Drawing.Size(257, 22);
            this.tsMnupmsReports.Text = "Export PMS Items";
            this.tsMnupmsReports.Click += new System.EventHandler(this.tsMnupmsReports_Click);
            // 
            // tsMnuCriticalSparesList
            // 
            this.tsMnuCriticalSparesList.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuAllCriticalSparesItems,
            this.tsMnuEquipmentWiseCriticalSparesItems});
            this.tsMnuCriticalSparesList.Name = "tsMnuCriticalSparesList";
            this.tsMnuCriticalSparesList.Size = new System.Drawing.Size(257, 22);
            this.tsMnuCriticalSparesList.Text = "Export Critical Spares";
            // 
            // tsMnuAllCriticalSparesItems
            // 
            this.tsMnuAllCriticalSparesItems.Name = "tsMnuAllCriticalSparesItems";
            this.tsMnuAllCriticalSparesItems.Size = new System.Drawing.Size(267, 22);
            this.tsMnuAllCriticalSparesItems.Text = "All Critical Spares Items";
            this.tsMnuAllCriticalSparesItems.Click += new System.EventHandler(this.tsMnuAllCriticalSparesItems_Click);
            // 
            // tsMnuEquipmentWiseCriticalSparesItems
            // 
            this.tsMnuEquipmentWiseCriticalSparesItems.Name = "tsMnuEquipmentWiseCriticalSparesItems";
            this.tsMnuEquipmentWiseCriticalSparesItems.Size = new System.Drawing.Size(267, 22);
            this.tsMnuEquipmentWiseCriticalSparesItems.Text = "Equipment wise Critical Spares Items";
            this.tsMnuEquipmentWiseCriticalSparesItems.Click += new System.EventHandler(this.tsMnuEquipmentWiseCriticalSparesItems_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(254, 6);
            // 
            // tsMnuVslAppplication
            // 
            this.tsMnuVslAppplication.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmu_VslDashBoard,
            this.toolStripSeparator3,
            this.tsm_VslSpares,
            this.toolStripSeparator4,
            this.tsm_VslStores,
            this.toolStripSeparator6,
            this.tsm_VslPMS,
            this.toolStripSeparator7,
            this.tsm_VslDefects,
            this.toolStripSeparator8,
            this.tsm_VslEngineData,
            this.toolStripSeparator10,
            this.tsm_VslNoonLog,
            this.tsMnuVslFormsSeparater,
            this.tsm_VslForms,
            this.toolStripSeparator16,
            this.tsm_CorrectiveMaintenance,
            this.toolStripMenuItem6,
            this.tsMnuDocumentManagement,
            this.toolStripMenuItem9,
            this.tsMnuVslAlerts_Circulars,
            this.toolStripMenuItem13,
            this.tsMnuVslRiskAssements});
            this.tsMnuVslAppplication.Name = "tsMnuVslAppplication";
            this.tsMnuVslAppplication.Size = new System.Drawing.Size(257, 22);
            this.tsMnuVslAppplication.Text = "Vsl Applications ( View Only )";
            // 
            // tsmu_VslDashBoard
            // 
            this.tsmu_VslDashBoard.Name = "tsmu_VslDashBoard";
            this.tsmu_VslDashBoard.Size = new System.Drawing.Size(204, 22);
            this.tsmu_VslDashBoard.Text = "Vsl Dashboard";
            this.tsmu_VslDashBoard.Click += new System.EventHandler(this.tsmu_VslDashBoard_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(201, 6);
            // 
            // tsm_VslSpares
            // 
            this.tsm_VslSpares.Name = "tsm_VslSpares";
            this.tsm_VslSpares.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslSpares.Text = "Spares";
            this.tsm_VslSpares.Click += new System.EventHandler(this.tsm_VslSpares_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(201, 6);
            // 
            // tsm_VslStores
            // 
            this.tsm_VslStores.Name = "tsm_VslStores";
            this.tsm_VslStores.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslStores.Text = "Stores";
            this.tsm_VslStores.Click += new System.EventHandler(this.tsm_VslStores_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(201, 6);
            // 
            // tsm_VslPMS
            // 
            this.tsm_VslPMS.Name = "tsm_VslPMS";
            this.tsm_VslPMS.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslPMS.Text = "PMS";
            this.tsm_VslPMS.Click += new System.EventHandler(this.tsm_VslPMS_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(201, 6);
            // 
            // tsm_VslDefects
            // 
            this.tsm_VslDefects.Name = "tsm_VslDefects";
            this.tsm_VslDefects.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslDefects.Text = "Defects";
            this.tsm_VslDefects.Visible = false;
            this.tsm_VslDefects.Click += new System.EventHandler(this.tsm_VslDefects_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(201, 6);
            this.toolStripSeparator8.Visible = false;
            // 
            // tsm_VslEngineData
            // 
            this.tsm_VslEngineData.Name = "tsm_VslEngineData";
            this.tsm_VslEngineData.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslEngineData.Text = "Engine Data";
            this.tsm_VslEngineData.Visible = false;
            this.tsm_VslEngineData.Click += new System.EventHandler(this.tsm_VslEngineData_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(201, 6);
            this.toolStripSeparator10.Visible = false;
            // 
            // tsm_VslNoonLog
            // 
            this.tsm_VslNoonLog.Name = "tsm_VslNoonLog";
            this.tsm_VslNoonLog.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslNoonLog.Text = "Noon Log";
            this.tsm_VslNoonLog.Visible = false;
            this.tsm_VslNoonLog.Click += new System.EventHandler(this.tsm_VslNoonLog_Click);
            // 
            // tsMnuVslFormsSeparater
            // 
            this.tsMnuVslFormsSeparater.Name = "tsMnuVslFormsSeparater";
            this.tsMnuVslFormsSeparater.Size = new System.Drawing.Size(201, 6);
            // 
            // tsm_VslForms
            // 
            this.tsm_VslForms.Name = "tsm_VslForms";
            this.tsm_VslForms.Size = new System.Drawing.Size(204, 22);
            this.tsm_VslForms.Text = "Vsl Forms";
            this.tsm_VslForms.Click += new System.EventHandler(this.tsm_VslForms_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(201, 6);
            // 
            // tsm_CorrectiveMaintenance
            // 
            this.tsm_CorrectiveMaintenance.Name = "tsm_CorrectiveMaintenance";
            this.tsm_CorrectiveMaintenance.Size = new System.Drawing.Size(204, 22);
            this.tsm_CorrectiveMaintenance.Text = "Corrective Maintenance";
            this.tsm_CorrectiveMaintenance.Click += new System.EventHandler(this.tsm_CorrectiveMaintenance_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(201, 6);
            // 
            // tsMnuDocumentManagement
            // 
            this.tsMnuDocumentManagement.Name = "tsMnuDocumentManagement";
            this.tsMnuDocumentManagement.Size = new System.Drawing.Size(204, 22);
            this.tsMnuDocumentManagement.Text = "Document Management";
            this.tsMnuDocumentManagement.Click += new System.EventHandler(this.tsMnuDocumentManagement_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(201, 6);
            // 
            // tsMnuVslAlerts_Circulars
            // 
            this.tsMnuVslAlerts_Circulars.Name = "tsMnuVslAlerts_Circulars";
            this.tsMnuVslAlerts_Circulars.Size = new System.Drawing.Size(204, 22);
            this.tsMnuVslAlerts_Circulars.Text = "Alerts / Circulars";
            this.tsMnuVslAlerts_Circulars.Click += new System.EventHandler(this.tsMnuVslAlerts_Circulars_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(201, 6);
            // 
            // tsMnuVslRiskAssements
            // 
            this.tsMnuVslRiskAssements.Name = "tsMnuVslRiskAssements";
            this.tsMnuVslRiskAssements.Size = new System.Drawing.Size(204, 22);
            this.tsMnuVslRiskAssements.Text = "Risk Assessments";
            this.tsMnuVslRiskAssements.Click += new System.EventHandler(this.tsMnuVslRiskAssements_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(254, 6);
            // 
            // tsmnSparesInventory
            // 
            this.tsmnSparesInventory.Name = "tsmnSparesInventory";
            this.tsmnSparesInventory.Size = new System.Drawing.Size(257, 22);
            this.tsmnSparesInventory.Text = "Spares - Inventory";
            this.tsmnSparesInventory.Click += new System.EventHandler(this.tsmnSparesInventory_Click);
            // 
            // tsmnStoresInventory
            // 
            this.tsmnStoresInventory.Name = "tsmnStoresInventory";
            this.tsmnStoresInventory.Size = new System.Drawing.Size(257, 22);
            this.tsmnStoresInventory.Text = "Stores - Inventory";
            this.tsmnStoresInventory.Click += new System.EventHandler(this.tsmnStoresInventory_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(254, 6);
            // 
            // tsmnSparesPurchase
            // 
            this.tsmnSparesPurchase.Name = "tsmnSparesPurchase";
            this.tsmnSparesPurchase.Size = new System.Drawing.Size(257, 22);
            this.tsmnSparesPurchase.Text = "HQ Spares - Purchase";
            this.tsmnSparesPurchase.Click += new System.EventHandler(this.tsmnSparesPurchase_Click);
            // 
            // tsmnuStoresPurchase
            // 
            this.tsmnuStoresPurchase.Name = "tsmnuStoresPurchase";
            this.tsmnuStoresPurchase.Size = new System.Drawing.Size(257, 22);
            this.tsmnuStoresPurchase.Text = "HQ Stores - Purchase";
            this.tsmnuStoresPurchase.Click += new System.EventHandler(this.tsmnuStoresPurchase_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(254, 6);
            // 
            // tsMnuHQPMS
            // 
            this.tsMnuHQPMS.Name = "tsMnuHQPMS";
            this.tsMnuHQPMS.Size = new System.Drawing.Size(257, 22);
            this.tsMnuHQPMS.Text = "PMS";
            this.tsMnuHQPMS.Click += new System.EventHandler(this.tsMnuHQPMS_Click);
            // 
            // tsMnuDefects
            // 
            this.tsMnuDefects.Name = "tsMnuDefects";
            this.tsMnuDefects.Size = new System.Drawing.Size(257, 22);
            this.tsMnuDefects.Text = "Defects";
            this.tsMnuDefects.Click += new System.EventHandler(this.tsMnuDefects_Click);
            // 
            // tsMnuRepairsPurchase
            // 
            this.tsMnuRepairsPurchase.Name = "tsMnuRepairsPurchase";
            this.tsMnuRepairsPurchase.Size = new System.Drawing.Size(257, 22);
            this.tsMnuRepairsPurchase.Text = "Repairs and Services";
            this.tsMnuRepairsPurchase.Click += new System.EventHandler(this.tsMnuRepairsPurchase_Click);
            // 
            // tsMnuForms
            // 
            this.tsMnuForms.Name = "tsMnuForms";
            this.tsMnuForms.Size = new System.Drawing.Size(257, 22);
            this.tsMnuForms.Text = "Forms";
            this.tsMnuForms.Click += new System.EventHandler(this.tsMnuForms_Click);
            // 
            // tsMnuRiskAssements
            // 
            this.tsMnuRiskAssements.Name = "tsMnuRiskAssements";
            this.tsMnuRiskAssements.Size = new System.Drawing.Size(257, 22);
            this.tsMnuRiskAssements.Text = "Risk Assessments";
            this.tsMnuRiskAssements.Click += new System.EventHandler(this.tsMnuRiskAssements_Click);
            // 
            // tsMnuAuditInspection
            // 
            this.tsMnuAuditInspection.Name = "tsMnuAuditInspection";
            this.tsMnuAuditInspection.Size = new System.Drawing.Size(257, 22);
            this.tsMnuAuditInspection.Text = "Audit / Inspection";
            this.tsMnuAuditInspection.Click += new System.EventHandler(this.tsMnuAuditInspection_Click);
            // 
            // tsMnuNCR
            // 
            this.tsMnuNCR.Name = "tsMnuNCR";
            this.tsMnuNCR.Size = new System.Drawing.Size(257, 22);
            this.tsMnuNCR.Text = "NCR";
            this.tsMnuNCR.Click += new System.EventHandler(this.tsMnuNCR_Click);
            // 
            // tsMnuTaskList
            // 
            this.tsMnuTaskList.Name = "tsMnuTaskList";
            this.tsMnuTaskList.Size = new System.Drawing.Size(257, 22);
            this.tsMnuTaskList.Text = "Task List";
            this.tsMnuTaskList.Click += new System.EventHandler(this.tsMnuTaskList_Click);
            // 
            // tsMnuIncidentReport
            // 
            this.tsMnuIncidentReport.Name = "tsMnuIncidentReport";
            this.tsMnuIncidentReport.Size = new System.Drawing.Size(257, 22);
            this.tsMnuIncidentReport.Text = "Incident / Investigation Report";
            this.tsMnuIncidentReport.Click += new System.EventHandler(this.tsMnuIncidentReport_Click);
            // 
            // tsMnuAwarenessReport
            // 
            this.tsMnuAwarenessReport.Name = "tsMnuAwarenessReport";
            this.tsMnuAwarenessReport.Size = new System.Drawing.Size(257, 22);
            this.tsMnuAwarenessReport.Text = "Awareness Report";
            this.tsMnuAwarenessReport.Click += new System.EventHandler(this.tsMnuAwarenessReport_Click);
            // 
            // tsMnuMastersReview
            // 
            this.tsMnuMastersReview.Name = "tsMnuMastersReview";
            this.tsMnuMastersReview.Size = new System.Drawing.Size(257, 22);
            this.tsMnuMastersReview.Text = "Master\'s Review";
            this.tsMnuMastersReview.Click += new System.EventHandler(this.tsMnuMastersReview_Click);
            // 
            // tsMnuMinutesOfSafety
            // 
            this.tsMnuMinutesOfSafety.Name = "tsMnuMinutesOfSafety";
            this.tsMnuMinutesOfSafety.Size = new System.Drawing.Size(257, 22);
            this.tsMnuMinutesOfSafety.Text = "Safety Committee Meeting";
            this.tsMnuMinutesOfSafety.Click += new System.EventHandler(this.tsMnuMinutesOfSafety_Click);
            // 
            // tsMnuMonthEndDoc
            // 
            this.tsMnuMonthEndDoc.Name = "tsMnuMonthEndDoc";
            this.tsMnuMonthEndDoc.Size = new System.Drawing.Size(257, 22);
            this.tsMnuMonthEndDoc.Text = "Month End Document";
            this.tsMnuMonthEndDoc.Click += new System.EventHandler(this.tsMnuMonthEndDoc_Click);
            // 
            // tsMnuVslCertificate
            // 
            this.tsMnuVslCertificate.Name = "tsMnuVslCertificate";
            this.tsMnuVslCertificate.Size = new System.Drawing.Size(257, 22);
            this.tsMnuVslCertificate.Text = "Vsl Certificates";
            this.tsMnuVslCertificate.Click += new System.EventHandler(this.tsMnuVslCertificate_Click);
            // 
            // tsMnuSplitterB4EquipmentManager
            // 
            this.tsMnuSplitterB4EquipmentManager.Name = "tsMnuSplitterB4EquipmentManager";
            this.tsMnuSplitterB4EquipmentManager.Size = new System.Drawing.Size(254, 6);
            // 
            // tsMnuEquipmentManager
            // 
            this.tsMnuEquipmentManager.Name = "tsMnuEquipmentManager";
            this.tsMnuEquipmentManager.Size = new System.Drawing.Size(257, 22);
            this.tsMnuEquipmentManager.Text = "Equipment Manager";
            this.tsMnuEquipmentManager.Click += new System.EventHandler(this.tsMnuEquipmentManager_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(254, 6);
            // 
            // tsMnuKPITrending_Vsl
            // 
            this.tsMnuKPITrending_Vsl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuKPITrendingForVsl_NonCriticalMaint,
            this.tsMnuKPITrendingForVsl_CriticalMaint,
            this.tsMnuKPITrendingForVsl_CriticalEqp,
            this.tsMnuKPITrendingForVsl_NonCriticalEqp,
            this.toolStripSeparator18,
            this.tsMnukPITrendingForVsl_All});
            this.tsMnuKPITrending_Vsl.Name = "tsMnuKPITrending_Vsl";
            this.tsMnuKPITrending_Vsl.Size = new System.Drawing.Size(257, 22);
            this.tsMnuKPITrending_Vsl.Text = "KPI Trending of Outstanding Maint";
            // 
            // tsMnuKPITrendingForVsl_NonCriticalMaint
            // 
            this.tsMnuKPITrendingForVsl_NonCriticalMaint.Name = "tsMnuKPITrendingForVsl_NonCriticalMaint";
            this.tsMnuKPITrendingForVsl_NonCriticalMaint.Size = new System.Drawing.Size(441, 22);
            this.tsMnuKPITrendingForVsl_NonCriticalMaint.Text = "KPI Trending of Outstanding Maint (Critical Maintenance excluded)";
            this.tsMnuKPITrendingForVsl_NonCriticalMaint.Click += new System.EventHandler(this.tsMnuKPITrendingForVsl_NonCriticalMaint_Click);
            // 
            // tsMnuKPITrendingForVsl_CriticalMaint
            // 
            this.tsMnuKPITrendingForVsl_CriticalMaint.Name = "tsMnuKPITrendingForVsl_CriticalMaint";
            this.tsMnuKPITrendingForVsl_CriticalMaint.Size = new System.Drawing.Size(441, 22);
            this.tsMnuKPITrendingForVsl_CriticalMaint.Text = "KPI Trending of Outstanding Maint (Critical Maintenance)";
            this.tsMnuKPITrendingForVsl_CriticalMaint.Click += new System.EventHandler(this.tsMnuKPITrendingForVsl_CriticalMaint_Click);
            // 
            // tsMnuKPITrendingForVsl_CriticalEqp
            // 
            this.tsMnuKPITrendingForVsl_CriticalEqp.Name = "tsMnuKPITrendingForVsl_CriticalEqp";
            this.tsMnuKPITrendingForVsl_CriticalEqp.Size = new System.Drawing.Size(441, 22);
            this.tsMnuKPITrendingForVsl_CriticalEqp.Text = "KPI Trending of Outstanding Maint (Critical Eqpmt Maintenance)";
            this.tsMnuKPITrendingForVsl_CriticalEqp.Click += new System.EventHandler(this.tsMnuKPITrendingForVsl_CriticalEqp_Click);
            // 
            // tsMnuKPITrendingForVsl_NonCriticalEqp
            // 
            this.tsMnuKPITrendingForVsl_NonCriticalEqp.Name = "tsMnuKPITrendingForVsl_NonCriticalEqp";
            this.tsMnuKPITrendingForVsl_NonCriticalEqp.Size = new System.Drawing.Size(441, 22);
            this.tsMnuKPITrendingForVsl_NonCriticalEqp.Text = "KPI Trending of Outstanding Maint (Non Critical Eqpmt Maintenance)";
            this.tsMnuKPITrendingForVsl_NonCriticalEqp.Click += new System.EventHandler(this.tsMnuKPITrendingForVsl_NonCriticalEqp_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(438, 6);
            // 
            // tsMnukPITrendingForVsl_All
            // 
            this.tsMnukPITrendingForVsl_All.Name = "tsMnukPITrendingForVsl_All";
            this.tsMnukPITrendingForVsl_All.Size = new System.Drawing.Size(441, 22);
            this.tsMnukPITrendingForVsl_All.Text = "KPI Trending of Outstanding Maint - All";
            this.tsMnukPITrendingForVsl_All.Click += new System.EventHandler(this.tsMnukPITrendingForVsl_All_Click);
            // 
            // tsMnuDefectTrendingEquipmentWise_SingleVsl
            // 
            this.tsMnuDefectTrendingEquipmentWise_SingleVsl.Name = "tsMnuDefectTrendingEquipmentWise_SingleVsl";
            this.tsMnuDefectTrendingEquipmentWise_SingleVsl.Size = new System.Drawing.Size(257, 22);
            this.tsMnuDefectTrendingEquipmentWise_SingleVsl.Text = "Defect Trending - Equipment wise";
            this.tsMnuDefectTrendingEquipmentWise_SingleVsl.Click += new System.EventHandler(this.tsMnuDefectTrendingEquipmentWise_SingleVsl_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(254, 6);
            // 
            // tsMnuRefreshforSelectedVessel
            // 
            this.tsMnuRefreshforSelectedVessel.Name = "tsMnuRefreshforSelectedVessel";
            this.tsMnuRefreshforSelectedVessel.Size = new System.Drawing.Size(257, 22);
            this.tsMnuRefreshforSelectedVessel.Text = "Refresh for Selected Vessel";
            this.tsMnuRefreshforSelectedVessel.Click += new System.EventHandler(this.tsMnuRefreshforSelectedVessel_Click);
            // 
            // toolStripSeparator_DTF
            // 
            this.toolStripSeparator_DTF.Name = "toolStripSeparator_DTF";
            this.toolStripSeparator_DTF.Size = new System.Drawing.Size(254, 6);
            // 
            // tsMnuDTFDataTransferToolStripMenuItem
            // 
            this.tsMnuDTFDataTransferToolStripMenuItem.Name = "tsMnuDTFDataTransferToolStripMenuItem";
            this.tsMnuDTFDataTransferToolStripMenuItem.Size = new System.Drawing.Size(257, 22);
            this.tsMnuDTFDataTransferToolStripMenuItem.Text = "DTF (Data Sync)";
            this.tsMnuDTFDataTransferToolStripMenuItem.Click += new System.EventHandler(this.tsMnuDTFDataTransferToolStripMenuItem_Click);
            // 
            // tsMnuVslUserManagement
            // 
            this.tsMnuVslUserManagement.Name = "tsMnuVslUserManagement";
            this.tsMnuVslUserManagement.Size = new System.Drawing.Size(257, 22);
            this.tsMnuVslUserManagement.Text = "Vsl User Management";
            this.tsMnuVslUserManagement.Click += new System.EventHandler(this.tsMnuVslUserManagement_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tsMnuEquipmentSparesList
            // 
            this.tsMnuEquipmentSparesList.Name = "tsMnuEquipmentSparesList";
            this.tsMnuEquipmentSparesList.Size = new System.Drawing.Size(235, 22);
            this.tsMnuEquipmentSparesList.Text = "All Equipment Spares List";
            this.tsMnuEquipmentSparesList.Click += new System.EventHandler(this.tsMnuEquipmentSparesList_Click);
            // 
            // tsMnuSetupProcurementInterface
            // 
            this.tsMnuSetupProcurementInterface.Name = "tsMnuSetupProcurementInterface";
            this.tsMnuSetupProcurementInterface.Size = new System.Drawing.Size(255, 22);
            this.tsMnuSetupProcurementInterface.Text = "Setup Procurement Interface";
            this.tsMnuSetupProcurementInterface.Click += new System.EventHandler(this.tsMnuSetupProcurementInterface_Click);
            // 
            // frmMainForm_Tech
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 589);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmMainForm_Tech";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMainForm_FormClosing);
            this.Load += new System.EventHandler(this.frmMainForm_Tech_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage_Fleet.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelLoading.ResumeLayout(false);
            this.panelLoading.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Particulars_Sheet1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.cntxtMnuStrip_Fleet.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsMnuCurrenctXRate;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripMenuItem administrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsMnuManageUserAndVsls;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSetup_StoresItemMaster;
        private System.Windows.Forms.ToolStripMenuItem templatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsMnuUserGuide;
        private System.Windows.Forms.ContextMenuStrip cntxtMnuStrip_Fleet;
        private System.Windows.Forms.ToolStripMenuItem tsmnSparesPurchase;
        private System.Windows.Forms.ToolStripMenuItem tsmnuStoresPurchase;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_Fleet;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private FarPoint.Win.Spread.FpSpread fpSpread_Particulars;
        private FarPoint.Win.Spread.SheetView fpSpread_Particulars_Sheet1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cboVslFilter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnExportXLParticulars;
        private System.Windows.Forms.Button btnProcurement;
        private System.Windows.Forms.ToolStripMenuItem tsMnuEquipmentManager;
        private System.Windows.Forms.ToolStripSeparator tsMnuSplitterB4EquipmentManager;
        private System.Windows.Forms.ToolStripMenuItem tsMnuExportParticulars;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuRepairsPurchase;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDelivLocationsManagement;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem tsMnuCurrencyManagement;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAll_HQ_VSLSettings;
        private System.Windows.Forms.LinkLabel lnkRefresh;
        private System.Windows.Forms.ToolStripMenuItem tsMnuLegalEntity;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripMenuItem tsMnuClients;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ProgressBar progressBarRefresh;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblSvrName;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblUserId;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel tlsStatuslblTotalVessels;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tsMnuCriticalSparesList;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslAppplication;
        private System.Windows.Forms.ToolStripMenuItem tsmu_VslDashBoard;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslSpares;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslStores;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslPMS;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslDefects;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslEngineData;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslNoonLog;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAllCriticalSparesItems;
        private System.Windows.Forms.ToolStripMenuItem tsMnuEquipmentWiseCriticalSparesItems;
        private System.Windows.Forms.ToolStripMenuItem tsMnuEquipmentSparesList;
        private System.Windows.Forms.ToolStripMenuItem tsMnuExportEquipmentParticulars;
        private System.Windows.Forms.ToolStripMenuItem tsMnuExportPMSItems;
        private System.Windows.Forms.ToolStripMenuItem tsMnuExportEquipmentUnitParticulars;
        private System.Windows.Forms.ToolStripMenuItem tsMnuWithoutCheckList;
        private System.Windows.Forms.ToolStripMenuItem tsMnuPMSItemsWithCheckList;
        private System.Windows.Forms.ToolStripMenuItem tsMnupmsReports;
        private System.Windows.Forms.Panel panelLoading;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ToolStripMenuItem tsmnSparesInventory;
        private System.Windows.Forms.ToolStripMenuItem tsmnStoresInventory;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripMenuItem tsm_VslForms;
        private System.Windows.Forms.ToolStripSeparator tsMnuVslFormsSeparater;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDefectTrendingEquipmentWise_SingleVsl;
        private System.Windows.Forms.ToolStripMenuItem tsMnuUOMList;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem tsMnuRefreshforSelectedVessel;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDTF;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDTFCurrentStatus;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDTFHistory;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDTFTrending;
        private System.Windows.Forms.ToolStripMenuItem tsm_CorrectiveMaintenance;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator_DTF;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDTFDataTransferToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDefects;
        private System.Windows.Forms.ToolStripMenuItem tsMnuForms;
        private System.Windows.Forms.ToolStripSeparator tsMnuSeparator5;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAgressoReinterface;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVendorLinks;
        private System.Windows.Forms.ToolStripMenuItem tsMnuHQPMS;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForFleet;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForFleet_NonCriticalMaint;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForFleet_CriticalEqp;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tsMnukPITrendingForFleet_All;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForFleet_CriticalMaint;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForFleet_NonCriticalEqp;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrending_Vsl;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForVsl_NonCriticalMaint;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForVsl_CriticalMaint;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForVsl_CriticalEqp;
        private System.Windows.Forms.ToolStripMenuItem tsMnuKPITrendingForVsl_NonCriticalEqp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripMenuItem tsMnukPITrendingForVsl_All;
        private System.Windows.Forms.ToolStripMenuItem tsMnuProcurement;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSparesPOsNotSubmitForRFQMoreThan3Days;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSparesPOsPurchaserNotSubmitedForSuptApprovalMoreThan7WorkingDays;
        private System.Windows.Forms.Button btnSQEDashboard;
        private System.Windows.Forms.ToolStripMenuItem tsMnuHoliDaysManagement;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDefectsReports;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDefectTrending_AllVsls;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDefectsVestsMnuDelAvailabilityKPI;
        private System.Windows.Forms.ToolStripMenuItem tsMnuFormsVesselSelection;
        private System.Windows.Forms.ToolStripSeparator tlsStripFormsVesselSelection;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem tsMnuDocumentManagement;
        private System.Windows.Forms.Button btnDMS;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem tsMnuClearCefCache;
        private System.Windows.Forms.ToolStripMenuItem tsMnuNCRTrending;
        private System.Windows.Forms.Button btnNcr;
        private System.Windows.Forms.ToolStripMenuItem tsMnuRiskAssements;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslRiskAssements;
        private System.Windows.Forms.ComboBox cboCompany_Filter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAuditInspection;
        private System.Windows.Forms.ToolStripMenuItem tsMnuTaskList;
        private System.Windows.Forms.ToolStripMenuItem tlsMnuRootCauseAnalysisChartSetup;
        private System.Windows.Forms.ToolStripMenuItem tlsMnuAuditInspectionSetup;
        private System.Windows.Forms.ToolStripMenuItem tsMnuNCR;
        private System.Windows.Forms.CheckBox chkShowOnlyActionColumns;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAwarenessReport;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMastersReview;
        private System.Windows.Forms.ToolStripMenuItem tsMnuIncidentReport;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMinutesOfSafety;
        private System.Windows.Forms.ToolStripMenuItem tsMnuUserSignManagement;
        private System.Windows.Forms.ToolStripMenuItem tsMnuUserAppRestrictions;
        private System.Windows.Forms.Button btnCrewDashboard;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslUserManagement;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMonthEndDoc;
        private System.Windows.Forms.ToolStripMenuItem tsMnuFormsDesigner;

        private System.Windows.Forms.ToolStripMenuItem tsMnuVslCertificate;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSettingManagement;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMonthEndDocumentReport;
        private System.Windows.Forms.CheckBox chkShowMyApproveColumn;
        private System.Windows.Forms.ToolStripMenuItem tsMnuManualSync_BigBlobs;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem tsMnuHQCirculars;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslAlerts_Circulars;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslCrewAddNewController;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripMenuItem tsMnuAbout;
        private System.Windows.Forms.ToolStripMenuItem tsMnuApplicationChangeDetails;
        private System.Windows.Forms.ToolStripMenuItem tsMnuQuarterlyStoresReports;
        private System.Windows.Forms.ToolStripMenuItem tsMnuUpdateDMSCompany;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVesselOperationModeSetup;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSetupProcurementInterface;
    }
}