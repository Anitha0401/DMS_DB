﻿using System;
using System.Windows.Forms;


namespace HqSDS_Main
{
    public partial class frmPMSReports : Form
    {
        public string vslName = "", groupType = "", calledMode = "";
        public int vesselID = -1;

        public frmPMSReports()
        {
            InitializeComponent();
        }

        private void frmPMSReports_Load(object sender, EventArgs e)
        {

        }

        private void btnExport_Click(object sender, EventArgs e)
        {           
            frmExportEquipmentList exportEqp = new frmExportEquipmentList();
            try
            {
                exportEqp.groupType = groupType.ToUpper();
                exportEqp.calledMode = calledMode.ToUpper();
                exportEqp.vesselID = vesselID;
                exportEqp.isWithCheckList = chkWithMaintCheckList.Checked;
                exportEqp.isWithMaintProcdure = chkWithMaintProcdure.Checked;
                exportEqp.vslName = vslName.ToString();
                exportEqp.btnSaveToXL_Click(null, null);
            }
            finally
            {
                exportEqp = null;
            }
        }
    }
}
