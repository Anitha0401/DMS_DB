﻿namespace HqSDS_Main
{
    partial class frmMaintInput_CheckList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer enhancedColumnHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer enhancedColumnHeaderRenderer2 = new FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer enhancedRowHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer();
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer5 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("ColumnHeaderEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("ColumnFooterEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle3 = new FarPoint.Win.Spread.NamedStyle("RowHeaderEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle4 = new FarPoint.Win.Spread.NamedStyle("CornerEnhanced");
            FarPoint.Win.Spread.CellType.EnhancedCornerRenderer enhancedCornerRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedCornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle5 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer6 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaintInput_CheckList));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.fpSpreadAssociatedForms = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadAssociatedForms_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblManhrs = new System.Windows.Forms.Label();
            this.lblInterval = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblManhrs1 = new System.Windows.Forms.Label();
            this.lblMaintDate = new System.Windows.Forms.Label();
            this.lblMaintType = new System.Windows.Forms.Label();
            this.lblPlace = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblPlace1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.fpSpread_MaintInstructions = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_MaintInstructions_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnPmsReportLog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_EqpName = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lbl_Maintenance = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblCompletion = new System.Windows.Forms.Label();
            this.lblCondition = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chkCarrriedOut = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkMaintDoneAsPerInstructions = new System.Windows.Forms.CheckBox();
            this.lblMemo1 = new System.Windows.Forms.Label();
            this.lnkViewMaintDetails = new System.Windows.Forms.LinkLabel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lnkViewHistAttach = new System.Windows.Forms.LinkLabel();
            this.lblAttachmentFileName = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lblComments = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_MaintInstructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_MaintInstructions_Sheet1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            enhancedColumnHeaderRenderer1.Name = "enhancedColumnHeaderRenderer1";
            enhancedColumnHeaderRenderer1.TextRotationAngle = 0D;
            enhancedColumnHeaderRenderer2.Name = "enhancedColumnHeaderRenderer2";
            enhancedColumnHeaderRenderer2.TextRotationAngle = 0D;
            enhancedRowHeaderRenderer1.Name = "enhancedRowHeaderRenderer1";
            enhancedRowHeaderRenderer1.TextRotationAngle = 0D;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel8, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel13, 0, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(804, 579);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.tableLayoutPanel3);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(1, 294);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(802, 111);
            this.panel8.TabIndex = 17;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.22078F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.77922F));
            this.tableLayoutPanel3.Controls.Add(this.panel9, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel10, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel11, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel12, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(802, 111);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label8);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(474, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(328, 20);
            this.panel9.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(3, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Associated Forms";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.fpSpread1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 20);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(474, 91);
            this.panel10.TabIndex = 18;
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.HorizontalScrollBar.Name = "";
            this.fpSpread1.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread1.HorizontalScrollBar.TabIndex = 4;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(474, 91);
            this.fpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread1.TabIndex = 7;
            this.fpSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.VerticalScrollBar.Name = "";
            this.fpSpread1.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread1.VerticalScrollBar.TabIndex = 3;
            this.fpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off;
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 5;
            this.fpSpread1_Sheet1.RowCount = 5;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.fpSpreadAssociatedForms);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(474, 20);
            this.panel11.Margin = new System.Windows.Forms.Padding(0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(328, 91);
            this.panel11.TabIndex = 17;
            // 
            // fpSpreadAssociatedForms
            // 
            this.fpSpreadAssociatedForms.AccessibleDescription = "fpSpreadAssociatedForms, Sheet1, Row 0, Column 0, ";
            this.fpSpreadAssociatedForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadAssociatedForms.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadAssociatedForms.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.fpSpreadAssociatedForms.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadAssociatedForms.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadAssociatedForms.Name = "fpSpreadAssociatedForms";
            this.fpSpreadAssociatedForms.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadAssociatedForms_Sheet1});
            this.fpSpreadAssociatedForms.Size = new System.Drawing.Size(328, 91);
            this.fpSpreadAssociatedForms.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadAssociatedForms.TabIndex = 12;
            this.fpSpreadAssociatedForms.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.VerticalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.VerticalScrollBar.Renderer = defaultScrollBarRenderer4;
            this.fpSpreadAssociatedForms.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadAssociatedForms.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.VisualStyles = FarPoint.Win.VisualStyles.On;
            this.fpSpreadAssociatedForms.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpreadAssociatedForms_HyperLinkClicked);
            this.fpSpreadAssociatedForms.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpreadAssociatedForms_Error);
            // 
            // fpSpreadAssociatedForms_Sheet1
            // 
            this.fpSpreadAssociatedForms_Sheet1.Reset();
            this.fpSpreadAssociatedForms_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadAssociatedForms_Sheet1.ColumnCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.RowCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadAssociatedForms_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.Visible = false;
            this.fpSpreadAssociatedForms_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadAssociatedForms_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label9);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Margin = new System.Windows.Forms.Padding(0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(474, 20);
            this.panel12.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(3, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Spare parts consumed";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtComments);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(1, 484);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(802, 94);
            this.panel1.TabIndex = 4;
            // 
            // txtComments
            // 
            this.txtComments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtComments.Location = new System.Drawing.Point(0, 0);
            this.txtComments.MaxLength = 510;
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComments.Size = new System.Drawing.Size(802, 94);
            this.txtComments.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lblManhrs);
            this.panel4.Controls.Add(this.lblInterval);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.lblManhrs1);
            this.panel4.Controls.Add(this.lblMaintDate);
            this.panel4.Controls.Add(this.lblMaintType);
            this.panel4.Controls.Add(this.lblPlace);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.lblDate);
            this.panel4.Controls.Add(this.lblPlace1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(1, 79);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(802, 46);
            this.panel4.TabIndex = 3;
            // 
            // lblManhrs
            // 
            this.lblManhrs.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblManhrs.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManhrs.ForeColor = System.Drawing.Color.Black;
            this.lblManhrs.Location = new System.Drawing.Point(560, 21);
            this.lblManhrs.Name = "lblManhrs";
            this.lblManhrs.Size = new System.Drawing.Size(77, 19);
            this.lblManhrs.TabIndex = 86;
            this.lblManhrs.Text = "....";
            // 
            // lblInterval
            // 
            this.lblInterval.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblInterval.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInterval.ForeColor = System.Drawing.Color.Black;
            this.lblInterval.Location = new System.Drawing.Point(643, 21);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(124, 19);
            this.lblInterval.TabIndex = 85;
            this.lblInterval.Text = "....";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(640, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 83;
            this.label10.Text = "Interval";
            // 
            // lblManhrs1
            // 
            this.lblManhrs1.AutoSize = true;
            this.lblManhrs1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManhrs1.Location = new System.Drawing.Point(560, 5);
            this.lblManhrs1.Name = "lblManhrs1";
            this.lblManhrs1.Size = new System.Drawing.Size(53, 13);
            this.lblManhrs1.TabIndex = 84;
            this.lblManhrs1.Text = "Man Hrs";
            // 
            // lblMaintDate
            // 
            this.lblMaintDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMaintDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintDate.ForeColor = System.Drawing.Color.Black;
            this.lblMaintDate.Location = new System.Drawing.Point(6, 21);
            this.lblMaintDate.Name = "lblMaintDate";
            this.lblMaintDate.Size = new System.Drawing.Size(152, 19);
            this.lblMaintDate.TabIndex = 82;
            this.lblMaintDate.Text = "....";
            // 
            // lblMaintType
            // 
            this.lblMaintType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMaintType.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintType.ForeColor = System.Drawing.Color.Black;
            this.lblMaintType.Location = new System.Drawing.Point(359, 21);
            this.lblMaintType.Name = "lblMaintType";
            this.lblMaintType.Size = new System.Drawing.Size(192, 19);
            this.lblMaintType.TabIndex = 81;
            this.lblMaintType.Text = "....";
            // 
            // lblPlace
            // 
            this.lblPlace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPlace.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlace.ForeColor = System.Drawing.Color.Black;
            this.lblPlace.Location = new System.Drawing.Point(166, 21);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(185, 19);
            this.lblPlace.TabIndex = 80;
            this.lblPlace.Text = "....";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(357, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Maint Type";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(5, 5);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(34, 13);
            this.lblDate.TabIndex = 5;
            this.lblDate.Text = "Date";
            // 
            // lblPlace1
            // 
            this.lblPlace1.AutoSize = true;
            this.lblPlace1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlace1.Location = new System.Drawing.Point(165, 5);
            this.lblPlace1.Name = "lblPlace1";
            this.lblPlace1.Size = new System.Drawing.Size(37, 13);
            this.lblPlace1.TabIndex = 6;
            this.lblPlace1.Text = "Place";
            this.lblPlace1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fpSpread_MaintInstructions);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 171);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(796, 119);
            this.panel3.TabIndex = 2;
            // 
            // fpSpread_MaintInstructions
            // 
            this.fpSpread_MaintInstructions.AccessibleDescription = "";
            this.fpSpread_MaintInstructions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_MaintInstructions.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_MaintInstructions.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_MaintInstructions.HorizontalScrollBar.Name = "";
            this.fpSpread_MaintInstructions.HorizontalScrollBar.Renderer = defaultScrollBarRenderer5;
            this.fpSpread_MaintInstructions.HorizontalScrollBar.TabIndex = 4;
            this.fpSpread_MaintInstructions.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_MaintInstructions.Name = "fpSpread_MaintInstructions";
            namedStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(220)))), ((int)(((byte)(233)))));
            namedStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.Renderer = enhancedColumnHeaderRenderer2;
            namedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(220)))), ((int)(((byte)(233)))));
            namedStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.Renderer = enhancedColumnHeaderRenderer1;
            namedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(247)))));
            namedStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle3.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle3.Renderer = enhancedRowHeaderRenderer1;
            namedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            namedStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle4.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle4.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle4.Renderer = enhancedCornerRenderer1;
            namedStyle4.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle5.BackColor = System.Drawing.SystemColors.Window;
            namedStyle5.CellType = generalCellType1;
            namedStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle5.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle5.Renderer = generalCellType1;
            this.fpSpread_MaintInstructions.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2,
            namedStyle3,
            namedStyle4,
            namedStyle5});
            this.fpSpread_MaintInstructions.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_MaintInstructions_Sheet1});
            this.fpSpread_MaintInstructions.Size = new System.Drawing.Size(796, 119);
            this.fpSpread_MaintInstructions.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_MaintInstructions.TabIndex = 0;
            this.fpSpread_MaintInstructions.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_MaintInstructions.VerticalScrollBar.Name = "";
            this.fpSpread_MaintInstructions.VerticalScrollBar.Renderer = defaultScrollBarRenderer6;
            this.fpSpread_MaintInstructions.VerticalScrollBar.TabIndex = 3;
            this.fpSpread_MaintInstructions.VisualStyles = FarPoint.Win.VisualStyles.Off;
            // 
            // fpSpread_MaintInstructions_Sheet1
            // 
            this.fpSpread_MaintInstructions_Sheet1.Reset();
            this.fpSpread_MaintInstructions_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_MaintInstructions_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_MaintInstructions_Sheet1.ColumnCount = 5;
            this.fpSpread_MaintInstructions_Sheet1.RowCount = 5;
            this.fpSpread_MaintInstructions_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_MaintInstructions_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_MaintInstructions_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_MaintInstructions_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_MaintInstructions_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_MaintInstructions_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_MaintInstructions_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_MaintInstructions_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_MaintInstructions_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_MaintInstructions_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_MaintInstructions_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnPmsReportLog);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.lbl_EqpName);
            this.panel5.Controls.Add(this.btnCancel);
            this.panel5.Controls.Add(this.lbl_Maintenance);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(1, 1);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(802, 77);
            this.panel5.TabIndex = 7;
            // 
            // btnPmsReportLog
            // 
            this.btnPmsReportLog.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPmsReportLog.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPmsReportLog.Image = ((System.Drawing.Image)(resources.GetObject("btnPmsReportLog.Image")));
            this.btnPmsReportLog.Location = new System.Drawing.Point(691, 4);
            this.btnPmsReportLog.Margin = new System.Windows.Forms.Padding(0);
            this.btnPmsReportLog.Name = "btnPmsReportLog";
            this.btnPmsReportLog.Size = new System.Drawing.Size(40, 41);
            this.btnPmsReportLog.TabIndex = 79;
            this.btnPmsReportLog.Text = "Log";
            this.btnPmsReportLog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPmsReportLog.UseVisualStyleBackColor = false;
            this.btnPmsReportLog.Click += new System.EventHandler(this.btnPmsReportLog_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(5, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 15);
            this.label1.TabIndex = 75;
            this.label1.Text = "Maintenance Title";
            // 
            // lbl_EqpName
            // 
            this.lbl_EqpName.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EqpName.ForeColor = System.Drawing.Color.Blue;
            this.lbl_EqpName.Location = new System.Drawing.Point(5, 5);
            this.lbl_EqpName.Name = "lbl_EqpName";
            this.lbl_EqpName.Size = new System.Drawing.Size(545, 27);
            this.lbl_EqpName.TabIndex = 13;
            this.lbl_EqpName.Text = "lbl_EqpName";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(738, 4);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(54, 41);
            this.btnCancel.TabIndex = 64;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lbl_Maintenance
            // 
            this.lbl_Maintenance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Maintenance.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Maintenance.ForeColor = System.Drawing.Color.Black;
            this.lbl_Maintenance.Location = new System.Drawing.Point(5, 48);
            this.lbl_Maintenance.Name = "lbl_Maintenance";
            this.lbl_Maintenance.Size = new System.Drawing.Size(786, 24);
            this.lbl_Maintenance.TabIndex = 12;
            this.lbl_Maintenance.Text = "\r\n";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.lblCompletion);
            this.panel7.Controls.Add(this.lblCondition);
            this.panel7.Controls.Add(this.lblReason);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Controls.Add(this.chkCarrriedOut);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(1, 126);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(802, 41);
            this.panel7.TabIndex = 8;
            // 
            // lblCompletion
            // 
            this.lblCompletion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCompletion.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompletion.ForeColor = System.Drawing.Color.Black;
            this.lblCompletion.Location = new System.Drawing.Point(362, 17);
            this.lblCompletion.Name = "lblCompletion";
            this.lblCompletion.Size = new System.Drawing.Size(178, 19);
            this.lblCompletion.TabIndex = 85;
            this.lblCompletion.Text = "....";
            // 
            // lblCondition
            // 
            this.lblCondition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCondition.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCondition.ForeColor = System.Drawing.Color.Black;
            this.lblCondition.Location = new System.Drawing.Point(168, 17);
            this.lblCondition.Name = "lblCondition";
            this.lblCondition.Size = new System.Drawing.Size(185, 19);
            this.lblCondition.TabIndex = 84;
            this.lblCondition.Text = "....";
            // 
            // lblReason
            // 
            this.lblReason.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblReason.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReason.ForeColor = System.Drawing.Color.Black;
            this.lblReason.Location = new System.Drawing.Point(5, 17);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(153, 19);
            this.lblReason.TabIndex = 83;
            this.lblReason.Text = "....";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(167, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Condition";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Reason";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chkCarrriedOut
            // 
            this.chkCarrriedOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.chkCarrriedOut.Checked = true;
            this.chkCarrriedOut.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCarrriedOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCarrriedOut.ForeColor = System.Drawing.Color.Green;
            this.chkCarrriedOut.Location = new System.Drawing.Point(729, 8);
            this.chkCarrriedOut.Margin = new System.Windows.Forms.Padding(0);
            this.chkCarrriedOut.Name = "chkCarrriedOut";
            this.chkCarrriedOut.Size = new System.Drawing.Size(54, 19);
            this.chkCarrriedOut.TabIndex = 5;
            this.chkCarrriedOut.Text = "CarriedOut below maintenance details";
            this.chkCarrriedOut.UseVisualStyleBackColor = false;
            this.chkCarrriedOut.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(360, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Completion";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chkMaintDoneAsPerInstructions);
            this.panel2.Controls.Add(this.lblMemo1);
            this.panel2.Controls.Add(this.lnkViewMaintDetails);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 438);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(796, 21);
            this.panel2.TabIndex = 18;
            // 
            // chkMaintDoneAsPerInstructions
            // 
            this.chkMaintDoneAsPerInstructions.AutoSize = true;
            this.chkMaintDoneAsPerInstructions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.chkMaintDoneAsPerInstructions.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMaintDoneAsPerInstructions.ForeColor = System.Drawing.Color.Blue;
            this.chkMaintDoneAsPerInstructions.Location = new System.Drawing.Point(172, 1);
            this.chkMaintDoneAsPerInstructions.Name = "chkMaintDoneAsPerInstructions";
            this.chkMaintDoneAsPerInstructions.Size = new System.Drawing.Size(353, 17);
            this.chkMaintDoneAsPerInstructions.TabIndex = 79;
            this.chkMaintDoneAsPerInstructions.Text = "Maintenance done as per Maintenance procedures";
            this.chkMaintDoneAsPerInstructions.UseVisualStyleBackColor = false;
            this.chkMaintDoneAsPerInstructions.Visible = false;
            // 
            // lblMemo1
            // 
            this.lblMemo1.AutoSize = true;
            this.lblMemo1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMemo1.Location = new System.Drawing.Point(1, 3);
            this.lblMemo1.Name = "lblMemo1";
            this.lblMemo1.Size = new System.Drawing.Size(160, 13);
            this.lblMemo1.TabIndex = 81;
            this.lblMemo1.Text = "Maintenance comments";
            // 
            // lnkViewMaintDetails
            // 
            this.lnkViewMaintDetails.AutoSize = true;
            this.lnkViewMaintDetails.Location = new System.Drawing.Point(555, 3);
            this.lnkViewMaintDetails.Name = "lnkViewMaintDetails";
            this.lnkViewMaintDetails.Size = new System.Drawing.Size(151, 13);
            this.lnkViewMaintDetails.TabIndex = 74;
            this.lnkViewMaintDetails.TabStop = true;
            this.lnkViewMaintDetails.Text = "View Maintenance procedures";
            this.lnkViewMaintDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintDetails_LinkClicked);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lnkViewHistAttach);
            this.panel6.Controls.Add(this.lblAttachmentFileName);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(1, 406);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(802, 28);
            this.panel6.TabIndex = 19;
            // 
            // lnkViewHistAttach
            // 
            this.lnkViewHistAttach.Location = new System.Drawing.Point(93, 7);
            this.lnkViewHistAttach.Name = "lnkViewHistAttach";
            this.lnkViewHistAttach.Size = new System.Drawing.Size(481, 17);
            this.lnkViewHistAttach.TabIndex = 78;
            this.lnkViewHistAttach.TabStop = true;
            this.lnkViewHistAttach.Text = "View";
            this.lnkViewHistAttach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewHistAttach_LinkClicked);
            // 
            // lblAttachmentFileName
            // 
            this.lblAttachmentFileName.AutoSize = true;
            this.lblAttachmentFileName.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAttachmentFileName.Location = new System.Drawing.Point(584, 12);
            this.lblAttachmentFileName.Name = "lblAttachmentFileName";
            this.lblAttachmentFileName.Size = new System.Drawing.Size(15, 14);
            this.lblAttachmentFileName.TabIndex = 75;
            this.lblAttachmentFileName.Text = "--";
            this.lblAttachmentFileName.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(5, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 13);
            this.label7.TabIndex = 80;
            this.label7.Text = "Attachment";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.lblComments);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(1, 463);
            this.panel13.Margin = new System.Windows.Forms.Padding(0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(802, 20);
            this.panel13.TabIndex = 20;
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComments.Location = new System.Drawing.Point(1, 5);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(75, 13);
            this.lblComments.TabIndex = 16;
            this.lblComments.Text = "Comments";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmMaintInput_CheckList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 579);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMaintInput_CheckList";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "  Maintenance Report";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMaintInput_CheckList_FormClosing);
            this.Load += new System.EventHandler(this.frmMaintInput_CheckList_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_MaintInstructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_MaintInstructions_Sheet1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblPlace1;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private FarPoint.Win.Spread.FpSpread fpSpread_MaintInstructions;
        private FarPoint.Win.Spread.SheetView fpSpread_MaintInstructions_Sheet1;
        private System.Windows.Forms.Label lbl_Maintenance;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Label lbl_EqpName;
        private System.Windows.Forms.CheckBox chkCarrriedOut;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.LinkLabel lnkViewMaintDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.LinkLabel lnkViewHistAttach;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label lblAttachmentFileName;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private FarPoint.Win.Spread.FpSpread fpSpreadAssociatedForms;
        private FarPoint.Win.Spread.SheetView fpSpreadAssociatedForms_Sheet1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblMemo1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.Label lblMaintType;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.Label lblMaintDate;
        private System.Windows.Forms.Label lblCompletion;
        private System.Windows.Forms.Label lblCondition;
        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.Label lblManhrs;
        private System.Windows.Forms.Label lblInterval;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblManhrs1;
        private System.Windows.Forms.CheckBox chkMaintDoneAsPerInstructions;
        private System.Windows.Forms.Button btnPmsReportLog;
    }
}