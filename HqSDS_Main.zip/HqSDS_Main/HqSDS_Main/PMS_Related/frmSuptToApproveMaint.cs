﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmSuptToApproveMaint : Form
    {
        public int vesselID = -1;
        public string callMode = "";        
        public  bool isMaintAckDone = false;

        bool isGridInitialied = false, canCloseForm = false, isUserAssignedVsl = false;
        long curEQUnitID = -1, curEQMaintID = -1, curPms_DocID = -1;
        int curVesselID = -1;

        const int COL_LINENO = 0,
                  COL_EQPNAME = 1,
                  COL_POSITION = 2,
                  COL_MNTDESC = 3,
                  COL_NMDATE = 4,
                  COL_POSTPONEDATE = 5,
                  COL_APPROVE = 6,
                  COL_NOTAPPROVE = 7,
                  COL_SUPTCOMMENTS = 8,
                  COL_VSLCOMMENTS = 9,
                  COL_VESSELID = 10,
                  COL_EQUNITSID = 11,
                  COL_EQMAINTENANCEID = 12,
                  COL_EQ_PMSLIST_CLASSID = 13,
                  COL_PMS_DOCID = 14,
                  COL_MREPREFNO = 15,
                  COL_SREPREFNO = 16,
                  COL_INTERVAL = 17,
                  COL_DEPT = 18,
                  COL_MAINTTYPE = 19,
                  COL_MPLACE = 20,
                  COL_MAINTCODE = 21,
                  COL_PMSCODE = 22,
                  COL_PMM_DOCREFNO = 23,
                  COL_COMPONENT = 24,
                  COL_INCHARGERANK = 25,
                  COL_RESPONSIBLERANK = 26, 
                  COL_PMSHISTID = 27,
                  COL_MTYPE = 28,
                  COL_MREASON = 29,                  
                  COL_MICOND = 30,
                  COL_MCOMPL = 31,
                  COL_MMHRS = 32,
                  COL_ISMAINTPOSTPONED=33;

        const int COL_ASSOC_FORMS_FORMNAME = 0,
                 COL_ASSOC_FORMS_STATUS = 1,
                 COL_ASSOC_FORMS_MODE = 2,
                 COL_ASSOC_FORMS_INSTANCENO = 3,
                 COL_ASSOC_FORMS_DEFAULTPARAMVALUE = 4,
                 COL_ASSOC_FORMS_FORMSLISTID = 5,
                 COL_ASSOC_FORMS_FORMSINSTANCEID = 6,
                 COL_ASSOC_FORMS_ISCOMPULSORY = 7,
                 COL_ASSOC_FORMS_REPORTDUEDATE = 8,
                 COL_ASSOC_FORMS_ISCOMPULSORYDISPLAY = 9;

        SuptReview suptRvw = null;

        public frmSuptToApproveMaint()
        {
            InitializeComponent();
        }

        private void frmSuptToApproveMaint_Load(object sender, EventArgs e)
        {
            suptRvw = new SuptReview();
            this.Text = "Supt To Approve Postponement Maintenance - " + PG.GetVslName(vesselID);

            if (PG.Gb.IsToConnecDirectDB)
                tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else
                tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();

            Gfn.SetFormWidthAndHeight(this, 1, 1, SystemInformation.PrimaryMonitorSize.Height, 1000);

            EnableDisableButtonsBasedonUserRights();
            DesignSuptToApproveGridDetails();
            DesignPmsConsumedGrid();
            DesignMaintAssociatedForms();

            BindSuptToApproveGrid();

            PG.InitialiseVesselSettings(vesselID);

            btnUpdate.Enabled = (suptRvw.dtSuptToAppr != null && suptRvw.dtSuptToAppr.Rows.Count > 0);

            lbl_PMSCode.Visible = !PG.isPMS_HidePMSCode; lblPMSCode.Visible = !PG.isPMS_HidePMSCode;
            lblPMM.Visible = !PG.isPMS_HidePMMDetails; lblPMMRefNo.Visible = !PG.isPMS_HidePMMDetails;
            lblMaint.Visible = !PG.isPMS_HidePMMDetails; lblMaintCode.Visible = !PG.isPMS_HidePMMDetails;
            lblComp.Visible = !PG.isPMS_HidePMMDetails; lblComponent.Visible = !PG.isPMS_HidePMMDetails;
            lblInCharge.Visible = !PG.isPMS_HideMaintIncharge; lblInChargeRank.Visible = !PG.isPMS_HideMaintIncharge;
            lblResponsible.Visible = !PG.isPMS_HideMaintIncharge; lblResponsibleRank.Visible = !PG.isPMS_HideMaintIncharge;

            lblComments.Text = PG.GetEQ_PMS_Settings(curVesselID, "PMS_VesselCommentsLablelValue");

            this.Cursor = Cursors.Default;
        }

        protected void EnableDisableButtonsBasedonUserRights()
        {
            try
            {
                string script = " select count(*) from Proc_UserActionVsls " +
                                " where VesselID=" + vesselID + " and UserId=" + Gfn.Qss(PG.Gb.User.CurUserID) +
                                "    and UserID in (select UserID from HQ_Users where Role in (" + "'" + PG.pmsAllowedRolesToSuptReview.Replace(",", "','") + "'" + " )) "; 
                int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                isUserAssignedVsl = (cnt > 0);

                btnUpdate.Enabled = isUserAssignedVsl;
                tsmnuSuptComments.Enabled = isUserAssignedVsl;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "EnableDisableButtonsBasedonUserRights", err.Message);
            }
        }

        protected void DesignSuptToApproveGridDetails()
        {
            List<DgvInits> suptQColList = new List<DgvInits>();
            try
            {
                Color bkColor = Color.Honeydew;
                suptQColList.Add(new DgvInits("LineItemNo", "#", 25, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                suptQColList.Add(new DgvInits("EqpName", "Equipment Name", 140, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                suptQColList.Add(new DgvInits("PositionDesc", "Position", 55, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                suptQColList.Add(new DgvInits("MaintDescription", "Maintenance", 250, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                suptQColList.Add(new DgvInits("nMdate_Display", "Maint Date", 80, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                suptQColList.Add(new DgvInits("Postponedate_Display", "Postpone Date", 85, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                suptQColList.Add(new DgvInits("Approve", " ", 0, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("NotApprove", " ", 0, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("SuptComments", "", 0, Color.Black, SystemColors.ButtonFace, true, false));
                suptQColList.Add(new DgvInits("VslComments", lblComments.Text, 25, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("VesselID", "VesselID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("Eq_UnitsID", "Eq_UnitsID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("Eq_MaintenanceID", "Eq_MaintenanceID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("EQ_PmsList_ClassID", "EQ_PmsList_ClassID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("PMS_DocID", "PMS_DocID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("mRepRefNo", "mRepRefNo", 80, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("sRepRefNo", "sRepRefNo", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("Interval", "Interval", 59, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("DeptDisplayStr", "Dept", 55, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("MaintType", "MaintType", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("mPlace", "mPlace", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MaintCode", "Maint Code", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("PmsCode", "PMS Code", 110, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("PMM_DocRefno", "PMM DocNo", 75, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("Component", "Component", 60, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("InChargeRank_Pms", "InCharge (Rank)", 69, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("ReponsibleRank_Pms", "Resp.(Rank)", 60, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("EQ_PmsHistID", "EQ_PmsHistID", 50, Color.Black, SystemColors.ButtonFace, false, true));                
                suptQColList.Add(new DgvInits("MType", "MType", 0, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("mReason", "mReason", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("miCond", "miCond", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MCompl", "MCompl", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MMHRS", "MMHRS", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("IsMaintPostponed", "IsMaintPostponed", 50, Color.Black, SystemColors.ButtonFace, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, suptQColList, null, false, false, true);
                FarPtColCtrls.AssignCheckBoxColumnsToFarPointGrid(fpSpread1, false, "SuptToApprove", "Appr", COL_APPROVE, "", 30, Color.White);
                FarPtColCtrls.AssignCheckBoxColumnsToFarPointGrid(fpSpread1, false, "SuptToNotApprove", "Not Appr", COL_NOTAPPROVE, "", 30, Color.White);
                FarPtColCtrls.AssignTextBoxColumnToFarPointGrid(fpSpread1, false, "SuptComments", "Supt Comments", COL_SUPTCOMMENTS, 230, true, Color.White, false, 510);

                fpSpread1.ActiveSheet.Columns[COL_APPROVE, COL_NOTAPPROVE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 30;

                fpSpread1.ActiveSheet.Columns[COL_APPROVE, COL_NOTAPPROVE].Locked = (!isUserAssignedVsl);
                fpSpread1.ActiveSheet.Columns[COL_SUPTCOMMENTS].Locked = (!isUserAssignedVsl);
            }
            finally
            {
                suptQColList = null;
            }
        }


        private void BindSuptToApproveGrid()
        {
            DataTable dt = null;
            try
            {
                fpSpread1.SuspendLayout();
                isGridInitialied = false;
                fpSpread1.ActiveSheet.RowCount = 0;

                string filterStr = txtSearch.Text;
                dt = suptRvw.GetSuptToApproveDataTable(vesselID, filterStr);
                fpSpread1.ActiveSheet.DataSource = dt;

                if (dt == null)
                {
                    ClearControls();
                }

                int lineNo = 1;
                for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
                {
                    int isApprove = 0, isNotApprove = 0;
                    if (fpSpread1.ActiveSheet.Cells[row, COL_APPROVE].Value != null)
                        isApprove = Convert.ToInt32(Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[row, COL_APPROVE].Value));
                    if (isApprove == 1) fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value = 0;

                    if (fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value != null)
                        isNotApprove = Convert.ToInt32(Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value));
                    if (isNotApprove == 1) fpSpread1.ActiveSheet.Cells[row, COL_APPROVE].Value = 0;
                    fpSpread1.ActiveSheet.Cells[row, COL_SUPTCOMMENTS].Locked = (isNotApprove == 0 && isApprove == 0);

                    fpSpread1.ActiveSheet.Cells[row, COL_LINENO].Value = lineNo.ToString();
                    fpSpread1.ActiveSheet.Rows[row].Height = fpSpread1.ActiveSheet.Rows[row].GetPreferredHeight();
                    lineNo = lineNo + 1;
                }
                
                if (fpSpread1.ActiveSheet.RowCount > 0) fpSpread1.ActiveSheet.SetActiveCell(0, 0);

                isGridInitialied = true;
                
                fpSpread1_SelectionChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "BindSuptToApproveGrid()", err.Message);
                Gfn.nWb("Failed to bind SuptToApprove details");
            }
            finally
            {
                fpSpread1.ResumeLayout();
                dt = null;
            }
            tsLblTotalItems.Text = "Total Items : " + fpSpread1.ActiveSheet.RowCount;
        }


        private void ClearControls()
        {
            lblEquipment.Text = "";            
            lblDept.Text = ""; 
            lblPlace.Text = ""; 
            lblInterval.Text = "";
            lblMaintCode.Text = "";            
            lblPMMRefNo.Text = ""; 
            lblResponsibleRank.Text = ""; 
            lblComponent.Text = "";            
            lblMaintType.Text = "";
            lblMType.Text = "";
            lblMaintenance.Text = "";
            lblInChargeRank.Text = "";
            lblPostponementDate.Text = "";
            lblPMSCode.Text = "";
            txtVslComments.Text = "";
            txtSuptComments.Text = "";
            lblMType.Text = "";
            lblManHrs.Text = "";
            lblCondition.Text = "";
            lblReason.Text = "";
            lblCompletion.Text = "";
            lblCompletion.BackColor = Color.AliceBlue;

            lnkViewMaintDetails.Visible = false;
            lnkViewMaintCheckList.Visible = false;
            lnkViewAlarmAndTestingItems.Visible = false;            
            lnkViewAttchment.Visible = false;
            fpSpreadConsumed.ActiveSheet.RowCount = 0;
            fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            BindSuptToApproveGrid();
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnGo_Click(null, null);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            btnGo_Click(null, null);
        }

        private void fpSpread1_Sheet1_CellChanged(object sender, FarPoint.Win.Spread.SheetViewEventArgs e)
        {
            if (!isGridInitialied) return;
            if (e.Row < 0) return;

            isGridInitialied = false;
            int rowIndex = e.Row;
            try
            {
                if (e.Column == COL_APPROVE)
                {
                    if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value != null)
                    {
                        if (Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value))
                        {
                            fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value = "0";
                        }
                    }
                }
                if (e.Column == COL_NOTAPPROVE)
                {
                    if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value != null)
                    {
                        if (Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value))
                        {
                            fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value = "0";
                        }
                    }
                }

                if (e.Column == COL_APPROVE || e.Column==COL_NOTAPPROVE || e.Column == COL_SUPTCOMMENTS)
                {
                    int isApprove = 0, isNotApprove = 0;
                    if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value != null)
                        isApprove = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value);
                    if (isApprove == 1) fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value = 0;

                    if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value != null)
                        isNotApprove = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value);
                    if (isNotApprove == 1) fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value = 0;

                    if (isNotApprove == 0 && isApprove == 0) fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Value = "";

                    string suptComments = GetCellValue(rowIndex, COL_SUPTCOMMENTS);
                    int mRepRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                    int sRepRefNo = GetCellValue_Int(rowIndex, COL_SREPREFNO);
                    long eq_PmsList_ClassID = GetCellValue_long(rowIndex, COL_EQ_PMSLIST_CLASSID);
                    long eq_unitsID = GetCellValue_long(rowIndex, COL_EQUNITSID);
                    long eq_maitnenanceID = GetCellValue_long(rowIndex, COL_EQMAINTENANCEID);

                    if (suptRvw != null)
                    {
                        suptRvw.AddEditSuptToApproveInTempDataTable(vesselID, isApprove, isNotApprove, suptComments, mRepRefNo, sRepRefNo, eq_unitsID, eq_maitnenanceID, eq_PmsList_ClassID);
                        btnUpdate.Enabled = (suptRvw.dtSuptToAppr != null && suptRvw.dtSuptToAppr.Rows.Count > 0);
                    }
                    fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Locked = (isNotApprove == 0 && isApprove == 0);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.CS", "fpSpread1_Sheet1_CellChanged", err.Message);
            }
            finally
            {
                isGridInitialied = true;
            }
        }

        private void fpSpread1_ButtonClicked(object sender, FarPoint.Win.Spread.EditorNotifyEventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            try
            {
                btnUpdate.Enabled = true;

                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
                int isApprove = 0, isNotApprove = 0;
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value != null)
                    isApprove = Convert.ToInt32(Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value));
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value != null)
                    isNotApprove = Convert.ToInt32(Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value));

                fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Locked = (isApprove == 0 && isNotApprove == 0);

                fpSpread1_SelectionChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.CS", "fpSpread1_ButtonClicked", err.Message);
            }
        }

        private void fpSpread1_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            if (!isGridInitialied) return;
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            try
            {
                int row = fpSpread1.ActiveSheet.ActiveRowIndex;
                txtVslComments.Text = GetCellValue(row, COL_VSLCOMMENTS);
                txtSuptComments.Text = GetCellValue(row, COL_SUPTCOMMENTS);
                lblEquipment.Text = GetCellValue(row, COL_EQPNAME) + " " + GetCellValue(row, COL_POSITION);
                lblMaintenance.Text = GetCellValue(row, COL_MNTDESC);
                lblDept.Text = GetCellValue(row, COL_DEPT);
                lblInterval.Text = GetCellValue(row, COL_INTERVAL);
                lblPMSCode.Text = GetCellValue(row, COL_PMSCODE);
                lblMaintType.Text = GetCellValue(row, COL_MAINTTYPE);
                lblPostponementDate.Text = GetCellValue(row, COL_POSTPONEDATE);
                lblPlace.Text = GetCellValue(row, COL_MPLACE);
                lblMType.Text = GetCellValue(row, COL_MTYPE);

                lblPMMRefNo.Text = GetCellValue(row, COL_PMM_DOCREFNO);
                lblComponent.Text = GetCellValue(row, COL_COMPONENT);
                lblMaintCode.Text = GetCellValue(row, COL_MAINTCODE);
                lblInChargeRank.Text = GetCellValue(row, COL_INCHARGERANK);
                lblResponsibleRank.Text = GetCellValue(row, COL_RESPONSIBLERANK);
                
                curVesselID = GetCellValue_Int(row, COL_VESSELID);
                curEQUnitID = GetCellValue_long(row, COL_EQUNITSID);
                curEQMaintID = GetCellValue_long(row, COL_EQMAINTENANCEID);
                curPms_DocID = GetCellValue_long(row, COL_PMS_DOCID);
                long pmsHistID = GetCellValue_long(row, COL_PMSHISTID);

                lnkViewMaintDetails.Visible = PG.CheckMaintProcedureOrManualRefExist(curVesselID, curPms_DocID, curEQUnitID);
               
                tableLayoutPanel2.RowStyles[2].Height = 0;
                lnkViewMaintCheckList.Visible = false;
                lnkViewAlarmAndTestingItems.Visible = false;
                lnkViewAttchment.Visible = HistContainsAttachment(pmsHistID);
               
                string maintType = GetCellValue(row, COL_MAINTTYPE);
                if (maintType.ToUpper() == PG.MAINTTYPE_PMS.ToUpper() || maintType.ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE.ToUpper())
                {
                     string mType = GetCellValue(row, COL_MTYPE);

                     if (mType.ToUpper() == "Postponement".ToUpper())
                     {
                         tableLayoutPanel2.RowStyles[2].Height = 0;
                         txtVslComments.Height = 150;
                         lblManHrs1.Visible = false; lblManHrs.Visible = false;
                         lblCondition1.Visible = false; lblCondition.Visible = false;
                         lblCompletion1.Visible = false; lblCompletion.Visible = false;
                         lblReason1.Visible = false; lblReason.Visible = false;
                     }
                     else
                     {
                         #region PMS

                         lblManHrs1.Visible = true; lblManHrs.Visible = true;
                         lblCondition1.Visible = true; lblCondition.Visible = true;
                         lblCompletion1.Visible = true; lblCompletion.Visible = true;
                         lblReason1.Visible = true; lblReason.Visible = true;
                         lblManHrs.Text = GetCellValue(row, COL_MMHRS);
                         lblCondition.Text = GetCellValue(row, COL_MICOND);
                         lblCompletion.Text = GetCellValue(row, COL_MCOMPL);
                         lblReason.Text = GetCellValue(row, COL_MREASON);

                         int isMaintPostPoned = GetCellValue_Int(row, COL_ISMAINTPOSTPONED);
                         if (isMaintPostPoned == 2)
                         {
                             //string script = " Select count(*) from EQ_MaintCheckList  " +
                             //                 " where IsDisabled =0 and VesselID= " + curVesselID + " and PMS_DocID =" + curPms_DocID;
                             string script = " Select COUNT(*) from EQ_PmsHist_MaintCheckListDetails " +
                                             " where VesselID=" + curVesselID + " and EQ_PmsHistID ='" + pmsHistID + "'";
                             if (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0)
                             {
                                 lnkViewMaintCheckList.Visible = true;
                                 lnkViewAlarmAndTestingItems.Visible = false;
                             }

                             BindAndLoadPmsConsumedGrid();

                             tableLayoutPanel3.ColumnStyles[1].Width = 41.56171f;
                             if (IsAssociatedFormsExists(pmsHistID))
                             {
                                 int col_ItemDetail_Width = 350, col_MakerCode_Width = 100, col_ConsQty_Width = 50;
                                 fpSpreadConsumed.ActiveSheet.Columns[0].Width = col_ItemDetail_Width;
                                 fpSpreadConsumed.ActiveSheet.Columns[1].Width = col_MakerCode_Width;
                                 fpSpreadConsumed.ActiveSheet.Columns[2].Width = col_ConsQty_Width;

                                 BindMaintAssociatedForms();
                                 tableLayoutPanel2.RowStyles[2].Height = 90;
                                 txtVslComments.Height = 86;
                             }
                             else
                             {
                                 int col_ItemDetail_Width = 500, col_MakerCode_Width = 200, col_ConsQty_Width = 100;
                                 fpSpreadConsumed.ActiveSheet.Columns[0].Width = col_ItemDetail_Width;
                                 fpSpreadConsumed.ActiveSheet.Columns[1].Width = col_MakerCode_Width;
                                 fpSpreadConsumed.ActiveSheet.Columns[2].Width = col_ConsQty_Width;
                                 tableLayoutPanel3.ColumnStyles[1].Width = 0;
                                 tableLayoutPanel2.RowStyles[2].Height = 90;
                                 txtVslComments.Height = 86;
                             }                       

                             if (maintType.ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE)
                             {
                                 lnkViewMaintCheckList.Visible = false;
                                 lnkViewAlarmAndTestingItems.Visible = true;
                                 lnkViewAttchmentRoutine.Visible = HistContainsAttachment(pmsHistID);
                             }
                         }
                         lblCompletion.BackColor = Color.AliceBlue;
                         lblCompletion.ForeColor = SystemColors.ControlText;
                         lblCompletion.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
                         if ((lblCompletion.Text.ToUpper() == PG.MCOMPL_STOPGAP_MEASUREONLY) || (lblCompletion.Text.ToUpper() == PG.MCOMPL_TOREDO_AT_DRYDOCKING) || (lblCompletion.Text.ToUpper() == PG.MCOMPL_TOREDO_WHEN_SPARESRECVD))
                         {
                             lblCompletion.BackColor = Color.Red;
                             lblCompletion.ForeColor = Color.White;
                             lblCompletion.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
                         }

                         lblReason.ForeColor = Color.Black;
                         if ((lblReason.Text.ToUpper() == PG.MREASON_BREAKDOWN) || (lblReason.Text.ToUpper() == PG.MREASON_LEAKAGES) || (lblReason.Text.ToUpper() == PG.MREASON_POOR_EFFICIENCY))
                         {
                             lblReason.ForeColor = Color.Red;
                         }
                         lblCondition.ForeColor = Color.Black;
                         if ((lblCondition.Text.ToUpper() == PG.MCOND_IN_VERY_POORSTATE) || (lblCondition.Text.ToUpper() == PG.MCOND_HEAVILY_CARBONISED))
                         {
                             lblCondition.ForeColor = Color.Red;
                         }
                         #endregion
                     }   
                }

                if (maintType.ToUpper() == PG.MAINTTYPE_PMS.ToUpper()) lnkViewMaintDetails.Text = "View Maintenance procedures";
                else if (maintType.ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE.ToUpper()) lnkViewMaintDetails.Text = "View Alarms and Routines procedures";
                else if (maintType.ToUpper() == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE.ToUpper()) lnkViewMaintDetails.Text = "View CM Routine procedures";
                lnkViewMaintDetails.Text = lnkViewMaintDetails.Text + " / Manual Ref";
            }
            catch (Exception err)
            {
                Gfn.Wb("Failed to load data");
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "fpSpread1_SelectionChanged", err.Message);
            }
        }

        private void fpSpread1_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread1.ContextMenuStrip = null;
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread1.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;

                int isApprove = 0, isNotApprove = 0;
                if (fpSpread1.ActiveSheet.Cells[row, COL_APPROVE].Value != null)
                    isApprove = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_APPROVE].Value);
                if (isApprove == 1) fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value = 0;

                if (fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value != null)
                    isNotApprove = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value);
                if (isNotApprove == 1) fpSpread1.ActiveSheet.Cells[row, COL_APPROVE].Value = 0;

                if (isNotApprove == 0 && isApprove == 0) tsmnuSuptComments.Enabled = false;
                else tsmnuSuptComments.Enabled = true;

                fpSpread1.ActiveSheet.SetActiveCell(row, col);
                fpSpread1.ContextMenuStrip = contextMenuStrip1;

                fpSpread1_SelectionChanged(null, null);
            }
        }

        private void tsmnuSuptComments_Click(object sender, EventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            frmSuptComments objSuptCmmnts = new frmSuptComments();
            try
            {
                objSuptCmmnts.suptComments  = GetCellValue(rowIndex, COL_SUPTCOMMENTS);
                if (DialogResult.OK == objSuptCmmnts.ShowDialog())
                {
                    fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Value = objSuptCmmnts.suptComments;

                    int isApprove = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_APPROVE].Value);
                    int isNotApprove = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NOTAPPROVE].Value);

                    string suptComments = GetCellValue(rowIndex, COL_SUPTCOMMENTS);
                    int mRepRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                    int sRepRefNo = GetCellValue_Int(rowIndex, COL_SREPREFNO);
                    long eq_PmsList_ClassID = GetCellValue_long(rowIndex, COL_EQ_PMSLIST_CLASSID);
                    long eq_unitsID = GetCellValue_long(rowIndex, COL_EQUNITSID);
                    long eq_maitnenanceID = GetCellValue_long(rowIndex, COL_EQMAINTENANCEID);

                    suptRvw.AddEditSuptToApproveInTempDataTable(vesselID, isApprove, isNotApprove, suptComments, mRepRefNo, sRepRefNo, eq_unitsID, eq_maitnenanceID, eq_PmsList_ClassID);

                    btnUpdate.Enabled = (suptRvw.dtSuptToAppr != null && suptRvw.dtSuptToAppr.Rows.Count > 0);

                    fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Locked = (isNotApprove == 0 && isApprove == 0);
                }
            }
            finally
            {
                objSuptCmmnts = null;
            }
        }


        private void tsMnuMaintHistory_Click(object sender, EventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            frmMaintHistory objMaintHist = new frmMaintHistory();
            try
            {
                objMaintHist.curVesselID = GetCellValue_Int(rowIndex, COL_VESSELID);
                objMaintHist.curEQUnitID = GetCellValue_long(rowIndex, COL_EQUNITSID);
                objMaintHist.curEQMaintID = GetCellValue_long(rowIndex, COL_EQMAINTENANCEID);
                objMaintHist.curPms_DocID = GetCellValue_long(rowIndex, COL_PMS_DOCID);

                objMaintHist.ShowDialog();
            }
            finally
            {
                objMaintHist = null;
            }
        }
        
        private void lnkViewMaintDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmViewMaintDescription viewMaintDesc = new frmViewMaintDescription();
            try
            {
                if (fpSpread1.ActiveSheet.ActiveCell == null) return;
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

                viewMaintDesc.curVesselID = vesselID;
                viewMaintDesc.curEQUnitID = GetCellValue_long(rowIndex, COL_EQUNITSID);
                viewMaintDesc.curEQMaintID = GetCellValue_long(rowIndex, COL_EQMAINTENANCEID);
                viewMaintDesc.maintType = GetCellValue(rowIndex, COL_MAINTTYPE);
                viewMaintDesc.curPms_DocID = GetCellValue_long(rowIndex, COL_PMS_DOCID);
                viewMaintDesc.parentMouseXPosn = this.Location.X;
                viewMaintDesc.ShowDialog();
            }
            finally
            {
                viewMaintDesc = null;
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            #region Validation
            if (suptRvw.dtSuptToAppr == null)
            {
                Gfn.nMbwithAlignAndCentrePosn("Atleast select one maintenance for approve/not approve", ContentAlignment.MiddleCenter);
                return;
            }

            if (suptRvw.dtSuptToAppr.Rows.Count == 0)
            {
                Gfn.nMbwithAlignAndCentrePosn("Atleast select one maintenance for approve/not approve", ContentAlignment.MiddleCenter);
                return;
            }
            
            string emptyErr = "", errMsg = "";
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                string suptComments = GetCellValue(row, COL_SUPTCOMMENTS);
                int isNotApprove = 0;
                if (fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value != null)
                    isNotApprove = Convert.ToInt32(Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[row, COL_NOTAPPROVE].Value));

                if (isNotApprove == 1)
                {
                    if (suptComments.Trim().Length <= 0)
                    {
                        emptyErr = emptyErr + "> Line No: " + GetCellValue(row, COL_LINENO) + Environment.NewLine;
                    }
                }

                if (suptComments.Length > 510)
                {
                    errMsg = errMsg + "> Line No: " + GetCellValue(row, COL_LINENO) + Environment.NewLine;
                }
            }

            if (emptyErr.Trim().Length > 0) emptyErr = "Following Postponement items marked as not approve, Comments cannot be empty " + Environment.NewLine + emptyErr;
            if (errMsg.Trim().Length > 0) errMsg = "Comments cannot be greater than 510 characters for the following postponement line items : " + Environment.NewLine + errMsg;
            errMsg = emptyErr + Environment.NewLine + Environment.NewLine + errMsg;
            if (errMsg.Trim().Length > 0)
            {
                Gfn.Wb(errMsg);
                return;
            } 
            #endregion

            try
            {
                progressBar1.Visible = true;
                if (progressBar1.Value > 0) progressBar1.Value = 1;
                progressBar1.Step = 1;
                progressBar1.Minimum = 0;
                progressBar1.Maximum = suptRvw.dtSuptToAppr.Rows.Count;

                int col = fpSpread1.ActiveSheet.ActiveColumnIndex;
                if (col == COL_APPROVE || col == COL_NOTAPPROVE || col == COL_SUPTCOMMENTS)
                {
                    fpSpread1_Sheet1.CellChanged += new FarPoint.Win.Spread.SheetViewEventHandler(this.fpSpread1_Sheet1_CellChanged);
                }

                UpdateSuptToAck();
                UpdateSuptNotAck();

                if (suptRvw.dtSuptToAppr.Rows.Count > 0)
                {
                    Gfn.nMbwithAlignAndCentrePosn("Updated Successfully.", ContentAlignment.MiddleCenter, 110, 250);
                    suptRvw.dtSuptToAppr.Rows.Clear();
                }
            }
            catch (Exception err)
            {
                Gfn.Wb("Failed to update");
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "btnUpdate_Click", err.Message);
                return;
            }
            finally
            {
                progressBar1.Visible = false;
            }

            suptRvw.InitialiseToApproveTempDataTable();

            BindSuptToApproveGrid();

            canCloseForm = true;
            if (fpSpread1.ActiveSheet.RowCount == 0)
            {
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        public void UpdateSuptToAck()
        {
            string script, suptComments = "";
            int suptApprove = 0, vslToViewSuptComments = 0, refNumber = 0, vesselID = -1;
            long eq_PmsList_ClassID = -1, eq_UnitsID = -1, eq_MaintenanceID = -1;

            try
            {
                string updStat = "p";
                foreach (DataRow dr in suptRvw.dtSuptToAppr.Rows)
                {
                    suptApprove = Convert.ToInt32(dr["SuptToAck"].ToString());
                    if (suptApprove == 0) continue;

                    suptComments = dr["SuptComments"].ToString().Trim();
                    vslToViewSuptComments = 0;
                    if (suptComments.Length > 0) vslToViewSuptComments = 1;

                    suptComments = "Postponement verified and approved by HQ " + Environment.NewLine + suptComments;

                    vesselID = Convert.ToInt32(dr["VesselID"].ToString());
                    eq_UnitsID = Convert.ToInt64(dr["EQ_UnitsID"].ToString());
                    eq_MaintenanceID = Convert.ToInt64(dr["EQ_MaintenanceID"].ToString());
                    eq_PmsList_ClassID = Convert.ToInt64(dr["EQ_PmsList_ClassID"].ToString());
                    refNumber = -1;

                    string sx = dr["mRepRefNo"].ToString();
                    if (sx.Trim().Length > 0) refNumber = Convert.ToInt32(dr["mRepRefNo"].ToString());

                    script = " update EQ_PMSList_PlannedItems set IsJobDone= 1, UpdatedBy='App' " +
                             " from EQ_PMSList_PlannedItems P, EQ_PmsHist H " +
                             " where P.VesselId =H.VesselId  and P.EQ_UnitsID =H.EQ_UnitsID and P.EQ_MaintenanceID=H.EQ_MaintenanceID " +
                             "    and Year(NmDate) = P.Yr and Month(NmDate) = P.Mon " +
                             "    and P.VesselId =" + vesselID + " and P.EQ_UnitsID =" + eq_UnitsID +
                             "    and P.EQ_MaintenanceID=" + eq_MaintenanceID +
                             "    and H.mRepRefNo = " + refNumber + " and P.IsJobDone= 0 ";
                    PG.Gb.DBFn.Xqry(script);

                    script = " update EQ_PMSHist set SuptToAck=" + suptApprove +
                             "   , MdueDATE = PostponeDate " +
                             "   , VslToViewSuptComments=" + vslToViewSuptComments +
                             "   , SuptComments=" + Gfn.Qss(suptComments) +
                             " where VesselId =" + vesselID + " and mRepRefNo = " + refNumber + " ; ";

                    script = script + " Update EQ_PmsList Set mRepRefNo = null " +
                                      //"   , LastOhDate = H.nMDATE " +
                                      "   , MaintDue   = H.PostponeDate " +
                                      "   , nMaintDue  = H.PostponeDate " +
                                      "   , LastOhHrs  = H.PrevLastHours " +
                                      "   , UpdStat    = " + Gfn.Qss(updStat) +
                                      " from EQ_PmsList L, EQ_PmsHist H " +
                                      " where L.VesselID=H.VesselID and L.EQ_MaintenanceID=H.EQ_MaintenanceID  and L.EQ_UnitsID=H.EQ_UnitsID " +
                                      "   and H.mRepRefNo=" + refNumber +
                                      "   and L.VesselID = " + vesselID +
                                      "   and L.EQ_UnitsID = " + eq_UnitsID +
                                      "   and L.EQ_MaintenanceID = " + eq_MaintenanceID + " ; " +

                                      " update EQ_PMSList set nMaintDue= M.StrToReplaceMaintDue " +
                                      " from EQ_PMSList P, EQ_Maintenance M  " +
                                      " where P.VesselId=M.VesselId and P.EQ_MaintenanceID=M.EQ_MaintenanceID " +
                                      "    and P.IsDisabled=0 " +
                                      "    and P.VesselID= " + vesselID +
                                      "    and P.EQ_UnitsID = " + eq_UnitsID + " and P.EQ_MaintenanceID = " + eq_MaintenanceID +
                                      "    and len(M.StrToReplaceMaintDue)>0  ; " +

                                      " update EQ_PMSList set nMaintDue='Cond Based' " +
                                      " from EQ_PMSList P, EQ_Maintenance M  " +
                                      " where isnull(M.IsCondnBased,0)=1 and P.VesselID=M.VesselID and P.EQ_MaintenanceID=M.EQ_MaintenanceID " +
                                      "     and P.VesselID= " + vesselID +
                                      "     and P.EQ_UnitsID = " + eq_UnitsID + " and P.EQ_MaintenanceID = " + eq_MaintenanceID;
                    PG.Gb.DBFn.Xqry(script);

                    progressBar1.PerformStep();
                }

                isMaintAckDone = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "UpdateSuptToAck", err.Message);
                throw err;
            }
        }

        public void UpdateSuptNotAck()
        {
            string script, suptComments = "";
            int suptNotApprove = 0, vslToViewSuptComments = 0, refNumber = 0, vesselID = -1;
            long eq_PmsList_ClassID = -1, eq_UnitsID = -1, eq_MaintenanceID = -1;

            try
            {
                string updStat = "";
                foreach (DataRow dr in suptRvw.dtSuptToAppr.Rows)
                {
                    suptNotApprove = Convert.ToInt32(dr["SuptToNotAck"].ToString());
                    if (suptNotApprove == 0) continue;

                    suptComments = dr["SuptComments"].ToString().Trim();
                    vslToViewSuptComments = 0;
                    if (suptComments.Length > 0) vslToViewSuptComments = 1;

                    suptComments = "Postponement cancelled by HQ " + Environment.NewLine + suptComments;

                    vesselID = Convert.ToInt32(dr["VesselID"].ToString());
                    eq_UnitsID = Convert.ToInt64(dr["EQ_UnitsID"].ToString());
                    eq_MaintenanceID = Convert.ToInt64(dr["EQ_MaintenanceID"].ToString());
                    eq_PmsList_ClassID = Convert.ToInt64(dr["EQ_PmsList_ClassID"].ToString());
                    refNumber = -1;

                    string sx = dr["mRepRefNo"].ToString();
                    if (sx.Trim().Length > 0) refNumber = Convert.ToInt32(dr["mRepRefNo"].ToString());

                    script = " update EQ_PMSHist set SuptToAck=" + suptNotApprove +
                             "    , VslToViewSuptComments=" + vslToViewSuptComments +
                             "    , SuptComments=" + Gfn.Qss(suptComments.Trim()) +
                             " where VesselId =" + vesselID + " and mRepRefNo = " + refNumber + " ; ";

                    script = script + " Update EQ_PmsList Set mRepRefNo = null " +
                                      "   , UpdStat = " + Gfn.Qss(updStat) +
                                      " from EQ_PmsList L, EQ_PmsHist H " +
                                      " where L.VesselID=H.VesselID and L.EQ_MaintenanceID=H.EQ_MaintenanceID  and L.EQ_UnitsID=H.EQ_UnitsID " +
                                      "   and H.mRepRefNo=" + refNumber +
                                      "   and L.VesselID = " + vesselID +
                                      "   and L.EQ_UnitsID = " + eq_UnitsID +
                                      "   and L.EQ_MaintenanceID = " + eq_MaintenanceID + " ; ";
                    PG.Gb.DBFn.Xqry(script);

                    progressBar1.PerformStep();
                }

                isMaintAckDone = true;
            }
            catch (Exception err)
            {
                Gfn.Wb("Faile to update");
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "UpdateSuptNotAck", err.Message);
            }
        }

        private bool HistContainsAttachment(long pmsHistID)
        {
            bool result = false;
            try
            {
                int cnt = PG.GetPmsHistAttachment(vesselID, pmsHistID);
                result = (cnt > 0);
            }
            catch (Exception err)
            {
                result = false;
                PG.DisplayException("Check hist contains attachment", err.Message);
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "HistContainsAttachment", err.Message);
            }
            return result;
        }

        private string GetCellValue(int row, int col)
        {
            string result = "";
            if (fpSpread1.ActiveSheet.Cells[row, col].Value != null && fpSpread1.ActiveSheet.Cells[row, col].Value.ToString().Length > 0)
            {
                result = fpSpread1.ActiveSheet.Cells[row, col].Value.ToString().Trim().Replace("\n", "\r\n");
            }
            return (result);
        }

        private int GetCellValue_Int(int row, int col)
        {
            int result = 0;
            try
            {
                string sx1 = GetCellValue(row, col);
                if (sx1.Length > 0) result = Convert.ToInt32(sx1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.CS", "GetCellValue_Int", err.Message);
            }
            return (result);
        }

        private long GetCellValue_long(int row, int col)
        {
            long result = 0;
            try
            {
                string sx1 = GetCellValue(row, col);
                if (sx1.Length > 0) result = Convert.ToInt64(sx1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptToApproveMaint.CS", "GetCellValue_Int", err.Message);
            }
            return (result);
        }

        private void lnkViewAlarmAndTestingItems_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMaintInput_AlarmsRoutines pmsInput = new frmMaintInput_AlarmsRoutines();
            try
            {
                if (fpSpread1.ActiveSheet.ActiveCell == null) return;
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

                //pmsInput.eqEquipmentId = GetCellValue(rowIndex, COL_EQPNO);
                pmsInput.calledMode = "VIEW";
                pmsInput.vesselID = vesselID;
                pmsInput.eqUnitId = curEQUnitID;
                pmsInput.eqMaintenanceID = curEQMaintID;
                pmsInput.refNumber = Convert.ToInt32(GetCellValue(rowIndex, COL_MREPREFNO));
                pmsInput.maintType = PG.MAINTTYPE_ALARMS_ROUTINE;
                pmsInput.pms_DocID = curPms_DocID;
                pmsInput.eq_PmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
                pmsInput.ShowDialog();
            }
            finally
            {
                pmsInput.Dispose();
            }
        }


        public void DesignPmsConsumedGrid()
        {
            List<DgvInits> pmsConsumed = new List<DgvInits>();
            try
            {
                pmsConsumed.Add(new DgvInits("ItemDetail", "Part Name", 500, Color.Black, SystemColors.ButtonFace, true, true));
                pmsConsumed.Add(new DgvInits("MakerCode", "Maker Code", 200, Color.Black, SystemColors.ButtonFace, true, true));
                pmsConsumed.Add(new DgvInits("ConsQty", "Qty Used", 100, Color.Black, SystemColors.ButtonFace, true, true));
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadConsumed, pmsConsumed, null, false, true);

                fpSpreadConsumed.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                fpSpreadConsumed.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
            }
            finally
            {
                pmsConsumed = null;
            }
        }

        public void BindAndLoadPmsConsumedGrid()
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            DataTable dtPmsConsumed = null;
            try
            {
                int row = fpSpread1.ActiveSheet.ActiveCell.Row.Index;
                int thismrepRefNo = GetCellValue_Int(row, COL_MREPREFNO);
                int thissRepRefNo = GetCellValue_Int(row, COL_SREPREFNO);

                long thisEq_PmsList_ClassID = GetCellValue_Int(row, COL_EQ_PMSLIST_CLASSID);
                fpSpreadConsumed.ActiveSheet.RowCount = 0;

                string sql = " SELECT M.MakerCode,M.Itemdetail, isnull(C.ConsQty,0) as ConsQty " +
                             " FROM EQ_SPConsumed C , Proc_ItemMaster M  " +
                             " where C.Proc_ItemMasterID=M.Proc_ItemMasterID " +
                             "    and C.VesselID =" + curVesselID +
                             "    and C.EQ_MaintenanceID=" + curEQMaintID +
                             "    and C.EQ_UnitsID=" + curEQUnitID;

                if (thisEq_PmsList_ClassID > 0) sql = sql + "    and C.SrepRefNo = " + thissRepRefNo;
                else sql = sql + "    and C.MrepRefNo = " + thismrepRefNo;

                sql = sql + " Order By C.EQ_SPConsumedID";
                dtPmsConsumed = PG.Gb.DBFn.DbRecords(sql);

                fpSpreadConsumed.ActiveSheet.DataSource = dtPmsConsumed;

                if (dtPmsConsumed != null && dtPmsConsumed.Rows.Count > 0) fpSpreadConsumed_ColumnWidthChanged(null, null);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to get PMS Maintenance Spares Consumed List");
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "BindAndLoadPmsConsumedGrid", err.Message);
            }
            finally
            {
                dtPmsConsumed = null;
            }
        }

        private void DesignMaintAssociatedForms()
        {
            List<DgvInits> assocForms = new List<DgvInits>();
            try
            {
                assocForms.Add(new DgvInits("FormName", "Form Name", 300, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Status", "Status", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Mode", "#", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("InstanceNo", "InstanceNo", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("DefaultParamValue", "DefaultParamValue", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsListID", "FormsListID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsInstancesID", "FormsInstancesID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("IsCompulsory", "IsCompulsory", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("ReportDueDate", "ReportDueDate", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("CompulsoryDisp", "IsComp.", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));                
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadAssociatedForms, assocForms, null, false, true);

                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadAssociatedForms, false, "#", COL_ASSOC_FORMS_MODE, "View", 35, SystemColors.ButtonFace);

                fpSpreadAssociatedForms.ActiveSheet.ColumnHeader.Rows[0].Height = 20;
                fpSpreadAssociatedForms.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpreadAssociatedForms.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;

                foreach (FarPoint.Win.Spread.Row row in fpSpreadAssociatedForms.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            finally
            {
                assocForms = null;
            }
        }


        public bool IsAssociatedFormsExists(long eq_PmsHistID)
        {
            bool result = false;
            string sql;
            try
            {
                sql = " SELECT count(*) " + Environment.NewLine +
                      " FROM EQ_MaintAssociatedForms A, FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                      " where A.VesselID=F.VesselID and A.FormsListID=F.FormsListID " + Environment.NewLine +
                      "      and A.PMS_DocID=H.PMS_DocID " + Environment.NewLine +
                      "      and A.FormsListID=I.FormsListID " + Environment.NewLine +
                      "      and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                      "      and H.VesselID =" + curVesselID + Environment.NewLine +
                      "      and H.EQ_PmsHistID = " + eq_PmsHistID + Environment.NewLine +
                      "      and A.PMS_DocID = " + curPms_DocID;
                result = (Convert.ToInt32(PG.Gb.DBFn.Aqr(sql)) > 0);
            }
            catch (Exception err)
            {
                result = false;
                Gfn.Eb("Failed to check is Associated Forms Exists");
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "IsAssociatedFormsExists", err.Message);
            }
            return result;
        }

        private void BindMaintAssociatedForms()
        {
            List<DgvInits> assocForms = new List<DgvInits>();
            DataTable dtAssociatedForms = null;
            string sql;
            try
            {
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;
                long pmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);

                fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;

                //Associated Forms
                sql = " SELECT A.FormsListID, H.FormsInstancesID, F.FormName, I.Status, I.InstanceNo, F.DefaultParamValue, A.IsCompulsory, I.ReportDueDate " + Environment.NewLine +
                      "    , 'VIEW' AS Mode " + Environment.NewLine +
                      "    , CASE WHEN  A.IsCompulsory= 1 THEN 'Yes' ELSE 'No' END AS CompulsoryDisp " + Environment.NewLine +
                      " FROM EQ_MaintAssociatedForms A, FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                      " where A.VesselID=F.VesselID and A.FormsListID=F.FormsListID " + Environment.NewLine +
                      "      and A.PMS_DocID=H.PMS_DocID " + Environment.NewLine +
                      "      and A.FormsListID=I.FormsListID " + Environment.NewLine +
                      "      and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                      "      and H.VesselID =" + curVesselID + Environment.NewLine +
                      "      and H.EQ_PmsHistID = " + pmsHistID + Environment.NewLine +
                      "      and A.PMS_DocID = " + curPms_DocID;
                dtAssociatedForms = PG.Gb.DBFn.DbRecords(sql);

                fpSpreadAssociatedForms.ActiveSheet.DataSource = dtAssociatedForms;

                foreach (FarPoint.Win.Spread.Row row in fpSpreadAssociatedForms.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to Initialise Associated FormsList");
                PG.AddToGenErrorLog("frmSuptToApproveMaint.cs", "BindMaintAssociatedForms", err.Message);
            }
            finally
            {
                dtAssociatedForms = null;
                assocForms = null;
            }
        }


        private void fpSpreadConsumed_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpreadConsumed.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void fpSpreadConsumed_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpreadConsumed.ActiveSheet.AutoSortColumn(e.Column);
            }
        }

        private void fpSpreadAssociatedForms_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            int rowIndex = e.Row;

            if (e.Column == COL_ASSOC_FORMS_MODE)
            {
                CallAssociatedFormsPage(rowIndex);
            }
        }

        private void CallAssociatedFormsPage(int rowIndex)
        {
            int xvesselID = -1, xInstanceNo = -1; long xFormInstanceID = 0, xFormListID = 0;
            string xCallMode = "", xParamValueList = "", xReportDueDate = "";
            try
            {
                if (rowIndex < 0)
                {
                    return;
                }

                xvesselID = curVesselID;
                xInstanceNo = Convert.ToInt32(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_INSTANCENO].Value.ToString());
                xFormInstanceID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSINSTANCEID].Value.ToString());
                xFormListID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSLISTID].Value.ToString());
                xCallMode = "View";
                xParamValueList = fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_DEFAULTPARAMVALUE].Value.ToString();
                xReportDueDate = Convert.ToDateTime(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_REPORTDUEDATE].Value.ToString()).ToString("dd-MMM-yyyy");

                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                //string param = PG.companaycode + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurUserID + "|HQ|" + xvesselID + "|YES|NO|HqAsVslMode";

                string param = GetParam(vesselID, false);
                //Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);

                VslForms.PG.FillupThisForm(xCallMode, xvesselID, xFormListID, xFormInstanceID, xInstanceNo, xParamValueList, false, PG.Gb, xReportDueDate, "PMS", -1);
            }
            catch (Exception er)
            {
                Gfn.nWb("Failed to edit pending form instance." + Environment.NewLine + "Please contact Administrator");
                PG.AddToGenErrorLog("frmSuptReview.cs", "tsmnuEditPendingForm_Click", er.Message);
            }
        }

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = PG.hqAppFolder + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = PG.hqAppFolder + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode SUPTREVIEW|" + PG.Gb.User.CurrentUserRole + "|YES";
            }
            return param;

        }

        private void fpSpreadAssociatedForms_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        private void lnkViewMaintCheckList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMaintInput_CheckList pmsInput = new frmMaintInput_CheckList();
            try
            {
                if (fpSpread1.ActiveSheet.ActiveCell == null) return;
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

                pmsInput.eq_PmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
                pmsInput.calledMode = "VIEW";
                pmsInput.vesselID = vesselID;
                pmsInput.eqUnitId = curEQUnitID;
                pmsInput.eqMaintenanceID = curEQMaintID;
                pmsInput.refNumber = Convert.ToInt32(GetCellValue(rowIndex, COL_MREPREFNO));
                pmsInput.maintType = PG.MAINTTYPE_PMS;
                pmsInput.pms_DocID = curPms_DocID;
                pmsInput.ShowDialog();
            }
            finally
            {
                pmsInput.Dispose();
            }
        }

        private void lnkViewAttchment_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            long pmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
            //PG.ViewHistAttachment(curVesselID, pmsHistID);
            string eqpName = GetCellValue(rowIndex, COL_EQPNAME);
            frmPmsHistViewAttachments objAttach = new frmPmsHistViewAttachments();
            try
            {
                objAttach.vesselID = GetCellValue_Int(rowIndex, COL_VESSELID);
                objAttach.eqpName = eqpName;
                objAttach.eq_PmsHistID = pmsHistID;
                objAttach.ShowDialog();
            }
            finally
            {
                objAttach = null;
            }
        }

        private void lnkViewAttchmentRoutine_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lnkViewAttchment_LinkClicked(null, null);
        }
        
        private void btnClose_Click(object sender, EventArgs e)
        {
            if (suptRvw.dtSuptToAppr != null && suptRvw.dtSuptToAppr.Rows.Count > 0)
            {
                if (!Gfn.ConfBox("Are you sure cancel the changes and exit?")) return;
            }
            canCloseForm = true;
            this.Close();
        }

        private void frmSuptReview_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!canCloseForm)
            {
                if (suptRvw.dtSuptToAppr != null && suptRvw.dtSuptToAppr.Rows.Count > 0)
                {
                    if (!Gfn.ConfBox("Are you sure cancel the changes and exit?"))
                    {
                        e.Cancel = true;
                        return;
                    }
                }                
            }
            suptRvw = null;
        }
    }
}