﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMaintInput_AlarmsRoutines : Form
    {
        public long eqMaintenanceID = -1, eqUnitId = -1, eqEquipmentId = -1, pms_DocID = -1, eq_PmsHistID= -1; public int vesselID = -1, refNumber = 0;
        public string maintType = "", calledMode = "";
        public DataTable dtPmsListDet, dtPmsHistDet, dtEQ_E0_ItemsHist;

        const int COL_E0DESCRIPTION = 0,
                  COL_SIGNALTYPE = 1,
                  COL_FTC = 2,
                  COL_UNITS = 3,
                  COL_RANGE_LOW = 4,
                  COL_RANGE_HIGH = 5,
                  COL_CURRENTVALUE = 6,
                  COL_STATUS_DONE = 7,
                  COL_STATUS_NOTDONE = 8,
                  COL_COMMENTS = 9,
                  COL_EQ_UNITSID = 10,
                  COL_EQ_E0_FIXEDITEMSLISTID = 11,
                  COL_EQ_E0_VSLITEMSLISTID = 12,
                  COL_EQ_E0_ITEMSHISTID = 13,
                  COL_SIGNAL_TYPEDESC = 14,
                  COL_LOW_LOWER_LIMIT = 15,
                  COL_LOW_LIMIT = 16,
                  COL_HIGH_HIGHER_LIMIT = 17,
                  COL_HIGH_LIMIT = 18,
                  COL_TEST_METHOD = 19,
                  COL_VSLCOMMENTS = 20;

        const string VIEW_MODE = "VIEW";

        public frmMaintInput_AlarmsRoutines()
        {
            InitializeComponent();
        }

        private void frmMaintInput_AlarmsRoutines_Load(object sender, EventArgs e)
        {
            Gfn.SetFormWidthAndHeight(this, 50, 50, Screen.PrimaryScreen.Bounds.Height - 50, 890);

            DesignE0ItemsGrid();

            FillupMaintDetails();
           
            if (calledMode == VIEW_MODE)
            {
                this.Text = "  View Alarms and Routines Report";
                DisableControls();
            }
        }

        private void DesignE0ItemsGrid()
        {
            List<DgvInits> maintColList = new List<DgvInits>();
            try
            {
                bool isReadOnly = (calledMode == VIEW_MODE);
                Color bkColor = Color.FromArgb(225, 255, 225), bkColor1 = Color.White;//235, 255, 235
                if (isReadOnly) bkColor1 = bkColor;
                maintColList.Add(new DgvInits("Description", "Description", 330, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("Signal_Type", "Action", 45, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("FTC", "FTC", 78, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("Units", "Unit", 50, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("Range_Low", "Range Low", 45, Color.Black, SystemColors.ButtonFace, (PG.isToShowRangeValue), true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("Range_High", "Range High", 45, Color.Black, SystemColors.ButtonFace, (PG.isToShowRangeValue), true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("Current_Value", "Current Value (If Applicable)", 80, Color.Black, SystemColors.ButtonFace, (PG.isToShowCurrentValue), isReadOnly, bkColor1, Color.Black));
                maintColList.Add(new DgvInits("Status", "Done ", 40, Color.Black, SystemColors.ButtonFace, true, false, bkColor1, Color.Black));
                maintColList.Add(new DgvInits("Status", "To Do", 80, Color.Black, SystemColors.ButtonFace, true, false, bkColor1, Color.Black));
                maintColList.Add(new DgvInits("Comments", "Remarks", 230, Color.Black, SystemColors.ButtonFace, true, isReadOnly, bkColor1, Color.Black));
                maintColList.Add(new DgvInits("EQ_UnitsID", "EQ_UnitsID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("EQ_E0_FixedItemsListID", "EQ_E0_FixedItemsListID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("EQ_E0_VslItemsListID", "EQ_E0_VslItemsListID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("EQ_E0_ItemsHistID", "EQ_E0_ItemsHistID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("Signal_TypeDesc", "SignalTypeDesc", 40, Color.Black, SystemColors.ButtonFace, false, true));
              
                maintColList.Add(new DgvInits("LL_Limit", "LL_Limit", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("L_Limit", "L_Limit", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("HH_Limit", "HH_Limit", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("H_Limit", "H_Limit", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("Test_Method", "Test_Method", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("VslComments", "VslComments", 40, Color.Black, SystemColors.ButtonFace, false, true));
                
                FarPtColCtrls.GenerateFarPointGridView(fpSpread_E0Items, maintColList, null, false, false, true);

                AssignRadioButton();

                fpSpread_E0Items.ActiveSheet.Columns[COL_STATUS_DONE, COL_STATUS_NOTDONE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread_E0Items.ActiveSheet.Columns[COL_STATUS_DONE, COL_STATUS_NOTDONE].Locked = isReadOnly;

                fpSpread_E0Items.ActiveSheet.Columns[COL_CURRENTVALUE].CellType = AssignNumberTextBoxColumnToFarPointGrid(2, isReadOnly);
                fpSpread_E0Items.ActiveSheet.Columns[COL_RANGE_LOW, COL_CURRENTVALUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;

                FarPoint.Win.Spread.CellType.TextCellType rchtxt = new FarPoint.Win.Spread.CellType.TextCellType();
                rchtxt.Multiline = true;  rchtxt.WordWrap = true;

                fpSpread_E0Items.ActiveSheet.Columns[COL_COMMENTS].CellType = rchtxt;
                ((FarPoint.Win.Spread.CellType.TextCellType)fpSpread_E0Items.ActiveSheet.Columns[COL_COMMENTS].CellType).MaxLength = 250;

                fpSpread_E0Items.ActiveSheet.RowHeader.Columns[0].Width = 35;
                fpSpread_E0Items.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;
                fpSpread_E0Items.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;

                fpSpread_E0Items.ActiveSheet.ColumnHeader.Rows[0].Add();
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_E0DESCRIPTION].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_E0DESCRIPTION].Text = "Description";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_SIGNALTYPE].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_SIGNALTYPE].Text = "Action";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_FTC].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_FTC].Text = "FTC";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_UNITS].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_UNITS].Text = "Unit";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_RANGE_LOW].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_RANGE_LOW].Text = "Range Low";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_RANGE_HIGH].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_RANGE_HIGH].Text = "Range High";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_CURRENTVALUE].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_CURRENTVALUE].Text = "Current Value (If Applicable)";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_COMMENTS].RowSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_COMMENTS].Text = "Remarks";
                                
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_STATUS_DONE].ColumnSpan = 2;
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_STATUS_DONE].Text ="Status";
                fpSpread_E0Items.ActiveSheet.ColumnHeader.Cells[0, COL_STATUS_DONE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            }
            finally
            {
                maintColList = null;
            }
        }

        private void AssignRadioButton()
        {
            FarPoint.Win.Spread.CellType.MultiOptionCellType opt = new FarPoint.Win.Spread.CellType.MultiOptionCellType();
            opt.Items = (new string[] { "Done", "Todo" });                                  
            opt.Orientation = FarPoint.Win.RadioOrientation.Horizontal;
            fpSpread_E0Items.ActiveSheet.Columns[COL_STATUS_DONE].CellType = opt;
            fpSpread_E0Items.ActiveSheet.Columns[COL_STATUS_DONE].Width = 40;
            fpSpread_E0Items.ActiveSheet.Columns[COL_STATUS_DONE].ForeColor = Color.White;
            if (calledMode.Trim().ToUpper() == "VIEW") fpSpread_E0Items.ActiveSheet.Columns[COL_STATUS_DONE].ForeColor = Color.FromArgb(225, 255, 225);
        }

        private void DisableControls()
        {
            btnCancel.Text = "Close";

            groupBox1.Enabled = false;
            groupBox2.Enabled = false;
            grpVerify.Enabled = false;
            dtpDateofTest.Enabled = false;

            txtRemarks.ReadOnly = true;
            txtRemarks.BackColor = SystemColors.Info;
        }

        public static FarPoint.Win.Spread.CellType.NumberCellType AssignNumberTextBoxColumnToFarPointGrid(int decimalPtLength, bool isReadOnly)
        {
            FarPoint.Win.Spread.CellType.NumberCellType txt = new FarPoint.Win.Spread.CellType.NumberCellType();
            txt.FocusPosition = FarPoint.Win.Spread.CellType.EditorFocusCursorPosition.SelectAll;
            txt.EnableSubEditor = false;
            txt.FixedPoint = false;
            //txt.LeadingZero = FarPoint.Win.Spread.CellType.LeadingZero.No;
            txt.NegativeFormat = FarPoint.Win.Spread.CellType.NegativeFormat.NegativeSignBeforeWithSpace;
            //txt.DecimalPlaces = decimalPtLength;
            txt.ReadOnly = isReadOnly;
            txt.MinimumValue = -99999999999;
            if (decimalPtLength == 0) txt.MaximumValue = 99999999999;
            else txt.MaximumValue = 99999999.99;

            return (txt);
        }

        private void FillupMaintDetails()
        {
            DataTable dtPmsHistDet;
            try
            {
                string script = " Select Distinct Dept, IntervalType, IntervalValue, MaintDescription, AddlMaintDescription " +
                                "    , EqpName, PositionDesc, EQ_EquipmentID, PmsCode, LastOhDate, MaintDue, UpdStat, LastOhHrs, EQ_UnitsID " +
                                " from PmsDetails_V " +
                                " where  VesselID=" + vesselID +
                                "    and EQ_UnitsID = " + eqUnitId +
                                "    and EQ_MaintenanceID =" + eqMaintenanceID;
                dtPmsListDet = PG.Gb.DBFn.DbRecords(script);
                if (dtPmsListDet != null && dtPmsListDet.Rows.Count == 1)
                {
                    lbl_EqpName.Text = dtPmsListDet.Rows[0]["EqpName"].ToString() + "  " + dtPmsListDet.Rows[0]["PositionDesc"].ToString();
                    lbl_Maintenance.Text = dtPmsListDet.Rows[0]["MaintDescription"].ToString();
                    string intvType = dtPmsListDet.Rows[0]["IntervalType"].ToString();
                    string interval = dtPmsListDet.Rows[0]["IntervalValue"].ToString();

                    string intvTypeExp = "";
                    if (intvType.Equals("D")) intvTypeExp = "Days";
                    else if (intvType.Equals("W")) intvTypeExp = "Weeks";
                    else if (intvType.Equals("M")) intvTypeExp = "Months";
                    else if (intvType.Equals("Y")) intvTypeExp = "Years";
                    else if (intvType.Equals("H")) intvTypeExp = "Hours";

                    lblInterval.Text = interval + " " + intvTypeExp;
                }

                script = " Select * from EQ_PmsHist " +
                         " where VesselID = " + vesselID +
                         "    and EQ_PmsHistID = " + eq_PmsHistID +
                         "    and mReprefNo=" + refNumber.ToString();
                dtPmsHistDet = PG.Gb.DBFn.DbRecords(script);

                //EQ_E0_ItemsHist
                script = " Select L.Description, V.Signal_Type, L.FTC, V.Units, V.Range_Low, V.Range_High " + Environment.NewLine +
                         "    , I.Current_Value, I.Status, I.Comments, L.EQ_E0_FixedItemsListID, I.EQ_E0_ItemsHistID, V.EQ_UnitsID, V.EQ_E0_VslItemsListID " + Environment.NewLine +
                         "    , Case When (I.Status=1) then 1 else 0 end as IsStatusDone " + Environment.NewLine +
                         "    , Case When (I.Status=0) then 1 else 0 end as IsStatusNotDone " + Environment.NewLine +
                         "    , isnull((select Description from EQ_E0_SignalType where Signal_Type=V.Signal_Type),V.Signal_Type) as Signal_TypeDesc " + Environment.NewLine +
                         "    , V.LL_Limit, V.L_Limit, V.HH_Limit, V.H_Limit, V.Test_Method,  V.Comments as VslComments " + Environment.NewLine +
                         " from EQ_E0_FixedItemsList L, EQ_E0_VslItemsList V, EQ_E0_ItemsHist I, EQ_PmsHist H " + Environment.NewLine +
                         " where L.EQ_E0_FixedItemsListID=V.EQ_E0_FixedItemsListID " + Environment.NewLine +
                         "    and L.EQ_E0_FixedItemsListID=I.EQ_E0_FixedItemsListID " + Environment.NewLine +
                         "    and V.VesselID=H.VesselID and V.EQ_UnitsId=H.EQ_UnitsID " + Environment.NewLine +
                         "    and I.VesselID=H.VesselID and I.EQ_PmsHistID=H.EQ_PmsHistID " + Environment.NewLine +
                         "    and V.EQ_E0_FixedItemsListID=I.EQ_E0_FixedItemsListID " + Environment.NewLine +
                         "    and L.PMS_DocID = " + pms_DocID + Environment.NewLine +
                         "    and H.VesselID = " + vesselID.ToString() + Environment.NewLine +
                         "    and H.EQ_PmsHistID = " + eq_PmsHistID + Environment.NewLine +
                         "    and H.mReprefNo=" + refNumber.ToString() + Environment.NewLine +
                         " Order by L.sortOrder";
                dtEQ_E0_ItemsHist = PG.Gb.DBFn.DbRecords(script);

                //Attachments
                lnkViewHistAttach.Visible = false;

                string maintInstruction = PG.GetHQAndVslMaintenanceInstructions(pms_DocID, vesselID, eqUnitId);
                lnkViewMaintDetails.Visible = (maintInstruction.Length > 0);

                // Verify
                pnlSetLimits.Visible = (PG.isToShowSetLimits);
                pnlRange.Visible = (PG.isToShowRangeValue);
                lblSingalType.Visible = (PG.isToShowSignalType); txtSignalType.Visible = (PG.isToShowSignalType);

                if (dtPmsHistDet != null && dtPmsHistDet.Rows.Count > 0)
                {
                    if ((dtPmsHistDet.Rows[0]["NMDATE"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["NMDATE"] != null))
                        dtpDateofTest.Value = Gfn.ToDate(dtPmsHistDet.Rows[0]["NMDATE"].ToString());
                    txtRemarks.Text = dtPmsHistDet.Rows[0]["VslComments"].ToString().Replace("\n", "\r\n");

                    string mCompl = dtPmsHistDet.Rows[0]["mCompl"].ToString().Trim();
                    if (mCompl == rdoSatisfactory.Text) rdoSatisfactory.Checked = true;
                    else if (mCompl == rdoIncomplete.Text) rdoIncomplete.Checked = true;

                    string place = dtPmsHistDet.Rows[0]["mplace"].ToString().Trim();
                    if (place == rdoSea.Text) rdoSea.Checked = true;
                    else if (place == rdoPort.Text) rdoPort.Checked = true;
                    else if (place == rdoDock.Text) rdoDock.Checked = true;

                    string verified = dtPmsHistDet.Rows[0]["Verified"].ToString().Trim();
                    if (verified == "1") rdoVerifyOk.Checked = true;
                    else if (verified == "0") rdoVerifyToRedo.Checked = true;

                    long pmsHistID = Convert.ToInt64(PG.Gb.DBFn.Aqr("select EQ_PmsHistID from EQ_PmsHist where VesselID= " + vesselID + " and mRepRefno=" + refNumber).ToString());

                    int cnt = PG.GetPmsHistAttachment(vesselID, pmsHistID);
                    lnkViewHistAttach.Visible = (cnt > 0);
                }

                // Enable (or) Disable Maint Instructions
                //chkMaintDoneAsPerInstructions.Visible = (maintInstruction.Length > 0);

                BindE0ItemsList();
            }
            catch (Exception err)
            {
                PG.DisplayException("Fillup Maint Details", err.Message);
                PG.AddToGenErrorLog("frmMaintInput_AlarmsRoutine.cs", "FillupMaintDetails", err.Message);
            }
            finally
            {
                dtPmsHistDet = null;
            }
        }

        private void BindE0ItemsList()
        {
            try
            {
                fpSpread_E0Items.SuspendLayout();
                fpSpread_E0Items.ActiveSheet.DataSource = dtEQ_E0_ItemsHist;

                lblTotalItems.Text = "Total Item(s): 0";
                if (fpSpread_E0Items.ActiveSheet.RowCount > 0)
                {
                    lblTotalItems.Text = "Total Item(s):" + fpSpread_E0Items.ActiveSheet.RowCount;

                    fpSpread_E0Items.ActiveSheet.SetActiveCell(0, 0);
                    if (fpSpread_E0Items.ActiveSheet.RowCount <= 10)
                    {
                        int ht = this.Height;
                        this.Height = 300 + (30 * fpSpread_E0Items.ActiveSheet.RowCount) + 70 + 20;
                        if (this.Height > ht) this.Height = ht;
                    }

                    for (int row = 0; row < fpSpread_E0Items.ActiveSheet.RowCount; row++)
                    {
                        fpSpread_E0Items.ActiveSheet.Cells[row, COL_STATUS_DONE, row, COL_STATUS_NOTDONE].ColumnSpan = 2;
                        if (fpSpread_E0Items.ActiveSheet.Cells[row, COL_STATUS_DONE].Value != null && fpSpread_E0Items.ActiveSheet.Cells[row, COL_STATUS_DONE].Value.ToString() == "1")
                            fpSpread_E0Items.ActiveSheet.Cells[row, COL_STATUS_DONE].Value = "0";
                        else
                            fpSpread_E0Items.ActiveSheet.Cells[row, COL_STATUS_DONE].Value = "1";
                        fpSpread_E0Items.ActiveSheet.Rows[row].Height = fpSpread_E0Items.ActiveSheet.Rows[row].GetPreferredHeight();
                    }
                    fpSpread_E0Items_SelectionChanged(null, null);
                }              
            }
            finally
            {
                fpSpread_E0Items.ResumeLayout();
            }
        }


        private void lnkViewHistAttach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (lblAttachmentFileName.Text.Trim().Length <= 0)
            {
                Gfn.nWbwithAlignAndCentrePosn("There is no attachment file found", ContentAlignment.MiddleCenter);
                return;
            }

            CallViewAttachmentPage();
        }

        private void CallViewAttachmentPage()
        {
            string eqpName = lbl_EqpName.Text;
            frmPmsHistViewAttachments objAttach = new frmPmsHistViewAttachments();
            try
            {
                objAttach.vesselID = vesselID;
                objAttach.eqpName = eqpName;
                objAttach.eq_PmsHistID = eq_PmsHistID;
                objAttach.ShowDialog();
            }
            finally
            {
                objAttach = null;
            }
        }

        private void lnkViewMaintDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmViewMaintDescription viewMaintDesc = new frmViewMaintDescription();
            try
            {
                viewMaintDesc.curVesselID = vesselID;
                viewMaintDesc.curEQUnitID = eqUnitId;
                viewMaintDesc.curEQMaintID = eqMaintenanceID;
                viewMaintDesc.maintType = maintType;
                viewMaintDesc.curPms_DocID = pms_DocID;
                viewMaintDesc.parentMouseXPosn = this.Location.X;
                viewMaintDesc.ShowDialog();
            }
            finally
            {
                viewMaintDesc = null;
            }
        }

        private void fpSpread_E0Items_TextTipFetch(object sender, FarPoint.Win.Spread.TextTipFetchEventArgs e)
        {
            if (e.Row < 0 || e.Column < 0 || e.ColumnHeader) return;

            e.ShowTip = false;
            if (e.Column == COL_SIGNALTYPE)
            {
                e.WrapText = true;
                e.ShowTip = true;
                e.TipText = fpSpread_E0Items.ActiveSheet.Cells[e.Row, COL_SIGNAL_TYPEDESC].Text;
            }
        }

        private void fpSpread_E0Items_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread_E0Items.ContextMenuStrip = null;
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread_E0Items.HitTest(e.X, e.Y).ViewportInfo == null) return;
                int row = fpSpread_E0Items.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread_E0Items.HitTest(e.X, e.Y).ViewportInfo.Column;
                if ((row < 0) || (col < 0)) return;

                fpSpread_E0Items.ActiveSheet.SetActiveCell(row, col);

            }
        }

        private void fpSpread_E0Items_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            if (fpSpread_E0Items.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread_E0Items.ActiveSheet.ActiveRowIndex;

            txtDescription.Text = GetCellValue(rowIndex, COL_E0DESCRIPTION);
            txtLL_Limit.Text = GetCellValue(rowIndex, COL_LOW_LOWER_LIMIT);
            txtL_Limit.Text = GetCellValue(rowIndex, COL_LOW_LIMIT);
            txtH_Limit.Text = GetCellValue(rowIndex, COL_HIGH_LIMIT);
            txtHH_Limit.Text = GetCellValue(rowIndex, COL_HIGH_HIGHER_LIMIT);
            txtRangeLow.Text = GetCellValue(rowIndex, COL_RANGE_LOW);
            txtRangeHigh.Text = GetCellValue(rowIndex, COL_RANGE_HIGH);
            txtTestMethod.Text = GetCellValue(rowIndex, COL_TEST_METHOD);
            txtSignalType.Text = GetCellValue(rowIndex, COL_SIGNAL_TYPEDESC);
            txtComments.Text = GetCellValue(rowIndex, COL_VSLCOMMENTS);
            lnkViewDetails.Visible = (txtTestMethod.Text.Trim().Length > 0);
        }

        private long GetCellValue_long(int row, int col)
        {
            long result = 0;
            string sx1 = GetCellValue(row, col);
            if (sx1.Length > 0)
            {
                result = Convert.ToInt64(sx1);
            }
            return (result);
        }

        private string GetCellValue(int row, int col)
        {
            string result = "";
            if ((fpSpread_E0Items.ActiveSheet.Cells[row, col].Value != null) && (fpSpread_E0Items.ActiveSheet.Cells[row, col].Value.ToString().Trim().Length > 0))
            {
                result = fpSpread_E0Items.ActiveSheet.Cells[row, col].Value.ToString().Trim().Replace("\n", "\r\n");
            }
            return (result);
        }


        private void btnPmsReportLog_Click(object sender, EventArgs e)
        {
            frmPMSReportLog eventLog = new frmPMSReportLog();
            try
            {
                eventLog.eqpNamePosn = lbl_EqpName.Text;
                eventLog.mntDesc = lbl_Maintenance.Text;
                eventLog.mRepRefNo = refNumber;
                eventLog.vesselID = vesselID;
                eventLog.DialogResult = eventLog.ShowDialog();
            }
            finally
            {
                eventLog.Dispose();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void frmMaintInput_AlarmsRoutines_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void lnkViewDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmViewTestMethod obj = new frmViewTestMethod();
            try
            {
                obj.testMethod = txtTestMethod.Text.Trim();
                obj.ShowDialog();
            }
            finally
            {
                obj = null;
            }
        }
    }
}
