﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMaintHistory : Form
    {
        public long curEqEquipmentId, curEQUnitID, curEQMaintID, curPms_DocID;
        public int curVesselID = -1; public bool isRunningHrsEqp = false;
        int thismrepRefNo = 0;
        bool isGridIntialised = false;
        const int COL_NMDATE = 0,
                  COL_MPLACE = 1,
                  COL_MTYPE = 2,
                  COL_MCOMPL = 3,
                  COL_DONEBY = 4,
                  COL_VERIFIEDBY = 5,

                  COL_ATTACH = 6,
                  COL_LOG = 7,
                  COL_VIEWFORM = 8,

                  COL_MREASON = 9,
                  COL_MCOND = 10,
                  COL_MMHRS = 11,
                  COL_MEASUREDVAL = 12,
                  COL_VSLCOMMTS = 13,
                  COL_SUPTCOMMTS = 14,

                  COL_MREPREFNO = 15,
                  COL_SREPREFNO = 16,
                  COL_EQPMSLISTID = 17,
                  COL_EQPMSHISTID = 18,
                  COL_FORMSLISTID = 19,
                  COL_FORMSINSTANCESID = 20,

                  COL_ISMAINTPOSTPONEMENT = 21,
                  COL_NMDATE1 = 22,
                  COL_PREVLASTOHHRS = 23,
                  COL_PREVMAINTDATE = 24,
                  COL_ATTACHCNT = 25,
                  COL_LOGCNT = 26,
                  COL_MAINTCHECKLIST_HISTORYCNT = 27,
                  COL_HASWORKDONEPROCEDURE = 28,
                  COL_CE_MAS_Verify = 29,
                  COL_POSTPONEDATEDISPLAY = 30,
                  COL_MDUEDATEDisplay = 31,
                  COL_ACTUALRUNNINGHRSATMAINT = 32;

        const int XL_COL_NMDATEDISPLAY = 0,
                  XL_COL_MPLACE = 1,
                  XL_COL_MTYPE = 2,
                  XL_COL_MREASON = 3,
                  XL_COL_MCOND = 4,
                  XL_COL_CE_MAS_Verify = 5,
                  XL_COL_MCOMPL = 6,
                  XL_COL_DONEBY = 7,
                  XL_COL_VERIFIEDBY = 8,
                  XL_COL_MEASUREDVAL = 9,
                  XL_COL_MMHRS = 10,
                  XL_COL_MDUEDATEDisplay = 11,
                  XL_COL_POSTPONEDATE = 12,
                  XL_COL_VSLCOMMTS = 13,
                  XL_COL_SUPT_COMMTS = 14;

        const int COL_ASSOC_FORMS_FORMNAME = 0,
                  COL_ASSOC_FORMS_STATUS = 1,
                  COL_ASSOC_FORMS_MODE = 2,
                  COL_ASSOC_FORMS_INSTANCENO = 3,
                  COL_ASSOC_FORMS_DEFAULTPARAMVALUE = 4,
                  COL_ASSOC_FORMS_FORMSLISTID = 5,
                  COL_ASSOC_FORMS_FORMSINSTANCEID = 6,
                  COL_ASSOC_FORMS_ISCOMPULSORY = 7,
                  COL_ASSOC_FORMS_REPORTDUEDATE = 8,
                  COL_ASSOC_FORMS_ISCOMPULSORYDISPLAY = 9;

        MaintHistory mntHist = null;
        public frmMaintHistory()
        {
            InitializeComponent();
        }

        private void frmMaintHistory_Load(object sender, EventArgs e)
        {
            mntHist = new MaintHistory(curVesselID, curEQUnitID, curEQMaintID, curPms_DocID);

            lblEqpname.Text = mntHist.eqpName;
            lblMaintdesc.Text = "[" + mntHist.pmsCode + "] " + mntHist.maintDesc;
            if (PG.isPMS_HidePMSCode) lblMaintdesc.Text = mntHist.maintDesc;
            lblSFICode.Text = mntHist.sfiCode;
            lblSFICode.Visible = (PG.isToShowSFICode);
            lblSFICodeTitle.Visible = (PG.isToShowSFICode);

            DesignPmsConsumedGrid();
            DesignMaintAssociatedForms();
            DesignAndBuildPmsHistGrid();

            Enable_LinksInPmsHistGrid();

            HideAndUnHideFormCtrlsBasedOnMaintType();

            string intvTypeExp = mntHist.intervalType;
            if (intvTypeExp.Equals("D")) intvTypeExp = "Days";
            else if (intvTypeExp.Equals("W")) intvTypeExp = "Weeks";
            else if (intvTypeExp.Equals("M")) intvTypeExp = "Months";
            else if (intvTypeExp.Equals("Y")) intvTypeExp = "Years";
            else if (intvTypeExp.Equals("H")) intvTypeExp = "Hours";

            lblInterval.Text = mntHist.intervalValue + " " + intvTypeExp;
            lblVessel.Text = PG.GetEQ_PMS_Settings(curVesselID, "PMS_VesselCommentsLablelValue");
        }

        public void DesignPmsConsumedGrid()
        {
            List<DgvInits> pmsConsumed = new List<DgvInits>();
            try
            {
                pmsConsumed.Add(new DgvInits("ItemDetail", "Part Name", 300, Color.Black, SystemColors.ButtonFace, true, true));
                pmsConsumed.Add(new DgvInits("MakerCode", "Maker Code", 150, Color.Black, SystemColors.ButtonFace, true, true));
                pmsConsumed.Add(new DgvInits("ConsQty", "Qty Used", 100, Color.Black, SystemColors.ButtonFace, true, true));
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadConsumed, pmsConsumed, null, false, true);

                fpSpreadConsumed.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                fpSpreadConsumed.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
            }
            finally
            {
                pmsConsumed = null;
            }
        }

        private void DesignMaintAssociatedForms()
        {
            List<DgvInits> assocForms = new List<DgvInits>();
            try
            {
                assocForms.Add(new DgvInits("FormName", "Form Name", 135, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Status", "Status", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Mode", "#", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("InstanceNo", "InstanceNo", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("DefaultParamValue", "DefaultParamValue", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsListID", "FormsListID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsInstancesID", "FormsInstancesID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("IsCompulsory", "IsCompulsory", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("ReportDueDate", "ReportDueDate", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("CompulsoryDisp", "Compulsory", 85, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));                
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadAssociatedForms, assocForms, null, false, true);

                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadAssociatedForms, false, "#", COL_ASSOC_FORMS_MODE, "View", 34, SystemColors.ButtonFace);

                fpSpreadAssociatedForms.ActiveSheet.ColumnHeader.Rows[0].Height = 20;
                fpSpreadAssociatedForms.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            }
            finally
            {
                assocForms = null;
            }
        }

        public void DesignAndBuildPmsHistGrid()
        {
            List<DgvInits> histColList = new List<DgvInits>();
            try
            {
                fpSpreadPmsHist.ActiveSheet.RowCount = 0;

                string maintDateTitle = "Maint Date";
                if (mntHist.maintType.Trim().ToUpper() == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE) maintDateTitle = "Date Monitored";
                else if (mntHist.maintType.Trim().ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE) maintDateTitle = "Date of Test";

                histColList.Add(new DgvInits("nmdateDisplay", maintDateTitle, 95, 0, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MPLACE", "Place", 100, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("MTYPE", "Maint Type", 180, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MCOMPL", "Completion", 120, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("DoneBy", "Done By", 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("VerifiedBy", "Verified By", 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("Attachment", " ", 60, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("Log", " ", 30, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("Form", " ", 35, Color.Black, SystemColors.ButtonFace, true, true));

                histColList.Add(new DgvInits("MREASON", "Reason", 100, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("MICOND", "Condition", 120, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("MMHRS", "Man Hrs", 45, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("MeasuredValue", "Measured Value", 70, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("VslComments", "VslComments", 100, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("SuptComments", "SuptComments", 100, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("mRepRefNo", "mrepRefNo", 0, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("sRepRefNo", "sRepRefNo", 0, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("EQ_PmsListID", "EQ_PmsListID", 90, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("EQ_PmsHistID", "EQ_PmsHistID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("FormsListID", "FormsListID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("FormsInstancesID", "FormsInstancesID", 90, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("IsMaintPostponed", "IsMaintPostponed", 90, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("NMDATE", "nmdate", 90, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("PrevLastHours", "PrevLastOhHrs", 40, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("PrevMaintDate", "PrevMaintDate", 40, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("AttachCnt", "AttachCnt", 40, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("logCnt", "logCnt", 10, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("MaintCheckListHistoryCnt", "MaintCheckListHistoryCnt", 40, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("AddlIntField", "AddlIntField", 0, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("CE_MAS_Verify", "CE_MAS_Verify", 0, Color.Black, SystemColors.ButtonFace, false, true));
                histColList.Add(new DgvInits("PostponeDateDisplay", "Postpone Date", 80, 0, Color.Black, SystemColors.ButtonFace, false, true));

                histColList.Add(new DgvInits("MdueDATEDisplay", "Next Maint Due", 105, 0, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("ActualRunningHrsAtMaint", "Actual Running Hrs at time of Maint", 100, 0, Color.Black, SystemColors.ButtonFace, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpreadPmsHist, histColList, mntHist.dtHist, false, true);

                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadPmsHist, false, "Attach", COL_ATTACH, "View", 60, SystemColors.ButtonFace);
                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadPmsHist, false, "Log", COL_LOG, "Log", 30, SystemColors.ButtonFace);
                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadPmsHist, false, "Form", COL_VIEWFORM, "View", 35, SystemColors.ButtonFace);

                fpSpreadPmsHist.ActiveSheet.Columns[COL_LOG].Visible = false;
                fpSpreadPmsHist.ActiveSheet.Columns[COL_MEASUREDVAL].Visible = (mntHist.maintType == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE);

                fpSpreadPmsHist.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpreadPmsHist.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpreadPmsHist.ActiveSheet.ColumnHeader.Rows[0].Height = 24;

                if (fpSpreadPmsHist.ActiveSheet.RowCount > 0)
                {
                    fpSpreadPmsHist.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    fpSpreadPmsHist.ActiveSheet.SelectionFont = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

                    FarPoint.Win.Spread.CellType.TextCellType text = new FarPoint.Win.Spread.CellType.TextCellType();
                    text.WordWrap = true;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_MTYPE, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_MTYPE].CellType = text;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_MPLACE, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_MPLACE].CellType = text;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_MCOMPL, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_MCOMPL].CellType = text;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_DONEBY, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_DONEBY].CellType = text;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_VERIFIEDBY, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_VERIFIEDBY].CellType = text;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_MREASON, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_MREASON].CellType = text;
                    fpSpreadPmsHist.ActiveSheet.Cells[0, COL_MCOND, fpSpreadPmsHist.ActiveSheet.RowCount - 1, COL_MCOND].CellType = text;

                    for (int row = 0; row < fpSpreadPmsHist.ActiveSheet.RowCount; row++)
                    {
                        fpSpreadPmsHist.ActiveSheet.Rows[row].Height = fpSpreadPmsHist.ActiveSheet.Rows[row].GetPreferredHeight();

                        string maintType = fpSpreadPmsHist.ActiveSheet.Cells[row, COL_MTYPE].Value.ToString().ToUpper();

                        if (maintType == PG.MAINTTYPE_ALARMS_ROUTINE) fpSpreadPmsHist.ActiveSheet.Cells[row, COL_MTYPE].Value = "Alarms & Routines";                        
                        else if (maintType == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE.ToUpper()) fpSpreadPmsHist.ActiveSheet.Cells[row, COL_MTYPE].Value = "Condn Monitoring Rtns";
                    }
                }

                isGridIntialised = true;
            }
            finally
            {
                histColList = null;
            }
        }

        protected void Enable_LinksInPmsHistGrid()
        {
            int logCnt;
            long formsInstancesID;
            bool anyFormMaintHistoryFound = false;

            fpSpreadPmsHist.ActiveSheet.Columns[COL_MDUEDATEDisplay].Visible = (mntHist.intervalType.ToUpper() != "H" || mntHist.strToReplaceMaintDue.Trim().Length > 0);

            for (int row = 0; row < fpSpreadPmsHist.ActiveSheet.RowCount; row++)
            {
                // View Log
                logCnt = GetCellValue_Int(row, COL_LOGCNT);
                if (logCnt <= 0)
                {
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_LOG].CellType = new FarPoint.Win.Spread.CellType.GeneralCellType();
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_LOG].Text = "";
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_LOG].Locked = true;
                }

                // View form
                formsInstancesID = GetCellValue_long(row, COL_FORMSINSTANCESID);
                if (formsInstancesID <= 0)
                {
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_VIEWFORM].CellType = new FarPoint.Win.Spread.CellType.GeneralCellType();
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_VIEWFORM].Text = "";
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_VIEWFORM].Locked = true;
                }
                else { anyFormMaintHistoryFound = true; }

                // View Attach
                int attachCnt = GetCellValue_Int(row, COL_ATTACHCNT);
                if (attachCnt <= 0)
                {
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_ATTACH].CellType = new FarPoint.Win.Spread.CellType.GeneralCellType();
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_ATTACH].Text = "";
                    fpSpreadPmsHist.ActiveSheet.Cells[row, COL_ATTACH].Locked = true;
                }
            }

            if (!anyFormMaintHistoryFound)
                fpSpreadPmsHist.ActiveSheet.Columns[COL_VIEWFORM].Visible = false;
        }

        public void HideAndUnHideFormCtrlsBasedOnMaintType()
        {
            lnkViewForm.Visible = false;
            lnkViewMaintDetails.Visible = (PG.GetHQAndVslMaintenanceInstructions(curPms_DocID,curVesselID, curEQUnitID ).Length > 0);
            lnkViewAlarmsRoutinesReport.Visible = false;

            pnlRoutine.Visible = false;
            pnlPMS.Visible = false;
            this.Height = 690;
            if (mntHist.maintType == PG.MAINTTYPE_PMS)
            {
                this.Text = "PMS Item History";
                pnlPMS.Visible = true;
                lblTitle.Text = "Maintenance Title";
                lnkViewMaintDetails.Text = "View Maintenance procedures";
                lblProcedure.Text = "Maintenance done as per Maintenance procedures";
                chkMaintDoneAsPerInstructions.Text = "Maintenance done as per Maintenance procedures";
            }
            else if (mntHist.maintType == PG.MAINTTYPE_ALARMS_ROUTINE)
            {
                this.Text = "Alarms and Routines Item History";
                lblTitle.Text = "Alarms and Routines Title";
                lnkViewMaintDetails.Text = "View Alarms and Routines procedures";
                lblProcedure.Text = "Alarms && Routines done as per Alarms && Routines procedures";
                chkMaintDoneAsPerInstructions.Text = "Alarms && Routines done as per Alarms && Routines procedures";

                tableLayoutPanel1.RowStyles[3].Height = 0;
                pnlRoutine.Visible = true;
                lnkViewAlarmsRoutinesReport.Visible = true;
            }
            else if (mntHist.maintType == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE)
            {
                this.Text = "CM Routine Item History";
                lblTitle.Text = "Routine Title";
                lnkViewMaintDetails.Text = "View CM Routine procedures";
                lblProcedure.Text = "CM Routine  done as per CM Routine  procedures";
                chkMaintDoneAsPerInstructions.Text = "CM Routine  done as per CM Routine  procedures";

                tableLayoutPanel1.RowStyles[3].Height = 0;
            }

            lnkViewMaintDetails.Text = lnkViewMaintDetails.Text + " / Manual Ref";

            lblHistIndicator.Visible = false;
            if (!mntHist.CheckMaintHistExists())
            {
                lblHistIndicator.Visible = true;
                lblHistIndicator.Text = "There is no " + this.Text + " for Current Item.";
                ClearControls();
                return;
            }            
            
            if (fpSpreadPmsHist.ActiveSheet.RowCount > 0)
            {
                fpSpreadPmsHist_SelectionChanged(null, null);
            }
        }

        #region Grid Events

        private void fpSpreadPmsHist_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE1].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
                if (e.Column == COL_NMDATE)
                    fpSpreadPmsHist.ActiveSheet.AutoSortColumn(COL_NMDATE1);
                else
                    fpSpreadPmsHist.ActiveSheet.AutoSortColumn(e.Column);

                fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE].SortIndicator = fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE1].SortIndicator;
            }
        }

        private void fpSpreadPmsHist_AutoSortingColumn(object sender, FarPoint.Win.Spread.AutoSortingColumnEventArgs e)
        {
            fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

            if (e.Column == COL_NMDATE)
            {
                fpSpreadPmsHist.ActiveSheet.AutoSortColumn(COL_NMDATE1);
                fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE].SortIndicator = fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE1].SortIndicator;
                if (!e.Ascending)
                {
                    fpSpreadPmsHist.ActiveSheet.AutoSortColumn(COL_NMDATE1);
                    fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE].SortIndicator = fpSpreadPmsHist.ActiveSheet.Columns[COL_NMDATE1].SortIndicator;
                }
                e.Cancel = true;
            }
        }

        private void fpSpreadPmsHist_AutoSortedColumn(object sender, FarPoint.Win.Spread.AutoSortedColumnEventArgs e)
        {
            fpSpreadPmsHist_SelectionChanged(null, null);
        }

        private void fpSpreadPmsHist_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpreadPmsHist.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }
      
        private void fpSpreadPmsHist_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpreadPmsHist.HitTest(e.X, e.Y).ViewportInfo == null) return;
                int row = fpSpreadPmsHist.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpreadPmsHist.HitTest(e.X, e.Y).ViewportInfo.Column;
                if ((row < 0) || (col < 0)) return;

                fpSpreadPmsHist.ActiveSheet.SetActiveCell(row, col);
                fpSpreadPmsHist_SelectionChanged(null, null);
            }
        }

        private void fpSpreadPmsHist_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            if (!isGridIntialised) return;

            ClearControls();

            if (fpSpreadPmsHist.ActiveSheet.ActiveCell == null) return;

            int rowIndex = fpSpreadPmsHist.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            int row = fpSpreadPmsHist.ActiveSheet.ActiveCell.Row.Index;
            thismrepRefNo = GetCellValue_Int(row, COL_MREPREFNO);
           
            if (GetCellValue_Int(row, COL_ISMAINTPOSTPONEMENT) == 1)
            {
                lblPlace_Postponement.Text = GetCellValuefromPmsHistGrid(row, COL_MPLACE);
                lblPostponementDate.Text = GetCellValuefromPmsHistGrid(row, COL_POSTPONEDATEDISPLAY);
                txtVesselComments.Text = GetCellValuefromPmsHistGrid(row, COL_VSLCOMMTS);
                txtSuptComments.Text = GetCellValuefromPmsHistGrid(row, COL_SUPTCOMMTS);

                pnlPostponement.Visible = true;
                tableLayoutPanel1.RowStyles[2].Height = 46;
                tableLayoutPanel1.RowStyles[3].Height = 0;
                //tableLayoutPanel1.RowStyles[4].Height = 0;
                lblProcedure.Visible = false;
                chkMaintDoneAsPerInstructions.Visible = false;
                pnlRoutine.Visible = false;
                pnlPMS.Visible = false;
                //lnkViewMaintDetails.Visible = false;
            }
            else
            {
                pnlPostponement.Visible = false;
                tableLayoutPanel1.RowStyles[2].Height = 46;
                if (mntHist.maintType == PG.MAINTTYPE_PMS) tableLayoutPanel1.RowStyles[3].Height = 100;

                lnkViewMaintDetails.Visible = PG.CheckMaintProcedureOrManualRefExist(curVesselID, curPms_DocID, curEQUnitID);
                tableLayoutPanel1.RowStyles[4].Height = 25;

                FillupMaintenanceDetails();

                if (mntHist.maintType.Trim().ToUpper() == PG.MAINTTYPE_PMS.ToUpper())
                {
                    long pmsHistID = GetCellValue_long(rowIndex, COL_EQPMSHISTID);

                    BindPmsConsumedGrid();

                    tableLayoutPanel2.ColumnStyles[1].Width = 41.56171f;
                    int col_ItemDetail_Width = 350, col_MakerCode_Width = 150, col_ConsQty_Width = 100;
                    if (mntHist.IsAssociatedFormsExists(pmsHistID) || (mntHist.isAllowedToSelectandFill_RequiredPmsForms))
                    {
                        col_ItemDetail_Width = 290; col_MakerCode_Width = 100; col_ConsQty_Width = 50;
                        BindMaintAssociatedForms();
                    }
                    else
                    {
                        tableLayoutPanel2.ColumnStyles[1].Width = 0;
                    }

                    fpSpreadConsumed.ActiveSheet.Columns[0].Width = col_ItemDetail_Width;
                    fpSpreadConsumed.ActiveSheet.Columns[1].Width = col_MakerCode_Width;
                    fpSpreadConsumed.ActiveSheet.Columns[2].Width = col_ConsQty_Width;

                    pnlPMS.Visible = true;
                    if (!lnkViewMaintDetails.Visible) tableLayoutPanel1.RowStyles[4].Height = 0;
                }
                else if (mntHist.maintType == PG.MAINTTYPE_ALARMS_ROUTINE)
                {
                    pnlRoutine.Visible = true;
                    pnlPostponement.Visible = false;
                    if (!lnkViewMaintDetails.Visible) tableLayoutPanel1.RowStyles[4].Height = 0;
                }
            }
        }

        private void fpSpreadPmsHist_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            int rowIndex = e.Row;

            if (e.Column == COL_LOG)          //EventLog
            {
                CallEventLogPage(rowIndex);
            }
            else if (e.Column == COL_VIEWFORM) //VIEWFORM
            {
                CallFormsPage(rowIndex);
            }
            else if (e.Column == COL_ATTACH)  //VIEWAttachment
            {
                long pmsHistID = GetCellValue_long(rowIndex, COL_EQPMSHISTID);
                //PG.ViewHistAttachment(curVesselID, pmsHistID);
                CallViewAttachmentPage(pmsHistID);
            }
        }

        private void CallViewAttachmentPage(long pmsHistID)
        {
            string eqpName = lblEqpname.Text;
            frmPmsHistViewAttachments objAttach = new frmPmsHistViewAttachments();
            try
            {
                objAttach.vesselID = curVesselID;
                objAttach.eqpName = eqpName;
                objAttach.eq_PmsHistID = pmsHistID;
                objAttach.ShowDialog();
            }
            finally
            {
                objAttach = null;
            }
        }

        private void fpSpreadPmsHist_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }


        private void fpSpreadConsumed_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpreadConsumed.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void fpSpreadConsumed_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpreadConsumed.ActiveSheet.AutoSortColumn(e.Column);
            }
        }

        #endregion

        private string GetCellValuefromPmsHistGrid(int row, int col)
        {
            string result = "";
            if ((fpSpreadPmsHist.ActiveSheet.Cells[row, col].Value != DBNull.Value) &&
                (fpSpreadPmsHist.ActiveSheet.Cells[row, col].Value != null) &&
                (fpSpreadPmsHist.ActiveSheet.Cells[row, col].Value.ToString().Trim().Length > 0))
            {
                result = fpSpreadPmsHist.ActiveSheet.Cells[row, col].Value.ToString().Trim().Replace("\n", "\r\n");
            }
            return (result);
        }

        private long GetCellValue_long(int row, int col)
        {
            long result = -1;
            string sx1 = GetCellValuefromPmsHistGrid(row, col);
            if (sx1.Length > 0)
            {
                result = Convert.ToInt64(sx1);
            }
            return (result);
        }

        private int GetCellValue_Int(int row, int col)
        {
            int result = -1;
            string sx1 = GetCellValuefromPmsHistGrid(row, col);
            if (sx1.Length > 0)
            {
                result = Convert.ToInt32(sx1);
            }
            return (result);
        }

        private void ClearControls()
        {
            txtVesselComments.Text = "";
            txtSuptComments.Text = "";

            lblManHrs.Text = "";
            lblReason.Text = "";
            lblCondition.Text = "";
            lblCompletion.Text = "";
            lblPlace.Text = "";

            lnkViewMaintCheckList.Visible = false;
            lnkViewAlarmsRoutinesReport.Visible = false;
            fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;
            fpSpreadConsumed.ActiveSheet.RowCount = 0;

            lblLocation.Text = "";
            lblVerifiy.Text = "";
            lblResult.Text = "";
            tableLayoutPanel2.ColumnStyles[1].Width = 0;

            lblPlace_Postponement.Text = "";
            lblPostponementDate.Text = "";

            chkMaintDoneAsPerInstructions.Visible = false;
            lblProcedure.Visible = false;
            lnkViewMaintDetails.Visible = false;
        }

        private void FillupMaintenanceDetails()
        {
            if (fpSpreadPmsHist.ActiveSheet.ActiveCell == null) return;

            int row = fpSpreadPmsHist.ActiveSheet.ActiveRowIndex;

            txtVesselComments.Text = GetCellValuefromPmsHistGrid(row, COL_VSLCOMMTS);
            txtSuptComments.Text = GetCellValuefromPmsHistGrid(row, COL_SUPTCOMMTS);

            chkMaintDoneAsPerInstructions.Visible = false;
            lblProcedure.Visible = false;

            lblActualRunningHours.Visible = false; lblActualRunningHours_Display.Visible = false;

            if (mntHist.maintType.Trim().ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE)
            {
                lblLocation.Text = GetCellValuefromPmsHistGrid(row, COL_MPLACE);
                lblVerifiy.Text = GetCellValuefromPmsHistGrid(row, COL_CE_MAS_Verify).ToString();
                lblResult.Text = GetCellValuefromPmsHistGrid(row, COL_MCOMPL);
             
                lblResult.BackColor = Color.AliceBlue;
                lblResult.ForeColor = SystemColors.ControlText;
                if (lblResult.Text.ToUpper() == "InComplete".ToUpper())
                {
                    lblResult.BackColor = Color.Yellow;
                    lblResult.ForeColor = Color.Black;
                }
                lnkViewAlarmsRoutinesReport.Visible = true;
            }
            else
            {
                lblManHrs.Text = GetCellValuefromPmsHistGrid(row, COL_MMHRS);
                lblReason.Text = GetCellValuefromPmsHistGrid(row, COL_MREASON);
                lblCondition.Text = GetCellValuefromPmsHistGrid(row, COL_MCOND);
                lblCompletion.Text = GetCellValuefromPmsHistGrid(row, COL_MCOMPL);
                lblPlace.Text = GetCellValuefromPmsHistGrid(row, COL_MPLACE);

                lblCompletion.BackColor = Color.AliceBlue;
                lblCompletion.ForeColor = SystemColors.ControlText;
                lblCompletion.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
                if ((lblCompletion.Text.ToUpper() == PG.MCOMPL_STOPGAP_MEASUREONLY) || (lblCompletion.Text.ToUpper() == PG.MCOMPL_TOREDO_AT_DRYDOCKING) || (lblCompletion.Text.ToUpper() == PG.MCOMPL_TOREDO_WHEN_SPARESRECVD))
                {
                    lblCompletion.BackColor = Color.Red;
                    lblCompletion.ForeColor = Color.White;
                    lblCompletion.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
                }

                lblReason.ForeColor = Color.Black;
                if ((lblReason.Text.ToUpper() == PG.MREASON_BREAKDOWN) || (lblReason.Text.ToUpper() == PG.MREASON_LEAKAGES) || (lblReason.Text.ToUpper() == PG.MREASON_POOR_EFFICIENCY))
                {
                     lblReason.ForeColor = Color.Red;
                }

                lblCondition.ForeColor = Color.Black;
                if ((lblCondition.Text.ToUpper() == PG.MCOND_IN_VERY_POORSTATE) || (lblCondition.Text.ToUpper() == PG.MCOND_HEAVILY_CARBONISED))
                {
                    lblCondition.ForeColor = Color.Red;
                }

                int checkListHistCnt = Convert.ToInt32(GetCellValuefromPmsHistGrid(row, COL_MAINTCHECKLIST_HISTORYCNT));
                lnkViewMaintCheckList.Visible = (checkListHistCnt > 0);

                chkMaintDoneAsPerInstructions.Checked = (GetCellValuefromPmsHistGrid(row, COL_HASWORKDONEPROCEDURE) == "1");
                chkMaintDoneAsPerInstructions.Visible = false;
                lblProcedure.Visible = false;
                if (checkListHistCnt <= 0)
                {
                    string maintInstructions = PG.GetHQAndVslMaintenanceInstructions(curPms_DocID, curVesselID, curEQUnitID);
                    chkMaintDoneAsPerInstructions.Visible = (maintInstructions.Trim().Length > 0);
                    lblProcedure.Visible = (maintInstructions.Trim().Length > 0);

                    if (GetCellValue_Int(row, COL_MREPREFNO) > 0)
                    {
                        lblProcedure.Text = " Maintenance done as per Maintenance procedures";
                        chkMaintDoneAsPerInstructions.Text = " Maintenance done as per Maintenance procedures";
                    }
                    else if (GetCellValue_Int(row, COL_SREPREFNO) > 0)
                    {
                        lblProcedure.Text = " Survey done as per Maintenance procedures";
                        chkMaintDoneAsPerInstructions.Text = " Survey done as per Maintenance procedures";
                    }
                }
                if (isRunningHrsEqp)
                {
                    lblActualRunningHours.Visible = true; lblActualRunningHours_Display.Visible = true;
                    lblActualRunningHours.Text = GetCellValuefromPmsHistGrid(row, COL_ACTUALRUNNINGHRSATMAINT);
                }
            }
        }

        public void BindPmsConsumedGrid()
        {
            if (fpSpreadPmsHist.ActiveSheet.ActiveCell == null) return;

            DataTable dtPmsConsumed = null;
            fpSpreadConsumed.SuspendLayout();
            try
            {
                fpSpreadConsumed.ActiveSheet.RowCount = 0;

                dtPmsConsumed = mntHist.GetPMSConsumedDataTable(thismrepRefNo);
                fpSpreadConsumed.ActiveSheet.DataSource = dtPmsConsumed;
            }
            finally
            {
                fpSpreadConsumed.ResumeLayout();
                dtPmsConsumed = null;
            }
        }

        private void BindMaintAssociatedForms()
        {
            DataTable dtAssociatedForms;
            fpSpreadAssociatedForms.SuspendLayout();
            try
            {
                fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;

                int rowIndex = fpSpreadPmsHist.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;

                long pmsHistID = GetCellValue_long(rowIndex, COL_EQPMSHISTID);
                dtAssociatedForms = mntHist.GetAssociatedFormsList(pmsHistID);

                fpSpreadAssociatedForms.ActiveSheet.DataSource = dtAssociatedForms;

                foreach (FarPoint.Win.Spread.Row row in fpSpreadAssociatedForms.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            finally
            {
                fpSpreadAssociatedForms.ResumeLayout();
                dtAssociatedForms = null;
            }
        }

        private void CallEventLogPage(int rowIndex)
        {
            frmEventLog eventLog = new frmEventLog();
            try
            {
                eventLog.eqpNamePosn = lblEqpname.Text;
                eventLog.mntDesc = lblMaintdesc.Text;
                eventLog.mReportRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                eventLog.DialogResult = eventLog.ShowDialog();
            }
            finally
            {
                eventLog.Dispose();
            }
        }

        private void CallFormsPage(int rowIndex)
        {
            try
            {
                long maintFormId = GetCellValue_long(rowIndex, COL_FORMSLISTID);
                long formsInstanceID = GetCellValue_long(rowIndex, COL_FORMSINSTANCESID);
                int instanceNo = mntHist.GetInstanceNo(formsInstanceID);
                string callMode = "View", category = ""; // note:- category used to fillup some dropdowns in the form , for View not needed

                string script = "Select ReportDueDate from FormsInstances where FormsInstancesID=" + formsInstanceID + " and FormsListID=" + maintFormId;
                string reportDueDate = PG.Gb.DBFn.Aqr(script).ToString();
                if (reportDueDate.Length > 0) reportDueDate = Convert.ToDateTime(reportDueDate).ToString("dd-MMMM-yyyy");

                int refNumber = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                string specialParam = curEqEquipmentId + "," + curEQUnitID + "," + curEQMaintID + "," + category + "," + refNumber;
                string Params = curVesselID + "||" + maintFormId + "||" + formsInstanceID + "||" + instanceNo + "||" + callMode + "||" + specialParam + "||" + reportDueDate;
                VslForms.DirectCall.CallThisForm(Params, PG.Gb);
            }
            catch (Exception err)
            {
                Gfn.nMb("Failed to Call Forms Page " + err.Message);
                PG.AddToGenErrorLog("frmMaintHistory.cs", "CallFormsPage", err.Message);
            }
        }
        

        private void fpSpreadAssociatedForms_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            int rowIndex = e.Row;

            if (e.Column == COL_ASSOC_FORMS_MODE)
            {
                CallAssociatedFormsPage(rowIndex);
            }
        }

        private void fpSpreadAssociatedForms_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        private void CallAssociatedFormsPage(int rowIndex)
        {
            int vesselID, instanceNo; long formInstanceID, formListID;
            string callMode, paramValueList, reportDueDate;
            try
            {
                if (rowIndex < 0) return;

                vesselID = curVesselID;
                instanceNo = Convert.ToInt32(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_INSTANCENO].Value.ToString());
                formInstanceID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSINSTANCEID].Value.ToString());
                formListID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSLISTID].Value.ToString());
                callMode = "View";
                //callMode = ((FarPoint.Win.Spread.CellType.HyperLinkCellType)fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_MODE].CellType).Text.ToString();
                paramValueList = fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_DEFAULTPARAMVALUE].Value.ToString();
                reportDueDate = Convert.ToDateTime(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_REPORTDUEDATE].Value.ToString()).ToString("dd-MMM-yyyy");

                VslForms.PG.FillupThisForm(callMode, vesselID, formListID, formInstanceID, instanceNo, paramValueList, false, PG.Gb, reportDueDate, "PMS", -1);
            }
            catch (Exception er)
            {
                Gfn.nWb("Failed to call associate form instance.");
                PG.AddToGenErrorLog("frmMaintHistory.cs", "CallAssociatedFormsPage", er.Message);
            }
        }


        private void lnkViewMaintDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmViewMaintDescription viewMaintDesc = new frmViewMaintDescription();
            try
            {
                viewMaintDesc.curVesselID = curVesselID;
                viewMaintDesc.curEQUnitID = curEQUnitID;
                viewMaintDesc.curEQMaintID = curEQMaintID;
                viewMaintDesc.maintType = mntHist.maintType;
                viewMaintDesc.curPms_DocID = curPms_DocID;
                viewMaintDesc.parentMouseXPosn = this.Location.X;
                viewMaintDesc.ShowDialog();
            }
            finally
            {
                viewMaintDesc = null;
            }
        }

        private void lnkViewMaintCheckList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (fpSpreadPmsHist.ActiveSheet.ActiveCell == null) return;

            frmMaintInput_CheckList pmsInput = new frmMaintInput_CheckList();
            try
            {
                pmsInput.calledMode = "VIEW";
                pmsInput.vesselID = curVesselID;
                pmsInput.eqEquipmentId = curEqEquipmentId;
                pmsInput.eqUnitId = curEQUnitID;
                pmsInput.eqMaintenanceID = curEQMaintID;
                pmsInput.refNumber = thismrepRefNo;
                pmsInput.maintType = PG.MAINTTYPE_PMS;
                pmsInput.pms_DocID = curPms_DocID;
                int rowIndex = fpSpreadPmsHist.ActiveSheet.ActiveRowIndex;
                pmsInput.eq_PmsHistID = GetCellValue_long(rowIndex, COL_EQPMSHISTID);
                pmsInput.ShowDialog();
            }
            finally
            {
                pmsInput.Dispose();
            }
        }

        private void lnkViewAlarmsRoutinesReport_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (fpSpreadPmsHist.ActiveSheet.ActiveCell == null) return;

            frmMaintInput_AlarmsRoutines pmsInput = new frmMaintInput_AlarmsRoutines();
            try
            {
                pmsInput.calledMode = "VIEW";
                pmsInput.vesselID = curVesselID;
                pmsInput.eqEquipmentId = curEqEquipmentId;
                pmsInput.eqUnitId = curEQUnitID;
                pmsInput.eqMaintenanceID = curEQMaintID;
                pmsInput.refNumber = thismrepRefNo;
                pmsInput.maintType = PG.MAINTTYPE_ALARMS_ROUTINE;
                pmsInput.pms_DocID = curPms_DocID;
                int rowIndex = fpSpreadPmsHist.ActiveSheet.ActiveRowIndex;
                pmsInput.eq_PmsHistID = GetCellValue_long(rowIndex, COL_EQPMSHISTID);
                pmsInput.ShowDialog();
            }
            finally
            {
                pmsInput.Dispose();
            }
        }

        private void lnkViewForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            long maintFormId = mntHist.maintFormNo;
            long formsInstanceID = -1;
            int instanceNo = -1;
            string callMode = "View", category = "";
            long curEQUnitID = mntHist.curEQUnitID;
            long curEQMaintID = mntHist.curEQMaintID;
            int refNumber = -1;
            string specialParam = curEQUnitID + "," + curEQMaintID + "," + category + "," + refNumber;
            string Params = curVesselID + "||" + maintFormId + "||" + formsInstanceID + "||" + instanceNo + "||" + callMode + "||" + specialParam;
            VslForms.DirectCall.CallThisForm(Params, PG.Gb);
        }


        private void btnExportXL_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            DataTable dt = null;
            FarPoint.Win.Spread.FpSpread fs = new FarPoint.Win.Spread.FpSpread();
            try
            {
                DateTime todaysDate = PG.GetDbServerDate();
                dt = mntHist.GetExportDataTable();
                if (dt == null)
                {
                    Gfn.nMbwithAlignAndCentrePosn("No rows to export", ContentAlignment.MiddleCenter, 100, 250);
                    return;
                }

                DesignAndFillupExportGrid(fs, dt, todaysDate);
                string script = " SELECT vslcode FROM V_Vessels where VesselID=" + curVesselID;
                string vslcode = PG.Gb.DBFn.Aqr(script).ToString().ToUpper();

                string fileName = PG.xlsOutputFolderPath + "\\" + vslcode + "_MaintHistory_" + todaysDate.ToString("ddMMMyyyy_hhmmssff") + ".xls";
                if (fileName.Length == 0) return;
                if (!Gfn.DeleteFileIfExists(fileName)) return;
                bool hasExportedSuccessfully = (fs.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            finally
            {
                fs = null;
                dt = null;
                this.Cursor = Cursors.Default;
            }
        }

        private void DesignAndFillupExportGrid(FarPoint.Win.Spread.FpSpread fs, DataTable dt, DateTime todaysDate)
        {
            List<DgvInits> histColList = new List<DgvInits>();
            try
            {
                fs.SuspendLayout();

                FarPoint.Win.Spread.SheetView fs_Sheet1 = new FarPoint.Win.Spread.SheetView();
                fs.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] { fs_Sheet1 });
                FarPoint.Win.Spread.DefaultSpreadSkins.Classic.Apply(fs);
                fs.Font = new Font("Verdana", 8, FontStyle.Regular);

                string maintDateTitle = "Maint Date", completionTitle = "Completion";
                if (mntHist.maintType.Trim().ToUpper() == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE)
                {
                    maintDateTitle = "Date Monitored";
                    completionTitle = "Result";
                }
                else if (mntHist.maintType.Trim().ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE)
                {
                    maintDateTitle = "Date of Test";
                    completionTitle = "Result";
                }

                histColList.Add(new DgvInits("nmdateDisplay", maintDateTitle, 90, 0, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MTYPE", "Maint Type", 110, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MPLACE", "Place", 120, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MREASON", "Reason", 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MICOND", "Condition", 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("CE_MAS_Verify", "Status", 90, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MCOMPL", completionTitle, 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("DoneBy", "Done By", 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("VerifiedBy", "Verified By", 150, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MeasuredValue", "Measured Value", 70, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MMHRS", "Man Hrs", 50, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("MdueDATEDisplay", "Next Maint Due", 90, 0, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("PostponeDateDisplay", "Postpone Date", 80, 0, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("WorkDoneProcedure", lblVessel.Text, 250, Color.Black, SystemColors.ButtonFace, true, true));
                histColList.Add(new DgvInits("SuptComments", "Supt Comments", 250, Color.Black, SystemColors.ButtonFace, true, true));

                FarPtColCtrls.GenerateFarPointGridView(fs, histColList, dt, false, true, false);
                fs.ActiveSheet.Columns[XL_COL_MEASUREDVAL].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;
                fs.ActiveSheet.Columns[XL_COL_MMHRS].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;
                fs.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;
                fs.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fs.ActiveSheet.Columns[XL_COL_MEASUREDVAL].Visible = (mntHist.maintType == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE);
                fs.ActiveSheet.Columns[XL_COL_MDUEDATEDisplay].Visible = fpSpreadPmsHist.ActiveSheet.Columns[COL_MDUEDATEDisplay].Visible;

                fs.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, Color.Empty);
                fs.ActiveSheet.VerticalGridLine = gdln;
                fs.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                if ((fs.ActiveSheet.RowCount > 0) && (fs.ActiveSheet.ColumnCount > 0))
                {
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].VisualStyles = FarPoint.Win.VisualStyles.Off;

                    fs.ActiveSheet.Cells[0, 0, fs.ActiveSheet.RowCount - 1, fs.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                }

                //Add Vsl Name row to grid heading
                fs.ActiveSheet.ColumnHeader.Rows[0].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].Text = PG.GetVslName(curVesselID);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 14, FontStyle.Bold);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].ForeColor = Color.Blue;
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fs.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                //Common Heading and date
                fs.ActiveSheet.ColumnHeader.Rows[1].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(1, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].Text = this.Text + "       " + todaysDate.ToString("dd-MMM-yyyy");
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 12, FontStyle.Bold);
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fs.ActiveSheet.ColumnHeader.Rows[1].Height = 20;

                //Equipment Name
                string filter = "Equipment     : " + lblEqpname.Text + Environment.NewLine +
                                 lblTitle.Text + " : " + lblMaintdesc.Text;
                fs.ActiveSheet.ColumnHeader.Rows[2].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(2, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[2, 0].Text = filter;
                fs.ActiveSheet.ColumnHeader.Cells[2, 0].Font = new Font("Arial", 10, FontStyle.Bold);
                fs.ActiveSheet.ColumnHeader.Cells[2, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[2, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fs.ActiveSheet.ColumnHeader.Rows[2].Height = 40;

                if (fs.ActiveSheet.RowCount > 0)
                {
                    FarPoint.Win.Spread.CellType.TextCellType text = new FarPoint.Win.Spread.CellType.TextCellType();
                    text.WordWrap = true;
                    fs.ActiveSheet.Cells[0, XL_COL_MTYPE, fs.ActiveSheet.RowCount - 1, XL_COL_MTYPE].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_MPLACE, fs.ActiveSheet.RowCount - 1, XL_COL_MPLACE].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_MREASON, fs.ActiveSheet.RowCount - 1, XL_COL_MREASON].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_MCOND, fs.ActiveSheet.RowCount - 1, XL_COL_MCOND].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_MCOMPL, fs.ActiveSheet.RowCount - 1, XL_COL_MCOMPL].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_DONEBY, fs.ActiveSheet.RowCount - 1, XL_COL_DONEBY].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_VERIFIEDBY, fs.ActiveSheet.RowCount - 1, XL_COL_VERIFIEDBY].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_VSLCOMMTS, fs.ActiveSheet.RowCount - 1, XL_COL_VSLCOMMTS].CellType = text;
                    fs.ActiveSheet.Cells[0, XL_COL_SUPT_COMMTS, fs.ActiveSheet.RowCount - 1, XL_COL_SUPT_COMMTS].CellType = text;
                    if ((mntHist.maintType.ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE))
                    {
                        fs.ActiveSheet.Columns[XL_COL_MMHRS].Visible = false;
                        fs.ActiveSheet.Columns[XL_COL_MREASON].Visible = false;
                        fs.ActiveSheet.Columns[XL_COL_MCOND].Visible = false;
                        fs.ActiveSheet.Columns[XL_COL_CE_MAS_Verify].Visible = true;
                        fs.ActiveSheet.Columns[XL_COL_MEASUREDVAL].Visible = false;
                    }
                    else
                    {
                        fs.ActiveSheet.Columns[XL_COL_MMHRS].Visible = true;
                        fs.ActiveSheet.Columns[XL_COL_MCOND].Visible = true;
                        fs.ActiveSheet.Columns[XL_COL_CE_MAS_Verify].Visible = false;
                        fs.ActiveSheet.Columns[XL_COL_MEASUREDVAL].Visible = false;
                    }
                    for (int row = 0; row < fpSpreadPmsHist.ActiveSheet.RowCount; row++)
                    {
                        fs.ActiveSheet.Rows[row].Height = fs.ActiveSheet.Rows[row].GetPreferredHeight();
                    }

                }
                fs.ActiveSheet.Protect = false;
            }
            catch (Exception err)
            {
                Gfn.nMb("Failed to export Planned Maintenance History " + err.Message);
                PG.AddToGenErrorLog("frmMaintHistory.cs", "DesignAndFillupExportGrid", err.Message);
            }
            finally
            {
                fs.ResumeLayout();
                histColList = null;
            }
        }


        private void frmMaintHistory_FormClosing(object sender, FormClosingEventArgs e)
        {
            mntHist = null;
        }
    }
}