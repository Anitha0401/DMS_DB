﻿using System;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmViewTestMethod : Form
    {
        public string testMethod = "";

        public frmViewTestMethod()
        {
            InitializeComponent();
        }

        private void frmViewTestMethod_Load(object sender, EventArgs e)
        {
            FillUpTestMethod();
        }

        private void FillUpTestMethod()
        {
            try
            {
                txtTestMethod.Text = testMethod;

                string script = " Select TestMethodDescription from EQ_Maint_TestMethodDetails " +
                                " where Test_Method=" + Gfn.Qss(testMethod);
                txtDescription.Text = PG.Gb.DBFn.Aqr(script).ToString();

                label2.Visible = (txtDescription.Text.Trim().Length > 0);
                txtDescription.Visible = (txtDescription.Text.Trim().Length > 0);
                lblNoDescription.Visible = (txtDescription.Text.Trim().Length <= 0);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmViewTestMethod.cs", "FillUpTestMethod", err.Message);
            }
        }
    }
}
