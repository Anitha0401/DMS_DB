using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmSearchEquipments : Form
    {
        public int vesselID = -1;
        public string gcode, defaultEqpGroup = "";
        public long curEqEquipmentID, selectedEqEquipmentID, selectedEQ_GroupsID = -1;
        public bool isToFilterEqpHavingPMS = false;
        const int COL_EQPNAME = 0, COL_SFICODE = 1, COL_EQ_EQUIPMENTID = 6, COL_EQ_GROUPSID = 7;

        public frmSearchEquipments()
        {
            InitializeComponent();
        }

        private void frmSearchEquipments_Load(object sender, EventArgs e)
        {
            GetGroupCode();

            DesignEquipmentsGrid();

            lblEqpName.Text = "";
            tStsTotalItems.Text = "";
            rdoSFICode.Visible = (PG.isToShowSFICode);

            btnOption.Text = "+";
            tableLayoutPanel1.RowStyles[1].Height = 0;
        }

        private void GetGroupCode()
        {
            try
            {
                if (gcode.Trim().Length > 0) return;

                string qryStr = " Select Top 1 LEFT(isNull(SortCode,''),1) from EQ_Equipment_V E, EQ_Units U" +
                                " Where U.IsDisabled=0 and E.EQ_EquipmentId= U.EQ_EquipmentId " +
                                "    and U.VesselId = " + vesselID + " and E.EQ_EquipmentId = " + curEqEquipmentID +
                                "    and GroupType=" + Gfn.Qs(defaultEqpGroup);
                gcode = PG.Gb.DBFn.Aqr(qryStr).ToString();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSearchEquipments.cs", "GetGroupCode", err.Message);
            }
        }

        private void DesignEquipmentsGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                Color bkColor = SystemColors.Info;
                colList.Add(new DgvInits("EqpName", "Eqpt Name", 190, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                colList.Add(new DgvInits("SFICode", "SFI Code", 130, Color.Black, SystemColors.ButtonFace, (PG.isToShowSFICode) , true, bkColor, Color.Black)); 
                colList.Add(new DgvInits("Maker", "Maker", 180, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                colList.Add(new DgvInits("Model", "Model", 140, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                colList.Add(new DgvInits("DwgNo", "Dwg No.", 80, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                colList.Add(new DgvInits("vesselId", "vesselId", 80, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                colList.Add(new DgvInits("EQ_EquipmentID", "EQ_EquipmentID", 0, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                colList.Add(new DgvInits("EQ_GroupsID", "EQ_GroupsID", 0, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("EQ_ModelsID", "EQ_ModelsID", 0, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("GroupName", "GroupName", 200, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));

                FarPtColCtrls.GenerateFarPointGridView(fpEquipment, colList, null, false, true, true);

                fpEquipment.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;

                fpEquipment.ActiveSheet.RowHeader.Columns[0].Width = 22;
                fpEquipment.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                fpEquipment.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
            }
            finally
            {
                colList = null;
            }
        }

        private void btnOption_Click(object sender, EventArgs e)
        {
            if (btnOption.Text == "-")
            {
                tableLayoutPanel1.RowStyles[1].Height = 0;
                btnOption.Text = "+";
            }
            else if (btnOption.Text == "+")
            {
                tableLayoutPanel1.RowStyles[1].Height = 78;
                btnOption.Text = "-";
            }
        }

        private void btnGO_Click(object sender, EventArgs e)
        {
            try
            {
                fpEquipment.SuspendLayout();
                if (txtSearch.Text.Trim().ToString() == "")
                {
                    Gfn.nWbwithAlignAndCentrePosn("Enter text to find and try again", ContentAlignment.MiddleCenter);
                    return;
                }
                lblEqpName.Text = "";

                fpEquipment.ActiveSheet.Rows.Clear();
                fpEquipment.ActiveSheet.DataSource = SearchData();
                if (fpEquipment.ActiveSheet.RowCount > 0) fpEquipment_ColumnWidthChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSearchEquipments.cs", "btnGO_Click", err.Message);
            }
            finally
            {
                fpEquipment.ResumeLayout();
            }
        }

        public DataTable SearchData()
        {
            string sx1 = "", sxScope = "";
            DataTable dtTbl = null;
            try
            {
                if (rdoCurrentGroup.Checked == true) { sxScope = " and E.GroupCode = '" + gcode + "'"; }
                else if (rdoAllGroups.Checked == true) { sxScope = "  "; }

                string field = "";
                if (rdoEqptName.Checked == true) field = " U.EqpUnitDescription";// " E.EqpName";
                else if (rdoSFICode.Checked == true) field = " E.SFICode";
                else if (rdoModel.Checked == true) field = " ML.Model";
                else if (rdoMaker.Checked == true) field = " MR.Maker";
               
                if (rdoEqptName.Checked == true)
                {
                    sx1 = "    and ( " + GetSearchCombination(" E.EqpName") + " or " + GetSearchCombination("U.EqpUnitDescription") + " ) ";
                }
                else
                {
                    sx1 = GetSearchCombination(field);
                    if (sx1.Trim().Length > 0) sx1 = "    and ( " + sx1 + " ) ";
                }

                if (vesselID > 0) sx1 = sx1 + "    and U.VesselID = " + vesselID + Environment.NewLine;

                string script = " Select Distinct E.EQ_EquipmentID, U.EqpUnitDescription as EqpName, E.GroupName, E.SFICode " + Environment.NewLine + // 
                                "    , MR.Maker, ML.Model, DWGNO, U.EQ_ModelsID, E.GroupSortOrder, E.SortCode, EQ_GroupsID " + Environment.NewLine +
                                " from EQ_Equipment_V E, EQ_Units U, EQ_Models ML, EQ_Makers MR " + Environment.NewLine +
                                " where U.IsDisabled=0 and E.EQ_EquipmentID=U.EQ_EquipmentID " + Environment.NewLine +
                                "    and U.EQ_ModelsID = ML.EQ_ModelsID " + Environment.NewLine +
                                "    and ML.EQ_MakersID = MR.EQ_MakersID " + Environment.NewLine +
                               
                                sx1 + sxScope + Environment.NewLine +
                                "    and GroupType=" + Gfn.Qs(defaultEqpGroup) + Environment.NewLine +
                                " Order by E.GroupSortOrder, E.SortCode ";
                dtTbl = PG.Gb.DBFn.DbRecords(script);

                // For status for search results
                tStsTotalItems.Text = "Search item Not Found";
                if (dtTbl != null) tStsTotalItems.Text = dtTbl.Rows.Count + " matching item(s) found";
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSearchEquipments.cs", "SearchData", err.Message);
            }

            return dtTbl;
        }

        public string GetSearchCombination(string field)
        {
            string keyWords = "", result = " ";
            string[] searchList = txtSearch.Text.Trim().Split(' ');

            PG.Permute(searchList, 0, searchList.Length, ref keyWords);

            if (keyWords.Length > 0) keyWords = keyWords.Substring(0, keyWords.Length - 1);

            string sx2;
            string[] keyWordList = keyWords.Trim().Split('~');
            for (int i = 0; i < keyWordList.Length; i++)
            {
                if (keyWordList[i].Trim().Length > 0)
                {
                    sx2 = keyWordList[i];
                    if (chkEmbedSearch.Checked) { sx2 = "%" + sx2 + "%"; }

                    if (chkCaseSensitive.Checked) result = result + "( " + field + " Like " + Gfn.Qss(sx2) + "   COLLATE SQL_Latin1_General_CP1_CS_AS )";
                    else result = result + "( " + field + " Like " + Gfn.Qss(sx2) + ")";

                    if (i != (keyWordList.Length - 1)) result = result + " OR ";
                }
            }
            return (result);
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnGO_Click(null, null);
            }
        }

        private void fpEquipment_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            if (fpEquipment.ActiveSheet != null && fpEquipment.ActiveSheet.Rows.Count > 0)
            {
                int arow = fpEquipment.ActiveSheet.ActiveRow.Index;
                if (arow < 0) return;
                lblEqpName.Text = fpEquipment.ActiveSheet.Cells[arow, COL_EQPNAME].Value.ToString();
            }
        }

        private void fpEquipment_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader) return;
            Eqp_Details();
        }


        private void btnOk_Click(object sender, EventArgs e)
        {
            Eqp_Details();
        }

        private void Eqp_Details()
        {
            if (fpEquipment.ActiveSheet != null && fpEquipment.ActiveSheet.Rows.Count > 0)
            {
                int arow = fpEquipment.ActiveSheet.ActiveRow.Index;
                if (arow < 0) return;

                selectedEqEquipmentID = -1;
                if (fpEquipment.ActiveSheet.Cells[arow, COL_EQ_EQUIPMENTID].Value != null)
                    selectedEqEquipmentID = Convert.ToInt64(fpEquipment.ActiveSheet.Cells[arow, COL_EQ_EQUIPMENTID].Value.ToString());
                if (fpEquipment.ActiveSheet.Cells[arow, COL_EQ_GROUPSID].Value != null)
                    selectedEQ_GroupsID = Convert.ToInt64(fpEquipment.ActiveSheet.Cells[arow, COL_EQ_GROUPSID].Value.ToString());
                
            }

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void fpEquipment_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            if (fpEquipment.ActiveSheet.RowCount > 0)
            {
                foreach (FarPoint.Win.Spread.Row row in fpEquipment.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            fpEquipment.ActiveSheet.Rows.Clear();
            fpEquipment.ActiveSheet.DataSource = SearchData();
            if (fpEquipment.ActiveSheet.RowCount > 0) fpEquipment_ColumnWidthChanged(null, null);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}