﻿using System;
using System.Data;

using Sds.CommonV1;

namespace HqSDS_Main
{
    class SuptReview
    {
        public DataTable dtSuptAck = null, dtSuptToAppr = null;

        public SuptReview()
        {
            InitialiseTempDataTable();
            InitialiseToApproveTempDataTable();
        }

        public DataTable GetSuptQDataTable(int vesselId, string callMode, string filterStr)
        {
            string script, addlCondn = "", orderby = "";
            DataTable dt = null;
            try
            {
                string groupType = PG.GetDefaultGroupType(vesselId);

                // addlCondition
                addlCondn = " and Isnull(H.suptToAck,0)=0 ";
                if (callMode == "RECENT_REPORT")
                {
                    addlCondn = " and H.nMDate>Getdate()-30 ";
                }

                if (filterStr.Trim().Length > 0)
                {
                    addlCondn = addlCondn + "    and (   ( " + PG.GetSearchCombination(" EqpName", filterStr) + " ) " +
                                            "         or ( " + PG.GetSearchCombination(" P.MaintDescription ", filterStr) + " )  " +
                                            "        )  ";
                }
                if (PG.isExcludeVerificationItemsFromDueList) addlCondn = addlCondn + "    and P.mRepRefNo is null " + Environment.NewLine;

                // basic SQL               
                script = " Select P.InChargeRank, P.ReponsibleRank, H.* " +
                        "    , replace(CONVERT(varchar(11),nMdate,113),' ','-')  as nMdate_Display, P.EqpName " + Environment.NewLine +
                        "    , P.PositionDesc, 0 IsSuptApproved , '' SuptComments, P.PMS_DocID, P.MaintType " + Environment.NewLine +
                        "    , P.MaintDescription as MaintDescription " + Environment.NewLine +
                        "    , P.PmsCode,P.PMM_DocRefno, P.MaintCode, P.Component " + Environment.NewLine +
                        "    , case H.Dept when 'E' then 'Engine'  " + Environment.NewLine +
                        "                  when 'L' then 'Electrical'  " + Environment.NewLine +
                        "                  when 'D' then 'Deck'  " + Environment.NewLine +
                        "                  when 'R' then 'Radio'  " + Environment.NewLine +
                        "      end as DeptDisplayStr     " + Environment.NewLine +
                        "    , cast(H.IntervalValue as varchar(15))+' '+ H.IntervalType Interval, MeasuredValue " + Environment.NewLine +
                        "    , case when(Verified =1) then 'Ok' when(Verified =0) then 'Not Accepted' when(Verified =-1) then '? (C/E or MAS Verify)'  else '' end   CE_MAS_Verify " + Environment.NewLine +
                        "    , ActualRunningHrsAtMaint " + Environment.NewLine +
                        " from Eq_PMSHist H, PmsDetails_V P " + Environment.NewLine +
                        " Where H.VesselID= " + vesselId +
                        "    and Isnull(H.suptToAck,0)=0   " + Environment.NewLine +
                        "    and H.IsMaintPostponed=0 " + Environment.NewLine +
                        "    and H.VesselID  =P.VesselID  and H.EQ_EquipmentID = P.EQ_EquipmentID  and H.EQ_UnitsID = P.EQ_UnitsID and H.EQ_MaintenanceID=P.EQ_MaintenanceID " + Environment.NewLine +
                        "    and GroupCode <>'" + PG.EQUIPMENT_GROUPCODE_CRITICAL + "'" +
                        addlCondn;                   

                // orderby
                orderby = " order by nmDate ";
                
                script = script +  orderby;
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("SuptReview.cs", "BindSuptQGrid()", err.Message);
                Gfn.nWb("Failed to bind SuptQ details");
            }

            return (dt);
        }

        public void InitialiseTempDataTable()
        {
            try
            {
                string sql = " select VesselId, mRepRefNo, SuptToAck, SuptComments, sRepRefNo, EQ_PmsList_ClassID, EQ_UnitsID, EQ_MaintenanceID " + 
                             " from EQ_PmsHist where 1=2 ";
                dtSuptAck = PG.Gb.DBFn.GetEmptyDataStructure(sql);
            }
            catch (Exception err)
            {
                dtSuptAck = null;
                PG.AddToGenErrorLog("SuptReview.cs", "InitialiseTempDataTable", err.Message);
            }
        }

        public void AddEditSuptToAckInTempDataTable(int vesselId, int mRepRefNo, int suptToAck, string suptComments, long eq_PmsList_ClassID, int sRepRefNo, long eq_UnitsID, long eq_MaintenanceID)
        {
            if (dtSuptAck == null) return;
            DataRow[] dr = null;
            DataRow dataRw = null;
            try
            {
                string filter = " VesselId=" + vesselId + " and mRepRefNo=" + mRepRefNo;
                if (eq_PmsList_ClassID > 0) filter = " VesselId=" + vesselId + " and sRepRefNo=" + sRepRefNo;

                dr = dtSuptAck.Select(filter);
                if (dr != null && dr.Length > 0)
                {
                    if (suptComments.Trim().Length <= 0 && suptToAck == 0)
                    {
                        dtSuptAck.Rows.Remove(dr[0]);
                    }
                    else
                    {
                        dr[0]["SuptToAck"] = suptToAck;
                        dr[0]["SuptComments"] = suptComments;
                    }
                }
                else
                {
                    if (suptToAck == 1)
                    {
                        dataRw = dtSuptAck.NewRow();
                        dataRw["VesselId"] = vesselId;
                        dataRw["SuptToAck"] = suptToAck;
                        dataRw["SuptComments"] = suptComments;
                        dataRw["mRepRefNo"] = mRepRefNo;
                        dataRw["sRepRefNo"] = sRepRefNo;
                        dataRw["EQ_PmsList_ClassID"] = eq_PmsList_ClassID;
                        dataRw["EQ_UnitsID"] = eq_UnitsID;
                        dataRw["EQ_MaintenanceID"] = eq_MaintenanceID;
                        dtSuptAck.Rows.Add(dataRw);
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("SuptReview.cs", "AddEditSuptToAckInTempDataTable", err.Message);
            }
            finally
            {
                dr = null;
                dataRw = null;
            }
        }

        public void SendBackToVslForAmendments(int vesselId, int mRepRefNo, string suptComments, long eq_UnitsID, long eq_MaintenanceID)
        {
            try
            {
                string script = " update EQ_PMSHist set IsToVslRedoMaint=1, SuptToAck=1 " +
                                "    , SuptComments=" + Gfn.Qss(suptComments) +
                                " where VesselId=" + vesselId + " and EQ_UnitsID=" + eq_UnitsID +
                                "    and EQ_MaintenanceID=" + eq_MaintenanceID + " and mRepRefNo=" + mRepRefNo;
                PG.Gb.DBFn.Xqry(script);

                script = " update EQ_PMSList_PlannedItems set IsJobDone= 0, UpdatedBy='App' " +
                         " from EQ_PMSList_PlannedItems P, EQ_PmsHist H " +
                         " where P.VesselId =H.VesselId  and P.EQ_UnitsID =H.EQ_UnitsID and P.EQ_MaintenanceID=H.EQ_MaintenanceID " +
                         "    and Year(NmDate) = P.Yr and Month(NmDate) = P.Mon " +
                         "    and P.VesselId =" + vesselId + " and P.EQ_UnitsID =" + eq_UnitsID +
                         "    and P.EQ_MaintenanceID=" + eq_MaintenanceID +
                         "    and H.mRepRefNo = " + mRepRefNo + " and P.IsJobDone= 0 ";
                PG.Gb.DBFn.Xqry(script);

                script = " select P.Yr, P.Mon from EQ_PMSList_PlannedItems P, EQ_PmsHist H " +
                         " where P.VesselId =H.VesselId  and P.EQ_UnitsID =H.EQ_UnitsID and P.EQ_MaintenanceID=H.EQ_MaintenanceID " +
                         "    and Year(NmDate) = P.Yr and Month(NmDate) = P.Mon " +
                         "    and P.VesselId =" + vesselId + " and P.EQ_UnitsID =" + eq_UnitsID +
                         "    and P.EQ_MaintenanceID=" + eq_MaintenanceID +
                         "    and H.mRepRefNo = " + mRepRefNo;
                DataTable dtRefresh = PG.Gb.DBFn.DbRecords(script);

                if (dtRefresh != null)
                {
                    foreach (DataRow drRefresh in dtRefresh.Rows)
                    {
                        string spName = "HQ_PMS_Refresh_EQ_PMSList_Planned_Done_Odue";
                        string[] paramField = new string[] { "@VesselID", "@Yr", "@Mon" };
                        object[] paramValue = new object[] { vesselId, drRefresh["Yr"].ToString(), drRefresh["Mon"].ToString() };
                        PG.RefreshHQDashboard_SP(spName, paramField, paramValue, vesselId);
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("SuptReview.cs", "SendBackToVslForAmendments", err.Message);
            }
        }



        public DataTable GetSuptToApproveDataTable(int vesselId, string filterStr)
        {
            string script, addlCondn = "";
            DataTable dt = null;
            try
            {
                string groupType = PG.GetDefaultGroupType(vesselId);

                if (filterStr.Trim().Length > 0)
                {
                    addlCondn = "    and (   ( " + PG.GetSearchCombination(" P.EqpName", filterStr) + " ) " +
                                "         or ( " + PG.GetSearchCombination(" MaintDescription ", filterStr) + " )  " +
                                "        )  ";                    
                }

                script = " Select distinct H.*, replace(CONVERT(varchar(11),nMdate,113),' ','-')  as nMdate_Display, EqpName " + Environment.NewLine +
                         "    , PositionDescDisplay PositionDesc, 0 IsSuptApproved, '' SuptComments, PMS_DocID, MaintType " + Environment.NewLine +
                         "    , replace(CONVERT(varchar(11),PostponeDate,113),' ','-') Postponedate_Display " + Environment.NewLine +
                         "    , P.MaintDescription as MaintDescription " + Environment.NewLine +
                         "    , (cast(H.IntervalValue as varchar(15))+' '+ H.IntervalType) as Interval, P.InChargeRank InChargeRank_Pms, P.ReponsibleRank ReponsibleRank_Pms, P.PmsCode, P.PMM_DocRefno, P.MaintCode, P.Component " + Environment.NewLine +
                         "    , case H.Dept when 'E' then 'Engine'  " + Environment.NewLine +
                         "                  when 'L' then 'Electrical'  " + Environment.NewLine +
                         "                  when 'D' then 'Deck'  " + Environment.NewLine +
                         "                  when 'R' then 'Radio'  " + Environment.NewLine +
                         "      end as DeptDisplayStr     " + Environment.NewLine +
                         " from Eq_PMSHist H, PMSDetails_V P " +
                         " Where H.VesselID= " + vesselId +
                         "    and Isnull(H.suptToAck,0)=0    " + Environment.NewLine +
                         "    and H.IsMaintPostponed in (1,2) " + Environment.NewLine +
                         "    and P.GroupCode<>'" + PG.EQUIPMENT_GROUPCODE_CRITICAL +"' " + 
                         "    and H.VesselID =P.VesselID and H.EQ_UnitsID = P.EQ_UnitsID and H.EQ_MaintenanceID=P.EQ_MaintenanceID and H.mRepRefNo = isnull(P.mRepRefNo, 0) " + Environment.NewLine +
                         addlCondn;                        
                script = script + " order by nmDate ";
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("SuptReview.cs", "GetSuptToApproveDataTable()", err.Message);
                Gfn.nWb("Failed to bind SuptQ details");
            }

            return (dt);
        }
       
        public void InitialiseToApproveTempDataTable()
        {
            try
            {
                string script = " select VesselId, mRepRefNo, SuptToAck, SuptToAck as SuptToNotAck, SuptComments, sRepRefNo, EQ_PmsList_ClassID, EQ_UnitsID, EQ_MaintenanceID " +
                                " from EQ_PmsHist where 1=2 ";
                dtSuptToAppr = PG.Gb.DBFn.GetEmptyDataStructure(script);
            }
            catch (Exception err)
            {
                dtSuptToAppr = null;
                PG.AddToGenErrorLog("SuptReview.cs", "InitialiseTempDataTable", err.Message);
            }
        }

        public void AddEditSuptToApproveInTempDataTable(int vesselId, int suptToApprove, int suptToNotApprove, string suptComments,  int mRepRefNo, int sRepRefNo,
                                                        long eq_UnitsID, long eq_MaintenanceID, long eq_PmsList_ClassID)
        {
            if (dtSuptAck == null) return;

            DataRow[] dr = null;
            DataRow dataRw = null;
            try
            {
                string filter = " VesselId=" + vesselId + " and mRepRefNo=" + mRepRefNo;
                if (eq_PmsList_ClassID > 0) filter = " VesselId=" + vesselId + " and sRepRefNo=" + sRepRefNo;

                dr = dtSuptToAppr.Select(filter);
                if (dr != null && dr.Length > 0)
                {
                    if (suptComments.Trim().Length <= 0 && (suptToApprove == 0 && suptToNotApprove==0))
                    {
                        dtSuptToAppr.Rows.Remove(dr[0]);
                    }
                    else
                    {
                        dr[0]["SuptToAck"] = suptToApprove;
                        dr[0]["SuptToNotAck"] = suptToNotApprove;
                        dr[0]["SuptComments"] = suptComments;
                    }
                }
                else
                {
                    dataRw = dtSuptToAppr.NewRow();
                    dataRw["VesselId"] = vesselId;
                    dataRw["SuptToAck"] = suptToApprove;
                    dataRw["SuptToNotAck"] = suptToNotApprove;
                    dataRw["SuptComments"] = suptComments;
                    dataRw["mRepRefNo"] = mRepRefNo;
                    dataRw["sRepRefNo"] = sRepRefNo;
                    dataRw["EQ_UnitsID"] = eq_UnitsID;
                    dataRw["EQ_MaintenanceID"] = eq_MaintenanceID;
                    dataRw["EQ_PmsList_ClassID"] = eq_PmsList_ClassID;
                    dtSuptToAppr.Rows.Add(dataRw);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("SuptReview.cs", "AddEditSuptToApproveInTempDataTable", err.Message);
            }
            finally
            {
                dr = null;
                dataRw = null;
            }
        }

    }
}
