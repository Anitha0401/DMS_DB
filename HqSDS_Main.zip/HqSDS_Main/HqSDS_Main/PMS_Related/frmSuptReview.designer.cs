﻿namespace HqSDS_Main
{
    partial class frmSuptReview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer enhancedColumnHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer enhancedRowHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSuptReview));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer5 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("ColumnHeaderSandstorm");
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("RowHeaderSandstorm");
            FarPoint.Win.Spread.NamedStyle namedStyle3 = new FarPoint.Win.Spread.NamedStyle("CornerSandstorm");
            FarPoint.Win.Spread.CellType.EnhancedCornerRenderer enhancedCornerRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedCornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle4 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer6 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer7 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer8 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnEnterSuptComments = new System.Windows.Forms.Button();
            this.btnSendBackToVSL = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnGo = new System.Windows.Forms.Button();
            this.chkShowHistory = new System.Windows.Forms.CheckBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnMarkAllNormalReports = new System.Windows.Forms.Button();
            this.btnUnMarkAll = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblSvrName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblTotalItems = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panelLoading = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lblComments = new System.Windows.Forms.Label();
            this.lnkViewMaintDetails = new System.Windows.Forms.LinkLabel();
            this.txtVslComments = new System.Windows.Forms.TextBox();
            this.lblProcedure = new System.Windows.Forms.Label();
            this.chkMaintDoneAsPerInstructions = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.fpSpreadConsumed = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadConsumed_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel8 = new System.Windows.Forms.Panel();
            this.fpSpreadAssociatedForms = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadAssociatedForms_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtSuptComments = new System.Windows.Forms.TextBox();
            this.lblSuptCom = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.pnlPMS = new System.Windows.Forms.Panel();
            this.lblPlace = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.lnkViewMaintCheckList = new System.Windows.Forms.LinkLabel();
            this.lblActualRunningHours = new System.Windows.Forms.Label();
            this.lblActualRunningHours_Display = new System.Windows.Forms.Label();
            this.lblManHrs = new System.Windows.Forms.Label();
            this.lblMaintCode = new System.Windows.Forms.Label();
            this.lblMaintType1 = new System.Windows.Forms.Label();
            this.lnkViewAlarmAndTestingItems = new System.Windows.Forms.LinkLabel();
            this.label16 = new System.Windows.Forms.Label();
            this.lblPMMRefNo = new System.Windows.Forms.Label();
            this.lblCompletion = new System.Windows.Forms.Label();
            this.lblComponent = new System.Windows.Forms.Label();
            this.lblResponsibleRank = new System.Windows.Forms.Label();
            this.lblComp = new System.Windows.Forms.Label();
            this.lblDept = new System.Windows.Forms.Label();
            this.lblPMM = new System.Windows.Forms.Label();
            this.lblMaint = new System.Windows.Forms.Label();
            this.lblResponsible = new System.Windows.Forms.Label();
            this.lblCondition = new System.Windows.Forms.Label();
            this.lblInChargeRank = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblInCharge = new System.Windows.Forms.Label();
            this.lblInterval = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lnkViewAttchment = new System.Windows.Forms.LinkLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.pnlRoutine = new System.Windows.Forms.Panel();
            this.lblMaintType = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblVerifiy = new System.Windows.Forms.Label();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblres = new System.Windows.Forms.Label();
            this.lblver = new System.Windows.Forms.Label();
            this.lblLoc = new System.Windows.Forms.Label();
            this.lblIntervalRoutine = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblDeptRoutine = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblResponsibleRankRoutine = new System.Windows.Forms.Label();
            this.lblResponsibleRoutine = new System.Windows.Forms.Label();
            this.lblInChargeRankRoutine = new System.Windows.Forms.Label();
            this.lblInChargeRoutine = new System.Windows.Forms.Label();
            this.lblMaintCodeRoutine = new System.Windows.Forms.Label();
            this.lblMaintRoutine = new System.Windows.Forms.Label();
            this.lblPMMRefNoRoutine = new System.Windows.Forms.Label();
            this.lblPMMRoutine = new System.Windows.Forms.Label();
            this.lblCompRoutine = new System.Windows.Forms.Label();
            this.lblComponentRoutine = new System.Windows.Forms.Label();
            this.lnkViewAttchmentRoutine = new System.Windows.Forms.LinkLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmnuSuptComments = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuMaintHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMnuSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuSendBackToVslForAmendments = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panelLoading.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed_Sheet1)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.pnlPMS.SuspendLayout();
            this.pnlRoutine.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            enhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.Goldenrod;
            enhancedColumnHeaderRenderer1.Name = "enhancedColumnHeaderRenderer1";
            enhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.Tan;
            enhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.BurlyWood;
            enhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.Tan;
            enhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.BurlyWood;
            enhancedColumnHeaderRenderer1.TextRotationAngle = 0D;
            enhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.Goldenrod;
            enhancedRowHeaderRenderer1.Name = "enhancedRowHeaderRenderer1";
            enhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.Tan;
            enhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.BurlyWood;
            enhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.Tan;
            enhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.BurlyWood;
            enhancedRowHeaderRenderer1.TextRotationAngle = 0D;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1008, 733);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnExport);
            this.panel1.Controls.Add(this.btnEnterSuptComments);
            this.panel1.Controls.Add(this.btnSendBackToVSL);
            this.panel1.Controls.Add(this.txtSearch);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.btnGo);
            this.panel1.Controls.Add(this.chkShowHistory);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.btnMarkAllNormalReports);
            this.panel1.Controls.Add(this.btnUnMarkAll);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1008, 50);
            this.panel1.TabIndex = 0;
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.Location = new System.Drawing.Point(740, 4);
            this.btnExport.Margin = new System.Windows.Forms.Padding(0);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(36, 44);
            this.btnExport.TabIndex = 76;
            this.btnExport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Visible = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnEnterSuptComments
            // 
            this.btnEnterSuptComments.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEnterSuptComments.Location = new System.Drawing.Point(778, 4);
            this.btnEnterSuptComments.Name = "btnEnterSuptComments";
            this.btnEnterSuptComments.Size = new System.Drawing.Size(73, 44);
            this.btnEnterSuptComments.TabIndex = 75;
            this.btnEnterSuptComments.Text = "Enter Supt Comments";
            this.btnEnterSuptComments.UseCompatibleTextRendering = true;
            this.btnEnterSuptComments.UseVisualStyleBackColor = true;
            this.btnEnterSuptComments.Visible = false;
            this.btnEnterSuptComments.Click += new System.EventHandler(this.btnEnterSuptComments_Click);
            // 
            // btnSendBackToVSL
            // 
            this.btnSendBackToVSL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSendBackToVSL.Location = new System.Drawing.Point(853, 4);
            this.btnSendBackToVSL.Name = "btnSendBackToVSL";
            this.btnSendBackToVSL.Size = new System.Drawing.Size(58, 44);
            this.btnSendBackToVSL.TabIndex = 74;
            this.btnSendBackToVSL.Text = "Send Back\r\nTo VSL";
            this.btnSendBackToVSL.UseCompatibleTextRendering = true;
            this.btnSendBackToVSL.UseVisualStyleBackColor = true;
            this.btnSendBackToVSL.Visible = false;
            this.btnSendBackToVSL.Click += new System.EventHandler(this.btnSendBackToVSL_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtSearch.Location = new System.Drawing.Point(484, 20);
            this.txtSearch.MaxLength = 15;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(123, 20);
            this.txtSearch.TabIndex = 10;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnClear.Location = new System.Drawing.Point(636, 17);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(38, 23);
            this.btnClear.TabIndex = 73;
            this.btnClear.Text = "clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(484, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 13);
            this.label12.TabIndex = 72;
            this.label12.Text = "Filter:";
            // 
            // btnGo
            // 
            this.btnGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnGo.Location = new System.Drawing.Point(608, 17);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(29, 23);
            this.btnGo.TabIndex = 11;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // chkShowHistory
            // 
            this.chkShowHistory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkShowHistory.AutoSize = true;
            this.chkShowHistory.BackColor = System.Drawing.SystemColors.Info;
            this.chkShowHistory.Checked = true;
            this.chkShowHistory.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowHistory.ForeColor = System.Drawing.Color.Blue;
            this.chkShowHistory.Location = new System.Drawing.Point(680, 13);
            this.chkShowHistory.Name = "chkShowHistory";
            this.chkShowHistory.Size = new System.Drawing.Size(65, 30);
            this.chkShowHistory.TabIndex = 9;
            this.chkShowHistory.Text = "Show \r\nDetails";
            this.chkShowHistory.UseVisualStyleBackColor = false;
            this.chkShowHistory.CheckedChanged += new System.EventHandler(this.chkShowHistory_CheckedChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(362, 21);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(118, 16);
            this.progressBar1.TabIndex = 8;
            this.progressBar1.Visible = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(167, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 44);
            this.label1.TabIndex = 7;
            this.label1.Text = "To enter Supt Comments right-click on the Maintenance item in the grid and select" +
    " \"Supt Comments\"";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Location = new System.Drawing.Point(917, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(82, 44);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "Acknowledge";
            this.btnUpdate.UseCompatibleTextRendering = true;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnMarkAllNormalReports
            // 
            this.btnMarkAllNormalReports.Location = new System.Drawing.Point(73, 2);
            this.btnMarkAllNormalReports.Name = "btnMarkAllNormalReports";
            this.btnMarkAllNormalReports.Size = new System.Drawing.Size(93, 45);
            this.btnMarkAllNormalReports.TabIndex = 1;
            this.btnMarkAllNormalReports.Text = "Mark All Normal Reports as Read";
            this.btnMarkAllNormalReports.UseCompatibleTextRendering = true;
            this.btnMarkAllNormalReports.UseVisualStyleBackColor = true;
            this.btnMarkAllNormalReports.Click += new System.EventHandler(this.btnMarkAllNormalReports_Click);
            // 
            // btnUnMarkAll
            // 
            this.btnUnMarkAll.Location = new System.Drawing.Point(3, 2);
            this.btnUnMarkAll.Name = "btnUnMarkAll";
            this.btnUnMarkAll.Size = new System.Drawing.Size(70, 45);
            this.btnUnMarkAll.TabIndex = 0;
            this.btnUnMarkAll.Text = "UnMark All marked Reports";
            this.btnUnMarkAll.UseCompatibleTextRendering = true;
            this.btnUnMarkAll.UseVisualStyleBackColor = true;
            this.btnUnMarkAll.Click += new System.EventHandler(this.btnUnMarkAll_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblSvrName,
            this.tsLblTotalItems});
            this.statusStrip1.Location = new System.Drawing.Point(0, 712);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1008, 21);
            this.statusStrip1.TabIndex = 23;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblSvrName
            // 
            this.tsLblSvrName.AutoSize = false;
            this.tsLblSvrName.Name = "tsLblSvrName";
            this.tsLblSvrName.Size = new System.Drawing.Size(500, 16);
            this.tsLblSvrName.Text = "---";
            this.tsLblSvrName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tsLblTotalItems
            // 
            this.tsLblTotalItems.ForeColor = System.Drawing.Color.Blue;
            this.tsLblTotalItems.Name = "tsLblTotalItems";
            this.tsLblTotalItems.Size = new System.Drawing.Size(22, 16);
            this.tsLblTotalItems.Text = "---";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.splitContainer1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 53);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1002, 656);
            this.panel3.TabIndex = 25;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Blue;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Panel1.Controls.Add(this.panelLoading);
            this.splitContainer1.Panel1.Controls.Add(this.fpSpread1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel2);
            this.splitContainer1.Size = new System.Drawing.Size(1002, 656);
            this.splitContainer1.SplitterDistance = 294;
            this.splitContainer1.TabIndex = 6;
            // 
            // panelLoading
            // 
            this.panelLoading.BackColor = System.Drawing.Color.White;
            this.panelLoading.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLoading.Controls.Add(this.label19);
            this.panelLoading.Controls.Add(this.label9);
            this.panelLoading.Location = new System.Drawing.Point(478, 118);
            this.panelLoading.Name = "panelLoading";
            this.panelLoading.Size = new System.Drawing.Size(143, 87);
            this.panelLoading.TabIndex = 171;
            this.panelLoading.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(23, 49);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "Please wait ...";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkGreen;
            this.label9.Location = new System.Drawing.Point(22, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 22);
            this.label9.TabIndex = 0;
            this.label9.Text = "Loading...  ";
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread1.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.fpSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.HorizontalScrollBar.Name = "";
            this.fpSpread1.HorizontalScrollBar.Renderer = defaultScrollBarRenderer5;
            this.fpSpread1.HorizontalScrollBar.TabIndex = 8;
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpread1.Name = "fpSpread1";
            namedStyle1.BackColor = System.Drawing.Color.NavajoWhite;
            namedStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.Renderer = enhancedColumnHeaderRenderer1;
            namedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle2.BackColor = System.Drawing.Color.NavajoWhite;
            namedStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.Renderer = enhancedRowHeaderRenderer1;
            namedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle3.BackColor = System.Drawing.Color.Tan;
            namedStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle3.NoteIndicatorColor = System.Drawing.Color.Red;
            enhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.Goldenrod;
            enhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty;
            enhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.BurlyWood;
            namedStyle3.Renderer = enhancedCornerRenderer1;
            namedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle4.BackColor = System.Drawing.SystemColors.Window;
            namedStyle4.CellType = generalCellType1;
            namedStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle4.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle4.Renderer = generalCellType1;
            this.fpSpread1.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2,
            namedStyle3,
            namedStyle4});
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(1002, 294);
            this.fpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread1.TabIndex = 22;
            this.fpSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.VerticalScrollBar.Name = "";
            this.fpSpread1.VerticalScrollBar.Renderer = defaultScrollBarRenderer6;
            this.fpSpread1.VerticalScrollBar.TabIndex = 9;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread1.SelectionChanged += new FarPoint.Win.Spread.SelectionChangedEventHandler(this.fpSpread1_SelectionChanged);
            this.fpSpread1.ButtonClicked += new FarPoint.Win.Spread.EditorNotifyEventHandler(this.fpSpread1_ButtonClicked);
            this.fpSpread1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread1_MouseDown);
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 10;
            this.fpSpread1_Sheet1.RowCount = 10;
            this.fpSpread1_Sheet1.AutoGenerateColumns = false;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.DataAutoSizeColumns = false;
            this.fpSpread1_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.fpSpread1_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpSpread1_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpread1_Sheet1.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpSpread1_Sheet1.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors;
            this.fpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.CellChanged += new FarPoint.Win.Spread.SheetViewEventHandler(this.fpSpread1_Sheet1_CellChanged);
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel11, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.panel6, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.panel13, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 71F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1002, 358);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.lblComments);
            this.panel11.Controls.Add(this.lnkViewMaintDetails);
            this.panel11.Controls.Add(this.txtVslComments);
            this.panel11.Controls.Add(this.lblProcedure);
            this.panel11.Controls.Add(this.chkMaintDoneAsPerInstructions);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(2, 209);
            this.panel11.Margin = new System.Windows.Forms.Padding(0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(998, 86);
            this.panel11.TabIndex = 0;
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.ForeColor = System.Drawing.Color.Blue;
            this.lblComments.Location = new System.Drawing.Point(6, 7);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(90, 13);
            this.lblComments.TabIndex = 6;
            this.lblComments.Text = "Vessel Comments";
            // 
            // lnkViewMaintDetails
            // 
            this.lnkViewMaintDetails.AutoSize = true;
            this.lnkViewMaintDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewMaintDetails.Location = new System.Drawing.Point(730, 3);
            this.lnkViewMaintDetails.Name = "lnkViewMaintDetails";
            this.lnkViewMaintDetails.Size = new System.Drawing.Size(173, 15);
            this.lnkViewMaintDetails.TabIndex = 83;
            this.lnkViewMaintDetails.TabStop = true;
            this.lnkViewMaintDetails.Text = "View Maintenance procedures";
            this.lnkViewMaintDetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkViewMaintDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintDetails_LinkClicked);
            // 
            // txtVslComments
            // 
            this.txtVslComments.AllowDrop = true;
            this.txtVslComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtVslComments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtVslComments.Location = new System.Drawing.Point(6, 22);
            this.txtVslComments.Multiline = true;
            this.txtVslComments.Name = "txtVslComments";
            this.txtVslComments.ReadOnly = true;
            this.txtVslComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtVslComments.Size = new System.Drawing.Size(976, 61);
            this.txtVslComments.TabIndex = 7;
            // 
            // lblProcedure
            // 
            this.lblProcedure.AutoSize = true;
            this.lblProcedure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblProcedure.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcedure.ForeColor = System.Drawing.Color.Blue;
            this.lblProcedure.Location = new System.Drawing.Point(354, 4);
            this.lblProcedure.Name = "lblProcedure";
            this.lblProcedure.Size = new System.Drawing.Size(334, 13);
            this.lblProcedure.TabIndex = 82;
            this.lblProcedure.Text = "Maintenance done as per Maintenance procedures";
            // 
            // chkMaintDoneAsPerInstructions
            // 
            this.chkMaintDoneAsPerInstructions.AutoSize = true;
            this.chkMaintDoneAsPerInstructions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.chkMaintDoneAsPerInstructions.Enabled = false;
            this.chkMaintDoneAsPerInstructions.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMaintDoneAsPerInstructions.ForeColor = System.Drawing.Color.Blue;
            this.chkMaintDoneAsPerInstructions.Location = new System.Drawing.Point(338, 2);
            this.chkMaintDoneAsPerInstructions.Name = "chkMaintDoneAsPerInstructions";
            this.chkMaintDoneAsPerInstructions.Size = new System.Drawing.Size(353, 17);
            this.chkMaintDoneAsPerInstructions.TabIndex = 81;
            this.chkMaintDoneAsPerInstructions.Text = "Maintenance done as per Maintenance procedures";
            this.chkMaintDoneAsPerInstructions.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tableLayoutPanel3);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(2, 75);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(998, 132);
            this.panel6.TabIndex = 3;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.09619F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.90381F));
            this.tableLayoutPanel3.Controls.Add(this.panel9, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel7, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel8, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel10, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(998, 132);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label4);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(479, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(519, 19);
            this.panel9.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(3, 2);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Associated Forms";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.fpSpreadConsumed);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 19);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(479, 113);
            this.panel7.TabIndex = 18;
            // 
            // fpSpreadConsumed
            // 
            this.fpSpreadConsumed.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpreadConsumed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadConsumed.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadConsumed.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadConsumed.HorizontalScrollBar.Name = "";
            this.fpSpreadConsumed.HorizontalScrollBar.Renderer = defaultScrollBarRenderer7;
            this.fpSpreadConsumed.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadConsumed.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadConsumed.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadConsumed.Name = "fpSpreadConsumed";
            this.fpSpreadConsumed.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.fpSpreadConsumed.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadConsumed_Sheet1});
            this.fpSpreadConsumed.Size = new System.Drawing.Size(479, 113);
            this.fpSpreadConsumed.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadConsumed.TabIndex = 16;
            this.fpSpreadConsumed.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadConsumed.VerticalScrollBar.Name = "";
            this.fpSpreadConsumed.VerticalScrollBar.Renderer = defaultScrollBarRenderer8;
            this.fpSpreadConsumed.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadConsumed.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadConsumed.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpreadConsumed.ColumnWidthChanged += new FarPoint.Win.Spread.ColumnWidthChangedEventHandler(this.fpSpreadConsumed_ColumnWidthChanged);
            this.fpSpreadConsumed.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpreadConsumed_CellClick);
            // 
            // fpSpreadConsumed_Sheet1
            // 
            this.fpSpreadConsumed_Sheet1.Reset();
            this.fpSpreadConsumed_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadConsumed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadConsumed_Sheet1.ColumnCount = 10;
            this.fpSpreadConsumed_Sheet1.RowCount = 10;
            this.fpSpreadConsumed_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadConsumed_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadConsumed_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadConsumed_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadConsumed_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadConsumed_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadConsumed_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadConsumed_Sheet1.RowHeader.Visible = false;
            this.fpSpreadConsumed_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadConsumed_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadConsumed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.fpSpreadAssociatedForms);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(479, 19);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(519, 113);
            this.panel8.TabIndex = 17;
            // 
            // fpSpreadAssociatedForms
            // 
            this.fpSpreadAssociatedForms.AccessibleDescription = "fpSpreadAssociatedForms, Sheet1, Row 0, Column 0, ";
            this.fpSpreadAssociatedForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadAssociatedForms.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadAssociatedForms.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpreadAssociatedForms.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadAssociatedForms.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadAssociatedForms.Name = "fpSpreadAssociatedForms";
            this.fpSpreadAssociatedForms.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadAssociatedForms_Sheet1});
            this.fpSpreadAssociatedForms.Size = new System.Drawing.Size(519, 113);
            this.fpSpreadAssociatedForms.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadAssociatedForms.TabIndex = 12;
            this.fpSpreadAssociatedForms.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.VerticalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpreadAssociatedForms.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadAssociatedForms.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpreadAssociatedForms.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpreadAssociatedForms_HyperLinkClicked);
            this.fpSpreadAssociatedForms.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpreadAssociatedForms_Error);
            // 
            // fpSpreadAssociatedForms_Sheet1
            // 
            this.fpSpreadAssociatedForms_Sheet1.Reset();
            this.fpSpreadAssociatedForms_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadAssociatedForms_Sheet1.ColumnCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.RowCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadAssociatedForms_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.Visible = false;
            this.fpSpreadAssociatedForms_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadAssociatedForms_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label6);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(479, 19);
            this.panel10.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(3, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Spare parts consumed";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtSuptComments);
            this.panel2.Controls.Add(this.lblSuptCom);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(2, 297);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(998, 59);
            this.panel2.TabIndex = 24;
            // 
            // txtSuptComments
            // 
            this.txtSuptComments.AllowDrop = true;
            this.txtSuptComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtSuptComments.Location = new System.Drawing.Point(8, 19);
            this.txtSuptComments.Multiline = true;
            this.txtSuptComments.Name = "txtSuptComments";
            this.txtSuptComments.ReadOnly = true;
            this.txtSuptComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSuptComments.Size = new System.Drawing.Size(983, 38);
            this.txtSuptComments.TabIndex = 5;
            // 
            // lblSuptCom
            // 
            this.lblSuptCom.AutoSize = true;
            this.lblSuptCom.ForeColor = System.Drawing.Color.Blue;
            this.lblSuptCom.Location = new System.Drawing.Point(7, 5);
            this.lblSuptCom.Name = "lblSuptCom";
            this.lblSuptCom.Size = new System.Drawing.Size(81, 13);
            this.lblSuptCom.TabIndex = 4;
            this.lblSuptCom.Text = "Supt Comments";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.pnlPMS);
            this.panel13.Controls.Add(this.pnlRoutine);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(2, 2);
            this.panel13.Margin = new System.Windows.Forms.Padding(0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(998, 71);
            this.panel13.TabIndex = 8;
            // 
            // pnlPMS
            // 
            this.pnlPMS.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlPMS.Controls.Add(this.lblPlace);
            this.pnlPMS.Controls.Add(this.lblReason);
            this.pnlPMS.Controls.Add(this.lnkViewMaintCheckList);
            this.pnlPMS.Controls.Add(this.lblActualRunningHours);
            this.pnlPMS.Controls.Add(this.lblActualRunningHours_Display);
            this.pnlPMS.Controls.Add(this.lblManHrs);
            this.pnlPMS.Controls.Add(this.lblMaintCode);
            this.pnlPMS.Controls.Add(this.lblMaintType1);
            this.pnlPMS.Controls.Add(this.lnkViewAlarmAndTestingItems);
            this.pnlPMS.Controls.Add(this.label16);
            this.pnlPMS.Controls.Add(this.lblPMMRefNo);
            this.pnlPMS.Controls.Add(this.lblCompletion);
            this.pnlPMS.Controls.Add(this.lblComponent);
            this.pnlPMS.Controls.Add(this.lblResponsibleRank);
            this.pnlPMS.Controls.Add(this.lblComp);
            this.pnlPMS.Controls.Add(this.lblDept);
            this.pnlPMS.Controls.Add(this.lblPMM);
            this.pnlPMS.Controls.Add(this.lblMaint);
            this.pnlPMS.Controls.Add(this.lblResponsible);
            this.pnlPMS.Controls.Add(this.lblCondition);
            this.pnlPMS.Controls.Add(this.lblInChargeRank);
            this.pnlPMS.Controls.Add(this.label8);
            this.pnlPMS.Controls.Add(this.lblInCharge);
            this.pnlPMS.Controls.Add(this.lblInterval);
            this.pnlPMS.Controls.Add(this.label7);
            this.pnlPMS.Controls.Add(this.label15);
            this.pnlPMS.Controls.Add(this.label3);
            this.pnlPMS.Controls.Add(this.label14);
            this.pnlPMS.Controls.Add(this.label5);
            this.pnlPMS.Controls.Add(this.lnkViewAttchment);
            this.pnlPMS.Controls.Add(this.label10);
            this.pnlPMS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPMS.Location = new System.Drawing.Point(0, 0);
            this.pnlPMS.Margin = new System.Windows.Forms.Padding(0);
            this.pnlPMS.Name = "pnlPMS";
            this.pnlPMS.Size = new System.Drawing.Size(998, 71);
            this.pnlPMS.TabIndex = 5;
            // 
            // lblPlace
            // 
            this.lblPlace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlace.Location = new System.Drawing.Point(163, 5);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(113, 17);
            this.lblPlace.TabIndex = 72;
            this.lblPlace.Text = "...";
            // 
            // lblReason
            // 
            this.lblReason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReason.Location = new System.Drawing.Point(163, 28);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(113, 17);
            this.lblReason.TabIndex = 3;
            this.lblReason.Text = "...";
            // 
            // lnkViewMaintCheckList
            // 
            this.lnkViewMaintCheckList.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lnkViewMaintCheckList.AutoSize = true;
            this.lnkViewMaintCheckList.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewMaintCheckList.Location = new System.Drawing.Point(422, 52);
            this.lnkViewMaintCheckList.Name = "lnkViewMaintCheckList";
            this.lnkViewMaintCheckList.Size = new System.Drawing.Size(171, 15);
            this.lnkViewMaintCheckList.TabIndex = 87;
            this.lnkViewMaintCheckList.TabStop = true;
            this.lnkViewMaintCheckList.Text = "View Maintenance CheckList";
            this.lnkViewMaintCheckList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintCheckList_LinkClicked);
            // 
            // lblActualRunningHours
            // 
            this.lblActualRunningHours.AutoSize = true;
            this.lblActualRunningHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblActualRunningHours.Location = new System.Drawing.Point(210, 50);
            this.lblActualRunningHours.Name = "lblActualRunningHours";
            this.lblActualRunningHours.Size = new System.Drawing.Size(16, 15);
            this.lblActualRunningHours.TabIndex = 98;
            this.lblActualRunningHours.Text = "...";
            // 
            // lblActualRunningHours_Display
            // 
            this.lblActualRunningHours_Display.AutoSize = true;
            this.lblActualRunningHours_Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblActualRunningHours_Display.ForeColor = System.Drawing.Color.Blue;
            this.lblActualRunningHours_Display.Location = new System.Drawing.Point(9, 50);
            this.lblActualRunningHours_Display.Name = "lblActualRunningHours_Display";
            this.lblActualRunningHours_Display.Size = new System.Drawing.Size(202, 15);
            this.lblActualRunningHours_Display.TabIndex = 97;
            this.lblActualRunningHours_Display.Text = "Actual Running Hrs at time of Maint:";
            // 
            // lblManHrs
            // 
            this.lblManHrs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblManHrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManHrs.Location = new System.Drawing.Point(554, 5);
            this.lblManHrs.Name = "lblManHrs";
            this.lblManHrs.Size = new System.Drawing.Size(39, 17);
            this.lblManHrs.TabIndex = 7;
            this.lblManHrs.Text = "...";
            // 
            // lblMaintCode
            // 
            this.lblMaintCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintCode.ForeColor = System.Drawing.Color.Black;
            this.lblMaintCode.Location = new System.Drawing.Point(554, 28);
            this.lblMaintCode.Name = "lblMaintCode";
            this.lblMaintCode.Size = new System.Drawing.Size(39, 17);
            this.lblMaintCode.TabIndex = 78;
            this.lblMaintCode.Text = "...";
            // 
            // lblMaintType1
            // 
            this.lblMaintType1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintType1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintType1.ForeColor = System.Drawing.Color.Black;
            this.lblMaintType1.Location = new System.Drawing.Point(661, 5);
            this.lblMaintType1.Name = "lblMaintType1";
            this.lblMaintType1.Size = new System.Drawing.Size(153, 17);
            this.lblMaintType1.TabIndex = 96;
            this.lblMaintType1.Text = "...";
            // 
            // lnkViewAlarmAndTestingItems
            // 
            this.lnkViewAlarmAndTestingItems.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lnkViewAlarmAndTestingItems.AutoSize = true;
            this.lnkViewAlarmAndTestingItems.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAlarmAndTestingItems.Location = new System.Drawing.Point(396, 52);
            this.lnkViewAlarmAndTestingItems.Name = "lnkViewAlarmAndTestingItems";
            this.lnkViewAlarmAndTestingItems.Size = new System.Drawing.Size(197, 15);
            this.lnkViewAlarmAndTestingItems.TabIndex = 87;
            this.lnkViewAlarmAndTestingItems.TabStop = true;
            this.lnkViewAlarmAndTestingItems.Text = "View Alarms and Routines Report";
            this.lnkViewAlarmAndTestingItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkViewAlarmAndTestingItems.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAlarmAndTestingItems_LinkClicked);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Blue;
            this.label16.Location = new System.Drawing.Point(603, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 95;
            this.label16.Text = "MaintType:";
            // 
            // lblPMMRefNo
            // 
            this.lblPMMRefNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPMMRefNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMMRefNo.ForeColor = System.Drawing.Color.Black;
            this.lblPMMRefNo.Location = new System.Drawing.Point(891, 50);
            this.lblPMMRefNo.Name = "lblPMMRefNo";
            this.lblPMMRefNo.Size = new System.Drawing.Size(76, 17);
            this.lblPMMRefNo.TabIndex = 76;
            this.lblPMMRefNo.Text = "...";
            // 
            // lblCompletion
            // 
            this.lblCompletion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCompletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompletion.Location = new System.Drawing.Point(340, 28);
            this.lblCompletion.Name = "lblCompletion";
            this.lblCompletion.Size = new System.Drawing.Size(147, 17);
            this.lblCompletion.TabIndex = 5;
            this.lblCompletion.Text = "...";
            // 
            // lblComponent
            // 
            this.lblComponent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblComponent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComponent.ForeColor = System.Drawing.Color.Black;
            this.lblComponent.Location = new System.Drawing.Point(661, 28);
            this.lblComponent.Name = "lblComponent";
            this.lblComponent.Size = new System.Drawing.Size(153, 17);
            this.lblComponent.TabIndex = 73;
            this.lblComponent.Text = ".....";
            this.lblComponent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblResponsibleRank
            // 
            this.lblResponsibleRank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResponsibleRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsibleRank.ForeColor = System.Drawing.Color.Black;
            this.lblResponsibleRank.Location = new System.Drawing.Point(889, 28);
            this.lblResponsibleRank.Name = "lblResponsibleRank";
            this.lblResponsibleRank.Size = new System.Drawing.Size(76, 17);
            this.lblResponsibleRank.TabIndex = 82;
            this.lblResponsibleRank.Text = "...";
            // 
            // lblComp
            // 
            this.lblComp.AutoSize = true;
            this.lblComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComp.ForeColor = System.Drawing.Color.Blue;
            this.lblComp.Location = new System.Drawing.Point(599, 30);
            this.lblComp.Name = "lblComp";
            this.lblComp.Size = new System.Drawing.Size(64, 13);
            this.lblComp.TabIndex = 74;
            this.lblComp.Text = "Component:";
            // 
            // lblDept
            // 
            this.lblDept.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDept.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDept.ForeColor = System.Drawing.Color.Black;
            this.lblDept.Location = new System.Drawing.Point(47, 5);
            this.lblDept.Name = "lblDept";
            this.lblDept.Size = new System.Drawing.Size(65, 17);
            this.lblDept.TabIndex = 84;
            this.lblDept.Text = "...";
            // 
            // lblPMM
            // 
            this.lblPMM.AutoSize = true;
            this.lblPMM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMM.ForeColor = System.Drawing.Color.Blue;
            this.lblPMM.Location = new System.Drawing.Point(819, 52);
            this.lblPMM.Name = "lblPMM";
            this.lblPMM.Size = new System.Drawing.Size(72, 13);
            this.lblPMM.TabIndex = 75;
            this.lblPMM.Text = "PMM Ref No:";
            // 
            // lblMaint
            // 
            this.lblMaint.AutoSize = true;
            this.lblMaint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaint.ForeColor = System.Drawing.Color.Blue;
            this.lblMaint.Location = new System.Drawing.Point(492, 30);
            this.lblMaint.Name = "lblMaint";
            this.lblMaint.Size = new System.Drawing.Size(64, 13);
            this.lblMaint.TabIndex = 77;
            this.lblMaint.Text = "Maint Code:";
            // 
            // lblResponsible
            // 
            this.lblResponsible.AutoSize = true;
            this.lblResponsible.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsible.ForeColor = System.Drawing.Color.Blue;
            this.lblResponsible.Location = new System.Drawing.Point(824, 30);
            this.lblResponsible.Name = "lblResponsible";
            this.lblResponsible.Size = new System.Drawing.Size(67, 13);
            this.lblResponsible.TabIndex = 81;
            this.lblResponsible.Text = "Resp. Rank:";
            // 
            // lblCondition
            // 
            this.lblCondition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCondition.Location = new System.Drawing.Point(339, 5);
            this.lblCondition.Name = "lblCondition";
            this.lblCondition.Size = new System.Drawing.Size(147, 17);
            this.lblCondition.TabIndex = 4;
            this.lblCondition.Text = "...";
            // 
            // lblInChargeRank
            // 
            this.lblInChargeRank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInChargeRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInChargeRank.ForeColor = System.Drawing.Color.Black;
            this.lblInChargeRank.Location = new System.Drawing.Point(889, 5);
            this.lblInChargeRank.Name = "lblInChargeRank";
            this.lblInChargeRank.Size = new System.Drawing.Size(76, 17);
            this.lblInChargeRank.TabIndex = 80;
            this.lblInChargeRank.Text = "...";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(117, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Reason:";
            // 
            // lblInCharge
            // 
            this.lblInCharge.AutoSize = true;
            this.lblInCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInCharge.ForeColor = System.Drawing.Color.Blue;
            this.lblInCharge.Location = new System.Drawing.Point(830, 7);
            this.lblInCharge.Name = "lblInCharge";
            this.lblInCharge.Size = new System.Drawing.Size(61, 13);
            this.lblInCharge.TabIndex = 79;
            this.lblInCharge.Text = "InCh.Rank:";
            // 
            // lblInterval
            // 
            this.lblInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInterval.ForeColor = System.Drawing.Color.Black;
            this.lblInterval.Location = new System.Drawing.Point(47, 28);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(65, 17);
            this.lblInterval.TabIndex = 86;
            this.lblInterval.Text = "...";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(288, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Condition:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(5, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 85;
            this.label15.Text = "Interval:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(281, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Completion:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(17, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 13);
            this.label14.TabIndex = 83;
            this.label14.Text = "Dept:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(506, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Man Hrs:";
            // 
            // lnkViewAttchment
            // 
            this.lnkViewAttchment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lnkViewAttchment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAttchment.Location = new System.Drawing.Point(703, 52);
            this.lnkViewAttchment.Name = "lnkViewAttchment";
            this.lnkViewAttchment.Size = new System.Drawing.Size(103, 15);
            this.lnkViewAttchment.TabIndex = 70;
            this.lnkViewAttchment.TabStop = true;
            this.lnkViewAttchment.Text = "View Attachment";
            this.lnkViewAttchment.Visible = false;
            this.lnkViewAttchment.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAttchment_LinkClicked);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(127, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 71;
            this.label10.Text = "Place:";
            // 
            // pnlRoutine
            // 
            this.pnlRoutine.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlRoutine.Controls.Add(this.lblMaintType);
            this.pnlRoutine.Controls.Add(this.label13);
            this.pnlRoutine.Controls.Add(this.lblResult);
            this.pnlRoutine.Controls.Add(this.lblVerifiy);
            this.pnlRoutine.Controls.Add(this.lblLocation);
            this.pnlRoutine.Controls.Add(this.lblres);
            this.pnlRoutine.Controls.Add(this.lblver);
            this.pnlRoutine.Controls.Add(this.lblLoc);
            this.pnlRoutine.Controls.Add(this.lblIntervalRoutine);
            this.pnlRoutine.Controls.Add(this.label18);
            this.pnlRoutine.Controls.Add(this.lblDeptRoutine);
            this.pnlRoutine.Controls.Add(this.label20);
            this.pnlRoutine.Controls.Add(this.lblResponsibleRankRoutine);
            this.pnlRoutine.Controls.Add(this.lblResponsibleRoutine);
            this.pnlRoutine.Controls.Add(this.lblInChargeRankRoutine);
            this.pnlRoutine.Controls.Add(this.lblInChargeRoutine);
            this.pnlRoutine.Controls.Add(this.lblMaintCodeRoutine);
            this.pnlRoutine.Controls.Add(this.lblMaintRoutine);
            this.pnlRoutine.Controls.Add(this.lblPMMRefNoRoutine);
            this.pnlRoutine.Controls.Add(this.lblPMMRoutine);
            this.pnlRoutine.Controls.Add(this.lblCompRoutine);
            this.pnlRoutine.Controls.Add(this.lblComponentRoutine);
            this.pnlRoutine.Controls.Add(this.lnkViewAttchmentRoutine);
            this.pnlRoutine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRoutine.Location = new System.Drawing.Point(0, 0);
            this.pnlRoutine.Margin = new System.Windows.Forms.Padding(0);
            this.pnlRoutine.Name = "pnlRoutine";
            this.pnlRoutine.Size = new System.Drawing.Size(998, 71);
            this.pnlRoutine.TabIndex = 87;
            // 
            // lblMaintType
            // 
            this.lblMaintType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintType.ForeColor = System.Drawing.Color.Black;
            this.lblMaintType.Location = new System.Drawing.Point(575, 6);
            this.lblMaintType.Name = "lblMaintType";
            this.lblMaintType.Size = new System.Drawing.Size(136, 17);
            this.lblMaintType.TabIndex = 94;
            this.lblMaintType.Text = "...";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(517, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 93;
            this.label13.Text = "MaintType:";
            // 
            // lblResult
            // 
            this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResult.Location = new System.Drawing.Point(170, 27);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(133, 17);
            this.lblResult.TabIndex = 92;
            this.lblResult.Text = "...";
            // 
            // lblVerifiy
            // 
            this.lblVerifiy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblVerifiy.Location = new System.Drawing.Point(377, 6);
            this.lblVerifiy.Name = "lblVerifiy";
            this.lblVerifiy.Size = new System.Drawing.Size(133, 17);
            this.lblVerifiy.TabIndex = 91;
            this.lblVerifiy.Text = "...";
            // 
            // lblLocation
            // 
            this.lblLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLocation.Location = new System.Drawing.Point(170, 6);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(133, 17);
            this.lblLocation.TabIndex = 90;
            this.lblLocation.Text = "...";
            // 
            // lblres
            // 
            this.lblres.AutoSize = true;
            this.lblres.ForeColor = System.Drawing.Color.Blue;
            this.lblres.Location = new System.Drawing.Point(131, 29);
            this.lblres.Name = "lblres";
            this.lblres.Size = new System.Drawing.Size(40, 13);
            this.lblres.TabIndex = 89;
            this.lblres.Text = "Result:";
            // 
            // lblver
            // 
            this.lblver.AutoSize = true;
            this.lblver.ForeColor = System.Drawing.Color.Blue;
            this.lblver.Location = new System.Drawing.Point(308, 8);
            this.lblver.Name = "lblver";
            this.lblver.Size = new System.Drawing.Size(69, 13);
            this.lblver.TabIndex = 88;
            this.lblver.Text = "Verify Status:";
            // 
            // lblLoc
            // 
            this.lblLoc.AutoSize = true;
            this.lblLoc.ForeColor = System.Drawing.Color.Blue;
            this.lblLoc.Location = new System.Drawing.Point(120, 8);
            this.lblLoc.Name = "lblLoc";
            this.lblLoc.Size = new System.Drawing.Size(51, 13);
            this.lblLoc.TabIndex = 87;
            this.lblLoc.Text = "Location:";
            // 
            // lblIntervalRoutine
            // 
            this.lblIntervalRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIntervalRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIntervalRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblIntervalRoutine.Location = new System.Drawing.Point(47, 27);
            this.lblIntervalRoutine.Name = "lblIntervalRoutine";
            this.lblIntervalRoutine.Size = new System.Drawing.Size(69, 17);
            this.lblIntervalRoutine.TabIndex = 86;
            this.lblIntervalRoutine.Text = "...";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(4, 29);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 13);
            this.label18.TabIndex = 85;
            this.label18.Text = "Interval:";
            // 
            // lblDeptRoutine
            // 
            this.lblDeptRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDeptRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeptRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblDeptRoutine.Location = new System.Drawing.Point(47, 6);
            this.lblDeptRoutine.Name = "lblDeptRoutine";
            this.lblDeptRoutine.Size = new System.Drawing.Size(69, 17);
            this.lblDeptRoutine.TabIndex = 84;
            this.lblDeptRoutine.Text = "...";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.Location = new System.Drawing.Point(16, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 13);
            this.label20.TabIndex = 83;
            this.label20.Text = "Dept:";
            // 
            // lblResponsibleRankRoutine
            // 
            this.lblResponsibleRankRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResponsibleRankRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsibleRankRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblResponsibleRankRoutine.Location = new System.Drawing.Point(940, 6);
            this.lblResponsibleRankRoutine.Name = "lblResponsibleRankRoutine";
            this.lblResponsibleRankRoutine.Size = new System.Drawing.Size(49, 17);
            this.lblResponsibleRankRoutine.TabIndex = 82;
            this.lblResponsibleRankRoutine.Text = "...";
            // 
            // lblResponsibleRoutine
            // 
            this.lblResponsibleRoutine.AutoSize = true;
            this.lblResponsibleRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsibleRoutine.ForeColor = System.Drawing.Color.Blue;
            this.lblResponsibleRoutine.Location = new System.Drawing.Point(849, 8);
            this.lblResponsibleRoutine.Name = "lblResponsibleRoutine";
            this.lblResponsibleRoutine.Size = new System.Drawing.Size(92, 13);
            this.lblResponsibleRoutine.TabIndex = 81;
            this.lblResponsibleRoutine.Text = "Reponsible Rank:";
            // 
            // lblInChargeRankRoutine
            // 
            this.lblInChargeRankRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInChargeRankRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInChargeRankRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblInChargeRankRoutine.Location = new System.Drawing.Point(794, 6);
            this.lblInChargeRankRoutine.Name = "lblInChargeRankRoutine";
            this.lblInChargeRankRoutine.Size = new System.Drawing.Size(49, 17);
            this.lblInChargeRankRoutine.TabIndex = 80;
            this.lblInChargeRankRoutine.Text = "...";
            // 
            // lblInChargeRoutine
            // 
            this.lblInChargeRoutine.AutoSize = true;
            this.lblInChargeRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInChargeRoutine.ForeColor = System.Drawing.Color.Blue;
            this.lblInChargeRoutine.Location = new System.Drawing.Point(714, 8);
            this.lblInChargeRoutine.Name = "lblInChargeRoutine";
            this.lblInChargeRoutine.Size = new System.Drawing.Size(82, 13);
            this.lblInChargeRoutine.TabIndex = 79;
            this.lblInChargeRoutine.Text = "InCharge Rank:";
            // 
            // lblMaintCodeRoutine
            // 
            this.lblMaintCodeRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintCodeRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintCodeRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblMaintCodeRoutine.Location = new System.Drawing.Point(575, 27);
            this.lblMaintCodeRoutine.Name = "lblMaintCodeRoutine";
            this.lblMaintCodeRoutine.Size = new System.Drawing.Size(49, 17);
            this.lblMaintCodeRoutine.TabIndex = 78;
            this.lblMaintCodeRoutine.Text = "...";
            // 
            // lblMaintRoutine
            // 
            this.lblMaintRoutine.AutoSize = true;
            this.lblMaintRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintRoutine.ForeColor = System.Drawing.Color.Blue;
            this.lblMaintRoutine.Location = new System.Drawing.Point(513, 29);
            this.lblMaintRoutine.Name = "lblMaintRoutine";
            this.lblMaintRoutine.Size = new System.Drawing.Size(64, 13);
            this.lblMaintRoutine.TabIndex = 77;
            this.lblMaintRoutine.Text = "Maint Code:";
            // 
            // lblPMMRefNoRoutine
            // 
            this.lblPMMRefNoRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPMMRefNoRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMMRefNoRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblPMMRefNoRoutine.Location = new System.Drawing.Point(377, 27);
            this.lblPMMRefNoRoutine.Name = "lblPMMRefNoRoutine";
            this.lblPMMRefNoRoutine.Size = new System.Drawing.Size(133, 17);
            this.lblPMMRefNoRoutine.TabIndex = 76;
            this.lblPMMRefNoRoutine.Text = "...";
            // 
            // lblPMMRoutine
            // 
            this.lblPMMRoutine.AutoSize = true;
            this.lblPMMRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMMRoutine.ForeColor = System.Drawing.Color.Blue;
            this.lblPMMRoutine.Location = new System.Drawing.Point(305, 29);
            this.lblPMMRoutine.Name = "lblPMMRoutine";
            this.lblPMMRoutine.Size = new System.Drawing.Size(72, 13);
            this.lblPMMRoutine.TabIndex = 75;
            this.lblPMMRoutine.Text = "PMM Ref No:";
            // 
            // lblCompRoutine
            // 
            this.lblCompRoutine.AutoSize = true;
            this.lblCompRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompRoutine.ForeColor = System.Drawing.Color.Blue;
            this.lblCompRoutine.Location = new System.Drawing.Point(636, 29);
            this.lblCompRoutine.Name = "lblCompRoutine";
            this.lblCompRoutine.Size = new System.Drawing.Size(64, 13);
            this.lblCompRoutine.TabIndex = 74;
            this.lblCompRoutine.Text = "Component:";
            // 
            // lblComponentRoutine
            // 
            this.lblComponentRoutine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblComponentRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComponentRoutine.ForeColor = System.Drawing.Color.Black;
            this.lblComponentRoutine.Location = new System.Drawing.Point(700, 27);
            this.lblComponentRoutine.Name = "lblComponentRoutine";
            this.lblComponentRoutine.Size = new System.Drawing.Size(180, 17);
            this.lblComponentRoutine.TabIndex = 73;
            this.lblComponentRoutine.Text = ".....";
            this.lblComponentRoutine.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lnkViewAttchmentRoutine
            // 
            this.lnkViewAttchmentRoutine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lnkViewAttchmentRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAttchmentRoutine.Location = new System.Drawing.Point(884, 27);
            this.lnkViewAttchmentRoutine.Name = "lnkViewAttchmentRoutine";
            this.lnkViewAttchmentRoutine.Size = new System.Drawing.Size(113, 17);
            this.lnkViewAttchmentRoutine.TabIndex = 70;
            this.lnkViewAttchmentRoutine.TabStop = true;
            this.lnkViewAttchmentRoutine.Text = "View Attachment";
            this.lnkViewAttchmentRoutine.Visible = false;
            this.lnkViewAttchmentRoutine.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAttchmentRoutine_LinkClicked);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmnuSuptComments,
            this.toolStripSeparator1,
            this.tsMnuMaintHistory,
            this.tsMnuSeparator1,
            this.tsMnuSendBackToVslForAmendments});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(254, 82);
            // 
            // tsmnuSuptComments
            // 
            this.tsmnuSuptComments.Name = "tsmnuSuptComments";
            this.tsmnuSuptComments.Size = new System.Drawing.Size(253, 22);
            this.tsmnuSuptComments.Text = "Supt Comments";
            this.tsmnuSuptComments.Click += new System.EventHandler(this.tsmnuSuptComments_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(250, 6);
            // 
            // tsMnuMaintHistory
            // 
            this.tsMnuMaintHistory.Name = "tsMnuMaintHistory";
            this.tsMnuMaintHistory.Size = new System.Drawing.Size(253, 22);
            this.tsMnuMaintHistory.Text = "Maint History";
            this.tsMnuMaintHistory.Click += new System.EventHandler(this.tsMnuMaintHistory_Click);
            // 
            // tsMnuSeparator1
            // 
            this.tsMnuSeparator1.Name = "tsMnuSeparator1";
            this.tsMnuSeparator1.Size = new System.Drawing.Size(250, 6);
            // 
            // tsMnuSendBackToVslForAmendments
            // 
            this.tsMnuSendBackToVslForAmendments.Name = "tsMnuSendBackToVslForAmendments";
            this.tsMnuSendBackToVslForAmendments.Size = new System.Drawing.Size(253, 22);
            this.tsMnuSendBackToVslForAmendments.Text = "Send Back to Vsl for Amendments";
            this.tsMnuSendBackToVslForAmendments.Click += new System.EventHandler(this.tsMnuSendBackToVslForAmendments_Click);
            // 
            // frmSuptReview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 733);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmSuptReview";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Supt Review";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSuptReview_FormClosing);
            this.Load += new System.EventHandler(this.frmSuptReview_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panelLoading.ResumeLayout(false);
            this.panelLoading.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed_Sheet1)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.pnlPMS.ResumeLayout(false);
            this.pnlPMS.PerformLayout();
            this.pnlRoutine.ResumeLayout(false);
            this.pnlRoutine.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private System.Windows.Forms.Button btnMarkAllNormalReports;
        private System.Windows.Forms.Button btnUnMarkAll;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblTotalItems;
        private System.Windows.Forms.ToolStripStatusLabel tsLblSvrName;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmnuSuptComments;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtSuptComments;
        private System.Windows.Forms.Label lblSuptCom;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMaintHistory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel7;
        private FarPoint.Win.Spread.FpSpread fpSpreadConsumed;
        private FarPoint.Win.Spread.SheetView fpSpreadConsumed_Sheet1;
        private System.Windows.Forms.Panel panel8;
        private FarPoint.Win.Spread.FpSpread fpSpreadAssociatedForms;
        private FarPoint.Win.Spread.SheetView fpSpreadAssociatedForms_Sheet1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnlPMS;
        private System.Windows.Forms.Label lblManHrs;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCompletion;
        private System.Windows.Forms.Label lblCondition;
        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkShowHistory;
        private System.Windows.Forms.LinkLabel lnkViewAttchment;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblProcedure;
        private System.Windows.Forms.CheckBox chkMaintDoneAsPerInstructions;
        private System.Windows.Forms.LinkLabel lnkViewMaintDetails;
        private System.Windows.Forms.Label lblComp;
        private System.Windows.Forms.Label lblComponent;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblResponsibleRank;
        private System.Windows.Forms.Label lblResponsible;
        private System.Windows.Forms.Label lblInChargeRank;
        private System.Windows.Forms.Label lblInCharge;
        private System.Windows.Forms.Label lblMaintCode;
        private System.Windows.Forms.Label lblMaint;
        private System.Windows.Forms.Label lblPMMRefNo;
        private System.Windows.Forms.Label lblPMM;
        private System.Windows.Forms.Label lblDept;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblInterval;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel pnlRoutine;
        private System.Windows.Forms.Label lblIntervalRoutine;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblDeptRoutine;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblResponsibleRankRoutine;
        private System.Windows.Forms.Label lblResponsibleRoutine;
        private System.Windows.Forms.Label lblInChargeRankRoutine;
        private System.Windows.Forms.Label lblInChargeRoutine;
        private System.Windows.Forms.Label lblMaintCodeRoutine;
        private System.Windows.Forms.Label lblMaintRoutine;
        private System.Windows.Forms.Label lblPMMRefNoRoutine;
        private System.Windows.Forms.Label lblPMMRoutine;
        private System.Windows.Forms.Label lblCompRoutine;
        private System.Windows.Forms.Label lblComponentRoutine;
        private System.Windows.Forms.LinkLabel lnkViewAttchmentRoutine;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblVerifiy;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblres;
        private System.Windows.Forms.Label lblver;
        private System.Windows.Forms.Label lblLoc;
        private System.Windows.Forms.LinkLabel lnkViewMaintCheckList;
        private System.Windows.Forms.LinkLabel lnkViewAlarmAndTestingItems;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.TextBox txtVslComments;
        private System.Windows.Forms.Label lblMaintType;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblMaintType1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panelLoading;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ToolStripSeparator tsMnuSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuSendBackToVslForAmendments;
        private System.Windows.Forms.Label lblActualRunningHours;
        private System.Windows.Forms.Label lblActualRunningHours_Display;
        private System.Windows.Forms.Button btnSendBackToVSL;
        private System.Windows.Forms.Button btnEnterSuptComments;
        private System.Windows.Forms.Button btnExport;
    }
}