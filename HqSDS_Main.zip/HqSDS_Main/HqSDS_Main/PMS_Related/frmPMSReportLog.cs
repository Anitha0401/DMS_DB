﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmPMSReportLog : Form
    {
        public string maintInputType = "", eqpNamePosn = "", mntDesc = "", optionFilter = "";
        public long eqEquipmentId = -1, eqUnitId = -1, eqMaintId = -1, eq_PmsList_ClassID = -1;
        public int mRepRefNo = -1, vesselID=-1;
        const int COL_LOGDATEDISPLAY = 0,
                  COL_LOGDATE = 5;
        public frmPMSReportLog()
        {
            InitializeComponent();
        }

        private void frmEventLog_Load(object sender, EventArgs e)
        {
            Refresh_EventLog();
        }

        private void Refresh_EventLog()
        {

            //_________________________________________________________________________________//

            lblEqpname.Text = "Equipment: " + eqpNamePosn.Replace("&", "&&");
            lblMaintDesc.Text = "Maintenance Title: " + mntDesc.Replace("&", "&&");
            if (eq_PmsList_ClassID > 0)
            {
                lblMaintDesc.Text = "Survey Title: " + mntDesc.Replace("&", "&&");
            }
            this.Text = "Event Log"; this.Width = 750;             

            DesignAndBindEventLogGrid();
        }

        private void frmEventLog_Activated(object sender, EventArgs e)
        {
            Refresh_EventLog();
        }

        private void DesignAndBindEventLogGrid()
        {
            DataTable dtPmsEventLog = null;
            List<DgvInits> logColList = new List<DgvInits>();
            try
            {
                fpSpread_Log.SuspendLayout();
                fpSpread_Log.ActiveSheet.RowCount = 0;


                logColList.Add(new DgvInits("LogDateDisplay", "Log Date", 135, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("UserName", "User Name", 130, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("Activity", "Activity", 140, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("MaintType", "Maint Type", 130, Color.Black, SystemColors.ButtonFace, false, true));
                logColList.Add(new DgvInits("Remarks", "Remarks", 320, Color.Black, SystemColors.ButtonFace, true, true));
                logColList.Add(new DgvInits("LogDate", "Date", 135, Color.Black, SystemColors.ButtonFace, false, true));

                dtPmsEventLog = GetEventLogDataTable();
                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Log, logColList, dtPmsEventLog, false, true);

                fpSpread_Log.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread_Log.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread_Log.ActiveSheet.ColumnHeader.Rows[0].Height = 24;

                for (int row = 0; row < fpSpread_Log.ActiveSheet.RowCount; row++)
                {
                    fpSpread_Log.ActiveSheet.Rows[row].Height = fpSpread_Log.ActiveSheet.Rows[row].GetPreferredHeight();
                }
            }
            finally
            {
                dtPmsEventLog = null;
                logColList = null;
                fpSpread_Log.ResumeLayout();
            }
        }

        private DataTable GetEventLogDataTable()
        {
            string script;
            DataTable dt = null;
            try
            {

                script = " Select replace(convert(varchar(12),LogDate,106),' ','-')+' '+RIGHT(CONVERT(VARCHAR, LogDate, 100), 7) as LogDateDisplay, MaintType " + Environment.NewLine +
                         "    , Activity, Remarks, UserRank + ' - ' + UserName as UserName, LogDate " + Environment.NewLine +
                         " from EQ_PmsReportsLog " +
                         " where VesselID = " + vesselID + Environment.NewLine +
                         " and mRepRefNo = " + mRepRefNo + Environment.NewLine;
                script = script + " order by LogDate ";

                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.DisplayException("Get EventLog DataTable", err.Message);
                PG.AddToGenErrorLog("frmPMSReportLog.cs", "GetEventLogDataTable", err.Message);
            }
            return dt;
        }

        public int GetEventLogCount()
        {
            int cnt = 0;
            string script;
            try
            {
                script = " Select count(*) from EQ_PmsReportsLog " +
                         " where VesselID = " + vesselID + Environment.NewLine +
                         "    and mRepRefNo = " + mRepRefNo + Environment.NewLine;

                cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmPMSReportLog.cs", "GetEventLogCount", err.Message);
            }
            return (cnt);
        }

        private void fpSpread1_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpread_Log.ActiveSheet.Columns[COL_LOGDATE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

                if (e.Column == COL_LOGDATEDISPLAY)
                    fpSpread_Log.ActiveSheet.AutoSortColumn(COL_LOGDATE);
                else
                    fpSpread_Log.ActiveSheet.AutoSortColumn(e.Column);
                fpSpread_Log.ActiveSheet.Columns[COL_LOGDATEDISPLAY].SortIndicator = fpSpread_Log.ActiveSheet.Columns[COL_LOGDATE].SortIndicator;
            }
        }

        private void fpSpread1_AutoSortingColumn(object sender, FarPoint.Win.Spread.AutoSortingColumnEventArgs e)
        {
            fpSpread_Log.ActiveSheet.Columns[COL_LOGDATEDISPLAY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

            if (e.Column == COL_LOGDATEDISPLAY)
            {
                if (e.Ascending)
                {
                    fpSpread_Log.ActiveSheet.AutoSortColumn(COL_LOGDATE);
                    fpSpread_Log.ActiveSheet.Columns[COL_LOGDATEDISPLAY].SortIndicator = fpSpread_Log.ActiveSheet.Columns[COL_LOGDATE].SortIndicator;
                }
                e.Cancel = true;
            }
        }

        private void fpSpread1_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpread_Log.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}