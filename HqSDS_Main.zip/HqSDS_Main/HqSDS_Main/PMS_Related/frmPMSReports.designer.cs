﻿namespace HqSDS_Main
{
    partial class frmPMSReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPMSReports));
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkWithMaintCheckList = new System.Windows.Forms.CheckBox();
            this.chkWithMaintProcdure = new System.Windows.Forms.CheckBox();
            this.btnExport = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnExport);
            this.panel1.Controls.Add(this.chkWithMaintProcdure);
            this.panel1.Controls.Add(this.chkWithMaintCheckList);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(271, 120);
            this.panel1.TabIndex = 0;
            // 
            // chkWithMaintCheckList
            // 
            this.chkWithMaintCheckList.AutoSize = true;
            this.chkWithMaintCheckList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWithMaintCheckList.Location = new System.Drawing.Point(35, 25);
            this.chkWithMaintCheckList.Name = "chkWithMaintCheckList";
            this.chkWithMaintCheckList.Size = new System.Drawing.Size(204, 20);
            this.chkWithMaintCheckList.TabIndex = 13;
            this.chkWithMaintCheckList.Text = "Show Maintenance Check List";
            this.chkWithMaintCheckList.UseVisualStyleBackColor = true;
            // 
            // chkWithMaintProcdure
            // 
            this.chkWithMaintProcdure.AutoSize = true;
            this.chkWithMaintProcdure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWithMaintProcdure.Location = new System.Drawing.Point(36, 48);
            this.chkWithMaintProcdure.Name = "chkWithMaintProcdure";
            this.chkWithMaintProcdure.Size = new System.Drawing.Size(212, 20);
            this.chkWithMaintProcdure.TabIndex = 14;
            this.chkWithMaintProcdure.Text = "Show Maintenance procedures";
            this.chkWithMaintProcdure.UseVisualStyleBackColor = true;
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.Location = new System.Drawing.Point(178, 81);
            this.btnExport.Margin = new System.Windows.Forms.Padding(0);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(68, 27);
            this.btnExport.TabIndex = 17;
            this.btnExport.Text = "Export";
            this.btnExport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 120);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Reports";
            this.Load += new System.EventHandler(this.frmPMSReports_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkWithMaintProcdure;
        private System.Windows.Forms.CheckBox chkWithMaintCheckList;
        private System.Windows.Forms.Button btnExport;

    }
}