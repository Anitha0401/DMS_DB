﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmExportEquipmentList : Form
    {
        public int vesselID = -1;
        public string companyID = "-99", vslName = "", calledMode = "", groupType = "";
        public bool isWithCheckList = false, isWithMaintProcdure = false;

        const int COL_MaintenanceProcedure = 4, COL_MaintenanceChecklist=5;

        public frmExportEquipmentList()
        {
            InitializeComponent();           
        }

        private void frmExportEquipmentList_Load(object sender, EventArgs e)
        {           
        }

        private void SetOtherProperities(string mainTitle)
        {
            try
            {
                if (fpSpread1.ActiveSheet.DataSource == null) return;
                fpSpread1.SuspendLayout();

                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Add();
                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fpSpread1.ActiveSheet.ColumnCount);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].Text = PG.companyName; 
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 12, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 35;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].ForeColor = Color.Blue;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Add();
                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(1, 0, 1, 5);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].Text = vslName + " - " + mainTitle + "                                    Date:" + PG.GetDbServerDate().ToString("dd-MMM-yyyy");
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 10, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Height = 23;

                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(1, 6, 1, 8);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].Text = lblRecCount.Text;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].Font = new Font("Arial", 10, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;


                fpSpread1.ActiveSheet.ColumnHeader.Rows[2].Height = 40;

                Application.DoEvents();
            }
            finally
            {
                fpSpread1.ResumeLayout();
            }
        }


        private void DesignEquipmentParticularsGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                fpSpread1.SuspendLayout();
                colList.Add(new DgvInits("GroupName", "GroupName", 160, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpCode", "EqpCode", 100, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpName", "Equipment Name", 150, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("NoOfUnits", "NoOfUnits", 55, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Maker", "Maker", 120, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Model", "Model", 120, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Contact", "Mkr Contact", 150, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("PhoneNo", "Maker Phone", 100, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FaxNo", "Mkr Fax", 100, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EmailID", "Mkr EmailID", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Address", "Mkr Address", 200, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("City", "Mkr City", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Country", "Mkr Country", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EQ_EquipmentID", "EqpNo", 45, Color.Black, SystemColors.ButtonFace, true, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, colList, null, false, false, false);

                // Other Properties
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread1.ActiveSheet.RowHeader.Visible = false;
                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread1.ActiveSheet.Columns[3].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "DesignEquipmentParticularsGrid", er.Message);
                Gfn.Mb("Failed to initialize Equipment Particulars Grid");
            }
            finally
            {
                colList = null;
                fpSpread1.ResumeLayout();
            }
        }

        private bool BindEquipmentParticularsGrid()
        {
            DataTable dt = null;
            string script = "";
            try
            {
                script = " select Distinct cast(E.EQ_EquipmentID as varchar) as EQ_EquipmentID, EqpCode, EqpName, Maker, Model,  " + Environment.NewLine +
                         "   Contact, PhoneNo, FaxNo, EmailID, Address1+' '+Address2+' '+Address3  as Address,        " + Environment.NewLine +
                         "   City, Country,  " + Environment.NewLine +
                         "   dbo.func_GetEqpNameList(U.VesselID, U.EQ_EquipmentID, E.EQ_GroupsID) as GroupName      " + Environment.NewLine +
                         "  ,   E.GroupSortOrder , E.AddlSortOrder " + Environment.NewLine +
                         "  , (select count(*) from  EQ_Units where IsDisabled =0 and VesselID = U.VesselID and  EQ_EquipmentID=E.EQ_EquipmentID  and EQ_ModelsID=U.EQ_ModelsID) as NoOfUnits " + Environment.NewLine + 
                         " from Eq_Equipment_V E, EQ_Units U, EQ_Makers M, EQ_Models O " + Environment.NewLine +
                         " where U.VesselID=" + vesselID + "    and E.EQ_EquipmentID=U.EQ_EquipmentID       " + Environment.NewLine +
                         "   and U.IsDisabled =0 and O.EQ_ModelsID=U.EQ_ModelsID and M.EQ_MakersID=O.EQ_MakersID       " + Environment.NewLine +
                         "   and E.EqpName <> 'Dummy' " + Environment.NewLine +
                         "   and E.GroupType=" + Gfn.Qss(groupType) +
                         " order by E.GroupSortOrder , E.AddlSortOrder ";
                dt = PG.Gb.DBFn.DbRecords(script);

                fpSpread1.DataSource = dt;
                lblRecCount.Text = "Total Records : 0";
                if (dt != null)
                {
                    lblRecCount.Text = "Total Records : " + dt.Rows.Count.ToString();
                }

                Application.DoEvents();

                return (true);
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "BindEquipmentGrid", er.Message);
                Gfn.Mb("Failed to Bind Equipment Grid");
                return (false);
            }
            finally
            {
                dt = null;
            }
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            //if(txtVslNo.Text.Trim().Length<=0)
            //{
            //    Gfn.Wb("VslNo should not be blank");
            //}

            //vslno = Convert.ToInt32(txtVslNo.Text.Trim());          

            //BindEquipmentGrid();
            //SetOtherProperities();
        }


        public void btnEqpParticulars_SaveToXL_Click(object sender, EventArgs e)
        {
            DesignEquipmentParticularsGrid();
            if (!BindEquipmentParticularsGrid()) return;
            SetOtherProperities("Equipment Particulars");

            if (fpSpread1.ActiveSheet.RowCount <= 0)
            {
                Gfn.nMbwithAlignAndCentrePosn("No Records to export for this vessel", ContentAlignment.MiddleCenter);
                return;
            }

            DateTime todaysDate = Gfn.GetTodaysDate(PG.Gb.DBFn);
            string fileName = "EquipmentParticulars_" + vslName + "_" + todaysDate.ToString("ddMMMyyyy_HHmm") + ".xls";
            string fileNameWithPath = PG.xlsOutputFolderPath + "\\" + fileName;
            if (!Gfn.DeleteFileIfExists(fileNameWithPath)) return;

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.InitialDirectory = PG.xlsOutputFolderPath;
            saveDialog.Filter = "Excel files (*.xls)|*.xls";
            saveDialog.FileName = fileName;

            if (saveDialog.ShowDialog() == DialogResult.Cancel) return;

            fileName = saveDialog.FileName;

            fpSpread1.ActiveSheet.Protect = false;
            try
            {
                //Gridlines Off
                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, Color.Empty);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;
                fpSpread1.ActiveSheet.SheetName = "Equipment Particulars";
                // assign Borders
                if ((fpSpread1.ActiveSheet.RowCount > 0) && (fpSpread1.ActiveSheet.ColumnCount > 0))
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[2, 0, 2, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[2, 0, 2, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);

                    fpSpread1.ActiveSheet.Cells[0, 0, fpSpread1.ActiveSheet.RowCount - 1, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                }

                bool hasExportedSuccessfully = (fpSpread1.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders | FarPoint.Excel.ExcelSaveFlags.SaveAsViewed));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to export equipment particulars -- " + err.Message);
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "btnEqpParticulars_SaveToXL_Click()", err.Message);
            }
            fpSpread1.ActiveSheet.Protect = true;
        }


        private void DesignPMSGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                fpSpread1.SuspendLayout();

                colList.Add(new DgvInits("GroupName", "Eqp Group", 150, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpName", "Equipment", 150, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("PositionDesc", "Position", 70, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("MaintDescription", "Maintenance Title", 180, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("MaintenanceProcedure", "Maintenance procedures", 220, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("MaintenanceChecklist", "Maintenance CheckList", 180, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("MaintTypeDisplay", "Maint Type", 60, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("DeptDisplayStr", "Dept", 60, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Interval", "Interval", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Lastohdate_display", "Last Maint", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Maintdue_display", "Maint Due", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("PMM_DocRefno", "PMM DocNo", 70, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("MaintCode", "Maint Code", 50, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("InChargeRank", "InCharge (Rank)", 69, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("ReponsibleRank", "Responsible (Rank)", 85, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("PmsCode", "PMS Code", 95, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Component", "Component", 200, Color.Black, SystemColors.ButtonFace, true, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, colList, null, false, false, true);

                FarPoint.Win.Spread.CellType.GeneralCellType cellFormat = new FarPoint.Win.Spread.CellType.GeneralCellType();
                cellFormat.WordWrap = true;
                cellFormat.EnableSubEditor = false;
                fpSpread1.ActiveSheet.Columns[3].CellType = cellFormat;

                // Other Properties
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread1.ActiveSheet.RowHeader.Visible = false;
                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 40;
                fpSpread1.ActiveSheet.DisplayZero = false;
                fpSpread1.ActiveSheet.Columns[8].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;

                fpSpread1.ActiveSheet.Columns[COL_MaintenanceProcedure].Visible = isWithMaintProcdure;
                fpSpread1.ActiveSheet.Columns[COL_MaintenanceChecklist].Visible = isWithCheckList;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "DesignPMSGrid", er.Message);
                Gfn.Mb("Failed to initialize PMS Grid");
            }
            finally
            {
                colList = null;
                fpSpread1.ResumeLayout();
            }
        }

        private void BindPMSGrid()
        {
            DataTable dt = null;
            string script;
            fpSpread1.SuspendLayout();
            try
            {
                PG.InitialiseVesselSettings(vesselID);

                fpSpread1.ActiveSheet.RowCount = 0;
                lblRecCount.Text = "Total Records : 0";

                script = " select distinct dbo.func_GetEqpNameList(V.VesselID, V.EQ_EquipmentID,V.EQ_GroupsID) as GroupName, EqpName " +
                         "    , PositionDescDisplay PositionDesc, MaintDescription  " + Environment.NewLine +
                         "    , Cast(isnull((select top 1 TextContents from EQ_MaintInstructions where VesselId=V.VesselId and PMS_DocID= V.PMS_DocID),'')  as varchar(max)) MaintenanceProcedure " + Environment.NewLine +
                         "    , '' MaintenanceCheckList, -1 EQ_MaintCheckListID " + Environment.NewLine +
                         "    , MaintType as MaintTypeDisplay, DeptDisplayStr, Interval , LastOhDate_Display, MaintDue_Display                " + Environment.NewLine +
                         "    , InChargeRank, ReponsibleRank, PmsCode, PMM_DocRefno, MaintCode, Component, CMEqpName " + Environment.NewLine +
                         "    , EqpUnitNo, EqpMaintNo " + Environment.NewLine +
                         "    , V.GroupSortOrder, V.UnitAddlSortOrder " + Environment.NewLine +
                         " from PmsDetails_V V " + Environment.NewLine +
                         " where GroupType='" + PG.defaultEqpGroup + "' " + Environment.NewLine +
                         "   and VesselID= " + vesselID + Environment.NewLine;
                //if (calledMode.Trim().ToUpper() == "PMSITEMSWITHCHECKLIST")
                if (isWithCheckList)
                {
                    script = script +
                               " union all " + Environment.NewLine +
                               " select ''  GroupName,  '' EqpName, '' PositionDesc, '' MaintDescription, '' MaintenanceProcedure " + Environment.NewLine +
                               "    , MaintDetails MaintenanceCheckList, EQ_MaintCheckListID, '' MaintTypeDisplay, '' DeptDisplayStr, '' Interval, '' LastOhDate_Display, '' MaintDue_Display  " + Environment.NewLine +
                               "    , '' InChargeRank, '' ReponsibleRank, '' PmsCode, '' PMM_DocRefno, '' MaintCode, '' Component, '' CMEqpName, EqpUnitNo, EqpMaintNo " + Environment.NewLine +
                               "    , V.GroupSortOrder, V.UnitAddlSortOrder " + Environment.NewLine +
                               " from PmsDetails_V V, EQ_MaintCheckList D " + Environment.NewLine +
                               " where V.PMS_DocID=D.PMS_DocID " + Environment.NewLine +
                               "    and V.GroupType='" + PG.defaultEqpGroup + "' " + Environment.NewLine +
                               "    and V.VesselID=D.VesselID " + Environment.NewLine +
                               "    and D.IsDisabled =0 " + 
                               "    and V.VesselID=" + vesselID + Environment.NewLine+
                               "    and D.EQ_UnitsID = -1 " +
                               "    and not exists(select * from EQ_MaintCheckList where VesselID = D.VesselID and PMS_DocID = D.PMS_DocID and EQ_UnitsID = V.EQ_UnitsID and EQ_UnitsID > 0)";
                    script = script +
                               " union all " + Environment.NewLine +
                               " select ''  GroupName,  '' EqpName, '' PositionDesc, '' MaintDescription, '' MaintenanceProcedure " + Environment.NewLine +
                               "    , MaintDetails MaintenanceCheckList, EQ_MaintCheckListID, '' MaintTypeDisplay, '' DeptDisplayStr, '' Interval, '' LastOhDate_Display, '' MaintDue_Display  " + Environment.NewLine +
                               "    , '' InChargeRank, '' ReponsibleRank, '' PmsCode, '' PMM_DocRefno, '' MaintCode, '' Component, '' CMEqpName, EqpUnitNo, EqpMaintNo " + Environment.NewLine +
                               "    , V.GroupSortOrder, V.UnitAddlSortOrder " + Environment.NewLine +
                               " from PmsDetails_V V, EQ_MaintCheckList D " + Environment.NewLine +
                               " where V.PMS_DocID=D.PMS_DocID " + Environment.NewLine +
                               "    and V.GroupType='" + PG.defaultEqpGroup + "' " + Environment.NewLine +
                               "    and V.VesselID=D.VesselID " + Environment.NewLine +
                               "    and D.EQ_UnitsID = V.EQ_UnitsID " +
                               "    and D.IsDisabled =0 " +
                               "    and V.VesselID=" + vesselID + Environment.NewLine;
                    fpSpread1.ActiveSheet.Columns[COL_MaintenanceChecklist].Visible = true;                               
                }
                
                //Exclude maint type
                string maintTypeToExclude = "";
                if (!PG.isEnableAlarmsAndRoutinesMaintType) maintTypeToExclude = maintTypeToExclude + PG.MAINTTYPE_ALARMS_ROUTINE + ", ";
                maintTypeToExclude = maintTypeToExclude.Trim();
                if (maintTypeToExclude.Length > 1)
                {
                    maintTypeToExclude = maintTypeToExclude.Substring(0, maintTypeToExclude.Length - 1);
                     script = script + "    and MaintType not in ('" + maintTypeToExclude.Replace(",", "','") + "')  " + Environment.NewLine;
                }

                script = script + " order by V.GroupSortOrder, V.UnitAddlSortOrder, EqpMaintNo, EQ_MaintCheckListID ";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt != null && dt.Rows.Count > 0)
                {
                    fpSpread1.ActiveSheet.DataSource = dt;
                    fpSpread1_ColumnWidthChanged(null, null);
                }
                
                if (dt != null)
                {
                    lblRecCount.Text = "Total Records : " + dt.Rows.Count.ToString();                                        
                }
                Application.DoEvents();
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "BindPMSGrid", er.Message);
                Gfn.Mb("Failed to Bind Pms List Grid");
            }
            finally
            {
                dt = null;
                fpSpread1.ResumeLayout();
            }
        }
             

        public void btnSaveToXL_Click(object sender, EventArgs e)
        {
            DesignPMSGrid();
            BindPMSGrid();
            SetOtherProperities();

            if (fpSpread1.ActiveSheet.RowCount <= 0)
            {   
                Gfn.nMbwithAlignAndCentrePosn("No Records to export for this vessel", ContentAlignment.MiddleCenter);
                return;
            }


            DateTime todaysDate = Gfn.GetTodaysDate(PG.Gb.DBFn);
            string fileName = "PMSList_" + vslName + "_" + todaysDate.ToString("ddMMMyyyy_HHmm") + ".xls";
            
            fileName = PG.RemoveInvalidChar(fileName);
            string fileNameWithPath = PG.xlsOutputFolderPath + "\\" + fileName;
            if (!Gfn.DeleteFileIfExists(fileNameWithPath)) return;

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.FileName = fileName;
            saveDialog.InitialDirectory = PG.xlsOutputFolderPath;
            saveDialog.Filter = "Excel files (*.xls)|*.xls";

            if (saveDialog.ShowDialog() == DialogResult.Cancel) return;

            fileName = saveDialog.FileName;

            if (!Gfn.DeleteFileIfExists(fileName)) return;

            fpSpread1.ActiveSheet.Protect = false;
            try
            {
                //Gridlines Off
                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, Color.Empty);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;
                
                fpSpread1.ActiveSheet.SheetName = "PMS Items";

                // assign Borders
                if ((fpSpread1.ActiveSheet.RowCount > 0) && (fpSpread1.ActiveSheet.ColumnCount > 0))
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[2, 0, 2, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[2, 0, 2, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);

                    fpSpread1.ActiveSheet.Cells[0, 0, fpSpread1.ActiveSheet.RowCount - 1, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                }

                bool hasExportedSuccessfully = (fpSpread1.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders | FarPoint.Excel.ExcelSaveFlags.SaveAsViewed));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to export  -- " + err.Message);
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "btnSaveToXL_Click()", err.Message);
            }
            finally
            {
                //fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Remove();
                //fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 40;
                //fpSpread1.ActiveSheet.Models.ColumnHeaderRowAxis.SetSize(0, 28);
            }
            fpSpread1.ActiveSheet.Protect = true;
        }

        private void SetOtherProperities()
        {
            try
            {
                if (fpSpread1.ActiveSheet.DataSource == null) return;
                fpSpread1.SuspendLayout();
                          
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Add();
                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fpSpread1.ActiveSheet.ColumnCount);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].Text = PG.companyName;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 12, FontStyle.Bold);                
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 35;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].ForeColor = Color.Blue;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Add();
                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(1, 0, 1, 7);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].Text = vslName + " - PMS Items List                                      Date:" + PG.GetDbServerDate().ToString("dd-MMM-yyyy");
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 12, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Height = 23;

                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(1, 8, 1, 11);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 8].Text = lblRecCount.Text;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 8].Font = new Font("Arial", 10, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 8].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 8].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;


                fpSpread1.ActiveSheet.ColumnHeader.Rows[2].Height = 40;
                fpSpread1.ActiveSheet.DisplayZero = false;

                Application.DoEvents();
            }
            finally
            {
                fpSpread1.ResumeLayout();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void btnEqpUnit_SaveToXL_Click(object sender, EventArgs e)
        {
            DesignEquipmentUnitGrid();
            if (!BindEquipmentUnitGrid()) return;
            SetOtherProperities("Equipment List");

            if (fpSpread1.ActiveSheet.RowCount <= 0)
            {
                Gfn.nMbwithAlignAndCentrePosn("No Records to export for this vessel",ContentAlignment.MiddleCenter, 110, 250);
                return;
            }

            DateTime todaysDate = Gfn.GetTodaysDate(PG.Gb.DBFn);
            string fileName = "EquipmentList_" + vslName + "_" + todaysDate.ToString("ddMMMyyyy_HHmm") + ".xls";
            string fileNameWithPath = PG.xlsOutputFolderPath + "\\" + fileName;
            if (!Gfn.DeleteFileIfExists(fileNameWithPath)) return;

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.InitialDirectory = PG.xlsOutputFolderPath;
            saveDialog.Filter = "Excel files (*.xls)|*.xls";
            saveDialog.FileName = fileName;

            if (saveDialog.ShowDialog() == DialogResult.Cancel) return;

            fileName = saveDialog.FileName;

            fpSpread1.ActiveSheet.Protect = false;
            try
            {
                fpSpread1.ActiveSheet.SheetName = "Equipment Unit Particulars";

                //Gridlines Off
                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, Color.Empty);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                // assign Borders
                if ((fpSpread1.ActiveSheet.RowCount > 0) && (fpSpread1.ActiveSheet.ColumnCount > 0))
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[2, 0, 2, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[2, 0, 2, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);

                    fpSpread1.ActiveSheet.Cells[0, 0, fpSpread1.ActiveSheet.RowCount - 1, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                }

                bool hasExportedSuccessfully = (fpSpread1.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders | FarPoint.Excel.ExcelSaveFlags.SaveAsViewed));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to export equipment unit list  -- " + err.Message);
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "btnEqpUnit_SaveToXL_Click()", err.Message);
            }
            fpSpread1.ActiveSheet.Protect = true;
        }

        private void DesignEquipmentUnitGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                fpSpread1.SuspendLayout();
                colList.Add(new DgvInits("GroupName", "GroupName", 160, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpCode", "EqpCode", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpName", "Equipment Name", 150, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpUnitNo", "UnitNo", 45, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("PositionDesc", "Position", 70, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EqpUnitDescription", "Eqp Unit Description", 180, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Maker", "Maker", 120, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Model", "Model", 120, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("DWGNO", "Drawing No", 100, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("SerialNo", "SerialNo", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Capacity", "Capacity", 100, Color.Black, SystemColors.ButtonFace, false, true));
                colList.Add(new DgvInits("Rating", "Rating", 100, Color.Black, SystemColors.ButtonFace, true, true));               
                colList.Add(new DgvInits("Volts", "Volts", 60, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("RPM", "RPM", 60, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("MFgYear", "Year", 60, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Contact", "Mkr Contact", 150, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("PhoneNo", "Maker Phone", 100, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("FaxNo", "Mkr Fax", 100, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EmailID", "Mkr EmailID", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Address", "Mkr Address", 200, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("City", "Mkr City", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("Country", "Mkr Country", 80, Color.Black, SystemColors.ButtonFace, true, true));                
                colList.Add(new DgvInits("InstallationDate_Display", "Installation Date", 90, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("IsRunHrsBased", "Is RunHrs Based", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("AvgRunHrsPerMonth", "AvgRunHrsPerMonth", 80, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("EQ_EquipmentID", "EqpNo", 45, Color.Black, SystemColors.ButtonFace, true, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, colList, null, false, false, false);

                // Other Properties
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread1.ActiveSheet.RowHeader.Visible = false;
                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "DesignEquipmentUnitGrid", er.Message);
                Gfn.Mb("Failed to initialize Equipment Grid");
            }
            finally
            {
                colList = null;
                fpSpread1.ResumeLayout();
            }
        }

        private bool BindEquipmentUnitGrid()
        {
            DataTable dt = null;
            string script = "";
            try
            {
                /*
                script = " select cast(E.EQ_EquipmentID as varchar) as EQ_EquipmentID, EqpCode,  E.EqpName, EqpUnitNo , PositionDesc, EqpUnitDescription, Maker, Model, " +
                         "        DWGNO, MFgYear, Contact, PhoneNo, FaxNo, EmailID, Address1+' '+Address2+' '+Address3  as Address, SerialNo, replace(convert (varchar(11),InstallationDate, 13),' ','-') as InstallationDate_Display, " +
                         "        U.IsRunHrsBased, AvgRunHrsPerMonth, City, Country, dbo.func_GetEqpNameList(U.VesselID, U.EQ_EquipmentID, E.EQ_GroupsID) as GroupName  " +
                         "       , E.GroupSortOrder, U.AddlSortOrder " +
                         " from Eq_Equipment_V E, EQ_Units U, EQ_Makers M, EQ_Models O " +
                         " where U.VesselID=" + vesselID +
                         "       and U.IsDisabled =0 and E.EQ_EquipmentID=U.EQ_EquipmentID " +
                         "       and O.EQ_ModelsID=U.EQ_ModelsID " +
                         "       and M.EQ_MakersID=O.EQ_MakersID " +
                         "       and E.EqpName <> 'Dummy' " +
                         "       and E.GroupType=" + Gfn.Qss(groupType) +
                         " order by E.GroupSortOrder, U.AddlSortOrder  ";
                 * */

                script = " Select  E.GroupSortOrder, U.AddlSortOrder  " + Environment.NewLine +
                         " , cast(E.EQ_EquipmentID as varchar) as EQ_EquipmentID, EqpCode,  E.EqpName, EqpUnitNo " + Environment.NewLine +
                         " , PositionDesc, EqpUnitDescription, Maker, Model,         DWGNO, MFgYear, Contact, PhoneNo, FaxNo" + Environment.NewLine +
                         " , EmailID, Address1+' '+Address2+' '+Address3  as Address, SerialNo " + Environment.NewLine +
                         " , replace(convert (varchar(11),InstallationDate, 13),' ','-') as InstallationDate_Display        " + Environment.NewLine +
                         " , U.IsRunHrsBased, AvgRunHrsPerMonth, City, Country, dbo.func_GetEqpNameList(U.VesselID, U.EQ_EquipmentID, E.EQ_GroupsID) as GroupName        " + Environment.NewLine +
                         " from Eq_Equipment_V E, EQ_Units U, EQ_Makers M, EQ_Models O  " +
                         " where U.VesselID=" + vesselID + Environment.NewLine +
                         "      and U.IsDisabled =0 and E.EQ_EquipmentID=U.EQ_EquipmentID and O.EQ_ModelsID=U.EQ_ModelsID   " + Environment.NewLine +
                         "      and M.EQ_MakersID=O.EQ_MakersID        and E.EqpName <> 'Dummy'      " + Environment.NewLine +
                         "      and E.GroupType= " + Gfn.Qss(groupType) + Environment.NewLine +
                         "      and E.GroupCode<>'@'" + Environment.NewLine +

                         " union all" + Environment.NewLine +

                         " select E.GroupSortOrder , E.AddlSortOrder  " + Environment.NewLine +
                         " , cast(E.EQ_EquipmentID as varchar) as EQ_EquipmentID, EqpCode,  E.EqpName, EqpUnitNo " + Environment.NewLine +
                         " , PositionDesc, EqpUnitDescription, Maker, Model,         DWGNO, MFgYear, Contact, PhoneNo, FaxNo" + Environment.NewLine +
                         " , EmailID, Address1+' '+Address2+' '+Address3  as Address, SerialNo " + Environment.NewLine +
                         " , replace(convert (varchar(11),InstallationDate, 13),' ','-') as InstallationDate_Display        " + Environment.NewLine +
                         " , U.IsRunHrsBased, AvgRunHrsPerMonth, City, Country, dbo.func_GetEqpNameList(U.VesselID, U.EQ_EquipmentID, E.EQ_GroupsID) as GroupName        " + Environment.NewLine +
                         " from Eq_Equipment_V E, EQ_Units U, EQ_Makers M, EQ_Models O  " + Environment.NewLine +
                         " where U.VesselID=" + vesselID + Environment.NewLine +
                         "      and U.IsDisabled =0 and E.EQ_EquipmentID=U.EQ_EquipmentID and O.EQ_ModelsID=U.EQ_ModelsID   " + Environment.NewLine +
                         "      and M.EQ_MakersID=O.EQ_MakersID and E.EqpName <> 'Dummy' " + Environment.NewLine +
                         "      and E.GroupType=" + Gfn.Qss(groupType) + Environment.NewLine +
                         "      and E.GroupCode ='@'" + Environment.NewLine +
                         " order by 1, 2, EqpUnitNo ";
                dt = PG.Gb.DBFn.DbRecords(script);

                fpSpread1.DataSource = dt;
                lblRecCount.Text = "Total Records : 0";
                if (dt != null)
                {
                    lblRecCount.Text = "Total Records : " + dt.Rows.Count.ToString();
                }

                Application.DoEvents();
                return (true);
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmExportEquipmentList.CS", "BindEquipmentUnitGrid", er.Message);
                Gfn.Mb("Failed to Bind Equipment Grid");
                return (false);
            }
            finally
            {
                dt = null;
            }
        }

        private void fpSpread1_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpread1.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }
    }
}
