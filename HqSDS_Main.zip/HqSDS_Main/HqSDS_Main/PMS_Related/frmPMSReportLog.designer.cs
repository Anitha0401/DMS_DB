﻿namespace HqSDS_Main
{
    partial class frmPMSReportLog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEventLog));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblMaintDesc = new System.Windows.Forms.Label();
            this.lblEqpname = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.fpSpread_Log = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_Log_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Log)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Log_Sheet1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(887, 427);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.lblMaintDesc);
            this.panel1.Controls.Add(this.lblEqpname);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(883, 64);
            this.panel1.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(809, 27);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(67, 30);
            this.btnClose.TabIndex = 37;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblMaintDesc
            // 
            this.lblMaintDesc.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintDesc.ForeColor = System.Drawing.Color.Black;
            this.lblMaintDesc.Location = new System.Drawing.Point(4, 27);
            this.lblMaintDesc.Name = "lblMaintDesc";
            this.lblMaintDesc.Size = new System.Drawing.Size(799, 34);
            this.lblMaintDesc.TabIndex = 1;
            this.lblMaintDesc.Text = "MaintDesc";
            // 
            // lblEqpname
            // 
            this.lblEqpname.Font = new System.Drawing.Font("Verdana", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEqpname.ForeColor = System.Drawing.Color.Blue;
            this.lblEqpname.Location = new System.Drawing.Point(3, 4);
            this.lblEqpname.Name = "lblEqpname";
            this.lblEqpname.Size = new System.Drawing.Size(800, 19);
            this.lblEqpname.TabIndex = 0;
            this.lblEqpname.Text = "EqpName";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.fpSpread_Log);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(5, 71);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(877, 351);
            this.panel2.TabIndex = 1;
            // 
            // fpSpread_Log
            // 
            this.fpSpread_Log.AccessibleDescription = "fpSpreadPmsHist, Sheet1, Row 0, Column 0, ";
            this.fpSpread_Log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_Log.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_Log.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_Log.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Log.HorizontalScrollBar.Name = "";
            this.fpSpread_Log.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread_Log.HorizontalScrollBar.TabIndex = 0;
            this.fpSpread_Log.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread_Log.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_Log.Name = "fpSpread_Log";
            this.fpSpread_Log.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_Log_Sheet1});
            this.fpSpread_Log.Size = new System.Drawing.Size(877, 351);
            this.fpSpread_Log.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_Log.TabIndex = 18;
            this.fpSpread_Log.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Log.VerticalScrollBar.Name = "";
            this.fpSpread_Log.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread_Log.VerticalScrollBar.TabIndex = 1;
            this.fpSpread_Log.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread_Log.VisualStyles = FarPoint.Win.VisualStyles.On;
            this.fpSpread_Log.ColumnWidthChanged += new FarPoint.Win.Spread.ColumnWidthChangedEventHandler(this.fpSpread1_ColumnWidthChanged);
            this.fpSpread_Log.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread1_CellClick);
            this.fpSpread_Log.AutoSortingColumn += new FarPoint.Win.Spread.AutoSortingColumnEventHandler(this.fpSpread1_AutoSortingColumn);
            // 
            // fpSpread_Log_Sheet1
            // 
            this.fpSpread_Log_Sheet1.Reset();
            this.fpSpread_Log_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_Log_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_Log_Sheet1.ColumnCount = 10;
            this.fpSpread_Log_Sheet1.RowCount = 10;
            this.fpSpread_Log_Sheet1.AutoGenerateColumns = false;
            this.fpSpread_Log_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Log_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Log_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Log_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Log_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_Log_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Log_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Log_Sheet1.DataAutoSizeColumns = false;
            this.fpSpread_Log_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpread_Log_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpread_Log_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Log_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_Log_Sheet1.RowHeader.Visible = false;
            this.fpSpread_Log_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpread_Log_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Log_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Log_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // frmEventLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 427);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmEventLog";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "  Event Log";
            this.Activated += new System.EventHandler(this.frmEventLog_Activated);
            this.Load += new System.EventHandler(this.frmEventLog_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Log)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Log_Sheet1)).EndInit();
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Label lblMaintDesc;
    private System.Windows.Forms.Label lblEqpname;
    private System.Windows.Forms.Button btnClose;
    private FarPoint.Win.Spread.FpSpread fpSpread_Log;
    private FarPoint.Win.Spread.SheetView fpSpread_Log_Sheet1;
  }
}