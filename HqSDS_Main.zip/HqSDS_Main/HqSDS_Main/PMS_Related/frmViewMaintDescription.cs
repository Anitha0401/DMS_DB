﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmViewMaintDescription : Form
    {
        public long curEQUnitID, curEQMaintID, curPms_DocID;
        public int curVesselID = -1;
        public string maintType = "";
        public int parentMouseXPosn = -1;

        const int COL_MANUAL_REFNO = 0,
                 COL_MANUAL_DESCRIPTION = 1,
                 COL_MANUAL_BLOBSIZEDSIPLAY = 2,
                 COL_MANUAL_VIEW = 3,
                 COL_MANUAL_PAGENO = 4,
                 COL_MANUAL_PMS_DOCID = 5,
                 COL_MANUAL_EQ_MAINT_MANUALREFERENCEID = 6,
                 COL_MANUAL_EQ_MAINT_MANUALREFERENCE_EXTID = 7,
                 COL_MANUAL_NAME = 8,
                 COL_MANUAL_ISMANUALREF = 9,
                 COL_MANUAL_ORIGIN = 10,
                 COL_MANUAL_VESSELID = 11;

        public frmViewMaintDescription()
        {
            InitializeComponent();
        }

        private void frmViewMaintDescription_Load(object sender, EventArgs e)
        {
            lblMaint.Text = "Maintenance Title";
            lblMaintDetails.Text = "Maintenance procedures";
            this.Text = "Maintenance procedures";

            if (maintType.ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE)
            {
                lblMaint.Text = "Alarms && Routines Title";
                lblMaintDetails.Text = "Alarms and Routines procedures";
                this.Text = "Alarms and Routines procedures";
            }
            else if (maintType.ToUpper() == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE)
            {
                lblMaint.Text = "CM Routine Title :";
                lblMaintDetails.Text = "CM Routine procedures";
                this.Text = "CM Routine procedures";
            }
            DesignManualReferenceGrid();
            BindMaintDetails();
            BindManualReferenceGrid();
        }

        private void DesignManualReferenceGrid()
        {
            List<DgvInits> manualColList = new List<DgvInits>();
            try
            {
                Color bkColor = Color.FromArgb(235, 255, 235);
              
                manualColList.Add(new DgvInits("ManualNo", "#", 50, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                manualColList.Add(new DgvInits("ManualDescription", "Description", 320, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                manualColList.Add(new DgvInits("BlobSizeDisplay", "Blob Size", 65, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                manualColList.Add(new DgvInits("View", "#", 0, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                manualColList.Add(new DgvInits("PageNo", "PageNo", 40, Color.Black, SystemColors.ButtonFace, false, true));
                manualColList.Add(new DgvInits("PMS_DocID", "PMS_DocID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                manualColList.Add(new DgvInits("EQ_Maint_ManualReferenceID", "EQ_Maint_ManualReferenceID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                manualColList.Add(new DgvInits("EQ_Maint_ManualReference_ExtID", "EQ_Maint_ManualReference_ExtID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                manualColList.Add(new DgvInits("ManualName", "ManualName", 40, Color.Black, SystemColors.ButtonFace, false, true));
                manualColList.Add(new DgvInits("IsManualRef", "IsManualRef", 40, Color.Black, SystemColors.ButtonFace, false, true));
                manualColList.Add(new DgvInits("Origin", "Origin", 50, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                manualColList.Add(new DgvInits("VesselID", "VesselID", 60, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));


                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Manual, manualColList, null, false, true, true);

                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpread_Manual, false, "View File", COL_MANUAL_VIEW, "View", 45, bkColor);

                fpSpread_Manual.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;
                fpSpread_Manual.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmViewMaintDescription.cs", "DesignManualReferenceGrid", err.Message);
            }
            finally
            {
                manualColList = null;
            }
        }
      
        private void BindMaintDetails()
        {
            string script; DataTable dtMaintDet;
            try
            {
                script = " select EqpName, MaintDescription " + Environment.NewLine +
                         " from PmsDetails_V V  " + Environment.NewLine +
                         " where V.GroupType=" + Gfn.Qss(PG.defaultEqpGroup) + Environment.NewLine +
                         "    and V.VesselID=" + curVesselID + Environment.NewLine +
                         "    and V.EQ_UnitsID = " + curEQUnitID.ToString() + Environment.NewLine +
                         "    and V.EQ_MaintenanceID = " + curEQMaintID.ToString();
                dtMaintDet = PG.Gb.DBFn.DbRecords(script);

                if (dtMaintDet != null)
                {
                    lblEqpName.Text = dtMaintDet.Rows[0]["EqpName"].ToString();
                    txtMaintenance.Text = dtMaintDet.Rows[0]["MaintDescription"].ToString().Replace("\n", "\r\n");
                }

                txtMaintDetails.Text = PG.GetHQAndVslMaintenanceInstructions(curPms_DocID,curVesselID, curEQUnitID).Replace("\n", "\r\n");
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmViewMaintDescription.cs", "BindMaintDetails", err.Message);
            }
        }

        

        private void BindManualReferenceGrid()
        {
            try
            {
                fpSpread_Manual.SuspendLayout();
                fpSpread_Manual.ActiveSheet.RowCount = 0;

                fpSpread_Manual.ActiveSheet.DataSource = PG.GetManualReferenceList(curVesselID, curPms_DocID);
                
                for (int row = 0; row < fpSpread_Manual.ActiveSheet.RowCount; row++)
                {
                    fpSpread_Manual.ActiveSheet.Rows[row].Height = fpSpread_Manual.ActiveSheet.Rows[row].GetPreferredHeight();
                    int isManualRef = 0;
                    if (fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_ISMANUALREF].Value != null) isManualRef = Convert.ToInt32(fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_ISMANUALREF].Value.ToString());
                    if (isManualRef == 1)
                    {
                        fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_VIEW].CellType = new FarPoint.Win.Spread.CellType.GeneralCellType();
                        fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_VIEW].Text = "";
                        fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_VIEW].Locked = true;
                    }
                }
            }
            finally
            {
                fpSpread_Manual.ResumeLayout();
            }
        }

        private void fpSpread_Manual_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;

            if (e.Column == COL_MANUAL_VIEW)
            {
                tsMnuViewManualFile_Click(null, null);
            }
        }

        private void fpSpread_Manual_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        private void fpSpread_Manual_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread_Manual.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread_Manual.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread_Manual.HitTest(e.X, e.Y).ViewportInfo.Column;
                if ((row < 0) || (col < 0)) return;

                fpSpread_Manual.ActiveSheet.SetActiveCell(row, col);

                int isManualRef = 0;
                if (fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_ISMANUALREF].Value != null) isManualRef = Convert.ToInt32(fpSpread_Manual.ActiveSheet.Cells[row, COL_MANUAL_ISMANUALREF].Value.ToString());

                tsMnuViewManualFile.Enabled = (isManualRef == 0);
            }
        }

        private void tsMnuViewManualFile_Click(object sender, EventArgs e)
        {
            if (fpSpread_Manual.ActiveSheet.ActiveCell == null) return;

            try
            {
                int rowIndex = fpSpread_Manual.ActiveSheet.ActiveRowIndex;
                long eq_Maint_ManualReference_ExtID = GetManualCellValue_long(rowIndex, COL_MANUAL_EQ_MAINT_MANUALREFERENCE_EXTID);

                if (eq_Maint_ManualReference_ExtID <= 0) return;

                int isManualRef = 0;
                if (fpSpread_Manual.ActiveSheet.Cells[rowIndex, COL_MANUAL_ISMANUALREF].Value != null) isManualRef = Convert.ToInt32(fpSpread_Manual.ActiveSheet.Cells[rowIndex, COL_MANUAL_ISMANUALREF].Value.ToString());
                if (isManualRef == 0)
                {
                    string vesselID = "-1";
                    if (fpSpread_Manual.ActiveSheet.Cells[rowIndex, COL_MANUAL_VESSELID].Value != null) vesselID = fpSpread_Manual.ActiveSheet.Cells[rowIndex, COL_MANUAL_VESSELID].Value.ToString();

                    PG.attachment.ViewFileFrom_DB_or_AzureStorage_or_LocalFolder(vesselID.ToString(), "EQ_MaintAttachments", eq_Maint_ManualReference_ExtID.ToString(), true);
                }
            }
            catch (Exception err)
            {
                PG.DisplayException("View Manual Reference", err.Message);
                PG.AddToGenErrorLog("frmViewMaintDescription.cs", "tsMnuViewManualFile_Click", err.Message);
            }
        }
        
        private long GetManualCellValue_long(int row, int col)
        {
            long result = -1;
            string sx1 = "";
            if (fpSpread_Manual.ActiveSheet.Cells[row, col].Value != null) sx1 = fpSpread_Manual.ActiveSheet.Cells[row, col].Value.ToString().Trim();
            if (sx1.Length > 0)
            {
                result = Convert.ToInt64(sx1);
            }
            return (result);
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
