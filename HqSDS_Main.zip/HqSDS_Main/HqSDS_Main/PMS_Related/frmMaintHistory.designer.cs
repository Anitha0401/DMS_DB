﻿namespace HqSDS_Main
{
  partial class frmMaintHistory
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaintHistory));
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer2 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer7 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer8 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSFICode = new System.Windows.Forms.Label();
            this.lblSFICodeTitle = new System.Windows.Forms.Label();
            this.lblInterval = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lnkViewForm = new System.Windows.Forms.LinkLabel();
            this.lblMaintdesc = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblEqpname = new System.Windows.Forms.Label();
            this.btnExportXL = new System.Windows.Forms.Button();
            this.lnkViewMaintDetails = new System.Windows.Forms.LinkLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtSuptComments = new System.Windows.Forms.TextBox();
            this.txtVesselComments = new System.Windows.Forms.TextBox();
            this.lblSuptCom = new System.Windows.Forms.Label();
            this.lblVessel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.fpSpreadConsumed = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadConsumed_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.fpSpreadAssociatedForms = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadAssociatedForms_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblHistIndicator = new System.Windows.Forms.Label();
            this.fpSpreadPmsHist = new FarPoint.Win.Spread.FpSpread();
            this.sheetView1 = new FarPoint.Win.Spread.SheetView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblProcedure = new System.Windows.Forms.Label();
            this.chkMaintDoneAsPerInstructions = new System.Windows.Forms.CheckBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.pnlPostponement = new System.Windows.Forms.Panel();
            this.lblPostponementDate = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.lblPlace_Postponement = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.pnlRoutine = new System.Windows.Forms.Panel();
            this.lnkViewAlarmsRoutinesReport = new System.Windows.Forms.LinkLabel();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblVerifiy = new System.Windows.Forms.Label();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblres = new System.Windows.Forms.Label();
            this.lblver = new System.Windows.Forms.Label();
            this.lblLoc = new System.Windows.Forms.Label();
            this.pnlPMS = new System.Windows.Forms.Panel();
            this.lblPlace = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lnkViewMaintCheckList = new System.Windows.Forms.LinkLabel();
            this.lblManHrs = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblCompletion = new System.Windows.Forms.Label();
            this.lblCondition = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblActualRunningHours = new System.Windows.Forms.Label();
            this.lblActualRunningHours_Display = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed_Sheet1)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).BeginInit();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadPmsHist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sheetView1)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel15.SuspendLayout();
            this.pnlPostponement.SuspendLayout();
            this.pnlRoutine.SuspendLayout();
            this.pnlPMS.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblSFICode);
            this.panel1.Controls.Add(this.lblSFICodeTitle);
            this.panel1.Controls.Add(this.lblInterval);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lnkViewForm);
            this.panel1.Controls.Add(this.lblMaintdesc);
            this.panel1.Controls.Add(this.lblTitle);
            this.panel1.Controls.Add(this.lblEqpname);
            this.panel1.Controls.Add(this.btnExportXL);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 71);
            this.panel1.TabIndex = 0;
            // 
            // lblSFICode
            // 
            this.lblSFICode.AutoSize = true;
            this.lblSFICode.Font = new System.Drawing.Font("Arial", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblSFICode.Location = new System.Drawing.Point(683, 8);
            this.lblSFICode.Name = "lblSFICode";
            this.lblSFICode.Size = new System.Drawing.Size(19, 13);
            this.lblSFICode.TabIndex = 74;
            this.lblSFICode.Text = "---";
            // 
            // lblSFICodeTitle
            // 
            this.lblSFICodeTitle.AutoSize = true;
            this.lblSFICodeTitle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic);
            this.lblSFICodeTitle.Location = new System.Drawing.Point(631, 8);
            this.lblSFICodeTitle.Name = "lblSFICodeTitle";
            this.lblSFICodeTitle.Size = new System.Drawing.Size(59, 14);
            this.lblSFICodeTitle.TabIndex = 73;
            this.lblSFICodeTitle.Text = "SFICode : ";
            // 
            // lblInterval
            // 
            this.lblInterval.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblInterval.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInterval.ForeColor = System.Drawing.Color.Black;
            this.lblInterval.Location = new System.Drawing.Point(631, 42);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(81, 24);
            this.lblInterval.TabIndex = 70;
            this.lblInterval.Text = "....";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic);
            this.label7.Location = new System.Drawing.Point(631, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 14);
            this.label7.TabIndex = 69;
            this.label7.Text = "Interval";
            // 
            // lnkViewForm
            // 
            this.lnkViewForm.AutoSize = true;
            this.lnkViewForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewForm.Location = new System.Drawing.Point(721, 23);
            this.lnkViewForm.Name = "lnkViewForm";
            this.lnkViewForm.Size = new System.Drawing.Size(65, 15);
            this.lnkViewForm.TabIndex = 68;
            this.lnkViewForm.TabStop = true;
            this.lnkViewForm.Text = "View Form";
            this.lnkViewForm.Visible = false;
            this.lnkViewForm.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewForm_LinkClicked);
            // 
            // lblMaintdesc
            // 
            this.lblMaintdesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMaintdesc.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintdesc.Location = new System.Drawing.Point(5, 42);
            this.lblMaintdesc.Name = "lblMaintdesc";
            this.lblMaintdesc.Size = new System.Drawing.Size(623, 26);
            this.lblMaintdesc.TabIndex = 64;
            this.lblMaintdesc.Text = "MntDesc";
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(5, 27);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(499, 15);
            this.lblTitle.TabIndex = 63;
            this.lblTitle.Text = "Maintenance Title ";
            // 
            // lblEqpname
            // 
            this.lblEqpname.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEqpname.ForeColor = System.Drawing.Color.Blue;
            this.lblEqpname.Location = new System.Drawing.Point(6, -1);
            this.lblEqpname.Name = "lblEqpname";
            this.lblEqpname.Size = new System.Drawing.Size(622, 28);
            this.lblEqpname.TabIndex = 60;
            this.lblEqpname.Text = "EQ\r\nMENT";
            this.lblEqpname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnExportXL
            // 
            this.btnExportXL.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExportXL.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportXL.Image = ((System.Drawing.Image)(resources.GetObject("btnExportXL.Image")));
            this.btnExportXL.Location = new System.Drawing.Point(720, 38);
            this.btnExportXL.Name = "btnExportXL";
            this.btnExportXL.Size = new System.Drawing.Size(69, 30);
            this.btnExportXL.TabIndex = 38;
            this.btnExportXL.Text = "Export";
            this.btnExportXL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExportXL.UseVisualStyleBackColor = false;
            this.btnExportXL.Click += new System.EventHandler(this.btnExportXL_Click);
            // 
            // lnkViewMaintDetails
            // 
            this.lnkViewMaintDetails.AutoSize = true;
            this.lnkViewMaintDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewMaintDetails.Location = new System.Drawing.Point(492, 6);
            this.lnkViewMaintDetails.Name = "lnkViewMaintDetails";
            this.lnkViewMaintDetails.Size = new System.Drawing.Size(246, 15);
            this.lnkViewMaintDetails.TabIndex = 70;
            this.lnkViewMaintDetails.TabStop = true;
            this.lnkViewMaintDetails.Text = "View Maintenance procedures / Manual Ref";
            this.lnkViewMaintDetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkViewMaintDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintDetails_LinkClicked);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtSuptComments);
            this.panel5.Controls.Add(this.txtVesselComments);
            this.panel5.Controls.Add(this.lblSuptCom);
            this.panel5.Controls.Add(this.lblVessel);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(2, 490);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(800, 160);
            this.panel5.TabIndex = 4;
            // 
            // txtSuptComments
            // 
            this.txtSuptComments.AllowDrop = true;
            this.txtSuptComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtSuptComments.Location = new System.Drawing.Point(5, 105);
            this.txtSuptComments.Multiline = true;
            this.txtSuptComments.Name = "txtSuptComments";
            this.txtSuptComments.ReadOnly = true;
            this.txtSuptComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSuptComments.Size = new System.Drawing.Size(788, 45);
            this.txtSuptComments.TabIndex = 3;
            // 
            // txtVesselComments
            // 
            this.txtVesselComments.AllowDrop = true;
            this.txtVesselComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtVesselComments.Location = new System.Drawing.Point(5, 19);
            this.txtVesselComments.Multiline = true;
            this.txtVesselComments.Name = "txtVesselComments";
            this.txtVesselComments.ReadOnly = true;
            this.txtVesselComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtVesselComments.Size = new System.Drawing.Size(788, 71);
            this.txtVesselComments.TabIndex = 2;
            // 
            // lblSuptCom
            // 
            this.lblSuptCom.AutoSize = true;
            this.lblSuptCom.ForeColor = System.Drawing.Color.Blue;
            this.lblSuptCom.Location = new System.Drawing.Point(5, 92);
            this.lblSuptCom.Name = "lblSuptCom";
            this.lblSuptCom.Size = new System.Drawing.Size(81, 13);
            this.lblSuptCom.TabIndex = 1;
            this.lblSuptCom.Text = "Supt Comments";
            // 
            // lblVessel
            // 
            this.lblVessel.AutoSize = true;
            this.lblVessel.ForeColor = System.Drawing.Color.Blue;
            this.lblVessel.Location = new System.Drawing.Point(5, 5);
            this.lblVessel.Name = "lblVessel";
            this.lblVessel.Size = new System.Drawing.Size(90, 13);
            this.lblVessel.TabIndex = 0;
            this.lblVessel.Text = "Vessel Comments";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tableLayoutPanel2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(5, 354);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(794, 104);
            this.panel4.TabIndex = 3;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.64484F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.35516F));
            this.tableLayoutPanel2.Controls.Add(this.panel9, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel6, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel8, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 13F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(794, 104);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Controls.Add(this.panel3);
            this.panel9.Controls.Add(this.label4);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(418, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(376, 13);
            this.panel9.TabIndex = 20;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Controls.Add(this.label10);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(376, 13);
            this.panel11.TabIndex = 22;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.label12);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Margin = new System.Windows.Forms.Padding(0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(376, 13);
            this.panel13.TabIndex = 22;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label11);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Margin = new System.Windows.Forms.Padding(0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(376, 13);
            this.panel14.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Maroon;
            this.label11.Location = new System.Drawing.Point(3, -1);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Associated Forms";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Maroon;
            this.label12.Location = new System.Drawing.Point(3, -1);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(176, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Associated Forms to Fillup";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label9);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Margin = new System.Windows.Forms.Padding(0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(376, 13);
            this.panel12.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(3, -1);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(176, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Associated Forms to Fillup";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Maroon;
            this.label10.Location = new System.Drawing.Point(3, -1);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(176, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Associated Forms to Fillup";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label8);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(376, 13);
            this.panel3.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(3, -1);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(176, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Associated Forms to Fillup";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(3, -1);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(176, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Associated Forms to Fillup";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.fpSpreadConsumed);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 13);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(418, 91);
            this.panel7.TabIndex = 18;
            // 
            // fpSpreadConsumed
            // 
            this.fpSpreadConsumed.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpreadConsumed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadConsumed.FocusRenderer = defaultFocusIndicatorRenderer2;
            this.fpSpreadConsumed.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadConsumed.HorizontalScrollBar.Name = "";
            this.fpSpreadConsumed.HorizontalScrollBar.Renderer = defaultScrollBarRenderer7;
            this.fpSpreadConsumed.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadConsumed.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadConsumed.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadConsumed.Name = "fpSpreadConsumed";
            this.fpSpreadConsumed.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.fpSpreadConsumed.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadConsumed_Sheet1});
            this.fpSpreadConsumed.Size = new System.Drawing.Size(418, 91);
            this.fpSpreadConsumed.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadConsumed.TabIndex = 16;
            this.fpSpreadConsumed.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadConsumed.VerticalScrollBar.Name = "";
            this.fpSpreadConsumed.VerticalScrollBar.Renderer = defaultScrollBarRenderer8;
            this.fpSpreadConsumed.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadConsumed.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadConsumed.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpreadConsumed.ColumnWidthChanged += new FarPoint.Win.Spread.ColumnWidthChangedEventHandler(this.fpSpreadConsumed_ColumnWidthChanged);
            this.fpSpreadConsumed.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpreadConsumed_CellClick);
            // 
            // fpSpreadConsumed_Sheet1
            // 
            this.fpSpreadConsumed_Sheet1.Reset();
            this.fpSpreadConsumed_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadConsumed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadConsumed_Sheet1.ColumnCount = 10;
            this.fpSpreadConsumed_Sheet1.RowCount = 10;
            this.fpSpreadConsumed_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadConsumed_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadConsumed_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadConsumed_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadConsumed_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadConsumed_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadConsumed_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadConsumed_Sheet1.RowHeader.Visible = false;
            this.fpSpreadConsumed_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadConsumed_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadConsumed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.fpSpreadAssociatedForms);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(418, 13);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(376, 91);
            this.panel6.TabIndex = 17;
            // 
            // fpSpreadAssociatedForms
            // 
            this.fpSpreadAssociatedForms.AccessibleDescription = "fpSpreadAssociatedForms, Sheet1, Row 0, Column 0, ";
            this.fpSpreadAssociatedForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadAssociatedForms.FocusRenderer = defaultFocusIndicatorRenderer2;
            this.fpSpreadAssociatedForms.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpreadAssociatedForms.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadAssociatedForms.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadAssociatedForms.Name = "fpSpreadAssociatedForms";
            this.fpSpreadAssociatedForms.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadAssociatedForms_Sheet1});
            this.fpSpreadAssociatedForms.Size = new System.Drawing.Size(376, 91);
            this.fpSpreadAssociatedForms.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadAssociatedForms.TabIndex = 12;
            this.fpSpreadAssociatedForms.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.VerticalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpreadAssociatedForms.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadAssociatedForms.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpreadAssociatedForms.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpreadAssociatedForms_HyperLinkClicked);
            this.fpSpreadAssociatedForms.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpreadAssociatedForms_Error);
            // 
            // fpSpreadAssociatedForms_Sheet1
            // 
            this.fpSpreadAssociatedForms_Sheet1.Reset();
            this.fpSpreadAssociatedForms_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadAssociatedForms_Sheet1.ColumnCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.RowCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadAssociatedForms_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.Visible = false;
            this.fpSpreadAssociatedForms_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadAssociatedForms_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label6);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(418, 13);
            this.panel8.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(3, -1);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Spare parts consumed";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 71F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(804, 652);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblHistIndicator);
            this.panel2.Controls.Add(this.fpSpreadPmsHist);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(5, 78);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(794, 220);
            this.panel2.TabIndex = 1;
            // 
            // lblHistIndicator
            // 
            this.lblHistIndicator.AutoSize = true;
            this.lblHistIndicator.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHistIndicator.Location = new System.Drawing.Point(136, 84);
            this.lblHistIndicator.Name = "lblHistIndicator";
            this.lblHistIndicator.Size = new System.Drawing.Size(102, 24);
            this.lblHistIndicator.TabIndex = 19;
            this.lblHistIndicator.Text = "No Record";
            // 
            // fpSpreadPmsHist
            // 
            this.fpSpreadPmsHist.AccessibleDescription = "fpSpreadPmsHist, Sheet1, Row 0, Column 0, ";
            this.fpSpreadPmsHist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadPmsHist.FocusRenderer = defaultFocusIndicatorRenderer2;
            this.fpSpreadPmsHist.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadPmsHist.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadPmsHist.HorizontalScrollBar.Name = "";
            this.fpSpreadPmsHist.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.fpSpreadPmsHist.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadPmsHist.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadPmsHist.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadPmsHist.Name = "fpSpreadPmsHist";
            this.fpSpreadPmsHist.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.fpSpreadPmsHist.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.sheetView1});
            this.fpSpreadPmsHist.Size = new System.Drawing.Size(794, 220);
            this.fpSpreadPmsHist.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadPmsHist.TabIndex = 17;
            this.fpSpreadPmsHist.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadPmsHist.VerticalScrollBar.Name = "";
            this.fpSpreadPmsHist.VerticalScrollBar.Renderer = defaultScrollBarRenderer4;
            this.fpSpreadPmsHist.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadPmsHist.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadPmsHist.VisualStyles = FarPoint.Win.VisualStyles.On;
            this.fpSpreadPmsHist.ColumnWidthChanged += new FarPoint.Win.Spread.ColumnWidthChangedEventHandler(this.fpSpreadPmsHist_ColumnWidthChanged);
            this.fpSpreadPmsHist.SelectionChanged += new FarPoint.Win.Spread.SelectionChangedEventHandler(this.fpSpreadPmsHist_SelectionChanged);
            this.fpSpreadPmsHist.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpreadPmsHist_HyperLinkClicked);
            this.fpSpreadPmsHist.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpreadPmsHist_CellClick);
            this.fpSpreadPmsHist.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpreadPmsHist_Error);
            this.fpSpreadPmsHist.AutoSortingColumn += new FarPoint.Win.Spread.AutoSortingColumnEventHandler(this.fpSpreadPmsHist_AutoSortingColumn);
            this.fpSpreadPmsHist.AutoSortedColumn += new FarPoint.Win.Spread.AutoSortedColumnEventHandler(this.fpSpreadPmsHist_AutoSortedColumn);
            this.fpSpreadPmsHist.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpreadPmsHist_MouseDown);
            // 
            // sheetView1
            // 
            this.sheetView1.Reset();
            this.sheetView1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.sheetView1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.sheetView1.ColumnCount = 10;
            this.sheetView1.RowCount = 10;
            this.sheetView1.AutoGenerateColumns = false;
            this.sheetView1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.sheetView1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.sheetView1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.sheetView1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.sheetView1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sheetView1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.sheetView1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.sheetView1.DataAutoSizeColumns = false;
            this.sheetView1.GrayAreaBackColor = System.Drawing.Color.White;
            this.sheetView1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.sheetView1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.sheetView1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.sheetView1.RowHeader.Visible = false;
            this.sheetView1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.sheetView1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sheetView1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.sheetView1.SheetCornerStyle.Parent = "CornerDefault";
            this.sheetView1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.lnkViewMaintDetails);
            this.panel10.Controls.Add(this.lblProcedure);
            this.panel10.Controls.Add(this.chkMaintDoneAsPerInstructions);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(2, 463);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(800, 25);
            this.panel10.TabIndex = 6;
            // 
            // lblProcedure
            // 
            this.lblProcedure.AutoSize = true;
            this.lblProcedure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblProcedure.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcedure.ForeColor = System.Drawing.Color.Blue;
            this.lblProcedure.Location = new System.Drawing.Point(35, 6);
            this.lblProcedure.Name = "lblProcedure";
            this.lblProcedure.Size = new System.Drawing.Size(334, 13);
            this.lblProcedure.TabIndex = 83;
            this.lblProcedure.Text = "Maintenance done as per Maintenance procedures";
            // 
            // chkMaintDoneAsPerInstructions
            // 
            this.chkMaintDoneAsPerInstructions.AutoSize = true;
            this.chkMaintDoneAsPerInstructions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.chkMaintDoneAsPerInstructions.Enabled = false;
            this.chkMaintDoneAsPerInstructions.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMaintDoneAsPerInstructions.ForeColor = System.Drawing.Color.Blue;
            this.chkMaintDoneAsPerInstructions.Location = new System.Drawing.Point(22, 5);
            this.chkMaintDoneAsPerInstructions.Name = "chkMaintDoneAsPerInstructions";
            this.chkMaintDoneAsPerInstructions.Size = new System.Drawing.Size(353, 17);
            this.chkMaintDoneAsPerInstructions.TabIndex = 82;
            this.chkMaintDoneAsPerInstructions.Text = "Maintenance done as per Maintenance procedures";
            this.chkMaintDoneAsPerInstructions.UseVisualStyleBackColor = false;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.pnlPMS);
            this.panel15.Controls.Add(this.pnlPostponement);
            this.panel15.Controls.Add(this.pnlRoutine);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(2, 303);
            this.panel15.Margin = new System.Windows.Forms.Padding(0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(800, 46);
            this.panel15.TabIndex = 9;
            // 
            // pnlPostponement
            // 
            this.pnlPostponement.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlPostponement.Controls.Add(this.lblPostponementDate);
            this.pnlPostponement.Controls.Add(this.label44);
            this.pnlPostponement.Controls.Add(this.lblPlace_Postponement);
            this.pnlPostponement.Controls.Add(this.label49);
            this.pnlPostponement.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPostponement.Location = new System.Drawing.Point(0, 0);
            this.pnlPostponement.Name = "pnlPostponement";
            this.pnlPostponement.Size = new System.Drawing.Size(800, 46);
            this.pnlPostponement.TabIndex = 74;
            // 
            // lblPostponementDate
            // 
            this.lblPostponementDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostponementDate.Location = new System.Drawing.Point(427, 15);
            this.lblPostponementDate.Name = "lblPostponementDate";
            this.lblPostponementDate.Size = new System.Drawing.Size(180, 17);
            this.lblPostponementDate.TabIndex = 90;
            this.lblPostponementDate.Text = "...";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Blue;
            this.label44.Location = new System.Drawing.Point(308, 17);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(122, 15);
            this.label44.TabIndex = 89;
            this.label44.Text = "Postponement Date: ";
            // 
            // lblPlace_Postponement
            // 
            this.lblPlace_Postponement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlace_Postponement.Location = new System.Drawing.Point(60, 15);
            this.lblPlace_Postponement.Name = "lblPlace_Postponement";
            this.lblPlace_Postponement.Size = new System.Drawing.Size(227, 17);
            this.lblPlace_Postponement.TabIndex = 81;
            this.lblPlace_Postponement.Text = "...";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Blue;
            this.label49.Location = new System.Drawing.Point(21, 17);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(41, 15);
            this.label49.TabIndex = 78;
            this.label49.Text = "Place:";
            // 
            // pnlRoutine
            // 
            this.pnlRoutine.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlRoutine.Controls.Add(this.lnkViewAlarmsRoutinesReport);
            this.pnlRoutine.Controls.Add(this.lblResult);
            this.pnlRoutine.Controls.Add(this.lblVerifiy);
            this.pnlRoutine.Controls.Add(this.lblLocation);
            this.pnlRoutine.Controls.Add(this.lblres);
            this.pnlRoutine.Controls.Add(this.lblver);
            this.pnlRoutine.Controls.Add(this.lblLoc);
            this.pnlRoutine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRoutine.Location = new System.Drawing.Point(0, 0);
            this.pnlRoutine.Name = "pnlRoutine";
            this.pnlRoutine.Size = new System.Drawing.Size(800, 46);
            this.pnlRoutine.TabIndex = 70;
            // 
            // lnkViewAlarmsRoutinesReport
            // 
            this.lnkViewAlarmsRoutinesReport.AutoSize = true;
            this.lnkViewAlarmsRoutinesReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAlarmsRoutinesReport.Location = new System.Drawing.Point(587, 7);
            this.lnkViewAlarmsRoutinesReport.Name = "lnkViewAlarmsRoutinesReport";
            this.lnkViewAlarmsRoutinesReport.Size = new System.Drawing.Size(190, 15);
            this.lnkViewAlarmsRoutinesReport.TabIndex = 70;
            this.lnkViewAlarmsRoutinesReport.TabStop = true;
            this.lnkViewAlarmsRoutinesReport.Text = "View Alarms and Routines Report";
            this.lnkViewAlarmsRoutinesReport.Visible = false;
            this.lnkViewAlarmsRoutinesReport.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAlarmsRoutinesReport_LinkClicked);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblResult.Location = new System.Drawing.Point(77, 26);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(16, 15);
            this.lblResult.TabIndex = 83;
            this.lblResult.Text = "...";
            // 
            // lblVerifiy
            // 
            this.lblVerifiy.AutoSize = true;
            this.lblVerifiy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblVerifiy.Location = new System.Drawing.Point(302, 7);
            this.lblVerifiy.Name = "lblVerifiy";
            this.lblVerifiy.Size = new System.Drawing.Size(16, 15);
            this.lblVerifiy.TabIndex = 82;
            this.lblVerifiy.Text = "...";
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblLocation.Location = new System.Drawing.Point(77, 7);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(16, 15);
            this.lblLocation.TabIndex = 81;
            this.lblLocation.Text = "...";
            // 
            // lblres
            // 
            this.lblres.AutoSize = true;
            this.lblres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblres.ForeColor = System.Drawing.Color.Blue;
            this.lblres.Location = new System.Drawing.Point(32, 26);
            this.lblres.Name = "lblres";
            this.lblres.Size = new System.Drawing.Size(45, 15);
            this.lblres.TabIndex = 80;
            this.lblres.Text = "Result:";
            // 
            // lblver
            // 
            this.lblver.AutoSize = true;
            this.lblver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblver.ForeColor = System.Drawing.Color.Blue;
            this.lblver.Location = new System.Drawing.Point(261, 7);
            this.lblver.Name = "lblver";
            this.lblver.Size = new System.Drawing.Size(44, 15);
            this.lblver.TabIndex = 79;
            this.lblver.Text = "Status:";
            // 
            // lblLoc
            // 
            this.lblLoc.AutoSize = true;
            this.lblLoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblLoc.ForeColor = System.Drawing.Color.Blue;
            this.lblLoc.Location = new System.Drawing.Point(20, 7);
            this.lblLoc.Name = "lblLoc";
            this.lblLoc.Size = new System.Drawing.Size(57, 15);
            this.lblLoc.TabIndex = 78;
            this.lblLoc.Text = "Location:";
            // 
            // pnlPMS
            // 
            this.pnlPMS.BackColor = System.Drawing.Color.AliceBlue;
            this.pnlPMS.Controls.Add(this.lblActualRunningHours);
            this.pnlPMS.Controls.Add(this.lblActualRunningHours_Display);
            this.pnlPMS.Controls.Add(this.lblPlace);
            this.pnlPMS.Controls.Add(this.label14);
            this.pnlPMS.Controls.Add(this.lnkViewMaintCheckList);
            this.pnlPMS.Controls.Add(this.lblManHrs);
            this.pnlPMS.Controls.Add(this.label5);
            this.pnlPMS.Controls.Add(this.lblCompletion);
            this.pnlPMS.Controls.Add(this.lblCondition);
            this.pnlPMS.Controls.Add(this.lblReason);
            this.pnlPMS.Controls.Add(this.label3);
            this.pnlPMS.Controls.Add(this.label2);
            this.pnlPMS.Controls.Add(this.label1);
            this.pnlPMS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPMS.Location = new System.Drawing.Point(0, 0);
            this.pnlPMS.Name = "pnlPMS";
            this.pnlPMS.Size = new System.Drawing.Size(800, 46);
            this.pnlPMS.TabIndex = 5;
            // 
            // lblPlace
            // 
            this.lblPlace.AutoSize = true;
            this.lblPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblPlace.Location = new System.Drawing.Point(163, 7);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(16, 15);
            this.lblPlace.TabIndex = 71;
            this.lblPlace.Text = "...";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(124, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 15);
            this.label14.TabIndex = 70;
            this.label14.Text = "Place:";
            // 
            // lnkViewMaintCheckList
            // 
            this.lnkViewMaintCheckList.AutoSize = true;
            this.lnkViewMaintCheckList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewMaintCheckList.Location = new System.Drawing.Point(622, 7);
            this.lnkViewMaintCheckList.Name = "lnkViewMaintCheckList";
            this.lnkViewMaintCheckList.Size = new System.Drawing.Size(164, 15);
            this.lnkViewMaintCheckList.TabIndex = 69;
            this.lnkViewMaintCheckList.TabStop = true;
            this.lnkViewMaintCheckList.Text = "View Maintenance CheckList";
            this.lnkViewMaintCheckList.Visible = false;
            this.lnkViewMaintCheckList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintCheckList_LinkClicked);
            // 
            // lblManHrs
            // 
            this.lblManHrs.AutoSize = true;
            this.lblManHrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblManHrs.Location = new System.Drawing.Point(63, 7);
            this.lblManHrs.Name = "lblManHrs";
            this.lblManHrs.Size = new System.Drawing.Size(16, 15);
            this.lblManHrs.TabIndex = 7;
            this.lblManHrs.Text = "...";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(10, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Man Hrs:";
            // 
            // lblCompletion
            // 
            this.lblCompletion.AutoSize = true;
            this.lblCompletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblCompletion.Location = new System.Drawing.Point(371, 26);
            this.lblCompletion.Name = "lblCompletion";
            this.lblCompletion.Size = new System.Drawing.Size(16, 15);
            this.lblCompletion.TabIndex = 5;
            this.lblCompletion.Text = "...";
            // 
            // lblCondition
            // 
            this.lblCondition.AutoSize = true;
            this.lblCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblCondition.Location = new System.Drawing.Point(371, 7);
            this.lblCondition.Name = "lblCondition";
            this.lblCondition.Size = new System.Drawing.Size(16, 15);
            this.lblCondition.TabIndex = 4;
            this.lblCondition.Text = "...";
            // 
            // lblReason
            // 
            this.lblReason.AutoSize = true;
            this.lblReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblReason.Location = new System.Drawing.Point(63, 26);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(16, 15);
            this.lblReason.TabIndex = 3;
            this.lblReason.Text = "...";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(298, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Completion:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(309, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Condition:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reason:";
            // 
            // lblActualRunningHours
            // 
            this.lblActualRunningHours.AutoSize = true;
            this.lblActualRunningHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblActualRunningHours.Location = new System.Drawing.Point(762, 26);
            this.lblActualRunningHours.Name = "lblActualRunningHours";
            this.lblActualRunningHours.Size = new System.Drawing.Size(16, 15);
            this.lblActualRunningHours.TabIndex = 100;
            this.lblActualRunningHours.Text = "...";
            // 
            // lblActualRunningHours_Display
            // 
            this.lblActualRunningHours_Display.AutoSize = true;
            this.lblActualRunningHours_Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblActualRunningHours_Display.ForeColor = System.Drawing.Color.Blue;
            this.lblActualRunningHours_Display.Location = new System.Drawing.Point(561, 26);
            this.lblActualRunningHours_Display.Name = "lblActualRunningHours_Display";
            this.lblActualRunningHours_Display.Size = new System.Drawing.Size(202, 15);
            this.lblActualRunningHours_Display.TabIndex = 99;
            this.lblActualRunningHours_Display.Text = "Actual Running Hrs at time of Maint:";
            // 
            // frmMaintHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 652);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMaintHistory";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "  Maintenance History";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMaintHistory_FormClosing);
            this.Load += new System.EventHandler(this.frmMaintHistory_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed_Sheet1)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadPmsHist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sheetView1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.pnlPostponement.ResumeLayout(false);
            this.pnlPostponement.PerformLayout();
            this.pnlRoutine.ResumeLayout(false);
            this.pnlRoutine.PerformLayout();
            this.pnlPMS.ResumeLayout(false);
            this.pnlPMS.PerformLayout();
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel5;
    private System.Windows.Forms.TextBox txtSuptComments;
    private System.Windows.Forms.TextBox txtVesselComments;
    private System.Windows.Forms.Label lblSuptCom;
    private System.Windows.Forms.Label lblVessel;
    private System.Windows.Forms.Panel panel4;
    private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnExportXL;
    private FarPoint.Win.Spread.FpSpread fpSpreadConsumed;
    private FarPoint.Win.Spread.SheetView fpSpreadConsumed_Sheet1;
    private System.Windows.Forms.Label lblEqpname;
    private System.Windows.Forms.Label lblTitle;
    private System.Windows.Forms.Label lblMaintdesc;
    private System.Windows.Forms.LinkLabel lnkViewForm;
    private System.Windows.Forms.LinkLabel lnkViewMaintDetails;
    private FarPoint.Win.Spread.FpSpread fpSpreadPmsHist;
    private FarPoint.Win.Spread.SheetView sheetView1;
    private System.Windows.Forms.Panel pnlPMS;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label lblCompletion;
    private System.Windows.Forms.Label lblCondition;
    private System.Windows.Forms.Label lblReason;
    private System.Windows.Forms.Label lblManHrs;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.LinkLabel lnkViewMaintCheckList;
    private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    private System.Windows.Forms.Panel panel9;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Panel panel7;
    private System.Windows.Forms.Panel panel6;
    private FarPoint.Win.Spread.FpSpread fpSpreadAssociatedForms;
    private FarPoint.Win.Spread.SheetView fpSpreadAssociatedForms_Sheet1;
    private System.Windows.Forms.Panel panel8;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Panel panel10;
    private System.Windows.Forms.Label lblProcedure;
    private System.Windows.Forms.CheckBox chkMaintDoneAsPerInstructions;
    private System.Windows.Forms.Label lblInterval;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Panel pnlRoutine;
    private System.Windows.Forms.Label lblResult;
    private System.Windows.Forms.Label lblVerifiy;
    private System.Windows.Forms.Label lblLocation;
    private System.Windows.Forms.Label lblres;
    private System.Windows.Forms.Label lblver;
    private System.Windows.Forms.Label lblLoc;
    private System.Windows.Forms.Panel panel11;
    private System.Windows.Forms.Panel panel13;
    private System.Windows.Forms.Panel panel14;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Panel panel12;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Panel panel15;
    private System.Windows.Forms.LinkLabel lnkViewAlarmsRoutinesReport;
    private System.Windows.Forms.Panel pnlPostponement;
    private System.Windows.Forms.Label lblPostponementDate;
    private System.Windows.Forms.Label label44;
    private System.Windows.Forms.Label lblPlace_Postponement;
    private System.Windows.Forms.Label label49;
    private System.Windows.Forms.Label lblHistIndicator;
    private System.Windows.Forms.Label lblPlace;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.Label lblSFICode;
    private System.Windows.Forms.Label lblSFICodeTitle;
        private System.Windows.Forms.Label lblActualRunningHours;
        private System.Windows.Forms.Label lblActualRunningHours_Display;
    }
}