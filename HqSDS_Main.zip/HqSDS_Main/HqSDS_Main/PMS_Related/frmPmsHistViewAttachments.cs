﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmPmsHistViewAttachments : Form
    {
        public long eq_PmsHistID;
        public int vesselID = -1;
        public string eqpName = "";
        const int COL_ATTACH_VIEW = 1, COL_EQ_PMSHIST_ATTACHMENTSID = 2;

        public frmPmsHistViewAttachments()
        {
            InitializeComponent();
        }

        private void frmWOAttachments_Load(object sender, EventArgs e)
        {
            lblEqpName.Text = eqpName;

            DesignPmsHistAttachmentGrid();
            BindPmsHistAttachmentGrid();
        }

        

        private void DesignPmsHistAttachmentGrid()
        {
            List<DgvInits> colListDFList = new List<DgvInits>();
            try
            {
                colListDFList.Add(new DgvInits("FileName", "FileName", 300, Color.Black, Color.LightGray, true, true));
                colListDFList.Add(new DgvInits("View", "View", 0, Color.Black, Color.LightGray, true, true));
                colListDFList.Add(new DgvInits("EQ_PmsHist_AttachmentsID", "EQ_PmsHist_AttachmentsID", 90, Color.Black, Color.LightGray, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Attachment, colListDFList, null, false, false, true);
                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpread_Attachment, false, " ", COL_ATTACH_VIEW, "View", 37, Color.White);

                fpSpread_Attachment.ActiveSheet.RowHeader.Columns[0].Width = 15;
                fpSpread_Attachment.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread_Attachment.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            }
            finally
            {
                colListDFList = null;
            }
        }


        private void BindPmsHistAttachmentGrid()
        {
            fpSpread_Attachment.SuspendLayout();
            DataTable dt;
            try
            {
                fpSpread_Attachment.ActiveSheet.RowCount = 0;

                string script = " select EQ_PmsHist_AttachmentsID, (FileName +  OriginalFileType) as FileName " +
                                " from EQ_PmsHist_Attachments " +
                                " where VesselID=" + vesselID + " and EQ_PmsHistID=" + eq_PmsHistID;

                string additionalCond = "    and IsDeleted=0 ";

                script = script + additionalCond + " Order by EQ_PmsHist_AttachmentsID ";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt == null) return;

                fpSpread_Attachment.DataSource = dt;

                if (dt != null && dt.Rows.Count > 0) fpSpread_Attachment_ColumnWidthChanged(null, null);

            }
            catch (Exception err)
            {
                Gfn.nWb("Failed to load attachment");
                PG.AddToGenErrorLog("frmPmsHistViewAttachments.cs", "BindWOAttachmentGrid", err.Message);
            }
            finally
            {
                fpSpread_Attachment.ResumeLayout();
                dt = null;
            }
        }
               
        private void fpSpreadAttachment_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        private void fpSpreadAttachment_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            fpSpread_Attachment.ActiveSheet.SetActiveCell(e.Row, e.Column);
            if (e.Column == COL_ATTACH_VIEW)
            {
                if (fpSpread_Attachment.ActiveSheet.ActiveCell == null) return;

                try
                {
                    int row = fpSpread_Attachment.ActiveSheet.ActiveRowIndex;
                    long eq_PmsHist_AttachmentsID = -1;
                    if (fpSpread_Attachment.ActiveSheet.Cells[row, COL_EQ_PMSHIST_ATTACHMENTSID].Value != null && fpSpread_Attachment.ActiveSheet.Cells[row, COL_EQ_PMSHIST_ATTACHMENTSID].Value.ToString().Trim().Length > 0)
                    {
                        eq_PmsHist_AttachmentsID = Convert.ToInt64(fpSpread_Attachment.ActiveSheet.Cells[row, COL_EQ_PMSHIST_ATTACHMENTSID].Value);
                    }

                    PG.attachment.ViewFileFrom_DB_or_AzureStorage_or_LocalFolder(vesselID.ToString(), "EQ_PmsHist_Attachments", eq_PmsHist_AttachmentsID.ToString());
                }
                catch (Exception err)
                {
                    Gfn.nWb("Failed to view attachment");
                    PG.AddToGenErrorLog("frmPmsHistViewAttachments.cs", "tsMnuViewAttachment_Click", err.Message);
                }
            }
        }

        private void fpSpread_Attachment_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpread_Attachment.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

       

    }
}
