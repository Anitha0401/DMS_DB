﻿namespace HqSDS_Main
{
    partial class frmSuptToApproveMaint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer enhancedColumnHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer enhancedRowHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer();
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("ColumnHeaderSandstorm");
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("RowHeaderSandstorm");
            FarPoint.Win.Spread.NamedStyle namedStyle3 = new FarPoint.Win.Spread.NamedStyle("CornerSandstorm");
            FarPoint.Win.Spread.CellType.EnhancedCornerRenderer enhancedCornerRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedCornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle4 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer5 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer6 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClear = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnGo = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblSvrName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblTotalItems = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSuptComments = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lnkViewMaintCheckList = new System.Windows.Forms.LinkLabel();
            this.lnkViewAlarmAndTestingItems = new System.Windows.Forms.LinkLabel();
            this.lnkViewMaintDetails = new System.Windows.Forms.LinkLabel();
            this.lblComments = new System.Windows.Forms.Label();
            this.txtVslComments = new System.Windows.Forms.TextBox();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.lblMType = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lnkViewAttchment = new System.Windows.Forms.LinkLabel();
            this.lnkViewAttchmentRoutine = new System.Windows.Forms.LinkLabel();
            this.lblPlace = new System.Windows.Forms.Label();
            this.lblManHrs = new System.Windows.Forms.Label();
            this.lblManHrs1 = new System.Windows.Forms.Label();
            this.lblCompletion = new System.Windows.Forms.Label();
            this.lblCondition = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.lblCompletion1 = new System.Windows.Forms.Label();
            this.lblCondition1 = new System.Windows.Forms.Label();
            this.lblReason1 = new System.Windows.Forms.Label();
            this.lblResponsibleRank = new System.Windows.Forms.Label();
            this.lblInChargeRank = new System.Windows.Forms.Label();
            this.lbl_PMSCode = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPMMRefNo = new System.Windows.Forms.Label();
            this.lblMaintenance = new System.Windows.Forms.Label();
            this.lblComponent = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblComp = new System.Windows.Forms.Label();
            this.lblEquipment = new System.Windows.Forms.Label();
            this.lblPMM = new System.Windows.Forms.Label();
            this.lblMaint = new System.Windows.Forms.Label();
            this.lblPostponementDate = new System.Windows.Forms.Label();
            this.lblMaintCode = new System.Windows.Forms.Label();
            this.lblInterval = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblInCharge = new System.Windows.Forms.Label();
            this.lblDept = new System.Windows.Forms.Label();
            this.lblResponsible = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMaintType = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblPMSCode = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.fpSpreadConsumed = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadConsumed_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel8 = new System.Windows.Forms.Panel();
            this.fpSpreadAssociatedForms = new FarPoint.Win.Spread.FpSpread();
            this.fpSpreadAssociatedForms_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmnuSuptComments = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuMaintHistory = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed_Sheet1)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).BeginInit();
            this.panel10.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            enhancedColumnHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.Goldenrod;
            enhancedColumnHeaderRenderer1.Name = "enhancedColumnHeaderRenderer1";
            enhancedColumnHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.Tan;
            enhancedColumnHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.BurlyWood;
            enhancedColumnHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.Tan;
            enhancedColumnHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.BurlyWood;
            enhancedColumnHeaderRenderer1.TextRotationAngle = 0D;
            enhancedRowHeaderRenderer1.ActiveBackgroundColor = System.Drawing.Color.Goldenrod;
            enhancedRowHeaderRenderer1.Name = "enhancedRowHeaderRenderer1";
            enhancedRowHeaderRenderer1.NormalGridLineColor = System.Drawing.Color.Tan;
            enhancedRowHeaderRenderer1.SelectedActiveBackgroundColor = System.Drawing.Color.BurlyWood;
            enhancedRowHeaderRenderer1.SelectedBackgroundColor = System.Drawing.Color.Tan;
            enhancedRowHeaderRenderer1.SelectedGridLineColor = System.Drawing.Color.BurlyWood;
            enhancedRowHeaderRenderer1.TextRotationAngle = 0D;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(984, 749);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.btnGo);
            this.panel1.Controls.Add(this.txtSearch);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(984, 37);
            this.panel1.TabIndex = 0;
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnClear.Location = new System.Drawing.Point(242, 7);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(42, 22);
            this.btnClear.TabIndex = 76;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(31, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 13);
            this.label12.TabIndex = 75;
            this.label12.Text = "Filter:";
            // 
            // btnGo
            // 
            this.btnGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnGo.Location = new System.Drawing.Point(197, 7);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(42, 22);
            this.btnGo.TabIndex = 74;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtSearch.Location = new System.Drawing.Point(63, 8);
            this.txtSearch.MaxLength = 15;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(132, 20);
            this.txtSearch.TabIndex = 73;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(885, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(55, 32);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "Close";
            this.btnClose.UseCompatibleTextRendering = true;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(340, 10);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(173, 16);
            this.progressBar1.TabIndex = 8;
            this.progressBar1.Visible = false;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Location = new System.Drawing.Point(793, 3);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(86, 32);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseCompatibleTextRendering = true;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblSvrName,
            this.tsLblTotalItems});
            this.statusStrip1.Location = new System.Drawing.Point(0, 728);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(984, 21);
            this.statusStrip1.TabIndex = 23;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblSvrName
            // 
            this.tsLblSvrName.AutoSize = false;
            this.tsLblSvrName.Name = "tsLblSvrName";
            this.tsLblSvrName.Size = new System.Drawing.Size(500, 16);
            this.tsLblSvrName.Text = "---";
            this.tsLblSvrName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tsLblTotalItems
            // 
            this.tsLblTotalItems.ForeColor = System.Drawing.Color.Blue;
            this.tsLblTotalItems.Name = "tsLblTotalItems";
            this.tsLblTotalItems.Size = new System.Drawing.Size(22, 16);
            this.tsLblTotalItems.Text = "---";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel6, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.panel4, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.fpSpread1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 40);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 315F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 112F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(978, 685);
            this.tableLayoutPanel2.TabIndex = 24;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Honeydew;
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.txtSuptComments);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 637);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(978, 48);
            this.panel6.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(8, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Supt Comments";
            // 
            // txtSuptComments
            // 
            this.txtSuptComments.AllowDrop = true;
            this.txtSuptComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtSuptComments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtSuptComments.Location = new System.Drawing.Point(8, 23);
            this.txtSuptComments.Multiline = true;
            this.txtSuptComments.Name = "txtSuptComments";
            this.txtSuptComments.ReadOnly = true;
            this.txtSuptComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSuptComments.Size = new System.Drawing.Size(955, 86);
            this.txtSuptComments.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Honeydew;
            this.panel4.Controls.Add(this.lnkViewMaintCheckList);
            this.panel4.Controls.Add(this.lnkViewAlarmAndTestingItems);
            this.panel4.Controls.Add(this.lnkViewMaintDetails);
            this.panel4.Controls.Add(this.lblComments);
            this.panel4.Controls.Add(this.txtVslComments);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 525);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(978, 112);
            this.panel4.TabIndex = 23;
            // 
            // lnkViewMaintCheckList
            // 
            this.lnkViewMaintCheckList.AutoSize = true;
            this.lnkViewMaintCheckList.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewMaintCheckList.Location = new System.Drawing.Point(792, 4);
            this.lnkViewMaintCheckList.Name = "lnkViewMaintCheckList";
            this.lnkViewMaintCheckList.Size = new System.Drawing.Size(171, 15);
            this.lnkViewMaintCheckList.TabIndex = 89;
            this.lnkViewMaintCheckList.TabStop = true;
            this.lnkViewMaintCheckList.Text = "View Maintenance CheckList";
            this.lnkViewMaintCheckList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintCheckList_LinkClicked);
            // 
            // lnkViewAlarmAndTestingItems
            // 
            this.lnkViewAlarmAndTestingItems.AutoSize = true;
            this.lnkViewAlarmAndTestingItems.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAlarmAndTestingItems.Location = new System.Drawing.Point(766, 4);
            this.lnkViewAlarmAndTestingItems.Name = "lnkViewAlarmAndTestingItems";
            this.lnkViewAlarmAndTestingItems.Size = new System.Drawing.Size(197, 15);
            this.lnkViewAlarmAndTestingItems.TabIndex = 88;
            this.lnkViewAlarmAndTestingItems.TabStop = true;
            this.lnkViewAlarmAndTestingItems.Text = "View Alarms and Routines Report";
            this.lnkViewAlarmAndTestingItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkViewAlarmAndTestingItems.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAlarmAndTestingItems_LinkClicked);
            // 
            // lnkViewMaintDetails
            // 
            this.lnkViewMaintDetails.AutoSize = true;
            this.lnkViewMaintDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewMaintDetails.Location = new System.Drawing.Point(395, 3);
            this.lnkViewMaintDetails.Name = "lnkViewMaintDetails";
            this.lnkViewMaintDetails.Size = new System.Drawing.Size(173, 15);
            this.lnkViewMaintDetails.TabIndex = 84;
            this.lnkViewMaintDetails.TabStop = true;
            this.lnkViewMaintDetails.Text = "View Maintenance procedures";
            this.lnkViewMaintDetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lnkViewMaintDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintDetails_LinkClicked);
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.ForeColor = System.Drawing.Color.Blue;
            this.lblComments.Location = new System.Drawing.Point(8, 8);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(90, 13);
            this.lblComments.TabIndex = 6;
            this.lblComments.Text = "Vessel Comments";
            // 
            // txtVslComments
            // 
            this.txtVslComments.AllowDrop = true;
            this.txtVslComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtVslComments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtVslComments.Location = new System.Drawing.Point(8, 23);
            this.txtVslComments.Multiline = true;
            this.txtVslComments.Name = "txtVslComments";
            this.txtVslComments.ReadOnly = true;
            this.txtVslComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtVslComments.Size = new System.Drawing.Size(955, 86);
            this.txtVslComments.TabIndex = 7;
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread1.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.fpSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.HorizontalScrollBar.Name = "";
            this.fpSpread1.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread1.HorizontalScrollBar.TabIndex = 0;
            this.fpSpread1.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.Location = new System.Drawing.Point(0, 0);
            this.fpSpread1.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpread1.Name = "fpSpread1";
            namedStyle1.BackColor = System.Drawing.Color.NavajoWhite;
            namedStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.Renderer = enhancedColumnHeaderRenderer1;
            namedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle2.BackColor = System.Drawing.Color.NavajoWhite;
            namedStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.Renderer = enhancedRowHeaderRenderer1;
            namedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle3.BackColor = System.Drawing.Color.Tan;
            namedStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle3.NoteIndicatorColor = System.Drawing.Color.Red;
            enhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.Goldenrod;
            enhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty;
            enhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.BurlyWood;
            namedStyle3.Renderer = enhancedCornerRenderer1;
            namedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle4.BackColor = System.Drawing.SystemColors.Window;
            namedStyle4.CellType = generalCellType1;
            namedStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle4.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle4.Renderer = generalCellType1;
            this.fpSpread1.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2,
            namedStyle3,
            namedStyle4});
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(978, 315);
            this.fpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread1.TabIndex = 22;
            this.fpSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.VerticalScrollBar.Name = "";
            this.fpSpread1.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread1.VerticalScrollBar.TabIndex = 9;
            this.fpSpread1.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread1.SelectionChanged += new FarPoint.Win.Spread.SelectionChangedEventHandler(this.fpSpread1_SelectionChanged);
            this.fpSpread1.ButtonClicked += new FarPoint.Win.Spread.EditorNotifyEventHandler(this.fpSpread1_ButtonClicked);
            this.fpSpread1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread1_MouseDown);
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 10;
            this.fpSpread1_Sheet1.RowCount = 10;
            this.fpSpread1_Sheet1.AutoGenerateColumns = false;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.DataAutoSizeColumns = false;
            this.fpSpread1_Sheet1.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.fpSpread1_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.DefaultStyle.Parent = "DataAreaDefault";
            this.fpSpread1_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpread1_Sheet1.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpSpread1_Sheet1.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors;
            this.fpSpread1_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.CellChanged += new FarPoint.Win.Spread.SheetViewEventHandler(this.fpSpread1_Sheet1_CellChanged);
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 315);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(978, 110);
            this.panel2.TabIndex = 25;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(978, 110);
            this.panel3.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Honeydew;
            this.panel12.Controls.Add(this.lblMType);
            this.panel12.Controls.Add(this.label10);
            this.panel12.Controls.Add(this.lnkViewAttchment);
            this.panel12.Controls.Add(this.lnkViewAttchmentRoutine);
            this.panel12.Controls.Add(this.lblPlace);
            this.panel12.Controls.Add(this.lblManHrs);
            this.panel12.Controls.Add(this.lblManHrs1);
            this.panel12.Controls.Add(this.lblCompletion);
            this.panel12.Controls.Add(this.lblCondition);
            this.panel12.Controls.Add(this.lblReason);
            this.panel12.Controls.Add(this.lblCompletion1);
            this.panel12.Controls.Add(this.lblCondition1);
            this.panel12.Controls.Add(this.lblReason1);
            this.panel12.Controls.Add(this.lblResponsibleRank);
            this.panel12.Controls.Add(this.lblInChargeRank);
            this.panel12.Controls.Add(this.lbl_PMSCode);
            this.panel12.Controls.Add(this.label6);
            this.panel12.Controls.Add(this.lblPMMRefNo);
            this.panel12.Controls.Add(this.lblMaintenance);
            this.panel12.Controls.Add(this.lblComponent);
            this.panel12.Controls.Add(this.label4);
            this.panel12.Controls.Add(this.lblComp);
            this.panel12.Controls.Add(this.lblEquipment);
            this.panel12.Controls.Add(this.lblPMM);
            this.panel12.Controls.Add(this.lblMaint);
            this.panel12.Controls.Add(this.lblPostponementDate);
            this.panel12.Controls.Add(this.lblMaintCode);
            this.panel12.Controls.Add(this.lblInterval);
            this.panel12.Controls.Add(this.label15);
            this.panel12.Controls.Add(this.lblInCharge);
            this.panel12.Controls.Add(this.lblDept);
            this.panel12.Controls.Add(this.lblResponsible);
            this.panel12.Controls.Add(this.label14);
            this.panel12.Controls.Add(this.label3);
            this.panel12.Controls.Add(this.lblMaintType);
            this.panel12.Controls.Add(this.label7);
            this.panel12.Controls.Add(this.label8);
            this.panel12.Controls.Add(this.lblPMSCode);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Margin = new System.Windows.Forms.Padding(0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(978, 110);
            this.panel12.TabIndex = 24;
            // 
            // lblMType
            // 
            this.lblMType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMType.Location = new System.Drawing.Point(638, 3);
            this.lblMType.Name = "lblMType";
            this.lblMType.Size = new System.Drawing.Size(156, 17);
            this.lblMType.TabIndex = 104;
            this.lblMType.Text = "...";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(576, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 13);
            this.label10.TabIndex = 103;
            this.label10.Text = "Maint Type:";
            // 
            // lnkViewAttchment
            // 
            this.lnkViewAttchment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lnkViewAttchment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAttchment.Location = new System.Drawing.Point(840, 5);
            this.lnkViewAttchment.Name = "lnkViewAttchment";
            this.lnkViewAttchment.Size = new System.Drawing.Size(103, 15);
            this.lnkViewAttchment.TabIndex = 102;
            this.lnkViewAttchment.TabStop = true;
            this.lnkViewAttchment.Text = "View Attachment";
            this.lnkViewAttchment.Visible = false;
            this.lnkViewAttchment.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAttchment_LinkClicked);
            // 
            // lnkViewAttchmentRoutine
            // 
            this.lnkViewAttchmentRoutine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lnkViewAttchmentRoutine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnkViewAttchmentRoutine.Location = new System.Drawing.Point(839, 3);
            this.lnkViewAttchmentRoutine.Name = "lnkViewAttchmentRoutine";
            this.lnkViewAttchmentRoutine.Size = new System.Drawing.Size(113, 15);
            this.lnkViewAttchmentRoutine.TabIndex = 101;
            this.lnkViewAttchmentRoutine.TabStop = true;
            this.lnkViewAttchmentRoutine.Text = "View Attachment";
            this.lnkViewAttchmentRoutine.Visible = false;
            this.lnkViewAttchmentRoutine.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewAttchmentRoutine_LinkClicked);
            // 
            // lblPlace
            // 
            this.lblPlace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlace.Location = new System.Drawing.Point(413, 66);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(154, 17);
            this.lblPlace.TabIndex = 72;
            this.lblPlace.Text = "...";
            // 
            // lblManHrs
            // 
            this.lblManHrs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblManHrs.Location = new System.Drawing.Point(638, 24);
            this.lblManHrs.Name = "lblManHrs";
            this.lblManHrs.Size = new System.Drawing.Size(41, 17);
            this.lblManHrs.TabIndex = 100;
            this.lblManHrs.Text = "...";
            // 
            // lblManHrs1
            // 
            this.lblManHrs1.AutoSize = true;
            this.lblManHrs1.ForeColor = System.Drawing.Color.Blue;
            this.lblManHrs1.Location = new System.Drawing.Point(589, 26);
            this.lblManHrs1.Name = "lblManHrs1";
            this.lblManHrs1.Size = new System.Drawing.Size(50, 13);
            this.lblManHrs1.TabIndex = 99;
            this.lblManHrs1.Text = "Man Hrs:";
            // 
            // lblCompletion
            // 
            this.lblCompletion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCompletion.Location = new System.Drawing.Point(791, 45);
            this.lblCompletion.Name = "lblCompletion";
            this.lblCompletion.Size = new System.Drawing.Size(182, 17);
            this.lblCompletion.TabIndex = 98;
            this.lblCompletion.Text = "...";
            // 
            // lblCondition
            // 
            this.lblCondition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCondition.Location = new System.Drawing.Point(791, 24);
            this.lblCondition.Name = "lblCondition";
            this.lblCondition.Size = new System.Drawing.Size(182, 17);
            this.lblCondition.TabIndex = 97;
            this.lblCondition.Text = "...";
            // 
            // lblReason
            // 
            this.lblReason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReason.Location = new System.Drawing.Point(638, 45);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(95, 17);
            this.lblReason.TabIndex = 96;
            this.lblReason.Text = "...";
            // 
            // lblCompletion1
            // 
            this.lblCompletion1.AutoSize = true;
            this.lblCompletion1.ForeColor = System.Drawing.Color.Blue;
            this.lblCompletion1.Location = new System.Drawing.Point(732, 47);
            this.lblCompletion1.Name = "lblCompletion1";
            this.lblCompletion1.Size = new System.Drawing.Size(62, 13);
            this.lblCompletion1.TabIndex = 95;
            this.lblCompletion1.Text = "Completion:";
            // 
            // lblCondition1
            // 
            this.lblCondition1.AutoSize = true;
            this.lblCondition1.ForeColor = System.Drawing.Color.Blue;
            this.lblCondition1.Location = new System.Drawing.Point(740, 26);
            this.lblCondition1.Name = "lblCondition1";
            this.lblCondition1.Size = new System.Drawing.Size(54, 13);
            this.lblCondition1.TabIndex = 94;
            this.lblCondition1.Text = "Condition:";
            // 
            // lblReason1
            // 
            this.lblReason1.AutoSize = true;
            this.lblReason1.ForeColor = System.Drawing.Color.Blue;
            this.lblReason1.Location = new System.Drawing.Point(592, 47);
            this.lblReason1.Name = "lblReason1";
            this.lblReason1.Size = new System.Drawing.Size(47, 13);
            this.lblReason1.TabIndex = 93;
            this.lblReason1.Text = "Reason:";
            // 
            // lblResponsibleRank
            // 
            this.lblResponsibleRank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResponsibleRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsibleRank.ForeColor = System.Drawing.Color.Black;
            this.lblResponsibleRank.Location = new System.Drawing.Point(913, 87);
            this.lblResponsibleRank.Name = "lblResponsibleRank";
            this.lblResponsibleRank.Size = new System.Drawing.Size(61, 17);
            this.lblResponsibleRank.TabIndex = 82;
            this.lblResponsibleRank.Text = "...";
            // 
            // lblInChargeRank
            // 
            this.lblInChargeRank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInChargeRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInChargeRank.ForeColor = System.Drawing.Color.Black;
            this.lblInChargeRank.Location = new System.Drawing.Point(913, 66);
            this.lblInChargeRank.Name = "lblInChargeRank";
            this.lblInChargeRank.Size = new System.Drawing.Size(61, 17);
            this.lblInChargeRank.TabIndex = 80;
            this.lblInChargeRank.Text = "...";
            // 
            // lbl_PMSCode
            // 
            this.lbl_PMSCode.AutoSize = true;
            this.lbl_PMSCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PMSCode.ForeColor = System.Drawing.Color.Blue;
            this.lbl_PMSCode.Location = new System.Drawing.Point(143, 89);
            this.lbl_PMSCode.Name = "lbl_PMSCode";
            this.lbl_PMSCode.Size = new System.Drawing.Size(61, 13);
            this.lbl_PMSCode.TabIndex = 91;
            this.lbl_PMSCode.Text = "PMS Code:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(4, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 90;
            this.label6.Text = "Maintenance:";
            // 
            // lblPMMRefNo
            // 
            this.lblPMMRefNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPMMRefNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMMRefNo.ForeColor = System.Drawing.Color.Black;
            this.lblPMMRefNo.Location = new System.Drawing.Point(638, 66);
            this.lblPMMRefNo.Name = "lblPMMRefNo";
            this.lblPMMRefNo.Size = new System.Drawing.Size(95, 17);
            this.lblPMMRefNo.TabIndex = 76;
            this.lblPMMRefNo.Text = "...";
            // 
            // lblMaintenance
            // 
            this.lblMaintenance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintenance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintenance.ForeColor = System.Drawing.Color.Black;
            this.lblMaintenance.Location = new System.Drawing.Point(76, 27);
            this.lblMaintenance.Name = "lblMaintenance";
            this.lblMaintenance.Size = new System.Drawing.Size(491, 32);
            this.lblMaintenance.TabIndex = 89;
            this.lblMaintenance.Text = ".....";
            // 
            // lblComponent
            // 
            this.lblComponent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblComponent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComponent.ForeColor = System.Drawing.Color.Black;
            this.lblComponent.Location = new System.Drawing.Point(638, 87);
            this.lblComponent.Name = "lblComponent";
            this.lblComponent.Size = new System.Drawing.Size(185, 17);
            this.lblComponent.TabIndex = 73;
            this.lblComponent.Text = ".....";
            this.lblComponent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(16, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 88;
            this.label4.Text = "Equipment:";
            // 
            // lblComp
            // 
            this.lblComp.AutoSize = true;
            this.lblComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComp.ForeColor = System.Drawing.Color.Blue;
            this.lblComp.Location = new System.Drawing.Point(575, 89);
            this.lblComp.Name = "lblComp";
            this.lblComp.Size = new System.Drawing.Size(64, 13);
            this.lblComp.TabIndex = 74;
            this.lblComp.Text = "Component:";
            // 
            // lblEquipment
            // 
            this.lblEquipment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEquipment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEquipment.ForeColor = System.Drawing.Color.Black;
            this.lblEquipment.Location = new System.Drawing.Point(76, 5);
            this.lblEquipment.Name = "lblEquipment";
            this.lblEquipment.Size = new System.Drawing.Size(491, 17);
            this.lblEquipment.TabIndex = 87;
            this.lblEquipment.Text = ".....";
            this.lblEquipment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPMM
            // 
            this.lblPMM.AutoSize = true;
            this.lblPMM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMM.ForeColor = System.Drawing.Color.Blue;
            this.lblPMM.Location = new System.Drawing.Point(567, 68);
            this.lblPMM.Name = "lblPMM";
            this.lblPMM.Size = new System.Drawing.Size(72, 13);
            this.lblPMM.TabIndex = 75;
            this.lblPMM.Text = "PMM Ref No:";
            // 
            // lblMaint
            // 
            this.lblMaint.AutoSize = true;
            this.lblMaint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaint.ForeColor = System.Drawing.Color.Blue;
            this.lblMaint.Location = new System.Drawing.Point(737, 68);
            this.lblMaint.Name = "lblMaint";
            this.lblMaint.Size = new System.Drawing.Size(64, 13);
            this.lblMaint.TabIndex = 77;
            this.lblMaint.Text = "Maint Code:";
            // 
            // lblPostponementDate
            // 
            this.lblPostponementDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPostponementDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostponementDate.Location = new System.Drawing.Point(413, 87);
            this.lblPostponementDate.Name = "lblPostponementDate";
            this.lblPostponementDate.Size = new System.Drawing.Size(154, 17);
            this.lblPostponementDate.TabIndex = 4;
            this.lblPostponementDate.Text = "...";
            // 
            // lblMaintCode
            // 
            this.lblMaintCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintCode.ForeColor = System.Drawing.Color.Black;
            this.lblMaintCode.Location = new System.Drawing.Point(801, 66);
            this.lblMaintCode.Name = "lblMaintCode";
            this.lblMaintCode.Size = new System.Drawing.Size(25, 17);
            this.lblMaintCode.TabIndex = 78;
            this.lblMaintCode.Text = "...";
            // 
            // lblInterval
            // 
            this.lblInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInterval.ForeColor = System.Drawing.Color.Black;
            this.lblInterval.Location = new System.Drawing.Point(76, 87);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(65, 17);
            this.lblInterval.TabIndex = 86;
            this.lblInterval.Text = "...";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(31, 89);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 85;
            this.label15.Text = "Interval:";
            // 
            // lblInCharge
            // 
            this.lblInCharge.AutoSize = true;
            this.lblInCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInCharge.ForeColor = System.Drawing.Color.Blue;
            this.lblInCharge.Location = new System.Drawing.Point(834, 68);
            this.lblInCharge.Name = "lblInCharge";
            this.lblInCharge.Size = new System.Drawing.Size(82, 13);
            this.lblInCharge.TabIndex = 79;
            this.lblInCharge.Text = "InCharge Rank:";
            // 
            // lblDept
            // 
            this.lblDept.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDept.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDept.ForeColor = System.Drawing.Color.Black;
            this.lblDept.Location = new System.Drawing.Point(76, 66);
            this.lblDept.Name = "lblDept";
            this.lblDept.Size = new System.Drawing.Size(65, 17);
            this.lblDept.TabIndex = 84;
            this.lblDept.Text = "...";
            // 
            // lblResponsible
            // 
            this.lblResponsible.AutoSize = true;
            this.lblResponsible.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResponsible.ForeColor = System.Drawing.Color.Blue;
            this.lblResponsible.Location = new System.Drawing.Point(824, 89);
            this.lblResponsible.Name = "lblResponsible";
            this.lblResponsible.Size = new System.Drawing.Size(92, 13);
            this.lblResponsible.TabIndex = 81;
            this.lblResponsible.Text = "Reponsible Rank:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(43, 68);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 13);
            this.label14.TabIndex = 83;
            this.label14.Text = "Dept:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(376, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 71;
            this.label3.Text = "Place:";
            // 
            // lblMaintType
            // 
            this.lblMaintType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMaintType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintType.Location = new System.Drawing.Point(204, 66);
            this.lblMaintType.Name = "lblMaintType";
            this.lblMaintType.Size = new System.Drawing.Size(163, 17);
            this.lblMaintType.TabIndex = 3;
            this.lblMaintType.Text = "...";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(309, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Postponement Date:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(170, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Type:";
            // 
            // lblPMSCode
            // 
            this.lblPMSCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPMSCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPMSCode.ForeColor = System.Drawing.Color.Black;
            this.lblPMSCode.Location = new System.Drawing.Point(204, 87);
            this.lblPMSCode.Name = "lblPMSCode";
            this.lblPMSCode.Size = new System.Drawing.Size(102, 17);
            this.lblPMSCode.TabIndex = 92;
            this.lblPMSCode.Text = "...";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tableLayoutPanel3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 425);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(978, 100);
            this.panel5.TabIndex = 26;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.57078F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.42922F));
            this.tableLayoutPanel3.Controls.Add(this.panel9, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel7, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel8, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.panel10, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 13F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(978, 100);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Honeydew;
            this.panel9.Controls.Add(this.label1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(494, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(484, 13);
            this.panel9.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Honeydew;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(3, -1);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Associated Forms";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.fpSpreadConsumed);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 13);
            this.panel7.Margin = new System.Windows.Forms.Padding(0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(494, 87);
            this.panel7.TabIndex = 18;
            // 
            // fpSpreadConsumed
            // 
            this.fpSpreadConsumed.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpreadConsumed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadConsumed.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadConsumed.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadConsumed.HorizontalScrollBar.Name = "";
            this.fpSpreadConsumed.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.fpSpreadConsumed.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadConsumed.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadConsumed.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadConsumed.Name = "fpSpreadConsumed";
            this.fpSpreadConsumed.RowSplitBoxPolicy = FarPoint.Win.Spread.SplitBoxPolicy.Never;
            this.fpSpreadConsumed.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadConsumed_Sheet1});
            this.fpSpreadConsumed.Size = new System.Drawing.Size(494, 87);
            this.fpSpreadConsumed.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadConsumed.TabIndex = 16;
            this.fpSpreadConsumed.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadConsumed.VerticalScrollBar.Name = "";
            this.fpSpreadConsumed.VerticalScrollBar.Renderer = defaultScrollBarRenderer4;
            this.fpSpreadConsumed.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadConsumed.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadConsumed.VisualStyles = FarPoint.Win.VisualStyles.On;
            // 
            // fpSpreadConsumed_Sheet1
            // 
            this.fpSpreadConsumed_Sheet1.Reset();
            this.fpSpreadConsumed_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadConsumed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadConsumed_Sheet1.ColumnCount = 10;
            this.fpSpreadConsumed_Sheet1.RowCount = 10;
            this.fpSpreadConsumed_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadConsumed_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadConsumed_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadConsumed_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadConsumed_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadConsumed_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadConsumed_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadConsumed_Sheet1.RowHeader.Visible = false;
            this.fpSpreadConsumed_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadConsumed_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadConsumed_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadConsumed_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadConsumed_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.fpSpreadAssociatedForms);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(494, 13);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(484, 87);
            this.panel8.TabIndex = 17;
            // 
            // fpSpreadAssociatedForms
            // 
            this.fpSpreadAssociatedForms.AccessibleDescription = "fpSpreadAssociatedForms, Sheet1, Row 0, Column 0, ";
            this.fpSpreadAssociatedForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpreadAssociatedForms.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpreadAssociatedForms.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.HorizontalScrollBar.Renderer = defaultScrollBarRenderer5;
            this.fpSpreadAssociatedForms.HorizontalScrollBar.TabIndex = 0;
            this.fpSpreadAssociatedForms.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.Location = new System.Drawing.Point(0, 0);
            this.fpSpreadAssociatedForms.Name = "fpSpreadAssociatedForms";
            this.fpSpreadAssociatedForms.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpreadAssociatedForms_Sheet1});
            this.fpSpreadAssociatedForms.Size = new System.Drawing.Size(484, 87);
            this.fpSpreadAssociatedForms.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpreadAssociatedForms.TabIndex = 12;
            this.fpSpreadAssociatedForms.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpreadAssociatedForms.VerticalScrollBar.Name = "";
            this.fpSpreadAssociatedForms.VerticalScrollBar.Renderer = defaultScrollBarRenderer6;
            this.fpSpreadAssociatedForms.VerticalScrollBar.TabIndex = 1;
            this.fpSpreadAssociatedForms.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpreadAssociatedForms.VisualStyles = FarPoint.Win.VisualStyles.On;
            this.fpSpreadAssociatedForms.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpreadAssociatedForms_HyperLinkClicked);
            this.fpSpreadAssociatedForms.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpreadAssociatedForms_Error);
            // 
            // fpSpreadAssociatedForms_Sheet1
            // 
            this.fpSpreadAssociatedForms_Sheet1.Reset();
            this.fpSpreadAssociatedForms_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpreadAssociatedForms_Sheet1.ColumnCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.RowCount = 10;
            this.fpSpreadAssociatedForms_Sheet1.AutoGenerateColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.DataAutoSizeColumns = false;
            this.fpSpreadAssociatedForms_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpreadAssociatedForms_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpreadAssociatedForms_Sheet1.RowHeader.Visible = false;
            this.fpSpreadAssociatedForms_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpreadAssociatedForms_Sheet1.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpreadAssociatedForms_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpreadAssociatedForms_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Honeydew;
            this.panel10.Controls.Add(this.label5);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Margin = new System.Windows.Forms.Padding(0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(494, 13);
            this.panel10.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Honeydew;
            this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(3, -1);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Spare parts consumed";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmnuSuptComments,
            this.toolStripSeparator1,
            this.tsMnuMaintHistory});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(161, 54);
            // 
            // tsmnuSuptComments
            // 
            this.tsmnuSuptComments.Name = "tsmnuSuptComments";
            this.tsmnuSuptComments.Size = new System.Drawing.Size(160, 22);
            this.tsmnuSuptComments.Text = "Supt Comments";
            this.tsmnuSuptComments.Click += new System.EventHandler(this.tsmnuSuptComments_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(157, 6);
            // 
            // tsMnuMaintHistory
            // 
            this.tsMnuMaintHistory.Name = "tsMnuMaintHistory";
            this.tsMnuMaintHistory.Size = new System.Drawing.Size(160, 22);
            this.tsMnuMaintHistory.Text = "Maint History";
            this.tsMnuMaintHistory.Click += new System.EventHandler(this.tsMnuMaintHistory_Click);
            // 
            // frmSuptToApproveMaint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 749);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmSuptToApproveMaint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Supt To Approve Postponement Maintenance";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSuptReview_FormClosing);
            this.Load += new System.EventHandler(this.frmSuptToApproveMaint_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadConsumed_Sheet1)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpreadAssociatedForms_Sheet1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblTotalItems;
        private System.Windows.Forms.ToolStripStatusLabel tsLblSvrName;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmnuSuptComments;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuMaintHistory;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblMaintenance;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblEquipment;
        private System.Windows.Forms.Label lblPostponementDate;
        private System.Windows.Forms.Label lblInterval;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblDept;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblResponsibleRank;
        private System.Windows.Forms.Label lblResponsible;
        private System.Windows.Forms.Label lblInChargeRank;
        private System.Windows.Forms.Label lblInCharge;
        private System.Windows.Forms.Label lblMaintCode;
        private System.Windows.Forms.Label lblMaint;
        private System.Windows.Forms.Label lblPMMRefNo;
        private System.Windows.Forms.Label lblPMM;
        private System.Windows.Forms.Label lblComp;
        private System.Windows.Forms.Label lblComponent;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMaintType;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtVslComments;
        private System.Windows.Forms.Label lbl_PMSCode;
        private System.Windows.Forms.Label lblPMSCode;
        private System.Windows.Forms.LinkLabel lnkViewMaintDetails;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel7;
        private FarPoint.Win.Spread.FpSpread fpSpreadConsumed;
        private FarPoint.Win.Spread.SheetView fpSpreadConsumed_Sheet1;
        private System.Windows.Forms.Panel panel8;
        private FarPoint.Win.Spread.FpSpread fpSpreadAssociatedForms;
        private FarPoint.Win.Spread.SheetView fpSpreadAssociatedForms_Sheet1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblManHrs;
        private System.Windows.Forms.Label lblManHrs1;
        private System.Windows.Forms.Label lblCompletion;
        private System.Windows.Forms.Label lblCondition;
        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.Label lblCompletion1;
        private System.Windows.Forms.Label lblCondition1;
        private System.Windows.Forms.Label lblReason1;
        private System.Windows.Forms.LinkLabel lnkViewAttchmentRoutine;
        private System.Windows.Forms.LinkLabel lnkViewMaintCheckList;
        private System.Windows.Forms.LinkLabel lnkViewAlarmAndTestingItems;
        private System.Windows.Forms.LinkLabel lnkViewAttchment;
        private System.Windows.Forms.Label lblMType;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSuptComments;
    }
}