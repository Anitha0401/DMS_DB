﻿namespace HqSDS_Main
{
    partial class frmMaintInput_AlarmsRoutines
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer enhancedColumnHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer enhancedColumnHeaderRenderer2 = new FarPoint.Win.Spread.CellType.EnhancedColumnHeaderRenderer();
            FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer enhancedRowHeaderRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedRowHeaderRenderer();
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("ColumnHeaderEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("ColumnFooterEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle3 = new FarPoint.Win.Spread.NamedStyle("RowHeaderEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle4 = new FarPoint.Win.Spread.NamedStyle("CornerEnhanced");
            FarPoint.Win.Spread.CellType.EnhancedCornerRenderer enhancedCornerRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedCornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle5 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaintInput_AlarmsRoutines));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grpVerify = new System.Windows.Forms.GroupBox();
            this.rdoVerifyToRedo = new System.Windows.Forms.RadioButton();
            this.rdoVerifyOk = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdoIncomplete = new System.Windows.Forms.RadioButton();
            this.rdoSatisfactory = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoDock = new System.Windows.Forms.RadioButton();
            this.rdoPort = new System.Windows.Forms.RadioButton();
            this.rdoSea = new System.Windows.Forms.RadioButton();
            this.lnkViewMaintDetails = new System.Windows.Forms.LinkLabel();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpDateofTest = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.fpSpread_E0Items = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_E0Items_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnPmsReportLog = new System.Windows.Forms.Button();
            this.lblInterval = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_EqpName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lbl_Maintenance = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblTotalItems = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lnkViewHistAttach = new System.Windows.Forms.LinkLabel();
            this.lblAttachmentFileName = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lnkViewDetails = new System.Windows.Forms.LinkLabel();
            this.txtSignalType = new System.Windows.Forms.TextBox();
            this.lblSingalType = new System.Windows.Forms.Label();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTestMethod = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.pnlRange = new System.Windows.Forms.Panel();
            this.txtRangeLow = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRangeHigh = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlSetLimits = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.txtH_Limit = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtL_Limit = new System.Windows.Forms.TextBox();
            this.txtHH_Limit = new System.Windows.Forms.TextBox();
            this.txtLL_Limit = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grpVerify.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_E0Items)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_E0Items_Sheet1)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.pnlRange.SuspendLayout();
            this.pnlSetLimits.SuspendLayout();
            this.SuspendLayout();
            enhancedColumnHeaderRenderer1.Name = "enhancedColumnHeaderRenderer1";
            enhancedColumnHeaderRenderer1.TextRotationAngle = 0D;
            enhancedColumnHeaderRenderer2.Name = "enhancedColumnHeaderRenderer2";
            enhancedColumnHeaderRenderer2.TextRotationAngle = 0D;
            enhancedRowHeaderRenderer1.Name = "enhancedRowHeaderRenderer1";
            enhancedRowHeaderRenderer1.TextRotationAngle = 0D;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(869, 662);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grpVerify);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.lnkViewMaintDetails);
            this.panel2.Controls.Add(this.txtRemarks);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.dtpDateofTest);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(1, 79);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(867, 69);
            this.panel2.TabIndex = 77;
            // 
            // grpVerify
            // 
            this.grpVerify.Controls.Add(this.rdoVerifyToRedo);
            this.grpVerify.Controls.Add(this.rdoVerifyOk);
            this.grpVerify.Location = new System.Drawing.Point(354, 8);
            this.grpVerify.Name = "grpVerify";
            this.grpVerify.Size = new System.Drawing.Size(100, 55);
            this.grpVerify.TabIndex = 79;
            this.grpVerify.TabStop = false;
            this.grpVerify.Text = "Verify";
            // 
            // rdoVerifyToRedo
            // 
            this.rdoVerifyToRedo.AutoSize = true;
            this.rdoVerifyToRedo.Location = new System.Drawing.Point(7, 34);
            this.rdoVerifyToRedo.Name = "rdoVerifyToRedo";
            this.rdoVerifyToRedo.Size = new System.Drawing.Size(91, 17);
            this.rdoVerifyToRedo.TabIndex = 2;
            this.rdoVerifyToRedo.TabStop = true;
            this.rdoVerifyToRedo.Text = "Not Accepted";
            this.rdoVerifyToRedo.UseVisualStyleBackColor = true;
            // 
            // rdoVerifyOk
            // 
            this.rdoVerifyOk.AutoSize = true;
            this.rdoVerifyOk.Location = new System.Drawing.Point(7, 15);
            this.rdoVerifyOk.Name = "rdoVerifyOk";
            this.rdoVerifyOk.Size = new System.Drawing.Size(39, 17);
            this.rdoVerifyOk.TabIndex = 0;
            this.rdoVerifyOk.TabStop = true;
            this.rdoVerifyOk.Text = "Ok";
            this.rdoVerifyOk.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdoIncomplete);
            this.groupBox2.Controls.Add(this.rdoSatisfactory);
            this.groupBox2.Location = new System.Drawing.Point(246, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(100, 55);
            this.groupBox2.TabIndex = 80;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Result";
            // 
            // rdoIncomplete
            // 
            this.rdoIncomplete.AutoSize = true;
            this.rdoIncomplete.Location = new System.Drawing.Point(7, 35);
            this.rdoIncomplete.Name = "rdoIncomplete";
            this.rdoIncomplete.Size = new System.Drawing.Size(78, 17);
            this.rdoIncomplete.TabIndex = 1;
            this.rdoIncomplete.TabStop = true;
            this.rdoIncomplete.Text = "InComplete";
            this.rdoIncomplete.UseVisualStyleBackColor = true;
            // 
            // rdoSatisfactory
            // 
            this.rdoSatisfactory.AutoSize = true;
            this.rdoSatisfactory.Location = new System.Drawing.Point(7, 16);
            this.rdoSatisfactory.Name = "rdoSatisfactory";
            this.rdoSatisfactory.Size = new System.Drawing.Size(80, 17);
            this.rdoSatisfactory.TabIndex = 0;
            this.rdoSatisfactory.TabStop = true;
            this.rdoSatisfactory.Text = "Satisfactory";
            this.rdoSatisfactory.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoDock);
            this.groupBox1.Controls.Add(this.rdoPort);
            this.groupBox1.Controls.Add(this.rdoSea);
            this.groupBox1.Location = new System.Drawing.Point(138, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(101, 54);
            this.groupBox1.TabIndex = 78;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Location";
            // 
            // rdoDock
            // 
            this.rdoDock.AutoSize = true;
            this.rdoDock.Location = new System.Drawing.Point(7, 34);
            this.rdoDock.Name = "rdoDock";
            this.rdoDock.Size = new System.Drawing.Size(51, 17);
            this.rdoDock.TabIndex = 2;
            this.rdoDock.TabStop = true;
            this.rdoDock.Text = "Dock";
            this.rdoDock.UseVisualStyleBackColor = true;
            // 
            // rdoPort
            // 
            this.rdoPort.AutoSize = true;
            this.rdoPort.Location = new System.Drawing.Point(52, 16);
            this.rdoPort.Name = "rdoPort";
            this.rdoPort.Size = new System.Drawing.Size(44, 17);
            this.rdoPort.TabIndex = 1;
            this.rdoPort.TabStop = true;
            this.rdoPort.Text = "Port";
            this.rdoPort.UseVisualStyleBackColor = true;
            // 
            // rdoSea
            // 
            this.rdoSea.AutoSize = true;
            this.rdoSea.Location = new System.Drawing.Point(7, 16);
            this.rdoSea.Name = "rdoSea";
            this.rdoSea.Size = new System.Drawing.Size(44, 17);
            this.rdoSea.TabIndex = 0;
            this.rdoSea.TabStop = true;
            this.rdoSea.Text = "Sea";
            this.rdoSea.UseVisualStyleBackColor = true;
            // 
            // lnkViewMaintDetails
            // 
            this.lnkViewMaintDetails.AutoSize = true;
            this.lnkViewMaintDetails.Location = new System.Drawing.Point(643, 4);
            this.lnkViewMaintDetails.Name = "lnkViewMaintDetails";
            this.lnkViewMaintDetails.Size = new System.Drawing.Size(186, 13);
            this.lnkViewMaintDetails.TabIndex = 74;
            this.lnkViewMaintDetails.TabStop = true;
            this.lnkViewMaintDetails.Text = "View Alarms and Routines procedures";
            this.lnkViewMaintDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewMaintDetails_LinkClicked);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Location = new System.Drawing.Point(460, 21);
            this.txtRemarks.MaxLength = 510;
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(398, 41);
            this.txtRemarks.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(460, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Remarks";
            // 
            // dtpDateofTest
            // 
            this.dtpDateofTest.CustomFormat = "dd-MMM-yyyy";
            this.dtpDateofTest.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateofTest.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateofTest.Location = new System.Drawing.Point(12, 22);
            this.dtpDateofTest.Name = "dtpDateofTest";
            this.dtpDateofTest.Size = new System.Drawing.Size(126, 21);
            this.dtpDateofTest.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Date of Test";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fpSpread_E0Items);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 192);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(861, 363);
            this.panel3.TabIndex = 2;
            // 
            // fpSpread_E0Items
            // 
            this.fpSpread_E0Items.AccessibleDescription = "";
            this.fpSpread_E0Items.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_E0Items.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_E0Items.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_E0Items.HorizontalScrollBar.Name = "";
            this.fpSpread_E0Items.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread_E0Items.HorizontalScrollBar.TabIndex = 4;
            this.fpSpread_E0Items.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_E0Items.Name = "fpSpread_E0Items";
            namedStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(220)))), ((int)(((byte)(233)))));
            namedStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.Renderer = enhancedColumnHeaderRenderer2;
            namedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(220)))), ((int)(((byte)(233)))));
            namedStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.Renderer = enhancedColumnHeaderRenderer1;
            namedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(247)))));
            namedStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle3.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle3.Renderer = enhancedRowHeaderRenderer1;
            namedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            namedStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle4.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle4.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle4.Renderer = enhancedCornerRenderer1;
            namedStyle4.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle5.BackColor = System.Drawing.SystemColors.Window;
            namedStyle5.CellType = generalCellType1;
            namedStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle5.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle5.Renderer = generalCellType1;
            this.fpSpread_E0Items.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2,
            namedStyle3,
            namedStyle4,
            namedStyle5});
            this.fpSpread_E0Items.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_E0Items_Sheet1});
            this.fpSpread_E0Items.Size = new System.Drawing.Size(861, 363);
            this.fpSpread_E0Items.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_E0Items.TabIndex = 0;
            this.fpSpread_E0Items.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_E0Items.VerticalScrollBar.Name = "";
            this.fpSpread_E0Items.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread_E0Items.VerticalScrollBar.TabIndex = 3;
            this.fpSpread_E0Items.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread_E0Items.SelectionChanged += new FarPoint.Win.Spread.SelectionChangedEventHandler(this.fpSpread_E0Items_SelectionChanged);
            this.fpSpread_E0Items.TextTipFetch += new FarPoint.Win.Spread.TextTipFetchEventHandler(this.fpSpread_E0Items_TextTipFetch);
            this.fpSpread_E0Items.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread_E0Items_MouseDown);
            // 
            // fpSpread_E0Items_Sheet1
            // 
            this.fpSpread_E0Items_Sheet1.Reset();
            this.fpSpread_E0Items_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_E0Items_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_E0Items_Sheet1.ColumnCount = 5;
            this.fpSpread_E0Items_Sheet1.RowCount = 5;
            this.fpSpread_E0Items_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_E0Items_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_E0Items_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_E0Items_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_E0Items_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_E0Items_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_E0Items_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_E0Items_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_E0Items_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_E0Items_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_E0Items_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnPmsReportLog);
            this.panel5.Controls.Add(this.lblInterval);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.lbl_EqpName);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.btnCancel);
            this.panel5.Controls.Add(this.lbl_Maintenance);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(1, 1);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(867, 77);
            this.panel5.TabIndex = 7;
            // 
            // btnPmsReportLog
            // 
            this.btnPmsReportLog.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPmsReportLog.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPmsReportLog.Image = ((System.Drawing.Image)(resources.GetObject("btnPmsReportLog.Image")));
            this.btnPmsReportLog.Location = new System.Drawing.Point(727, 4);
            this.btnPmsReportLog.Margin = new System.Windows.Forms.Padding(0);
            this.btnPmsReportLog.Name = "btnPmsReportLog";
            this.btnPmsReportLog.Size = new System.Drawing.Size(40, 41);
            this.btnPmsReportLog.TabIndex = 81;
            this.btnPmsReportLog.Text = "Log";
            this.btnPmsReportLog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPmsReportLog.UseVisualStyleBackColor = false;
            this.btnPmsReportLog.Click += new System.EventHandler(this.btnPmsReportLog_Click);
            // 
            // lblInterval
            // 
            this.lblInterval.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblInterval.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInterval.ForeColor = System.Drawing.Color.Black;
            this.lblInterval.Location = new System.Drawing.Point(576, 5);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(87, 19);
            this.lblInterval.TabIndex = 80;
            this.lblInterval.Text = "....";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(523, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 13);
            this.label16.TabIndex = 78;
            this.label16.Text = "Interval: ";
            // 
            // lbl_EqpName
            // 
            this.lbl_EqpName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_EqpName.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EqpName.ForeColor = System.Drawing.Color.Blue;
            this.lbl_EqpName.Location = new System.Drawing.Point(6, 3);
            this.lbl_EqpName.Name = "lbl_EqpName";
            this.lbl_EqpName.Size = new System.Drawing.Size(517, 27);
            this.lbl_EqpName.TabIndex = 79;
            this.lbl_EqpName.Text = "lbl_EqpName";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(5, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 15);
            this.label1.TabIndex = 75;
            this.label1.Text = "Alarms and Routines Title";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(773, 4);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(0);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(54, 41);
            this.btnCancel.TabIndex = 64;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lbl_Maintenance
            // 
            this.lbl_Maintenance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Maintenance.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Maintenance.ForeColor = System.Drawing.Color.Black;
            this.lbl_Maintenance.Location = new System.Drawing.Point(5, 49);
            this.lbl_Maintenance.Name = "lbl_Maintenance";
            this.lbl_Maintenance.Size = new System.Drawing.Size(824, 24);
            this.lbl_Maintenance.TabIndex = 12;
            this.lbl_Maintenance.Text = "\r\n";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lblTotalItems);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.lnkViewHistAttach);
            this.panel6.Controls.Add(this.lblAttachmentFileName);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(1, 149);
            this.panel6.Margin = new System.Windows.Forms.Padding(0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(867, 39);
            this.panel6.TabIndex = 19;
            // 
            // lblTotalItems
            // 
            this.lblTotalItems.AutoSize = true;
            this.lblTotalItems.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblTotalItems.ForeColor = System.Drawing.Color.Blue;
            this.lblTotalItems.Location = new System.Drawing.Point(706, 22);
            this.lblTotalItems.Name = "lblTotalItems";
            this.lblTotalItems.Size = new System.Drawing.Size(68, 13);
            this.lblTotalItems.TabIndex = 126;
            this.lblTotalItems.Text = "TotalItems";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(6, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 18);
            this.label10.TabIndex = 125;
            this.label10.Text = "Items List";
            // 
            // lnkViewHistAttach
            // 
            this.lnkViewHistAttach.Location = new System.Drawing.Point(93, 7);
            this.lnkViewHistAttach.Name = "lnkViewHistAttach";
            this.lnkViewHistAttach.Size = new System.Drawing.Size(549, 17);
            this.lnkViewHistAttach.TabIndex = 78;
            this.lnkViewHistAttach.TabStop = true;
            this.lnkViewHistAttach.Text = "View";
            this.lnkViewHistAttach.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewHistAttach_LinkClicked);
            // 
            // lblAttachmentFileName
            // 
            this.lblAttachmentFileName.AutoSize = true;
            this.lblAttachmentFileName.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAttachmentFileName.Location = new System.Drawing.Point(584, 12);
            this.lblAttachmentFileName.Name = "lblAttachmentFileName";
            this.lblAttachmentFileName.Size = new System.Drawing.Size(15, 14);
            this.lblAttachmentFileName.TabIndex = 75;
            this.lblAttachmentFileName.Text = "--";
            this.lblAttachmentFileName.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(5, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 13);
            this.label7.TabIndex = 80;
            this.label7.Text = "Attachment";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(1, 559);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(867, 93);
            this.panel1.TabIndex = 78;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel4.Controls.Add(this.lnkViewDetails);
            this.panel4.Controls.Add(this.txtSignalType);
            this.panel4.Controls.Add(this.lblSingalType);
            this.panel4.Controls.Add(this.txtComments);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.txtTestMethod);
            this.panel4.Controls.Add(this.txtDescription);
            this.panel4.Controls.Add(this.pnlRange);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.pnlSetLimits);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(867, 93);
            this.panel4.TabIndex = 79;
            // 
            // lnkViewDetails
            // 
            this.lnkViewDetails.AutoSize = true;
            this.lnkViewDetails.Location = new System.Drawing.Point(403, 39);
            this.lnkViewDetails.Name = "lnkViewDetails";
            this.lnkViewDetails.Size = new System.Drawing.Size(60, 13);
            this.lnkViewDetails.TabIndex = 81;
            this.lnkViewDetails.TabStop = true;
            this.lnkViewDetails.Text = "View Detail";
            this.lnkViewDetails.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkViewDetails_LinkClicked);
            // 
            // txtSignalType
            // 
            this.txtSignalType.BackColor = System.Drawing.SystemColors.Info;
            this.txtSignalType.ForeColor = System.Drawing.Color.Black;
            this.txtSignalType.Location = new System.Drawing.Point(66, 63);
            this.txtSignalType.MaxLength = 25;
            this.txtSignalType.Name = "txtSignalType";
            this.txtSignalType.ReadOnly = true;
            this.txtSignalType.Size = new System.Drawing.Size(164, 20);
            this.txtSignalType.TabIndex = 59;
            // 
            // lblSingalType
            // 
            this.lblSingalType.AutoSize = true;
            this.lblSingalType.ForeColor = System.Drawing.Color.Black;
            this.lblSingalType.Location = new System.Drawing.Point(31, 67);
            this.lblSingalType.Name = "lblSingalType";
            this.lblSingalType.Size = new System.Drawing.Size(37, 13);
            this.lblSingalType.TabIndex = 58;
            this.lblSingalType.Text = "Action";
            // 
            // txtComments
            // 
            this.txtComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtComments.ForeColor = System.Drawing.Color.Black;
            this.txtComments.Location = new System.Drawing.Point(535, 8);
            this.txtComments.MaxLength = 25;
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.ReadOnly = true;
            this.txtComments.Size = new System.Drawing.Size(326, 32);
            this.txtComments.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(481, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 56;
            this.label6.Text = "Comments";
            // 
            // txtTestMethod
            // 
            this.txtTestMethod.BackColor = System.Drawing.SystemColors.Info;
            this.txtTestMethod.ForeColor = System.Drawing.Color.Black;
            this.txtTestMethod.Location = new System.Drawing.Point(66, 35);
            this.txtTestMethod.MaxLength = 25;
            this.txtTestMethod.Name = "txtTestMethod";
            this.txtTestMethod.ReadOnly = true;
            this.txtTestMethod.Size = new System.Drawing.Size(324, 20);
            this.txtTestMethod.TabIndex = 51;
            // 
            // txtDescription
            // 
            this.txtDescription.BackColor = System.Drawing.SystemColors.Info;
            this.txtDescription.ForeColor = System.Drawing.Color.Black;
            this.txtDescription.Location = new System.Drawing.Point(66, 8);
            this.txtDescription.MaxLength = 25;
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ReadOnly = true;
            this.txtDescription.Size = new System.Drawing.Size(407, 24);
            this.txtDescription.TabIndex = 54;
            // 
            // pnlRange
            // 
            this.pnlRange.Controls.Add(this.txtRangeLow);
            this.pnlRange.Controls.Add(this.label4);
            this.pnlRange.Controls.Add(this.txtRangeHigh);
            this.pnlRange.Controls.Add(this.label5);
            this.pnlRange.Location = new System.Drawing.Point(232, 58);
            this.pnlRange.Name = "pnlRange";
            this.pnlRange.Size = new System.Drawing.Size(241, 29);
            this.pnlRange.TabIndex = 55;
            // 
            // txtRangeLow
            // 
            this.txtRangeLow.BackColor = System.Drawing.SystemColors.Info;
            this.txtRangeLow.ForeColor = System.Drawing.Color.Black;
            this.txtRangeLow.Location = new System.Drawing.Point(60, 4);
            this.txtRangeLow.MaxLength = 25;
            this.txtRangeLow.Name = "txtRangeLow";
            this.txtRangeLow.ReadOnly = true;
            this.txtRangeLow.Size = new System.Drawing.Size(61, 20);
            this.txtRangeLow.TabIndex = 44;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(1, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 43;
            this.label4.Text = "Range Low";
            // 
            // txtRangeHigh
            // 
            this.txtRangeHigh.BackColor = System.Drawing.SystemColors.Info;
            this.txtRangeHigh.ForeColor = System.Drawing.Color.Black;
            this.txtRangeHigh.Location = new System.Drawing.Point(178, 4);
            this.txtRangeHigh.MaxLength = 25;
            this.txtRangeHigh.Name = "txtRangeHigh";
            this.txtRangeHigh.ReadOnly = true;
            this.txtRangeHigh.Size = new System.Drawing.Size(61, 20);
            this.txtRangeHigh.TabIndex = 46;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(119, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 45;
            this.label5.Text = "Range High";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(8, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 53;
            this.label3.Text = "Description";
            // 
            // pnlSetLimits
            // 
            this.pnlSetLimits.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnlSetLimits.Controls.Add(this.label14);
            this.pnlSetLimits.Controls.Add(this.txtH_Limit);
            this.pnlSetLimits.Controls.Add(this.label12);
            this.pnlSetLimits.Controls.Add(this.label9);
            this.pnlSetLimits.Controls.Add(this.txtL_Limit);
            this.pnlSetLimits.Controls.Add(this.txtHH_Limit);
            this.pnlSetLimits.Controls.Add(this.txtLL_Limit);
            this.pnlSetLimits.Controls.Add(this.label13);
            this.pnlSetLimits.Location = new System.Drawing.Point(486, 45);
            this.pnlSetLimits.Margin = new System.Windows.Forms.Padding(0);
            this.pnlSetLimits.Name = "pnlSetLimits";
            this.pnlSetLimits.Size = new System.Drawing.Size(339, 39);
            this.pnlSetLimits.TabIndex = 52;
            // 
            // label14
            // 
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(4, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 14);
            this.label14.TabIndex = 27;
            this.label14.Text = "LL Limit";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtH_Limit
            // 
            this.txtH_Limit.BackColor = System.Drawing.SystemColors.Info;
            this.txtH_Limit.ForeColor = System.Drawing.Color.Black;
            this.txtH_Limit.Location = new System.Drawing.Point(170, 16);
            this.txtH_Limit.MaxLength = 25;
            this.txtH_Limit.Name = "txtH_Limit";
            this.txtH_Limit.ReadOnly = true;
            this.txtH_Limit.Size = new System.Drawing.Size(80, 20);
            this.txtH_Limit.TabIndex = 32;
            this.txtH_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(170, 2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 14);
            this.label12.TabIndex = 30;
            this.label12.Text = "H Limit";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(252, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 14);
            this.label9.TabIndex = 33;
            this.label9.Text = "HH Limit";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtL_Limit
            // 
            this.txtL_Limit.BackColor = System.Drawing.SystemColors.Info;
            this.txtL_Limit.ForeColor = System.Drawing.Color.Black;
            this.txtL_Limit.Location = new System.Drawing.Point(87, 16);
            this.txtL_Limit.MaxLength = 6;
            this.txtL_Limit.Name = "txtL_Limit";
            this.txtL_Limit.ReadOnly = true;
            this.txtL_Limit.Size = new System.Drawing.Size(80, 20);
            this.txtL_Limit.TabIndex = 31;
            this.txtL_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtHH_Limit
            // 
            this.txtHH_Limit.BackColor = System.Drawing.SystemColors.Info;
            this.txtHH_Limit.ForeColor = System.Drawing.Color.Black;
            this.txtHH_Limit.Location = new System.Drawing.Point(252, 16);
            this.txtHH_Limit.MaxLength = 25;
            this.txtHH_Limit.Name = "txtHH_Limit";
            this.txtHH_Limit.ReadOnly = true;
            this.txtHH_Limit.Size = new System.Drawing.Size(80, 20);
            this.txtHH_Limit.TabIndex = 34;
            this.txtHH_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtLL_Limit
            // 
            this.txtLL_Limit.BackColor = System.Drawing.SystemColors.Info;
            this.txtLL_Limit.ForeColor = System.Drawing.Color.Black;
            this.txtLL_Limit.Location = new System.Drawing.Point(4, 16);
            this.txtLL_Limit.MaxLength = 6;
            this.txtLL_Limit.Name = "txtLL_Limit";
            this.txtLL_Limit.ReadOnly = true;
            this.txtLL_Limit.Size = new System.Drawing.Size(80, 20);
            this.txtLL_Limit.TabIndex = 28;
            this.txtLL_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(87, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 14);
            this.label13.TabIndex = 29;
            this.label13.Text = "L Limit";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(1, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 13);
            this.label15.TabIndex = 50;
            this.label15.Text = "Test Method";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frmMaintInput_AlarmsRoutines
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 662);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMaintInput_AlarmsRoutines";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "  Alarms Routines Report";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMaintInput_AlarmsRoutines_FormClosing);
            this.Load += new System.EventHandler(this.frmMaintInput_AlarmsRoutines_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.grpVerify.ResumeLayout(false);
            this.grpVerify.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_E0Items)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_E0Items_Sheet1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pnlRange.ResumeLayout(false);
            this.pnlRange.PerformLayout();
            this.pnlSetLimits.ResumeLayout(false);
            this.pnlSetLimits.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private FarPoint.Win.Spread.FpSpread fpSpread_E0Items;
        private FarPoint.Win.Spread.SheetView fpSpread_E0Items_Sheet1;
        private System.Windows.Forms.Label lbl_Maintenance;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.LinkLabel lnkViewHistAttach;
        private System.Windows.Forms.Label lblAttachmentFileName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtpDateofTest;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.LinkLabel lnkViewMaintDetails;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTestMethod;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Panel pnlRange;
        private System.Windows.Forms.TextBox txtRangeLow;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRangeHigh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlSetLimits;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtH_Limit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtL_Limit;
        private System.Windows.Forms.TextBox txtHH_Limit;
        private System.Windows.Forms.TextBox txtLL_Limit;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSignalType;
        private System.Windows.Forms.Label lblSingalType;
        private System.Windows.Forms.GroupBox grpVerify;
        private System.Windows.Forms.RadioButton rdoVerifyToRedo;
        private System.Windows.Forms.RadioButton rdoVerifyOk;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdoIncomplete;
        private System.Windows.Forms.RadioButton rdoSatisfactory;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoDock;
        private System.Windows.Forms.RadioButton rdoPort;
        private System.Windows.Forms.RadioButton rdoSea;
        private System.Windows.Forms.Label lblInterval;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_EqpName;
        private System.Windows.Forms.Label lblTotalItems;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnPmsReportLog;
        private System.Windows.Forms.LinkLabel lnkViewDetails;
    }
}