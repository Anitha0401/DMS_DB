﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmSuptReview : Form
    {
        public int vesselID = -1;
        public string callMode = "";
        public  bool isMaintAckDone = false;

        bool isGridInitialied = false, canCloseForm = false, isUserAssignedVsl = false, isRunningHrsEqp = false;
        const int COL_EQPNAME = 0,
                  COL_POSITION = 1,
                  COL_MNTDESC = 2,
                  COL_NMDATE = 3,
                  COL_ACK = 4,
                  COL_COMMENTS = 5,
                  COL_MREPREFNO = 6,
                  COL_MREASON = 7,
                  COL_MPLACE = 8,
                  COL_MICOND = 9,
                  COL_MCOMPL = 10,
                  COL_MMHRS = 11,
                  COL_VSLNO = 12,
                  COL_EQ_EQUIPMENTID = 13,
                  COL_UNITNO = 14,
                  COL_MAINTNO = 15,
                  COL_ISSUPTAPPROVED = 16,
                  COL_SUPTCOMMENTS = 17,
                  COL_PMS_DOCID = 18,
                  COL_MAINTTYPE = 19,
                  COL_PMSHISTID = 20,
                  COL_EQ_PMSLIST_CLASSID = 21,
                  COL_SREPREFNO = 22,
                  COL_HASWORKDONEPROCDURE = 23,
                  COL_PMM_DOCREFNO = 24,
                  COL_MAINTCODE = 25,
                  COL_INTERVAL = 26,
                  COL_COMPONENT = 27,
                  COL_INCHARGERANK = 28,
                  COL_RESPONSIBLERANK = 29,
                  COL_PMSCODE = 30,
                  COL_DEPT = 31,
                  COL_MEASUREDVAL = 32,
                  COL_CE_MAS_Verify = 33,
                  COL_MTYPE = 34,
                  COL_ACTUALRUNNINGHRSATMAINT = 35;

        SuptReview suptRvw = null;
        long curEQUnitID = -1, curEQMaintID = -1, curPms_DocID = -1;
        int curVesselID = -1;

        public frmSuptReview()
        {
            InitializeComponent();
        }

        private void frmSuptReview_Load(object sender, EventArgs e)
        {
            suptRvw = new SuptReview();
            this.Text = "Supt Review - " + PG.GetVslName(vesselID);
            if (PG.Gb.IsToConnecDirectDB)
                tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else
                tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();
          
            Gfn.SetFormWidthAndHeight(this, 1, 1, SystemInformation.PrimaryMonitorSize.Height, 1024);

            PG.InitialiseVesselSettings(vesselID);

            EnableDisableButtonsBasedonUserRights();
            DesignSuptQGridDetails();
            BindSuptQGrid();

            DesignPmsConsumedGrid();
            DesignMaintAssociatedForms();
          
            if (fpSpread1.ActiveSheet.RowCount > 0)
            {
                fpSpread1_SelectionChanged(null, null);
                btnUpdate.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
                btnSendBackToVSL.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);

                lblPMM.Visible = !PG.isPMS_HidePMMDetails; lblPMMRefNo.Visible = !PG.isPMS_HidePMMDetails;
                lblMaint.Visible = !PG.isPMS_HidePMMDetails; lblMaintCode.Visible = !PG.isPMS_HidePMMDetails;
                lblComp.Visible = !PG.isPMS_HidePMMDetails; lblComponent.Visible = !PG.isPMS_HidePMMDetails;
                lblInCharge.Visible = !PG.isPMS_HideMaintIncharge; lblInChargeRank.Visible = !PG.isPMS_HideMaintIncharge;
                lblResponsible.Visible = !PG.isPMS_HideMaintResponsible; lblResponsibleRank.Visible = !PG.isPMS_HideMaintResponsible;

                lblPMMRoutine.Visible = !PG.isPMS_HidePMMDetails; lblPMMRefNoRoutine.Visible = !PG.isPMS_HidePMMDetails;
                lblMaintRoutine.Visible = !PG.isPMS_HidePMMDetails; lblMaintCodeRoutine.Visible = !PG.isPMS_HidePMMDetails;
                lblCompRoutine.Visible = !PG.isPMS_HidePMMDetails; lblComponentRoutine.Visible = !PG.isPMS_HidePMMDetails;
                lblInChargeRoutine.Visible = !PG.isPMS_HideMaintIncharge; lblInChargeRankRoutine.Visible = !PG.isPMS_HideMaintIncharge;
                lblResponsibleRoutine.Visible = !PG.isPMS_HideMaintResponsible; lblResponsibleRankRoutine.Visible = !PG.isPMS_HideMaintResponsible;
            }

            lblComments.Text = PG.GetEQ_PMS_Settings(curVesselID, "PMS_VesselCommentsLablelValue");

            this.Cursor = Cursors.Default;
        }

        protected void EnableDisableButtonsBasedonUserRights()
        {
            try
            {
                string script = " select count(*) from Proc_UserActionVsls " +
                                " where VesselID=" + vesselID + " and userId=" + Gfn.Qss(PG.Gb.User.CurUserID) +
                                "       and UserID in (select UserID from HQ_USers where Role in (" + "'" + PG.pmsAllowedRolesToSuptReview.Replace(",", "','") + "'" + " )) ";
                int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
                isUserAssignedVsl = (cnt > 0);

                btnMarkAllNormalReports.Enabled = isUserAssignedVsl;
                btnUnMarkAll.Enabled = isUserAssignedVsl;
                btnUpdate.Enabled = isUserAssignedVsl;
                btnSendBackToVSL.Enabled = isUserAssignedVsl;
                tsmnuSuptComments.Enabled = isUserAssignedVsl;
                tsMnuSendBackToVslForAmendments.Enabled = isUserAssignedVsl;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.cs", "EnableDisableButtonsBasedonUserRights", err.Message);
            }
        }

        protected void DesignSuptQGridDetails()
        {
            List<DgvInits> suptQColList = new List<DgvInits>();
            try
            {   
                suptQColList.Add(new DgvInits("EqpName", "Equipment Name", 165, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("PositionDesc", "Position", 70, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("MaintDescription", "Maintenance", 270, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("nMdate_Display", "Maint Date", 80, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("Ack", "Ack", 30, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("VslComments", lblComments.Text, 250, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("mRepRefNo", "mRepRefNo", 80, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("mReason", "Reason", 75, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("mPlace", "Place", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("miCond", "Condition", 100, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MCompl", "Completion", 100, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MMHRS", "Man Hours", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("VesselID", "VesselID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("EQ_EquipmentID", "EQ_EquipmentID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("Eq_UnitsID", "Eq_UnitsID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("Eq_MaintenanceID", "Eq_MaintenanceID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("IsSuptApproved", "IsSuptApproved", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("SuptComments", "Supt Comments", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("PMS_DocID", "PMS_DocID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MaintType", "Maint Type", 75, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("EQ_PmsHistID", "EQ_PmsHistID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("EQ_PmsList_ClassID", "EQ_PmsList_ClassID", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("SREPREFNO", "SREPREFNO", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("AddlIntField", "AddlIntField", 50, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("PMM_DocRefno", "PMM DocNo", 75, Color.Black, SystemColors.ButtonFace, !(PG.isPMS_HidePMMDetails), true));
                suptQColList.Add(new DgvInits("MaintCode", "Maint Code", 50, Color.Black, SystemColors.ButtonFace, !(PG.isPMS_HidePMMDetails), true));
                suptQColList.Add(new DgvInits("Interval", "Interval", 59, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("Component", "Component", 100, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("InChargeRank", "InCharge (Rank)", 70, Color.Black, SystemColors.ButtonFace, !(PG.isPMS_HideMaintIncharge), true));
                suptQColList.Add(new DgvInits("ReponsibleRank", "Resp.(Rank)", 70, Color.Black, SystemColors.ButtonFace, !(PG.isPMS_HideMaintResponsible), true));
                suptQColList.Add(new DgvInits("PmsCode", "PMS Code", 110, Color.Black, SystemColors.ButtonFace, !(PG.isPMS_HidePMSCode), true));
                suptQColList.Add(new DgvInits("DeptDisplayStr", "Dept", 55, Color.Black, SystemColors.ButtonFace, true, true));
                suptQColList.Add(new DgvInits("MeasuredValue", "Measured Value", 70, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("CE_MAS_Verify", "CE/Mas Verify", 0, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("MType", "Type", 0, Color.Black, SystemColors.ButtonFace, false, true));
                suptQColList.Add(new DgvInits("ActualRunningHrsAtMaint", "Actual Running Hrs", 0, Color.Black, SystemColors.ButtonFace, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, suptQColList, null, false, false, true);
                FarPtColCtrls.AssignCheckBoxColumnsToFarPointGrid(fpSpread1, false, "SuptToAck", "Ack", COL_ACK, "", 30, Color.White);
                FarPtColCtrls.AssignTextBoxColumnToFarPointGrid(fpSpread1, false, "SuptComments", "Supt Comments", COL_SUPTCOMMENTS, 230, true, Color.White, false, 450);

                fpSpread1.ActiveSheet.Columns[COL_ACK].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 25;

                fpSpread1.ActiveSheet.Columns[COL_ACK].Locked = (!isUserAssignedVsl);
            }
            finally
            {
                suptQColList = null;
            }
        }

        private void BindSuptQGrid()
        {
            DataTable dt = null;
            try
            {
                fpSpread1.SuspendLayout();
                isGridInitialied = false;
                fpSpread1.ActiveSheet.RowCount = 0;
                string filterStr = "";
                filterStr = txtSearch.Text;

                if (suptRvw == null) return;

                dt = suptRvw.GetSuptQDataTable(vesselID, callMode, filterStr);
                fpSpread1.ActiveSheet.DataSource = dt;
                if (dt == null)
                {
                    ClearControls();
                }
                if (dt != null && dt.Rows.Count > 0)
                {
                    RefreshGrid();                       
                }
                                
                isGridInitialied = true;
                if (fpSpread1.ActiveSheet.RowCount > 0)
                {
                    fpSpread1_SelectionChanged(null, null);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.cs", "BindSuptQGrid()", err.Message);
                Gfn.nWb("Failed to bind SuptQ details");
            }
            finally
            {
                fpSpread1.ResumeLayout();
                dt = null;
            }
            tsLblTotalItems.Text = "Total Items : " + fpSpread1.ActiveSheet.RowCount;
        }

        private void ClearControls()
        {
            lblDept.Text = ""; lblDeptRoutine.Text = "";
            lblPlace.Text = ""; lblLocation.Text = "";
            lblInterval.Text = ""; lblIntervalRoutine.Text = "";
            lblMaintCode.Text = ""; lblMaintCodeRoutine.Text = "";
            lblManHrs.Text = "";
            lblPMMRefNo.Text = ""; lblPMMRefNoRoutine.Text = "";
            lblResponsibleRank.Text = ""; lblResponsibleRankRoutine.Text = "";
            lblResponsibleRankRoutine.Text = ""; lblResponsibleRankRoutine.Text = "";
            lblComponent.Text = ""; lblComponentRoutine.Text = "";
            lblCondition.Text = ""; lblVerifiy.Text = "";
            lblReason.Text = ""; lblResult.Text = "";
            lblCompletion.Text = ""; lblInChargeRank.Text = "";
            lblActualRunningHours.Text = "";

            lblMaintType.Text = ""; lblMaintType1.Text = "";
            lnkViewMaintCheckList.Visible = false;
            lnkViewAlarmAndTestingItems.Visible = false;
            lnkViewMaintDetails.Visible = false;
            chkMaintDoneAsPerInstructions.Visible = false; lblProcedure.Visible = false;
            txtVslComments.Text = ""; txtSuptComments.Text = "";
            
            lnkViewAttchment.Visible = false;
            fpSpreadConsumed.ActiveSheet.RowCount = 0;
            fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;
        }

        private void RefreshGrid()
        {
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                if (!isNormalReport(row))
                {
                    fpSpread1.ActiveSheet.Rows[row].ForeColor = Color.Blue;
                    fpSpread1.ActiveSheet.Rows[row].Font = new Font("Verdana", 8, FontStyle.Regular);
                }
                fpSpread1.ActiveSheet.Rows[row].Height = fpSpread1.ActiveSheet.Rows[row].GetPreferredHeight();
            }
        }

        private bool isNormalReport(int rowIndex)
        {
            string sx1;
            bool toNote = false;
            if (GetCellValue(rowIndex, COL_COMMENTS).Length > 0) toNote = true;

            sx1 = GetCellValue(rowIndex, COL_MICOND).ToUpper();
            if (sx1 == ("in Very Poor State").ToUpper() || sx1 == ("Heavily Carbonised").ToUpper()) toNote = true; //very poor or very heavily carbonised
            sx1 = GetCellValue(rowIndex, COL_MPLACE).ToUpper();
            if (sx1 == ("Stoppage At Sea").ToUpper() || sx1 == ("Delay In Port").ToUpper()) toNote = true;
            sx1 = GetCellValue(rowIndex, COL_MCOMPL).ToUpper();
            if (sx1 != ("Satisfactory Completion").ToUpper() && sx1 != ("Running Test Satisfactory").ToUpper()) toNote = true;
            sx1 = GetCellValue(rowIndex, COL_MREASON).ToUpper();
            if (sx1 != ("Schedule").ToUpper() && sx1 != ("CMS Survey").ToUpper()) toNote = true;
            return (!toNote);
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            BindSuptQGrid();            
        }

        private void btnExport_Click(object sender, EventArgs e)
        {

        }

        private void SetOtherProperities()
        {
            try
            {
                if (fpSpread1.ActiveSheet.DataSource == null) return;
                fpSpread1.SuspendLayout();

                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Add();
                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fpSpread1.ActiveSheet.ColumnCount);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].Text = PG.companyName;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 12, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 35;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].ForeColor = Color.Blue;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Add();
                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(1, 0, 1, 5);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].Text = "Supt Review List - " + PG.GetVslName(vesselID) + "                                    Date:" + PG.GetDbServerDate().ToString("dd-MMM-yyyy");
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 10, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Height = 23;

                fpSpread1.ActiveSheet.AddColumnHeaderSpanCell(1, 6, 1, 8);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].Text = tsLblTotalItems.Text;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].Font = new Font("Arial", 10, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 6].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[2].Height = 40;

                Application.DoEvents();
            }
            finally
            {
                fpSpread1.ResumeLayout();
            }
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnGo_Click(null, null);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            if (suptRvw != null) suptRvw.dtSuptAck.Clear();           
            btnGo_Click(null, null);
        }

        private void fpSpread1_Sheet1_CellChanged(object sender, FarPoint.Win.Spread.SheetViewEventArgs e)
        {
            if (!isGridInitialied) return;
            if (e.Row < 0) return;

            isGridInitialied = false;
            int rowIndex = e.Row;
            try
            {
                if (e.Column == COL_ACK || e.Column == COL_SUPTCOMMENTS)
                {
                    int mRepRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                    int isAck = 0;
                    if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_ACK].Value != null)
                        isAck = Convert.ToInt32(Convert.ToBoolean(fpSpread1.ActiveSheet.Cells[rowIndex, COL_ACK].Value));
                    if (isAck == 0) fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Value = "";
                    string suptComments = GetCellValue(rowIndex, COL_SUPTCOMMENTS);

                    int sRepRefNo = GetCellValue_Int(rowIndex, COL_SREPREFNO);
                    long eq_PmsList_ClassID = GetCellValue_long(rowIndex, COL_EQ_PMSLIST_CLASSID);
                    long eq_UnitsID = GetCellValue_long(rowIndex, COL_UNITNO);
                    long eq_MaintenanceID = GetCellValue_long(rowIndex, COL_MAINTNO);

                    if (suptRvw != null)
                    {
                        suptRvw.AddEditSuptToAckInTempDataTable(vesselID, mRepRefNo, isAck, suptComments, eq_PmsList_ClassID, sRepRefNo, eq_UnitsID, eq_MaintenanceID);
                        btnUpdate.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
                        btnSendBackToVSL.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.CS", "fpSpread1_Sheet1_CellChanged", err.Message);
            }
            finally
            {
                isGridInitialied = true;
            }
        }

        private void fpSpread1_ButtonClicked(object sender, FarPoint.Win.Spread.EditorNotifyEventArgs e)
        {
            btnUpdate.Enabled = true;
            btnSendBackToVSL.Enabled = true;
            fpSpread1_SelectionChanged(null, null);
        }

        private void fpSpread1_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            if (!isGridInitialied) return; //|| e.Range.Row < 0
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            if (chkShowHistory.Checked) FillupHistory();
        }

        private void fpSpread1_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread1.ContextMenuStrip = null;
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread1.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;

                fpSpread1.ActiveSheet.SetActiveCell(row, col);
                fpSpread1.ContextMenuStrip = contextMenuStrip1;
                int isAck = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_ACK].Value);
                tsmnuSuptComments.Enabled = (isAck == 1);

                if (chkShowHistory.Checked) FillupHistory();
            }
        }

        private void tsmnuSuptComments_Click(object sender, EventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            frmSuptComments objSuptCmmnts = new frmSuptComments();
            try
            {
                string suptComments = GetCellValue(rowIndex, COL_SUPTCOMMENTS);
                objSuptCmmnts.suptComments = suptComments;
                if (DialogResult.OK == objSuptCmmnts.ShowDialog())
                {
                    fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Value = objSuptCmmnts.suptComments;

                    int isAck = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_ACK].Value);
                    int mRepRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                    long eq_UnitsID = GetCellValue_long(rowIndex, COL_UNITNO);
                    long eq_MaintenanceID = GetCellValue_long(rowIndex, COL_MAINTNO); 
                  
                    int sRepRefNo = GetCellValue_Int(rowIndex, COL_SREPREFNO);
                    int eq_PmsList_ClassID = GetCellValue_Int(rowIndex, COL_EQ_PMSLIST_CLASSID);
                   
                    suptRvw.AddEditSuptToAckInTempDataTable(vesselID, mRepRefNo, isAck, objSuptCmmnts.suptComments, eq_PmsList_ClassID, sRepRefNo, eq_UnitsID, eq_MaintenanceID);
                    txtSuptComments.Text = objSuptCmmnts.suptComments;
                }
            }
            finally
            {
                objSuptCmmnts = null;
            }
        }

        private void tsMnuMaintHistory_Click(object sender, EventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            frmMaintHistory objMaintHist = new frmMaintHistory();
            try
            {
                objMaintHist.curVesselID = GetCellValue_Int(rowIndex, COL_VSLNO);                
                objMaintHist.curEQUnitID = GetCellValue_long(rowIndex, COL_UNITNO);
                objMaintHist.curEQMaintID = GetCellValue_long(rowIndex, COL_MAINTNO);
                objMaintHist.curPms_DocID = GetCellValue_long(rowIndex, COL_PMS_DOCID);
                objMaintHist.isRunningHrsEqp = isRunningHrsEqp;

                objMaintHist.ShowDialog();
            }
            finally
            {
                objMaintHist = null;
            }
        }

        private void tsMnuSendBackToVslForAmendments_Click(object sender, EventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            
            if (!Gfn.ConfBox("Are you sure you want to send back for amendments?")) return;

            frmSuptComments objSuptCmmnts = new frmSuptComments();
            try
            {
                string suptComments = GetCellValue(rowIndex, COL_SUPTCOMMENTS);
                objSuptCmmnts.suptComments = suptComments;
                objSuptCmmnts.isSuptCommentsCompulsory = true;
                if (DialogResult.OK == objSuptCmmnts.ShowDialog())
                {
                    int mRepRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                    long eq_UnitsID = GetCellValue_long(rowIndex, COL_UNITNO);
                    long eq_MaintenanceID = GetCellValue_long(rowIndex, COL_MAINTNO);

                    suptRvw.SendBackToVslForAmendments(vesselID, mRepRefNo, objSuptCmmnts.suptComments, eq_UnitsID, eq_MaintenanceID);

                    BindSuptQGrid();
                    fpSpread1_SelectionChanged(null, null);

                    isMaintAckDone = true;
                }
            }
            finally
            {
                objSuptCmmnts = null;
            }
        }

        private void chkShowHistory_CheckedChanged(object sender, EventArgs e)
        {
            splitContainer1.Panel2Collapsed = (!chkShowHistory.Checked);
        }

        #region History

        const int COL_ASSOC_FORMS_FORMNAME = 0,
                  COL_ASSOC_FORMS_STATUS = 1,
                  COL_ASSOC_FORMS_MODE = 2,
                  COL_ASSOC_FORMS_INSTANCENO = 3,
                  COL_ASSOC_FORMS_DEFAULTPARAMVALUE = 4,
                  COL_ASSOC_FORMS_FORMSLISTID = 5,
                  COL_ASSOC_FORMS_FORMSINSTANCEID = 6,
                  COL_ASSOC_FORMS_ISCOMPULSORY = 7,
                  COL_ASSOC_FORMS_REPORTDUEDATE = 8;

        private void FillupHistory()
        {
            pnlRoutine.Visible = false;
            pnlPMS.Visible = false;
            lnkViewMaintCheckList.Visible = false;
            lnkViewAlarmAndTestingItems.Visible = false;
            tableLayoutPanel3.Visible = true;

            fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;
            fpSpreadConsumed.ActiveSheet.RowCount = 0;
            txtSuptComments.Text = ""; txtVslComments.Text = "";

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            curVesselID = GetCellValue_Int(rowIndex, COL_VSLNO);
            curEQUnitID = GetCellValue_long(rowIndex, COL_UNITNO);
            curEQMaintID = GetCellValue_long(rowIndex, COL_MAINTNO);
            curPms_DocID = GetCellValue_long(rowIndex, COL_PMS_DOCID);
            string maintType = GetCellValue(rowIndex, COL_MAINTTYPE);
            long pmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
            long eq_PmsList_ClassID = GetCellValue_long(rowIndex, COL_EQ_PMSLIST_CLASSID);
            if (eq_PmsList_ClassID > 0) maintType = "PMS";
            long eq_EquipmentID = GetCellValue_long(rowIndex, COL_EQ_EQUIPMENTID);
            isRunningHrsEqp = PG.CheckIsRunningHrsEquipment(eq_EquipmentID);

            // Enable (or) Disable Maint Instructions
            lnkViewMaintDetails.Visible = PG.CheckMaintProcedureOrManualRefExist(curVesselID, curPms_DocID, curEQUnitID);
            lnkViewAttchment.Visible = HistContainsAttachment(pmsHistID);

            tableLayoutPanel3.Visible = false; // Spares Consumed
            txtVslComments.Height = 80;

            FillupMaintenanceDetails(maintType);

            txtVslComments.Text = GetCellValue(rowIndex, COL_COMMENTS);
            txtSuptComments.Text = GetCellValue(rowIndex, COL_SUPTCOMMENTS);
            //if (fpSpread1.ActiveSheet.RowCount == 0) tableLayoutPanel2.RowStyles[2].Height = 0;
            chkMaintDoneAsPerInstructions.Checked = (GetCellValue(rowIndex, COL_HASWORKDONEPROCDURE) == "1");

            bool isToShowMaintCheckbox = false;
            string maintInstructions = PG.GetHQAndVslMaintenanceInstructions(curPms_DocID, curVesselID, curEQUnitID);
            if (maintType.ToUpper() == PG.MAINTTYPE_PMS.ToUpper())
            {
                #region PMS
                BindAndLoadPmsConsumedGrid();

                tableLayoutPanel3.ColumnStyles[1].Width = 41.56171f;
                if (IsAssociatedFormsExists(pmsHistID))
                {
                    int col_ItemDetail_Width = 350, col_MakerCode_Width = 100, col_ConsQty_Width = 50;
                    fpSpreadConsumed.ActiveSheet.Columns[0].Width = col_ItemDetail_Width;
                    fpSpreadConsumed.ActiveSheet.Columns[1].Width = col_MakerCode_Width;
                    fpSpreadConsumed.ActiveSheet.Columns[2].Width = col_ConsQty_Width;

                    BindMaintAssociatedForms();
                }
                else
                {
                    int col_ItemDetail_Width = 500, col_MakerCode_Width = 200, col_ConsQty_Width = 100;
                    fpSpreadConsumed.ActiveSheet.Columns[0].Width = col_ItemDetail_Width;
                    fpSpreadConsumed.ActiveSheet.Columns[1].Width = col_MakerCode_Width;
                    fpSpreadConsumed.ActiveSheet.Columns[2].Width = col_ConsQty_Width;
                    tableLayoutPanel3.ColumnStyles[1].Width = 0;
                }

                bool isCheckListExists = false;                
                
                string script = " Select COUNT(*) from EQ_PmsHist_MaintCheckListDetails " +
                                " where VesselID=" + curVesselID + " and EQ_PmsHistID ='" + pmsHistID + "'";
                if (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0)
                {
                    lnkViewMaintCheckList.Visible = true;
                    lnkViewAlarmAndTestingItems.Visible = false;
                    isCheckListExists = true;
                }

                #endregion

                lnkViewMaintDetails.Text = "View Maintenance procedures";
                lblProcedure.Text = "Maintenance done as per Maintenance procedures";
                chkMaintDoneAsPerInstructions.Text = "Maintenance done as per Maintenance procedures";

                pnlPMS.Visible = true;
                //tableLayoutPanel2.RowStyles[0].SizeType = SizeType.Absolute;
                //tableLayoutPanel2.RowStyles[1].SizeType = SizeType.Percent;
                //tableLayoutPanel2.RowStyles[1].Height = 100;
                //tableLayoutPanel2.RowStyles[3].Height = 90;
                txtVslComments.Height = 61;
                txtSuptComments.Height = 38;

                tableLayoutPanel3.Visible = true; // Spares Consumed

                isToShowMaintCheckbox = ((!isCheckListExists) && maintInstructions.Trim().Length > 0);

                lblCompletion.BackColor = Color.AliceBlue;
                lblCompletion.ForeColor = SystemColors.ControlText;
                lblCompletion.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Regular);
                if ((lblCompletion.Text.ToUpper() == PG.MCOMPL_STOPGAP_MEASUREONLY) || (lblCompletion.Text.ToUpper() == PG.MCOMPL_TOREDO_AT_DRYDOCKING) || (lblCompletion.Text.ToUpper() == PG.MCOMPL_TOREDO_WHEN_SPARESRECVD))
                {
                    lblCompletion.BackColor = Color.Red;
                    lblCompletion.ForeColor = Color.White;
                    lblCompletion.Font = new Font("Microsoft Sans Serif", 9, FontStyle.Bold);
                }

                lblReason.ForeColor = Color.Black;
                if ((lblReason.Text.ToUpper() == PG.MREASON_BREAKDOWN) || (lblReason.Text.ToUpper() == PG.MREASON_LEAKAGES) || (lblReason.Text.ToUpper() == PG.MREASON_POOR_EFFICIENCY))
                {
                    lblReason.ForeColor = Color.Red;
                }
                lblCondition.ForeColor = Color.Black;
                if ((lblCondition.Text.ToUpper() == PG.MCOND_IN_VERY_POORSTATE) || (lblCondition.Text.ToUpper() == PG.MCOND_HEAVILY_CARBONISED))
                {
                    lblCondition.ForeColor = Color.Red;
                }

            }
            else if (maintType.ToUpper() == PG.MAINTTYPE_ALARMS_ROUTINE)
            {
                lnkViewMaintDetails.Text = "View Alarms and Routines procedures";
                lblProcedure.Text = "Alarms and Routines done as per Routine procedures";
                chkMaintDoneAsPerInstructions.Text = "Alarms and Routines done as per Routine procedures";

                pnlRoutine.Visible = true;
                lnkViewAttchmentRoutine.Visible = HistContainsAttachment(pmsHistID);

                //tableLayoutPanel2.RowStyles[3].SizeType = SizeType.Percent;
                //tableLayoutPanel2.RowStyles[1].SizeType = SizeType.Absolute;
                //tableLayoutPanel2.RowStyles[1].Height = 0;
                //tableLayoutPanel2.RowStyles[3].Height = 90;
                //tableLayoutPanel2.RowStyles[4].Height = 120;
                txtVslComments.Height = 100;
                txtSuptComments.Height = 100;

                lnkViewMaintCheckList.Visible = false;
                lnkViewAlarmAndTestingItems.Visible = true;

                isToShowMaintCheckbox = false;
            }
            else if (maintType.ToUpper() == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE)
            {
                lnkViewMaintDetails.Text = "View CM Routine procedures";
                lblProcedure.Text = "CM Routine  done as per CM Routine  procedures";
                chkMaintDoneAsPerInstructions.Text = "CM Routine  done as per CM Routine  procedures";

                isToShowMaintCheckbox = (maintInstructions.Trim().Length > 0);
            }

            lnkViewMaintDetails.Text = lnkViewMaintDetails.Text + " / Manual Ref";

            chkMaintDoneAsPerInstructions.Visible = isToShowMaintCheckbox;
            lblProcedure.Visible = isToShowMaintCheckbox;
        }

        private bool HistContainsAttachment(long pmsHistID)
        {
            bool result = false;
            try
            {
                int cnt = PG.GetPmsHistAttachment(vesselID, pmsHistID);
                result = (cnt > 0);
            }
            catch (Exception err)
            {
                result = false;
                PG.DisplayException("Check hist contains attachment", err.Message);
                PG.AddToGenErrorLog("frmSuptReview.cs", "HistContainsAttachment", err.Message);
            }
            return result;
        }

        private void FillupMaintenanceDetails(string maintType)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int row = fpSpread1.ActiveSheet.ActiveCell.Row.Index;
            
            if (maintType == PG.MAINTTYPE_PMS)
            {
                lblManHrs.Text = GetCellValue(row, COL_MMHRS);
                lblReason.Text = GetCellValue(row, COL_MREASON);
                lblCondition.Text = GetCellValue(row, COL_MICOND);
                lblCompletion.Text = GetCellValue(row, COL_MCOMPL);
                lblPlace.Text = GetCellValue(row, COL_MPLACE);
                lblPMMRefNo.Text = GetCellValue(row, COL_PMM_DOCREFNO);
                lblMaintCode.Text = GetCellValue(row, COL_MAINTCODE);
                lblInChargeRank.Text = GetCellValue(row, COL_INCHARGERANK);
                lblResponsibleRank.Text = GetCellValue(row, COL_RESPONSIBLERANK);
                lblComponent.Text = GetCellValue(row, COL_COMPONENT);
                lblDept.Text = GetCellValue(row, COL_DEPT);
                lblInterval.Text = GetCellValue(row, COL_INTERVAL);
                lblMaintType1.Text = GetCellValue(row, COL_MTYPE);
               
                lblActualRunningHours.Visible = false; lblActualRunningHours_Display.Visible = false;
                if (isRunningHrsEqp)
                {
                    lblActualRunningHours.Visible = true; lblActualRunningHours_Display.Visible = true;
                    lblActualRunningHours.Text = GetCellValue(row, COL_ACTUALRUNNINGHRSATMAINT);
                }               
            }
            else
            {
                lblVerifiy.Text = GetCellValue(row, COL_CE_MAS_Verify);
                lblResult.Text = GetCellValue(row, COL_MCOMPL);
                lblLocation.Text = GetCellValue(row, COL_MPLACE);
                lblPMMRefNoRoutine.Text = GetCellValue(row, COL_PMM_DOCREFNO);
                lblMaintCodeRoutine.Text = GetCellValue(row, COL_MAINTCODE);
                lblInChargeRankRoutine.Text = GetCellValue(row, COL_INCHARGERANK);
                lblResponsibleRankRoutine.Text = GetCellValue(row, COL_RESPONSIBLERANK);
                lblComponentRoutine.Text = GetCellValue(row, COL_COMPONENT);
                lblDeptRoutine.Text = GetCellValue(row, COL_DEPT);
                lblIntervalRoutine.Text = GetCellValue(row, COL_INTERVAL);
                lblMaintType.Text = GetCellValue(row, COL_MTYPE);
            }
        }


        private void lnkViewMaintDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmViewMaintDescription viewMaintDesc = new frmViewMaintDescription();
            try
            {
                if (fpSpread1.ActiveSheet.ActiveCell == null) return;
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

                viewMaintDesc.curVesselID = vesselID;
                viewMaintDesc.curEQUnitID = curEQUnitID;
                viewMaintDesc.curEQMaintID = curEQMaintID;
                viewMaintDesc.maintType = GetCellValue(rowIndex, COL_MAINTTYPE);
                viewMaintDesc.curPms_DocID = GetCellValue_long(rowIndex, COL_PMS_DOCID);
                viewMaintDesc.parentMouseXPosn = this.Location.X;
                viewMaintDesc.ShowDialog();
            }
            finally
            {
                viewMaintDesc = null;
            }
        }

        private void lnkViewAlarmAndTestingItems_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMaintInput_AlarmsRoutines pmsInput = new frmMaintInput_AlarmsRoutines();
            try
            {
                if (fpSpread1.ActiveSheet.ActiveCell == null) return;
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

                //pmsInput.eqEquipmentId = GetCellValue(rowIndex, COL_EQPNO);
                pmsInput.calledMode = "VIEW";
                pmsInput.vesselID = vesselID;
                pmsInput.eqUnitId = curEQUnitID;
                pmsInput.eqMaintenanceID = curEQMaintID;
                pmsInput.refNumber = Convert.ToInt32(GetCellValue(rowIndex, COL_MREPREFNO));
                pmsInput.maintType = PG.MAINTTYPE_ALARMS_ROUTINE;
                pmsInput.pms_DocID = curPms_DocID;
                pmsInput.eq_PmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
                pmsInput.ShowDialog();
            }
            finally
            {
                pmsInput.Dispose();
            }
        }


        public void DesignPmsConsumedGrid()
        {
            List<DgvInits> pmsConsumed = new List<DgvInits>();
            try
            {
                pmsConsumed.Add(new DgvInits("ItemDetail", "Part Name", 500, Color.Black, SystemColors.ButtonFace, true, true));
                pmsConsumed.Add(new DgvInits("MakerCode", "Maker Code", 200, Color.Black, SystemColors.ButtonFace, true, true));
                pmsConsumed.Add(new DgvInits("ConsQty", "Qty Used", 100, Color.Black, SystemColors.ButtonFace, true, true));
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadConsumed, pmsConsumed, null, false, true);

                fpSpreadConsumed.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                fpSpreadConsumed.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
            }
            finally
            {
                pmsConsumed = null;
            }
        }

        public void BindAndLoadPmsConsumedGrid()
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            DataTable dtPmsConsumed = null;
            try
            {
                int row = fpSpread1.ActiveSheet.ActiveCell.Row.Index;
                int thismrepRefNo = GetCellValue_Int(row, COL_MREPREFNO);
                int thissRepRefNo = GetCellValue_Int(row, COL_SREPREFNO);

                long thisEq_PmsList_ClassID = GetCellValue_Int(row, COL_EQ_PMSLIST_CLASSID);
                fpSpreadConsumed.ActiveSheet.RowCount = 0;

                string sql = " SELECT M.MakerCode,M.Itemdetail, isnull(C.ConsQty,0) as ConsQty " +
                            " FROM EQ_SPConsumed C , Proc_ItemMaster M  " +
                            " where  C.Proc_ItemMasterID=M.Proc_ItemMasterID " +
                            "    and C.VesselID =" + curVesselID +
                            "    and C.EQ_MaintenanceID=" + curEQMaintID +
                            "    and C.EQ_UnitsID=" + curEQUnitID;

                if (thisEq_PmsList_ClassID > 0) sql = sql + "    and C.SrepRefNo = " + thissRepRefNo;
                else sql = sql + "    and C.MrepRefNo = " + thismrepRefNo;

                sql = sql + " Order By C.EQ_SPConsumedID";
                dtPmsConsumed = PG.Gb.DBFn.DbRecords(sql);

                fpSpreadConsumed.ActiveSheet.DataSource = dtPmsConsumed;

                if (dtPmsConsumed != null && dtPmsConsumed.Rows.Count > 0) fpSpreadConsumed_ColumnWidthChanged(null, null);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to get PMS Maintenance Spares Consumed List");
                PG.AddToGenErrorLog("frmSuptReview.cs", "BindAndLoadPmsConsumedGrid", err.Message);
            }
            finally
            {
                dtPmsConsumed = null;
            }
        }

        private void DesignMaintAssociatedForms()
        {
            List<DgvInits> assocForms = new List<DgvInits>();
            try
            {
                assocForms.Add(new DgvInits("FormName", "Form Name", 250, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Status", "Status", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Mode", "#", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("InstanceNo", "InstanceNo", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("DefaultParamValue", "DefaultParamValue", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsListID", "FormsListID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsInstancesID", "FormsInstancesID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("IsCompulsory", "Compulsory", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("ReportDueDate", "ReportDueDate", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("CompulsoryDisp", "Compulsory", 85, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));                
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadAssociatedForms, assocForms, null, false, true);
                
                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadAssociatedForms, false, "#", COL_ASSOC_FORMS_MODE, "View", 34, SystemColors.ButtonFace);

                fpSpreadAssociatedForms.ActiveSheet.ColumnHeader.Rows[0].Height = 20;
                fpSpreadAssociatedForms.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpreadAssociatedForms.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;

                foreach (FarPoint.Win.Spread.Row row in fpSpreadAssociatedForms.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            finally
            {
                assocForms = null;
            }
        }


        public bool IsAssociatedFormsExists(long eq_PmsHistID)
        {
            bool result = false;
            try
            {
                string sql = "";
                sql = " SELECT count(*) " + Environment.NewLine +
                      " FROM FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                      " where  F.FormsListID=I.FormsListID " + Environment.NewLine +
                      "    and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                      "    and H.VesselID =" + curVesselID + Environment.NewLine +
                      "    and H.EQ_PmsHistID = " + eq_PmsHistID + Environment.NewLine +
                      "    and H.PMS_DocID = " + curPms_DocID;
                result = (Convert.ToInt32(PG.Gb.DBFn.Aqr(sql)) > 0);
            }
            catch (Exception err)
            {
                result = false;
                Gfn.Eb("Failed to check is Associated Forms Exists");
                PG.AddToGenErrorLog("frmSuptReview.cs", "IsAssociatedFormsExists", err.Message);
            }
            return result;
        }

        private void BindMaintAssociatedForms()
        {
            List<DgvInits> assocForms = new List<DgvInits>();
            DataTable dtAssociatedForms = null;
            try
            {
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
                if (rowIndex < 0) return;
                long pmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);

                fpSpreadAssociatedForms.ActiveSheet.RowCount = 0;

                //Associated Forms               
                string script =   " Select F.FormsListID, H.FormsInstancesID, F.FormName, I.Status, I.InstanceNo, F.DefaultParamValue, I.ReportDueDate  " + Environment.NewLine +
                                  " , CASE WHEN I.Status='COMPLETED' THEN 'VIEW' ELSE 'EDIT' END AS Mode " + Environment.NewLine +
                                  " , isnull((select IsCompulsory from EQ_MaintAssociatedForms A where  A.FormsListID=F.FormsListID and A.PMS_DocID=H.PMS_DocID and A.FormsListID=I.FormsListID),1) as IsCompulsory " + Environment.NewLine +
                                  ", '' CompulsoryDisp " +
                                  " , Source, SourceKeyID" + Environment.NewLine +
                                  " from FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                                  " where F.FormsListID=I.FormsListID " + Environment.NewLine +
                                  "   and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                                  "   and H.VesselID =" + curVesselID + Environment.NewLine +
                                  "   and H.EQ_PmsHistID = '" + pmsHistID + "'" + Environment.NewLine +
                                  "   and H.PMS_DocID = " + curPms_DocID;
                dtAssociatedForms = PG.Gb.DBFn.DbRecords(script);
                if (dtAssociatedForms != null && dtAssociatedForms.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtAssociatedForms.Rows)
                    {
                        dr["CompulsoryDisp"] = "No";
                        if (dr["IsCompulsory"].ToString() == "1") dr["CompulsoryDisp"] = "Yes";
                    }
                }

                fpSpreadAssociatedForms.ActiveSheet.DataSource = dtAssociatedForms;

                foreach (FarPoint.Win.Spread.Row row in fpSpreadAssociatedForms.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to Initialise Associated FormsList");
                PG.AddToGenErrorLog("frmSuptReview.cs", "BindMaintAssociatedForms", err.Message);
            }
            finally
            {
                dtAssociatedForms = null;
                assocForms = null;
            }
        }

        private void lnkViewAttchment_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (fpSpread1.ActiveSheet.ActiveCell == null) return;
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

            long pmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
            //PG.ViewHistAttachment(curVesselID, pmsHistID);

            string eqpName = GetCellValue(rowIndex, COL_EQPNAME);
            frmPmsHistViewAttachments objAttach = new frmPmsHistViewAttachments();
            try
            {
                objAttach.vesselID = GetCellValue_Int(rowIndex, COL_VSLNO);
                objAttach.eqpName = eqpName;
                objAttach.eq_PmsHistID = pmsHistID;
                objAttach.ShowDialog();
            }
            finally
            {
                objAttach = null;
            }
        }

        private void lnkViewAttchmentRoutine_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lnkViewAttchment_LinkClicked(null, null);
        }
        
        #endregion

        private void btnUnMarkAll_Click(object sender, EventArgs e)
        {
            string suptComments = "";

            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                int isAck = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_ACK].Value);
                if (isAck == 1)
                {
                    isAck = 0; suptComments = "";
                    fpSpread1.ActiveSheet.Cells[row, COL_ACK].Value = isAck;
                    int mRepRefNo = GetCellValue_Int(row, COL_MREPREFNO);
                    long eq_UnitsID = GetCellValue_long(row, COL_UNITNO);
                    long eq_MaintenanceID = GetCellValue_long(row, COL_MAINTNO); 
                 
                    int sRepRefNo = GetCellValue_Int(row, COL_SREPREFNO);
                    int eq_PmsList_ClassID = GetCellValue_Int(row, COL_EQ_PMSLIST_CLASSID);

                    fpSpread1.ActiveSheet.Cells[row, COL_SUPTCOMMENTS].Value = "";
                    suptComments = GetCellValue(row, COL_SUPTCOMMENTS);

                    suptRvw.AddEditSuptToAckInTempDataTable(vesselID, mRepRefNo, isAck, suptComments, eq_PmsList_ClassID, sRepRefNo, eq_UnitsID, eq_MaintenanceID);
                }
            }
            if (suptRvw != null) btnUpdate.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
            if (suptRvw != null) btnSendBackToVSL.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
        }

        private void btnMarkAllNormalReports_Click(object sender, EventArgs e)
        {
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                if (isNormalReport(row))
                {
                    fpSpread1.ActiveSheet.Cells[row, COL_ACK].Value = 1;

                    int isAck = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_ACK].Value);
                    int mRepRefNo = GetCellValue_Int(row, COL_MREPREFNO);
                    long eq_UnitsID = GetCellValue_long(row, COL_UNITNO);
                    long eq_MaintenanceID = GetCellValue_long(row, COL_MAINTNO);
                    string suptComments = GetCellValue(row, COL_SUPTCOMMENTS);
                    int sRepRefNo = GetCellValue_Int(row, COL_SREPREFNO);
                    int eq_PmsList_ClassID = GetCellValue_Int(row, COL_EQ_PMSLIST_CLASSID);
                    suptRvw.AddEditSuptToAckInTempDataTable(vesselID, mRepRefNo, isAck, suptComments, eq_PmsList_ClassID, sRepRefNo, eq_UnitsID, eq_MaintenanceID);
                }
            }
            if (suptRvw != null) btnUpdate.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
            if (suptRvw != null) btnSendBackToVSL.Enabled = (suptRvw.dtSuptAck.Rows.Count > 0);
        }


        private void btnEnterSuptComments_Click(object sender, EventArgs e)
        {
            if (!Gfn.ConfBox("Are you sure you want to enter supt comments for the selected item(s)?")) return;

            frmSuptComments objSuptCmmnts = new frmSuptComments();
            try
            {
                string suptComments = "";
                objSuptCmmnts.suptComments = suptComments;
                if (DialogResult.OK == objSuptCmmnts.ShowDialog())
                {
                    for (int rowIndex = 0; rowIndex < fpSpread1.ActiveSheet.RowCount; rowIndex++)
                    {
                        int isAck = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_ACK].Value);

                        if (isAck == 1)
                        {
                            fpSpread1.ActiveSheet.Cells[rowIndex, COL_SUPTCOMMENTS].Value = objSuptCmmnts.suptComments;

                            int mRepRefNo = GetCellValue_Int(rowIndex, COL_MREPREFNO);
                            long eq_UnitsID = GetCellValue_long(rowIndex, COL_UNITNO);
                            long eq_MaintenanceID = GetCellValue_long(rowIndex, COL_MAINTNO);

                            int sRepRefNo = GetCellValue_Int(rowIndex, COL_SREPREFNO);
                            int eq_PmsList_ClassID = GetCellValue_Int(rowIndex, COL_EQ_PMSLIST_CLASSID);

                            suptRvw.AddEditSuptToAckInTempDataTable(vesselID, mRepRefNo, isAck, objSuptCmmnts.suptComments, eq_PmsList_ClassID, sRepRefNo, eq_UnitsID, eq_MaintenanceID);
                            txtSuptComments.Text = objSuptCmmnts.suptComments;
                        }
                    }
                }
            }
            finally
            {
                objSuptCmmnts = null;
            }
        }

        private void btnSendBackToVSL_Click(object sender, EventArgs e)
        {
            int col = fpSpread1.ActiveSheet.ActiveColumnIndex;

            if (col == COL_ACK || col == COL_SUPTCOMMENTS)
            {
                fpSpread1_Sheet1.CellChanged += new FarPoint.Win.Spread.SheetViewEventHandler(this.fpSpread1_Sheet1_CellChanged);
            }

            if (suptRvw != null && suptRvw.dtSuptAck.Rows.Count == 0)
            {
                Gfn.nMbwithAlignAndCentrePosn("Atleast select one maintenance for Acknowledge", ContentAlignment.MiddleCenter);
                return;
            }

            if (!Gfn.ConfBox("Are you sure you want to send back for amendments?")) return;

            panelLoading.Visible = true;
            Application.DoEvents();

            string suptComments = "";

            #region Supt comments
            frmSuptComments objSuptCmmnts = new frmSuptComments();
            try
            {
                objSuptCmmnts.isSuptCommentsCompulsory = true;
                if (DialogResult.OK != objSuptCmmnts.ShowDialog())
                {
                    return;
                }
                suptComments = objSuptCmmnts.suptComments;
            }
            finally
            {
                objSuptCmmnts = null;
            }

            #endregion

            SendBackToVslForAmendments(suptComments);

            isMaintAckDone = true;

            BindSuptQGrid();
            fpSpread1_SelectionChanged(null, null);
            canCloseForm = true;
            panelLoading.Visible = false;

            if (fpSpread1.ActiveSheet.RowCount == 0)
            {
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }
        
        public void SendBackToVslForAmendments(string suptComments)
        {
            progressBar1.Visible = true;
            if (progressBar1.Value > 0) progressBar1.Value = 1;
            progressBar1.Step = 1;
            try
            {
                if (suptRvw == null) return;

                progressBar1.Minimum = 0;
                progressBar1.Maximum = suptRvw.dtSuptAck.Rows.Count;

                foreach (DataRow dr in suptRvw.dtSuptAck.Rows)
                {
                    suptComments = dr["SuptComments"].ToString().Trim();

                    int xVesselID = Convert.ToInt32(dr["VesselId"].ToString());
                    long xEQ_UnitsID = Convert.ToInt64(dr["EQ_UnitsID"].ToString());
                    long xEQ_MaintenanceID = Convert.ToInt64(dr["EQ_MaintenanceID"].ToString());
                    int xmRepRefNo = Convert.ToInt32(dr["mRepRefNo"].ToString());

                    suptRvw.SendBackToVslForAmendments(xVesselID, xmRepRefNo, suptComments, xEQ_UnitsID, xEQ_MaintenanceID);

                    progressBar1.PerformStep();
                }

                isMaintAckDone = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.cs", "SendBackToVslForAmendments", err.Message);
            }
            finally
            {
                progressBar1.Visible = false;
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {  
            int col = fpSpread1.ActiveSheet.ActiveColumnIndex;
          
            if (col == COL_ACK || col == COL_SUPTCOMMENTS)
            {
                fpSpread1_Sheet1.CellChanged += new FarPoint.Win.Spread.SheetViewEventHandler(this.fpSpread1_Sheet1_CellChanged);
            }

            if (suptRvw !=null && suptRvw.dtSuptAck.Rows.Count == 0)
            {
                Gfn.nMbwithAlignAndCentrePosn("Atleast select one maintenance for Acknowledge", ContentAlignment.MiddleCenter);
                return;
            }

            panelLoading.Visible = true;
            Application.DoEvents();
            
            UpdateSuptToAck();

            BindSuptQGrid();
            fpSpread1_SelectionChanged(null, null);
            canCloseForm = true;
            panelLoading.Visible = false;

            if (suptRvw.dtSuptAck.Rows.Count > 0)
            {
                Gfn.nMbwithAlignAndCentrePosn("Done", ContentAlignment.MiddleCenter, 110, 150);
                suptRvw.dtSuptAck.Rows.Clear();                
            }
            
            if (fpSpread1.ActiveSheet.RowCount == 0)
            {
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        public void UpdateSuptToAck()
        {
            string script = "", suptComments = "";
            int suptAck = 0;
            int vslToViewSuptComments = 0;
            progressBar1.Visible = true;
            if (progressBar1.Value > 0) progressBar1.Value = 1;
            progressBar1.Step = 1;
            try
            {
                if (suptRvw == null) return;

                progressBar1.Minimum = 0;
                progressBar1.Maximum = suptRvw.dtSuptAck.Rows.Count;

                foreach (DataRow dr in suptRvw.dtSuptAck.Rows)
                {
                    suptAck = Convert.ToInt32(dr["SuptToAck"].ToString());
                    suptComments = dr["SuptComments"].ToString().Trim();
                    vslToViewSuptComments = 0;
                    if (suptComments.Length > 0)
                    {
                        vslToViewSuptComments = 1;
                    }

                    string xVesselID = dr["VesselId"].ToString();
                    string xEQ_UnitsID = dr["EQ_UnitsID"].ToString();
                    string xEQ_MaintenanceID = dr["EQ_MaintenanceID"].ToString();
                    string xmRepRefNo = dr["mRepRefNo"].ToString();

                    script = " update EQ_PMSList_PlannedItems set IsJobDone= 1, UpdatedBy='App' " +
                             " from EQ_PMSList_PlannedItems P, EQ_PmsHist H " +
                             " where P.VesselId =H.VesselId  and P.EQ_UnitsID =H.EQ_UnitsID and P.EQ_MaintenanceID=H.EQ_MaintenanceID " +
                             "    and Year(NmDate) = P.Yr and Month(NmDate) = P.Mon " +
                             "    and P.VesselId =" + xVesselID + " and P.EQ_UnitsID =" + xEQ_UnitsID +
                             "    and P.EQ_MaintenanceID=" + xEQ_MaintenanceID +
                             "    and H.mRepRefNo = " + xmRepRefNo + " and P.IsJobDone= 0 ";
                    PG.Gb.DBFn.Xqry(script);

                    script = " update EQ_PMSHist set SuptToAck=" + suptAck +
                             "    , VslToViewSuptComments = " + vslToViewSuptComments +
                             "    , SuptComments = " + Gfn.Qss(suptComments) +
                             " where VesselId =" + xVesselID + " and mRepRefNo = " + xmRepRefNo + " ; ";
                    PG.Gb.DBFn.Xqry(script);

                    progressBar1.PerformStep();
                }

                isMaintAckDone = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.cs", "UpdateSuptToAck", err.Message);
            }
            finally
            {
                progressBar1.Visible = false;
            }
        }


        private string GetCellValue(int row, int col)
        {
            string result = "";
            if (fpSpread1.ActiveSheet.Cells[row, col].Value != null && fpSpread1.ActiveSheet.Cells[row, col].Value.ToString().Length > 0)
            {
                result = fpSpread1.ActiveSheet.Cells[row, col].Value.ToString().Trim().Replace("\n", "\r\n");
            }
            return (result);
        }

        private int GetCellValue_Int(int row, int col)
        {
            int result = 0;
            try
            {
                string sx1 = GetCellValue(row, col);
                if (sx1.Length > 0) result = Convert.ToInt32(sx1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.CS", "GetCellValue_Int", err.Message);
            }
            return (result);
        }

        private long GetCellValue_long(int row, int col)
        {
            long result = 0;
            try
            {
                string sx1 = GetCellValue(row, col);
                if (sx1.Length > 0) result = Convert.ToInt64(sx1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmSuptReview.CS", "GetCellValue_Int", err.Message);
            }
            return (result);
        }


        private void fpSpreadAssociatedForms_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            int rowIndex = e.Row;

            if (e.Column == COL_ASSOC_FORMS_MODE)
            {
                CallAssociatedFormsPage(rowIndex);
            }
        }

        private void CallAssociatedFormsPage(int rowIndex)
        {
            int xvesselID = -1, xInstanceNo = -1; long xFormInstanceID = 0, xFormListID = 0;
            string xCallMode = "", xParamValueList = "", xReportDueDate = "";
            try
            {
                if (rowIndex < 0)
                {
                    return;
                }

                xvesselID = curVesselID;
                xInstanceNo = Convert.ToInt32(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_INSTANCENO].Value.ToString());
                xFormInstanceID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSINSTANCEID].Value.ToString());
                xFormListID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSLISTID].Value.ToString());
                xCallMode = "View";
                xParamValueList = fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_DEFAULTPARAMVALUE].Value.ToString();
                xReportDueDate = Convert.ToDateTime(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_REPORTDUEDATE].Value.ToString()).ToString("dd-MMM-yyyy");

                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                //string param = PG.companaycode + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurUserID + "|HQ|" + xvesselID + "|YES|NO|HqAsVslMode";

                string param = GetParam(vesselID, false);
                //Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);

                VslForms.PG.FillupThisForm(xCallMode, xvesselID, xFormListID, xFormInstanceID, xInstanceNo, xParamValueList, false, PG.Gb, xReportDueDate, "PMS", -1);
            }
            catch (Exception er)
            {
                Gfn.nWb("Failed to edit pending form instance." + Environment.NewLine + "Please contact Administrator");
                PG.AddToGenErrorLog("frmSuptReview.cs", "tsmnuEditPendingForm_Click", er.Message);
            }
        }

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = PG.hqAppFolder + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = PG.hqAppFolder + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode SUPTREVIEW|" + PG.Gb.User.CurrentUserRole + "|YES";
            }
            return param;

        }

        private void fpSpreadAssociatedForms_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }


        private void lnkViewMaintCheckList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmMaintInput_CheckList pmsInput = new frmMaintInput_CheckList();
            try
            {
                if (fpSpread1.ActiveSheet.ActiveCell == null) return;
                int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;

                pmsInput.eq_PmsHistID = GetCellValue_long(rowIndex, COL_PMSHISTID);
                pmsInput.calledMode = "VIEW"; 
                pmsInput.vesselID = vesselID;
                pmsInput.eqUnitId = curEQUnitID;
                pmsInput.eqMaintenanceID = curEQMaintID;
                pmsInput.refNumber = Convert.ToInt32(GetCellValue(rowIndex, COL_MREPREFNO));
                pmsInput.maintType = PG.MAINTTYPE_PMS;
                pmsInput.pms_DocID = curPms_DocID;
                pmsInput.ShowDialog();
            }
            finally
            {
                pmsInput.Dispose();
            }
        }

        private void fpSpreadConsumed_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpreadConsumed.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void fpSpreadConsumed_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpreadConsumed.ActiveSheet.AutoSortColumn(e.Column);
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            if (suptRvw.dtSuptAck != null && suptRvw.dtSuptAck.Rows.Count > 0)
            {
                if (!Gfn.ConfBox("Are you sure cancel the changes and exit?")) return;
            }
            canCloseForm = true;
            this.Close();
        }

        private void frmSuptReview_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!canCloseForm)
            {
                if (suptRvw.dtSuptAck != null && suptRvw.dtSuptAck.Rows.Count > 0)
                {
                    if (!Gfn.ConfBox("Are you sure cancel the changes and exit?"))
                    {
                        e.Cancel = true;
                        return;
                    }
                }
            }
            suptRvw = null;
        }
          
    }
}