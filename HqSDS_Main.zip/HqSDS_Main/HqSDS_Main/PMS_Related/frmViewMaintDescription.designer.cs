﻿namespace HqSDS_Main
{
    partial class frmViewMaintDescription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("ColumnHeaderEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("ColumnFooterEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle3 = new FarPoint.Win.Spread.NamedStyle("RowHeaderEnhanced");
            FarPoint.Win.Spread.NamedStyle namedStyle4 = new FarPoint.Win.Spread.NamedStyle("CornerEnhanced");
            FarPoint.Win.Spread.CellType.EnhancedCornerRenderer enhancedCornerRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedCornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle5 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewMaintDescription));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.fpSpread_Manual = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_Manual_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMaintDetails = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtMaintenance = new System.Windows.Forms.TextBox();
            this.lblMaint = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMaintDetails = new System.Windows.Forms.Label();
            this.lblEqpName = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsMnuViewManualFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Manual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Manual_Sheet1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.fpSpread_Manual, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 268F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(634, 562);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // fpSpread_Manual
            // 
            this.fpSpread_Manual.AccessibleDescription = "fpSpread_Manual, Sheet1, Row 0, Column 0, ";
            this.fpSpread_Manual.ContextMenuStrip = this.contextMenuStrip1;
            this.fpSpread_Manual.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_Manual.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_Manual.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Manual.HorizontalScrollBar.Name = "";
            this.fpSpread_Manual.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread_Manual.HorizontalScrollBar.TabIndex = 6;
            this.fpSpread_Manual.Location = new System.Drawing.Point(1, 390);
            this.fpSpread_Manual.Margin = new System.Windows.Forms.Padding(0);
            this.fpSpread_Manual.Name = "fpSpread_Manual";
            namedStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(220)))), ((int)(((byte)(233)))));
            namedStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(220)))), ((int)(((byte)(233)))));
            namedStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(236)))), ((int)(((byte)(247)))));
            namedStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle3.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(196)))), ((int)(((byte)(233)))));
            namedStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle4.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle4.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle4.Renderer = enhancedCornerRenderer1;
            namedStyle4.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle5.BackColor = System.Drawing.SystemColors.Window;
            namedStyle5.CellType = generalCellType1;
            namedStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle5.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle5.Renderer = generalCellType1;
            this.fpSpread_Manual.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2,
            namedStyle3,
            namedStyle4,
            namedStyle5});
            this.fpSpread_Manual.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_Manual_Sheet1});
            this.fpSpread_Manual.Size = new System.Drawing.Size(632, 171);
            this.fpSpread_Manual.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_Manual.TabIndex = 7;
            this.fpSpread_Manual.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_Manual.VerticalScrollBar.Name = "";
            this.fpSpread_Manual.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread_Manual.VerticalScrollBar.TabIndex = 7;
            this.fpSpread_Manual.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread_Manual.HyperLinkClicked += new FarPoint.Win.Spread.HyperLinkClickedEventHandler(this.fpSpread_Manual_HyperLinkClicked);
            this.fpSpread_Manual.Error += new FarPoint.Win.Spread.ErrorEventHandler(this.fpSpread_Manual_Error);
            this.fpSpread_Manual.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread_Manual_MouseDown);
            // 
            // fpSpread_Manual_Sheet1
            // 
            this.fpSpread_Manual_Sheet1.Reset();
            this.fpSpread_Manual_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_Manual_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_Manual_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Manual_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Manual_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Manual_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Manual_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Manual_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_Manual_Sheet1.ColumnHeader.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
            this.fpSpread_Manual_Sheet1.ColumnHeader.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
            this.fpSpread_Manual_Sheet1.ColumnHeader.Visible = false;
            this.fpSpread_Manual_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.Transparent);
            this.fpSpread_Manual_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread_Manual_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Manual_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_Manual_Sheet1.RowHeader.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Raised, System.Drawing.Color.Transparent);
            this.fpSpread_Manual_Sheet1.RowHeader.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Raised, System.Drawing.Color.Transparent);
            this.fpSpread_Manual_Sheet1.RowHeader.Visible = false;
            this.fpSpread_Manual_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_Manual_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_Manual_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.Transparent);
            this.fpSpread_Manual_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtMaintDetails);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 104);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(626, 262);
            this.panel2.TabIndex = 1;
            // 
            // txtMaintDetails
            // 
            this.txtMaintDetails.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaintDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMaintDetails.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaintDetails.Location = new System.Drawing.Point(0, 0);
            this.txtMaintDetails.Multiline = true;
            this.txtMaintDetails.Name = "txtMaintDetails";
            this.txtMaintDetails.ReadOnly = true;
            this.txtMaintDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMaintDetails.Size = new System.Drawing.Size(626, 262);
            this.txtMaintDetails.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtMaintenance);
            this.panel1.Controls.Add(this.lblMaint);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblMaintDetails);
            this.panel1.Controls.Add(this.lblEqpName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(632, 99);
            this.panel1.TabIndex = 0;
            // 
            // txtMaintenance
            // 
            this.txtMaintenance.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtMaintenance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMaintenance.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaintenance.ForeColor = System.Drawing.Color.Blue;
            this.txtMaintenance.HideSelection = false;
            this.txtMaintenance.Location = new System.Drawing.Point(9, 48);
            this.txtMaintenance.Multiline = true;
            this.txtMaintenance.Name = "txtMaintenance";
            this.txtMaintenance.ReadOnly = true;
            this.txtMaintenance.Size = new System.Drawing.Size(604, 30);
            this.txtMaintenance.TabIndex = 60;
            this.txtMaintenance.Text = "n/a";
            // 
            // lblMaint
            // 
            this.lblMaint.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaint.Location = new System.Drawing.Point(9, 32);
            this.lblMaint.Name = "lblMaint";
            this.lblMaint.Size = new System.Drawing.Size(588, 13);
            this.lblMaint.TabIndex = 59;
            this.lblMaint.Text = "Maintenance Title: ";
            // 
            // btnClose
            // 
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(551, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(64, 25);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Equipment: ";
            // 
            // lblMaintDetails
            // 
            this.lblMaintDetails.AutoSize = true;
            this.lblMaintDetails.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintDetails.ForeColor = System.Drawing.Color.Black;
            this.lblMaintDetails.Location = new System.Drawing.Point(9, 81);
            this.lblMaintDetails.Name = "lblMaintDetails";
            this.lblMaintDetails.Size = new System.Drawing.Size(23, 13);
            this.lblMaintDetails.TabIndex = 7;
            this.lblMaintDetails.Text = "....";
            // 
            // lblEqpName
            // 
            this.lblEqpName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEqpName.ForeColor = System.Drawing.Color.Blue;
            this.lblEqpName.Location = new System.Drawing.Point(81, 7);
            this.lblEqpName.Name = "lblEqpName";
            this.lblEqpName.Size = new System.Drawing.Size(465, 21);
            this.lblEqpName.TabIndex = 6;
            this.lblEqpName.Text = "....";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(1, 370);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(632, 19);
            this.panel3.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Manual Reference: ";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMnuViewManualFile});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.ShowImageMargin = false;
            this.contextMenuStrip1.ShowItemToolTips = false;
            this.contextMenuStrip1.Size = new System.Drawing.Size(139, 26);
            // 
            // tsMnuViewManualFile
            // 
            this.tsMnuViewManualFile.Name = "tsMnuViewManualFile";
            this.tsMnuViewManualFile.Size = new System.Drawing.Size(138, 22);
            this.tsMnuViewManualFile.Text = "View Manual File";
            this.tsMnuViewManualFile.Click += new System.EventHandler(this.tsMnuViewManualFile_Click);
            // 
            // frmViewMaintDescription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 562);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmViewMaintDescription";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "View Maintenance Procedures / Manual Reference";
            this.Load += new System.EventHandler(this.frmViewMaintDescription_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Manual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_Manual_Sheet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblEqpName;
        private System.Windows.Forms.Label lblMaintDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtMaintenance;
        private System.Windows.Forms.Label lblMaint;
        private System.Windows.Forms.TextBox txtMaintDetails;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private FarPoint.Win.Spread.FpSpread fpSpread_Manual;
        private FarPoint.Win.Spread.SheetView fpSpread_Manual_Sheet1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsMnuViewManualFile;
    }
}