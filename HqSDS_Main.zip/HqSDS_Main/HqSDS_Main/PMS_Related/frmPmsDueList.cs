﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmPmsDueList : Form
    {
        public int vesselID = -1;
        public string callMode = "";
        string groupType = "";

        int COL_MAINTDESCRIPTION = 2, COL_LASTMAINT_DISPLAY = 4, COL_MAINTDUE_DISPLAY = 5, 
            COL_LASTSVY_DISPLAY = 6, COL_SVYDUE_DISPLAY = 7, 
            COL_MAINTDUE = 13,
            COL_PMS_TOTALDUEDAYS = 14,
            COL_LASTOHDATE = 18,
            COL_LASTSVY = 19,
            COL_SVYDUE = 20;

        public frmPmsDueList()
        {
            InitializeComponent();
        }

        private void frmPmsDueList_Load(object sender, EventArgs e)
        {
            Gfn.SetFormWidthAndHeight(this, 10, 10, 700, 900);
            
            string vslname = PG.Gb.DBFn.Aqr("select vslName from v_vessels where vesselID=" + vesselID).ToString();

            Text = "PMS Outstanding List ";
            lblTitle.Text = vslname;
            label1.Visible = false; lblTotalPlannedMaint.Visible = false;
            label2.Visible = false; lblTotalDoneMaint.Visible = false;
            label3.Visible = false; lblTotalOutstanding.Visible = false;

            DesignPMSListGrid();

            fpSpread_PMS.ActiveSheet.Columns[COL_LASTSVY_DISPLAY, COL_SVYDUE_DISPLAY].Visible = false;
            fpSpread_PMS.ActiveSheet.Columns[COL_LASTMAINT_DISPLAY, COL_MAINTDUE_DISPLAY].Visible = true;
            fpSpread_PMS.ActiveSheet.ColumnHeader.Cells[0, COL_MAINTDESCRIPTION].Text = "Maintenance Description";
            chkShowLinkedMaintenance.Visible = false;

            int totalNoOfPendingMaintItems = 0, totalNoOfOverDueMaintItems = 0, totalNoOfPendingEqpMaintItems = 0, totalNoOfOverDueEqpMaintItems = 0;
            
            PG.InitialiseVesselSettings(vesselID);

            if (callMode.ToUpper() == "ODUESVY")
            {
                Text = "Survey Over Due List";
                fpSpread_PMS.ActiveSheet.Columns[COL_LASTSVY_DISPLAY, COL_SVYDUE_DISPLAY].Visible = true;
                fpSpread_PMS.ActiveSheet.Columns[COL_LASTMAINT_DISPLAY, COL_MAINTDUE_DISPLAY].Visible = false;
                fpSpread_PMS.ActiveSheet.ColumnHeader.Cells[0, COL_MAINTDESCRIPTION].Text = "Survey Description";
                chkShowLinkedMaintenance.Visible = true;
                chkShowLinkedMaintenance.Checked = false;
            }
            else if (callMode.ToUpper() == "CRITICALODUEMAINT")
            {
                Text = "Critical Equipment Over Due List";
            }  
            else if (callMode.ToUpper() == "OstdngCriticalEqpMaintItems".ToUpper())
            {
                Text = "Critical Equipment Maintenance Over Due List";
                label1.Visible = true; lblTotalPlannedMaint.Visible = true;
                label2.Visible = true; lblTotalDoneMaint.Visible = true;
                label3.Visible = true; lblTotalOutstanding.Visible = true;
                
                lblTotalOutstanding.Text = GetTotalEqpMaintDuePercentage(true, ref totalNoOfPendingEqpMaintItems, ref totalNoOfOverDueEqpMaintItems).ToString();
                lblTotalPlannedMaint.Text = totalNoOfPendingEqpMaintItems.ToString();
                lblTotalDoneMaint.Text = totalNoOfOverDueEqpMaintItems.ToString();
            }
            else if (callMode.ToUpper() == "OstdngNonCriticalEqpMaintItems".ToUpper())
            {
                Text = "Non Critical Equipment Maintenance Over Due List";
                label1.Visible = true; lblTotalPlannedMaint.Visible = true;
                label2.Visible = true; lblTotalDoneMaint.Visible = true;
                label3.Visible = true; lblTotalOutstanding.Visible = true;

                lblTotalOutstanding.Text = GetTotalEqpMaintDuePercentage(false, ref totalNoOfPendingEqpMaintItems, ref totalNoOfOverDueEqpMaintItems).ToString();
                lblTotalPlannedMaint.Text = totalNoOfPendingEqpMaintItems.ToString();
                lblTotalDoneMaint.Text = totalNoOfOverDueEqpMaintItems.ToString();
            }
            else if (callMode.ToUpper() == "OStdngMaintItemsCritical".ToUpper())
            {
                Text = "Critical Maintenance Over Due List";
                label1.Visible = true; lblTotalPlannedMaint.Visible = true;
                label2.Visible = true; lblTotalDoneMaint.Visible = true;
                label3.Visible = true; lblTotalOutstanding.Visible = true;

                lblTotalOutstanding.Text = GetTotalMaintDuePercentage(true, ref totalNoOfPendingMaintItems, ref totalNoOfOverDueMaintItems).ToString();
                lblTotalPlannedMaint.Text = totalNoOfPendingMaintItems.ToString();
                lblTotalDoneMaint.Text = totalNoOfOverDueMaintItems.ToString();
            }
            else if (callMode.ToUpper() == "OStdngMaintItemsNonCritical".ToUpper())
            {
                label1.Visible = true; lblTotalPlannedMaint.Visible = true;
                label2.Visible = true; lblTotalDoneMaint.Visible = true;
                label3.Visible = true; lblTotalOutstanding.Visible = true;

                lblTotalOutstanding.Text = GetTotalMaintDuePercentage(false, ref totalNoOfPendingMaintItems, ref totalNoOfOverDueMaintItems).ToString();
                lblTotalPlannedMaint.Text = totalNoOfPendingMaintItems.ToString();
                lblTotalDoneMaint.Text = totalNoOfOverDueMaintItems.ToString();
            }
            else if (callMode.ToUpper() == "AllOstndgMaint".ToUpper())
            {
                label1.Visible = true; lblTotalPlannedMaint.Visible = true;
                label2.Visible = true; lblTotalDoneMaint.Visible = true;
                label3.Visible = true; lblTotalOutstanding.Visible = true;

                lblTotalOutstanding.Text = GetTotalMaintDuePercentage(false, ref totalNoOfPendingMaintItems, ref totalNoOfOverDueMaintItems).ToString();
                lblTotalPlannedMaint.Text = totalNoOfPendingMaintItems.ToString();
                lblTotalDoneMaint.Text = totalNoOfOverDueMaintItems.ToString();
            }

            chkShowLinkedMaintenance_CheckedChanged(null, null);
          
            

            groupType = PG.defaultEqpGroup;
           
            BindPMSListGrid();
            this.Cursor = Cursors.Default;
        }

        private DataTable GetPMSOverMaintDueList(bool isCriticalMaint)
        {
            string addlCond = "    and not exists (select * from EQ_MaintCritical where VesselID in (-1, P.VesselID) and PMS_DocID = P.PMS_DocID) " + Environment.NewLine;
            int windowPeriod = PG.windowPeriod_OStdngNonCritMaintItems;
            if (isCriticalMaint)
            {
                addlCond = "    and exists (select * from EQ_MaintCritical where VesselID in (-1, P.VesselID) and PMS_DocID = P.PMS_DocID) " + Environment.NewLine;
                windowPeriod = PG.windowPeriod_OStdngCritMaintItems;
            }

            DataTable dt = GetPMSOverDueMaintList(addlCond, windowPeriod);

            return (dt);
        }

        private DataTable GetPMSOverDueMaintList_CriticalEqp(bool isCriticalEqpMaint)
        {
            string addlCond = "   and not exists (select * from EQ_CriticalEquipment where VesselID = P.VesselID and Eq_EquipmentID = P.Eq_EquipmentID) " + Environment.NewLine;
            int windowPeriod = PG.windowPeriod_OStdngNonCritEqpMaintItems;
            if (isCriticalEqpMaint)
            {
                addlCond = "   and exists (select * from EQ_CriticalEquipment where VesselID = P.VesselID and Eq_EquipmentID = P.Eq_EquipmentID) " + Environment.NewLine;
                windowPeriod = PG.windowPeriod_OStdngCritEqpMaintItems;
            }

            DataTable dt = GetPMSOverDueMaintList(addlCond, windowPeriod);

            return (dt);
        }

        private DataTable GetPMSOverDueMaintList(string addlCond, int windowPeriod)
        {
            string maintTypeToExclude = "";

            if (PG.isExcludeVerificationItemsFromDueList)
            {
                addlCond = addlCond + "    and P.mRepRefNo is null " + Environment.NewLine;
            }
            if (!PG.isEnableAlarmsAndRoutinesMaintType) maintTypeToExclude = maintTypeToExclude + PG.MAINTTYPE_ALARMS_ROUTINE + ",";

            maintTypeToExclude = maintTypeToExclude.Trim();
            if (maintTypeToExclude.Length > 1)
            {
                maintTypeToExclude = maintTypeToExclude.Substring(0, maintTypeToExclude.Length - 1);
                addlCond = addlCond  +"    and P.MaintType not in ('" + maintTypeToExclude.Replace(",", "','") + "')  " + Environment.NewLine;
            }

            string script = " Select P.PmsCode, P.EqpName, P.PositionDesc, P.EqpUnitNo " + Environment.NewLine +
                            "    , P.MaintDescription  " + Environment.NewLine +
                            "    , cast (P.IntervalValue as varchar(15))+ P.IntervalType as Interval " + Environment.NewLine +
                            "    , case P.Dept when 'E' then 'Engine'  " + Environment.NewLine +
                            "                  when 'L' then 'Electrical'  " + Environment.NewLine +
                            "                  when 'D' then 'Deck'  " + Environment.NewLine +
                            "                  when 'R' then 'Radio'  " + Environment.NewLine +
                            "      end as DeptDisplayStr               " + Environment.NewLine +
                            "    , P.MaintType " + Environment.NewLine +
                            "    , '' as SvyDue_Display " + Environment.NewLine +
                            "    , replace(convert (varchar(11), P.LastOhDate, 13),' ','-') as LastOhDate_Display " + Environment.NewLine +
                            "    , MaintDue_Display as MaintDue_Display  " + Environment.NewLine +
                            "    , P.EqpMaintNo , -1 EQ_MaintCheckListID, P.IntervalValue, P.IntervalType " + Environment.NewLine +
                            "    , ISNULL(datediff(d,DATEADD(hh , " + PG.timeToAdd + ", getdate()), P.MAINTDUE),-1) as TotalDue, P.LastOhDate, P.MAINTDUE" + Environment.NewLine +
                            " from PmsDetails_V P " + Environment.NewLine +
                            " where P.VesselID = " + vesselID + Environment.NewLine +
                            "    and P.GroupCode<>'@' " + Environment.NewLine +
                            "    and P.MaintDue <  " + Environment.NewLine +
                            "      (	 " + Environment.NewLine +
                            "         DATEDIFF(dd, 0, DATEADD(hh ," + PG.timeToAdd + " ,getdate()))  " + Environment.NewLine +
                            "         + (" + windowPeriod + ")  " + Environment.NewLine +
                            "      )" + Environment.NewLine +
                              addlCond +
                            " Order by MaintDue ";
            DataTable dt = PG.Gb.DBFn.DbRecords(script);

            return (dt);
        }

        private double GetTotalMaintDuePercentage(bool isCriticalMaint, ref int totalNoOfPendingMaintItems , ref int totalNoOfOverDueMaintItems)
        {
            string addlCond = "    and not exists (select * from EQ_MaintCritical where VesselID in (-1, P.VesselID) and PMS_DocID = P.PMS_DocID) " + Environment.NewLine;
            int windowPeriod = PG.windowPeriod_OStdngNonCritMaintItems;
            if (isCriticalMaint)
            {
                addlCond = "    and exists (select * from EQ_MaintCritical where VesselID in (-1, P.VesselID) and PMS_DocID = P.PMS_DocID) " + Environment.NewLine;
                windowPeriod = PG.windowPeriod_OStdngCritMaintItems;
            }
            if (callMode.ToUpper() == "AllOstndgMaint".ToUpper())
            {
                addlCond = "";
                windowPeriod = 0;
            }

            string maintTypeToExclude = "";
            if (PG.isExcludeVerificationItemsFromDueList)
            {
                addlCond = addlCond + "    and P.mRepRefNo is null " + Environment.NewLine;
            }
            if (!PG.isEnableAlarmsAndRoutinesMaintType) maintTypeToExclude = maintTypeToExclude + PG.MAINTTYPE_ALARMS_ROUTINE + ",";

            maintTypeToExclude = maintTypeToExclude.Trim();
            if (maintTypeToExclude.Length > 1)
            {
                maintTypeToExclude = maintTypeToExclude.Substring(0, maintTypeToExclude.Length - 1);
                addlCond = addlCond + "    and P.MaintType not in ('" + maintTypeToExclude.Replace(",", "','") + "')  " + Environment.NewLine;
            }

            string script = " select COUNT(Distinct EQ_PMSListID) as TotalNoOfPendingMaintItems " + Environment.NewLine +
                            " from PmsDetails_V P " + Environment.NewLine +
                            " where P.VesselID=" + vesselID +
                             addlCond +
                            "    and P.GroupCode<>'@' " + Environment.NewLine;
            totalNoOfPendingMaintItems = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));
            
            script = " Select COUNT(Distinct EQ_PMSListID) as TotalNoOfOverDueMaintItems " + Environment.NewLine +
                     " from PmsDetails_V P " + Environment.NewLine +
                     " where P.VesselID=" + vesselID + Environment.NewLine +
                     "    and P.MaintDue < " + Environment.NewLine +
                     "      (	" + Environment.NewLine +
                     "         DATEDIFF(dd, 0, DATEADD(hh ," + PG.timeToAdd + " ,getdate()))  +  " + Environment.NewLine +
                     "        (" + windowPeriod + ")  " + Environment.NewLine +
                     "      )" + Environment.NewLine +
                      addlCond +
                     "    and P.GroupCode<>'@' " + Environment.NewLine;
            totalNoOfOverDueMaintItems = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

            double totalPercentage = 0;
            if (totalNoOfPendingMaintItems > 0) totalPercentage = (100.0 * (totalNoOfOverDueMaintItems) / (totalNoOfPendingMaintItems));

            totalPercentage = Math.Round(totalPercentage, 1);

            return (totalPercentage);
        }

        private double GetTotalEqpMaintDuePercentage( bool isCriticalEqpMaint, ref int totalNoOfPendingMaintItems, ref int totalNoOfOverDueMaintItems)
        {
            string addlCond = "    and not exists (select * from EQ_CriticalEquipment where VesselID = P.VesselID and Eq_EquipmentID = P.Eq_EquipmentID) " + Environment.NewLine;
            int windowPeriod = PG.windowPeriod_OStdngNonCritEqpMaintItems;
            if (isCriticalEqpMaint)
            {
                addlCond = "    and exists (select * from EQ_CriticalEquipment where VesselID = P.VesselID and Eq_EquipmentID = P.Eq_EquipmentID) " + Environment.NewLine;
                windowPeriod = PG.windowPeriod_OStdngCritEqpMaintItems;
            }

            string maintTypeToExclude = "";
            if (PG.isExcludeVerificationItemsFromDueList)
            {
                addlCond = addlCond + "    and P.mRepRefNo is null " + Environment.NewLine;
            }
            if (!PG.isEnableAlarmsAndRoutinesMaintType) maintTypeToExclude = maintTypeToExclude + PG.MAINTTYPE_ALARMS_ROUTINE + ",";

            maintTypeToExclude = maintTypeToExclude.Trim();
            if (maintTypeToExclude.Length > 1)
            {
                maintTypeToExclude = maintTypeToExclude.Substring(0, maintTypeToExclude.Length - 1);
                addlCond = addlCond + "    and P.MaintType not in ('" + maintTypeToExclude.Replace(",", "','") + "')  " + Environment.NewLine;
            }

            string script = " select COUNT(Distinct EQ_PMSListID) as TotalNoOfPendingMaintItems " + Environment.NewLine +
                            " from PmsDetails_V P " + Environment.NewLine +
                            " where P.VesselID=" + vesselID +
                             addlCond +
                            "    and P.GroupCode<>'@' " + Environment.NewLine;
            totalNoOfPendingMaintItems = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

            script = " Select COUNT(Distinct EQ_PMSListID) as TotalNoOfOverDueMaintItems " + Environment.NewLine +
                     " from PmsDetails_V P " + Environment.NewLine +
                     " where P.VesselID=" + vesselID + Environment.NewLine +
                     "    and P.MaintDue < " + Environment.NewLine +
                     "      (	" + Environment.NewLine +
                     "         DATEDIFF(dd, 0, DATEADD(hh ," + PG.timeToAdd + " ,getdate()))  +  " + Environment.NewLine +
                     "        (" + windowPeriod + ")  " + Environment.NewLine +
                     "      )" + Environment.NewLine +
                      addlCond +
                     "    and P.GroupCode<>'@' " + Environment.NewLine;
            totalNoOfOverDueMaintItems = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

            double totalPercentage = 0;
            if (totalNoOfPendingMaintItems > 0) totalPercentage = (100.0 * (totalNoOfOverDueMaintItems) / (totalNoOfPendingMaintItems));

            totalPercentage = Math.Round(totalPercentage, 1);

            return (totalPercentage);
        }

        protected void DesignPMSListGrid()
        {
            List<DgvInits> pmsColList = new List<DgvInits>();
            try
            {
                pmsColList.Add(new DgvInits("EQPNAME", "Equipment", 175, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("PositionDesc", "Position ", 64, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("MaintDescription", "Maintenance", 255, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("DeptDisplayStr", "Dept", 55, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("LastOhDate_Display", "Last Maint", 85, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("MaintDue_Display", "Maint Due", 85, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("LastSvy_Display", "Last Svy", 85, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("SvyDue_Display", "Svy Due", 85, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("Interval", "Interval", 62, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                pmsColList.Add(new DgvInits("EQ_FunctionalID", "EQ_FunctionalID", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("EQ_UnitsID", "EQ_UnitsID ", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("EQ_MaintenanceID", "EQ_MaintenanceID", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("mrepRefNo", "mrepRefNo", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("MAINTDUE", "Maint Due", 85, 0, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("TotalDue", "TotalDue", 40, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("isCB", "isCB", 40, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("FormsListID", "FormsListID", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("MaintType", "MaintType", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("LastOhDate", "Last Maint", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("LastSvy", "Last Svy", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("SvyDue", "Svy Due", 80, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("IntervalType", "IntervalType", 40, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("IntervalValue", "IntervalValue", 40, Color.Black, SystemColors.ButtonFace, false, true));
                pmsColList.Add(new DgvInits("Mntdesc", "Associated Maintenance", 210, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Blue));
                
                FarPtColCtrls.GenerateFarPointGridView(fpSpread_PMS, pmsColList, null, false, true, false);
                fpSpread_PMS.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread_PMS.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                fpSpread_PMS.ActiveSheet.ScrollingContentInfo.RowNumberPolicy = FarPoint.Win.Spread.ScrollingContentRowNumberPolicy.Never;
                fpSpread_PMS.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
            }
            finally
            {
                pmsColList = null;
            }
        }

        private void BindPMSListGrid()
        {
            DataTable dt = null;
            fpSpread_PMS.SuspendLayout();
            try
            {
                fpSpread_PMS.ActiveSheet.RowCount = 0;
                ToolStripStatus.Text = "";

                if (callMode.ToUpper() == "ODUESVY")
                {
                    dt = GetSvyList();
                }
                else
                {
                    bool isCriticalMaint = (callMode.ToUpper() == "OStdngMaintItemsCritical".ToUpper());
                    bool isCriticalEqpMaint = (callMode.ToUpper() == "OstdngCriticalEqpMaintItems".ToUpper());                    

                    if (callMode.ToUpper() == "OStdngMaintItemsCritical".ToUpper() || callMode.ToUpper() == "OStdngMaintItemsNonCritical".ToUpper())
                    {
                        dt = GetPMSOverMaintDueList(isCriticalMaint);
                    }
                    else if (callMode.ToUpper() == "OstdngCriticalEqpMaintItems".ToUpper() || callMode.ToUpper() == "OstdngNonCriticalEqpMaintItems".ToUpper())
                    {

                        dt = GetPMSOverDueMaintList_CriticalEqp(isCriticalEqpMaint);
                    }
                    else
                    {
                        dt = GetPMSOverDueMaintList("", 0);
                    }
                }

                fpSpread_PMS.ActiveSheet.DataSource = dt;

                ToolStripStatus.Text = "No Records Found";
                if (dt != null && dt.Rows.Count > 0)
                {
                    ToolStripStatus.Text = "Total Overdue Items: " + dt.Rows.Count;
                }

                for (int row = 0; row < fpSpread_PMS.ActiveSheet.RowCount; row++)
                {
                    //ODue
                    long totalDueDays = 0;
                    if (fpSpread_PMS.ActiveSheet.Cells[row, COL_PMS_TOTALDUEDAYS].Value != null)
                        totalDueDays = Convert.ToInt32(fpSpread_PMS.ActiveSheet.Cells[row, COL_PMS_TOTALDUEDAYS].Value);

                    if (totalDueDays < 0)
                    {
                        if (callMode.ToUpper() == "ODUESVY")
                        {
                            fpSpread_PMS.ActiveSheet.Cells[row, COL_SVYDUE_DISPLAY].ForeColor = Color.Red;
                        }
                        else
                        {
                            fpSpread_PMS.ActiveSheet.Cells[row, COL_MAINTDUE_DISPLAY].ForeColor = Color.Red;
                        }
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmPmsDuelist.cs", "BindPMSListGrid", callMode + " - " + err.Message);
            }
            finally
            {
                fpSpread_PMS.ResumeLayout();
            }
        }

        public DataTable GetSvyList()
        {
            string sqlScript;
            DataTable dt = null;
                        
            sqlScript = " select isnull((select isnull(EqpMaintNo, 0 )  from EQ_Maintenance where VesselID=C.VesselID and EQ_MaintenanceID=C.EQ_MaintenanceID),0) as EqpMaintNo " + 
                        ", E.EQ_EquipmentID, C.PmsCode, U.EqpUnitDescription as EqpName, U.PositionDesc  " + Environment.NewLine +
                        "   , case C.Dept when 'E' then 'Engine'  " + Environment.NewLine +
                        "                 when 'L' then 'Electrical'  " + Environment.NewLine +
                        "                 when 'D' then 'Deck'  " + Environment.NewLine +
                        "                 when 'R' then 'Radio'  " + Environment.NewLine +
                        "     end as DeptDisplayStr               " + Environment.NewLine +
                        "   , isnull((select isnull(MaintType, '')  from EQ_Maintenance where VesselID=C.VesselID and EQ_MaintenanceID=C.EQ_MaintenanceID),'')  as MaintType " + Environment.NewLine +
                        "   , C.LastSvy, replace(convert (varchar(11), C.LastSvy, 13),' ','-') as LastSvy_Display " + Environment.NewLine +
                        "   , replace(convert (varchar(11), C.SvyDue, 13),' ','-') as SvyDue_Display " + Environment.NewLine +
                        "   , isnull(C.SvyDesc,'') SvyDesc   " +
                        "   , Svydesc as MaintDescription  " + Environment.NewLine +
                        "   , cast (c.SvyIntv as varchar(10))+ ' Years' Interval, isnull(C.Classcode,'') Classcode " + Environment.NewLine +
                        "   , '' as LastOhDate_Display " + Environment.NewLine +
                        "   , '' as MaintDue_Display " + Environment.NewLine +
                        "   , U.EqpUnitNo, -1 EQ_MaintCheckListID " + Environment.NewLine +
                        "   , ISNULL(datediff(d,DATEADD(hh , " + PG.timeToAdd + " ,getdate()), C.SvyDue),-1) as TotalDue, C.LastSvy, C.SvyDue " + Environment.NewLine +
                        "   , (select MaintDescription from EQ_Maintenance where VesselID=C.VesselID and EQ_MaintenanceID=C.EQ_MaintenanceID ) as Mntdesc " + Environment.NewLine +
                        " from Eq_Equipment E, Eq_units U, EQ_PMSList_Class C " + Environment.NewLine +
                        " Where  E.EQ_EquipmentID= U.EQ_EquipmentID and E.EQ_EquipmentID= C.EQ_EquipmentID " + Environment.NewLine +
                        "    and U.IsDisabled=0 and U.VesselID=C.VesselID and U.EQ_EquipmentID= C.EQ_EquipmentID and U.EQ_UnitsID=C.EQ_UnitsID  " + Environment.NewLine +
                        "    and exists (select * from EQ_Equipment_V E1  where E.EQ_EquipmentID=E1.EQ_EquipmentID and E1.GroupType='" + groupType + "') " + Environment.NewLine +
                        "    and U.VesselID=" + vesselID + Environment.NewLine +
                        "    and isNull(C.SVYDUE,'1900.01.01') < convert(varchar(50),DATEADD(dd, " + PG.windowPeriod_OStdngSvyItems + ", DATEDIFF(dd, 0, DATEADD(hh , " + PG.timeToAdd + " ,getdate()))),102) " + Environment.NewLine;

            string addlCondition = "";
            if (txtSearch.Text.Trim().Length > 0)
            {
                addlCondition = addlCondition + "    and ( ( " + PG.GetSearchCombination(" U.EqpUnitDescription", txtSearch.Text.Trim()) + " ) " + Environment.NewLine +
                                                "           or ( " + PG.GetSearchCombination(" (select MaintDescription from EQ_Maintenance where VesselID=C.VesselID and EQ_MaintenanceID=C.EQ_MaintenanceID )", txtSearch.Text.Trim()) + " )  " + Environment.NewLine +
                                                "           or ( " + PG.GetSearchCombination(" C.SvyDesc ", txtSearch.Text.Trim()) + " )  " + Environment.NewLine +
                                                "        )  " + Environment.NewLine;
            }

            string maintTypeToExclude = "";
            if (!PG.isEnableAlarmsAndRoutinesMaintType) maintTypeToExclude = maintTypeToExclude + PG.MAINTTYPE_ALARMS_ROUTINE + ",";
            maintTypeToExclude = maintTypeToExclude.Trim();
            if (maintTypeToExclude.Length > 1)
            {
                maintTypeToExclude = maintTypeToExclude.Substring(0, maintTypeToExclude.Length - 1);
                addlCondition = addlCondition + " and not exists (select * from EQ_Maintenance where VesselID=C.VesselID and EQ_MaintenanceID=C.EQ_MaintenanceID AND MaintType in ('" + maintTypeToExclude.Replace(",", "','") + "'))  " + Environment.NewLine;
            }

            string orderByClause = " Order By C.LastSvy, U.EqpUnitNo, 1 ";
            sqlScript = sqlScript + addlCondition + orderByClause;

            dt = PG.Gb.DBFn.DbRecords(sqlScript);

            return (dt);
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            BindPMSListGrid();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            BindPMSListGrid();
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) BindPMSListGrid();
        }

        private void fpSpread_PMS_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpread_PMS.ActiveSheet.Columns[COL_MAINTDUE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
                fpSpread_PMS.ActiveSheet.Columns[COL_LASTOHDATE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
                fpSpread_PMS.ActiveSheet.Columns[COL_SVYDUE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
                fpSpread_PMS.ActiveSheet.Columns[COL_LASTSVY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

                if (e.Column == COL_MAINTDUE_DISPLAY)
                    fpSpread_PMS.ActiveSheet.AutoSortColumn(COL_MAINTDUE);
                else if (e.Column == COL_LASTMAINT_DISPLAY)
                    fpSpread_PMS.ActiveSheet.AutoSortColumn(COL_LASTOHDATE);
                else if (e.Column == COL_SVYDUE_DISPLAY)
                    fpSpread_PMS.ActiveSheet.AutoSortColumn(COL_SVYDUE);
                else if (e.Column == COL_LASTSVY_DISPLAY)
                    fpSpread_PMS.ActiveSheet.AutoSortColumn(COL_LASTSVY);
                else
                    fpSpread_PMS.ActiveSheet.AutoSortColumn(e.Column);

                fpSpread_PMS.ActiveSheet.Columns[COL_MAINTDUE_DISPLAY].SortIndicator = fpSpread_PMS.ActiveSheet.Columns[COL_MAINTDUE].SortIndicator;
                fpSpread_PMS.ActiveSheet.Columns[COL_LASTMAINT_DISPLAY].SortIndicator = fpSpread_PMS.ActiveSheet.Columns[COL_LASTOHDATE].SortIndicator;
                fpSpread_PMS.ActiveSheet.Columns[COL_SVYDUE_DISPLAY].SortIndicator = fpSpread_PMS.ActiveSheet.Columns[COL_SVYDUE].SortIndicator;
                fpSpread_PMS.ActiveSheet.Columns[COL_LASTSVY_DISPLAY].SortIndicator = fpSpread_PMS.ActiveSheet.Columns[COL_LASTSVY].SortIndicator;
            }
        }

        private void fpSpread_PMS_AutoSortingColumn(object sender, FarPoint.Win.Spread.AutoSortingColumnEventArgs e)
        {
            fpSpread_PMS.ActiveSheet.Columns[COL_MAINTDUE_DISPLAY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
            fpSpread_PMS.ActiveSheet.Columns[COL_LASTMAINT_DISPLAY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
            fpSpread_PMS.ActiveSheet.Columns[COL_SVYDUE_DISPLAY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
            fpSpread_PMS.ActiveSheet.Columns[COL_LASTSVY_DISPLAY].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

            int colToSort = -1;
            if (e.Column == COL_MAINTDUE_DISPLAY) colToSort = COL_MAINTDUE;
            else if (e.Column == COL_LASTMAINT_DISPLAY) colToSort = COL_LASTOHDATE;
            else if (e.Column == COL_SVYDUE_DISPLAY) colToSort = COL_SVYDUE;
            else if (e.Column == COL_LASTSVY_DISPLAY) colToSort = COL_LASTSVY;

            if (colToSort > 0)
            {
                fpSpread_PMS.ActiveSheet.AutoSortColumn(colToSort);
                fpSpread_PMS.ActiveSheet.Columns[e.Column].SortIndicator = fpSpread_PMS.ActiveSheet.Columns[colToSort].SortIndicator;
                if (!e.Ascending)
                {
                    fpSpread_PMS.ActiveSheet.AutoSortColumn(colToSort);
                    fpSpread_PMS.ActiveSheet.Columns[e.Column].SortIndicator = fpSpread_PMS.ActiveSheet.Columns[colToSort].SortIndicator;
                }
                e.Cancel = true;
            }
            if (fpSpread_PMS.ActiveSheet.RowCount > 0)
            {
                fpSpread_PMS.ActiveSheet.SetActiveCell(0, 0);
                fpSpread_PMS.SetViewportTopRow(0, 0);
            }
        }

        private void chkShowLinkedMaintenance_CheckedChanged(object sender, EventArgs e)
        {            
            fpSpread_PMS.ActiveSheet.Columns[23].Visible = (chkShowLinkedMaintenance.Checked);
        }
    }
}
