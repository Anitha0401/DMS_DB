﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMaintInput_CheckList : Form
    {
        public long eqMaintenanceID = -1, eqUnitId = -1, eqEquipmentId = -1, pms_DocID = -1, eq_PmsHistID = -1;
        public string maintType = "", calledMode = "";
        bool canCloseThisForm = false;
        public string mReason = "", mType = "", mPlace = "", mCompl = "", mCond = "";
        public string dept = "", eqpNamePosn = "", mntDesc = "", intvType = "xx", vslComments = "", mntTypeStr = "";
        public DataTable dtPmsListDet, dtPmsHistDet, dtSPConsumed, dtAssociateForms;
        public DateTime mntDoneDate = new DateTime(), mntPostponedDate = new DateTime();
        public DateTime todaysDate;
        public int refNumber = -1, interval, vesselID = -1;

        public const int COL_REFNO = 0,
                         COL_MAINTDETAILS = 1,
                         COL_ISMAINTDONE = 2,
                         COL_COMMENTS = 3,
                         COL_EQ_MAINTCHECKLISTID = 4,
                         COL_EQ_PMSHISTID = 5;

        const string VIEW_MODE = "VIEW";

        const int COL_ASSOC_FORMS_FORMNAME = 0,
                  COL_ASSOC_FORMS_STATUS = 1,
                  COL_ASSOC_FORMS_MODE = 2,
                  COL_ASSOC_FORMS_INSTANCENO = 3,
                  COL_ASSOC_FORMS_DEFAULTPARAMVALUE = 4,
                  COL_ASSOC_FORMS_FORMSLISTID = 5,
                  COL_ASSOC_FORMS_FORMSINSTANCEID = 6,
                  COL_ASSOC_FORMS_ISCOMPULSORY = 7,
                  COL_ASSOC_FORMS_REPORTDUEDATE = 8;

        public frmMaintInput_CheckList()
        {
            InitializeComponent();
        }

        private void frmMaintInput_CheckList_Load(object sender, EventArgs e)
        {
            DesignMaintInstructionsGrid();

            BindMaintInstructionsGrid();

            FillupMaintDetails();
            
            calledMode = calledMode.ToUpper();
            if (calledMode == VIEW_MODE)
            {
                this.Text = "  View Maintenance Report";
                DisableControls();
            }
        }

        private void FillupMaintDetails()
        {
            DataTable dtPmsListDet, dtPmsHistDet;
            try
            {
                tableLayoutPanel1.RowStyles[6].Height = 0;

                string maintInstruction = PG.GetHQAndVslMaintenanceInstructions(pms_DocID, vesselID, eqUnitId);
                if (maintInstruction.Length > 0) tableLayoutPanel1.RowStyles[6].Height = 30;
                lnkViewMaintDetails.Visible = (maintInstruction.Length > 0);

                string script = " Select Distinct Dept, IntervalType, IntervalValue, MaintDescription, AddlMaintDescription " +
                                 "    , EqpName, PositionDesc, EQ_EquipmentID, PmsCode, LastOhDate, MaintDue, UpdStat, LastOhHrs, EQ_UnitsID " +
                                 " from PmsDetails_V " +
                                 " where " + //GroupType=" + Gfn.Qss(PG.defaultEqpGroup) + " and" +
                                 "     VesselID=" + vesselID +
                                 "    and EQ_UnitsID = " + eqUnitId +
                                 "    and EQ_MaintenanceID =" + eqMaintenanceID;
                dtPmsListDet = PG.Gb.DBFn.DbRecords(script);
                if (dtPmsListDet != null && dtPmsListDet.Rows.Count == 1)
                {
                    lbl_EqpName.Text = dtPmsListDet.Rows[0]["EqpName"].ToString() + "  " + dtPmsListDet.Rows[0]["PositionDesc"].ToString();
                    lbl_Maintenance.Text = dtPmsListDet.Rows[0]["MaintDescription"].ToString();
                    string intvType = dtPmsListDet.Rows[0]["IntervalType"].ToString();
                    string interval = dtPmsListDet.Rows[0]["IntervalValue"].ToString();

                    string intvTypeExp = "";
                    if (intvType.Equals("D")) intvTypeExp = "Days";
                    else if (intvType.Equals("W")) intvTypeExp = "Weeks";
                    else if (intvType.Equals("M")) intvTypeExp = "Months";
                    else if (intvType.Equals("Y")) intvTypeExp = "Years";
                    else if (intvType.Equals("H")) intvTypeExp = "Hours";

                    lblInterval.Text = interval + " " + intvTypeExp;
                }

                script = " Select * from EQ_PmsHist " +
                         " where VesselID = " + vesselID +
                         "    and EQ_PmsHistID=" + eq_PmsHistID;
                dtPmsHistDet = PG.Gb.DBFn.DbRecords(script);

                //SpConsumed 
                script = " SELECT M.Itemdetail, M.MakerCode, isnull(C.ConsQty,0) as ConsQty, C.EQ_UnitsID, C.EQ_SPConsumedID, M.Proc_ItemMasterID " +
                         " FROM EQ_SPConsumed C, Proc_ItemMaster M  " +
                         " where C.VesselID=M.VesselID and C.Proc_ItemMasterID=M.Proc_ItemMasterID and C.ConsQty <> 0  " +
                         "    and C.VesselID =" + vesselID +
                         "    and C.MrepRefNo = " + refNumber +
                         "    and C.EQ_UnitsID = " + eqUnitId +
                         "    and C.EQ_MaintenanceID=" + eqMaintenanceID +
                         " Order By C.EQ_SPConsumedID";
                dtSPConsumed = PG.Gb.DBFn.DbRecords(script);

                if (dtPmsHistDet != null && dtPmsHistDet.Rows.Count == 1)
                {
                    if ((dtPmsHistDet.Rows[0]["mPlace"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["mPlace"] != null))
                    {
                        lblPlace.Text = dtPmsHistDet.Rows[0]["mPlace"].ToString();
                    }
                    if ((dtPmsHistDet.Rows[0]["mType"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["mType"] != null))
                    {
                        lblMaintType.Text = dtPmsHistDet.Rows[0]["mType"].ToString();
                    }
                    if ((dtPmsHistDet.Rows[0]["mReason"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["mReason"] != null))
                    {
                        lblReason.Text = dtPmsHistDet.Rows[0]["mReason"].ToString();
                    }
                    if ((dtPmsHistDet.Rows[0]["miCond"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["miCond"] != null))
                    {
                        lblCondition.Text = dtPmsHistDet.Rows[0]["miCond"].ToString();
                    }
                    if ((dtPmsHistDet.Rows[0]["mCompl"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["mCompl"] != null))
                    {
                        lblCompletion.Text = dtPmsHistDet.Rows[0]["mCompl"].ToString();
                    }

                    //ManHrs
                    int mmHrs = 0;
                    if ((dtPmsHistDet.Rows[0]["mmHrs"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["mmHrs"] != null && dtPmsHistDet.Rows[0]["mmHrs"].ToString().Length > 0))
                        mmHrs = Convert.ToInt32(dtPmsHistDet.Rows[0]["mmHrs"]);
                    lblManhrs.Text = mmHrs.ToString();

                    // Maint Done Date
                    if ((dtPmsHistDet.Rows[0]["NMDATE"] != DBNull.Value) && (dtPmsHistDet.Rows[0]["NMDATE"] != null))
                        lblMaintDate.Text = Gfn.ToDate(dtPmsHistDet.Rows[0]["NMDATE"].ToString()).ToString("dd-MMM-yyyy");

                    // comments
                    txtComments.Text = dtPmsHistDet.Rows[0]["VslComments"].ToString().Replace("\n", "\r\n");
                    chkMaintDoneAsPerInstructions.Checked = (dtPmsHistDet.Rows[0]["AddlIntField"].ToString() == "1");
                }

                DesignAndBindSPConsumedDetails();
                if (dtPmsHistDet != null && dtPmsHistDet.Rows.Count > 0) GetAssociatedFormsList();

                if (dtAssociateForms != null)
                {
                    DesignAndBindMaintAssociatedForms();
                }
                else
                {
                    tableLayoutPanel3.ColumnStyles[1].Width = 0;
                }

                // Attachment
                long pmsHistID = Convert.ToInt64(PG.Gb.DBFn.Aqr("select EQ_PmsHistID from EQ_PmsHist where VesselID= " + vesselID + " and mRepRefno=" + refNumber).ToString());

                int cnt = PG.GetPmsHistAttachment(vesselID, pmsHistID);

                lnkViewHistAttach.Visible = (cnt > 0);

                // Enable (or) Disable Maint Instructions
                //string maintInstructions = PG.GetHqAndVslMaintInstrunctions(vesselID, "", pms_DocID);
                //chkMaintDoneAsPerInstructions.Visible = (maintInstructions.Length > 0);     
                chkMaintDoneAsPerInstructions.Visible = false;

                lblComments.Text = PG.GetEQ_PMS_Settings(vesselID, "PMS_VesselCommentsLablelValue");
            }
            catch (Exception err)
            {
                PG.DisplayException("Fillup Maint Details", err.Message);
                PG.AddToGenErrorLog("frmMaintInput_CheckList.cs", "FillupMaintDetails", err.Message);
            }
            finally
            {
                dtPmsHistDet = null; dtPmsListDet = null;
            }
        }

        private void DesignMaintInstructionsGrid()
        {
            List<DgvInits> maintColList = new List<DgvInits>();
            try
            {
                Color bkColor = Color.FromArgb(235, 255, 235);
                maintColList.Add(new DgvInits("RefNo", "#", 30, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("MaintDetails", "Maintenance Details", 480, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("IsMaintDone", "Maint Done", 45, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                maintColList.Add(new DgvInits("Comments", "Comments", 200, Color.Black, SystemColors.ButtonFace, true, false, Color.White, Color.Black));
                maintColList.Add(new DgvInits("EQ_MaintCheckListID", "EQ_MaintCheckListID", 40, Color.Black, SystemColors.ButtonFace, false, true));
                maintColList.Add(new DgvInits("EQ_PmsHistID", "EQ_PmsHistID", 40, Color.Black, SystemColors.ButtonFace, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread_MaintInstructions, maintColList, null, false, false, true);
                FarPtColCtrls.AssignCheckBoxColumnsToFarPointGrid(fpSpread_MaintInstructions, false, "IsMaintDone", "Maint Done", COL_ISMAINTDONE,  " ", 75, Color.White);
                              
                List<string> stringList = new List<string>() { "Not done", "Spares not found", "NA"};                
                fpSpread_MaintInstructions.ActiveSheet.Columns[COL_COMMENTS].CellType = AssignComboboxColumnToFarPointGridWithStringList(stringList);
                fpSpread_MaintInstructions.ActiveSheet.Columns[COL_ISMAINTDONE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread_MaintInstructions.ActiveSheet.RowHeader.Columns[0].Width = 18;
                fpSpread_MaintInstructions.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;
                fpSpread_MaintInstructions.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
            }
            finally
            {
                maintColList = null;
            }
        } 

        public static FarPoint.Win.Spread.CellType.ComboBoxCellType AssignComboboxColumnToFarPointGridWithStringList(List<string> stringList)
        {
            FarPoint.Win.Spread.CellType.ComboBoxCellType cmb = new FarPoint.Win.Spread.CellType.ComboBoxCellType();
            ArrayList arrCboItemValue = new ArrayList();
            try
            {
                cmb.AutoSearch = FarPoint.Win.AutoSearch.SingleCharacter;

                for (int i = 0; i < stringList.Count; i++)
                {
                    arrCboItemValue.Add(stringList[i]);
                }
                cmb.Items = (string[])arrCboItemValue.ToArray(typeof(string));
                cmb.MaxLength = 50;
                cmb.Editable = true;
                cmb.MaxDrop = 20;
            }
            finally
            {

            }
            return cmb;
        }

        private void DesignAndBindSPConsumedDetails()
        {
            List<DgvInits> spConsumedDetails = new List<DgvInits>();
            try
            {
                int col_ItemDetail_Width = 320, col_MakerCode_Width = 130, col_ConsQty_Width = 100;
                if (dtAssociateForms != null)
                {
                    col_ItemDetail_Width = 265;
                    col_MakerCode_Width = 100;
                    col_ConsQty_Width = 68;
                }

                fpSpread1.ActiveSheet.RowCount = 0;
                spConsumedDetails.Add(new DgvInits("ItemDetail", "Part Name", col_ItemDetail_Width, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                spConsumedDetails.Add(new DgvInits("MakerCode", "Maker Code", col_MakerCode_Width, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                spConsumedDetails.Add(new DgvInits("ConsQty", "Qty Used", col_ConsQty_Width, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, spConsumedDetails, dtSPConsumed, false, true);
                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 20;

                foreach (FarPoint.Win.Spread.Row row in fpSpread1.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            catch (Exception err)
            {
                PG.DisplayException("Design And Bind SPConsumed Details", err.Message);
                PG.AddToGenErrorLog("frmMaintInput_CheckList.cs", "DesignAndBindSPConsumedDetails", err.Message);
            }
            finally
            {
                spConsumedDetails = null;
            }
        }

        private void DesignAndBindMaintAssociatedForms()
        {
            List<DgvInits> assocForms = new List<DgvInits>();
            try
            {
                assocForms.Add(new DgvInits("FormName", "Form Name", 135, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Status", "Status", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("Mode", "#", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("InstanceNo", "InstanceNo", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("DefaultParamValue", "DefaultParamValue", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsListID", "FormsListID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("FormsInstancesID", "FormsInstancesID", 60, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("IsCompulsory", "IsCompulsory", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                assocForms.Add(new DgvInits("ReportDueDate", "ReportDueDate", 70, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadAssociatedForms, assocForms, dtAssociateForms, false, true);
                FarPtColCtrls.AssignLinkColumnsToFarPointGrid(fpSpreadAssociatedForms, false, "#", COL_ASSOC_FORMS_MODE, "Edit", 34, SystemColors.ButtonFace);

                fpSpreadAssociatedForms.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpreadAssociatedForms.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;

                string status = "";
                for (int rowIndex = 0; rowIndex < fpSpreadAssociatedForms.ActiveSheet.RowCount; rowIndex++)
                {
                    status = fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_STATUS].Value.ToString().ToUpper();
                    if (status == "COMPLETED" ||calledMode ==VIEW_MODE)
                    {
                        FarPoint.Win.Spread.CellType.HyperLinkCellType lnk = new FarPoint.Win.Spread.CellType.HyperLinkCellType();
                        lnk.Text = "View";
                        fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_MODE].CellType = lnk;
                    }
                    fpSpreadAssociatedForms.ActiveSheet.Rows[rowIndex].Height = fpSpreadAssociatedForms.ActiveSheet.Rows[rowIndex].GetPreferredHeight();
                }

            }
            finally
            {
                assocForms = null;
            }
        }

        private void DisableControls()
        {
            btnCancel.Text = "Close";

            txtComments.ReadOnly = true;
            txtComments.BackColor = SystemColors.Info;

            fpSpread_MaintInstructions.ActiveSheet.Columns[0, fpSpread_MaintInstructions.ActiveSheet.ColumnCount - 1].Locked = true;
            fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].Locked = true;
           // fpSpreadAssociatedForms.ActiveSheet.Columns[0, fpSpreadAssociatedForms.ActiveSheet.ColumnCount - 1].Locked = true;
        }


        private void BindMaintInstructionsGrid()
        {
            DataTable dt;
            try
            {
                fpSpread_MaintInstructions.SuspendLayout();

                string script = " Select MaintDetails, isNull(IsMaintDone,0) as IsMaintDone, isNull(Comments,'') as Comments, C.EQ_MaintCheckListID, ISNULL(C.EQ_PmsHistID,-1) " + Environment.NewLine +
                                " from EQ_PmsHist_MaintCheckListDetails C " + Environment.NewLine +
                                " where C.VesselID = " + vesselID +
                                "    and EQ_PmsHistID= " + eq_PmsHistID +
                                " order by C.EQ_MaintCheckListID ";
                dt = PG.Gb.DBFn.DbRecords(script);

                fpSpread_MaintInstructions.ActiveSheet.DataSource = dt;

                if (fpSpread_MaintInstructions.ActiveSheet.RowCount > 0)
                {
                    fpSpread_MaintInstructions.ActiveSheet.SetActiveCell(0, 0);
                }
                foreach (FarPoint.Win.Spread.Row row in fpSpread_MaintInstructions.ActiveSheet.Rows)
                {
                    row.Height = row.GetPreferredHeight();
                }
            }
            finally
            {
                fpSpread_MaintInstructions.ResumeLayout();
                dt = null;
            }
        }

        private void lnkViewHistAttach_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (lblAttachmentFileName.Text.Trim().Length <= 0)
            {
                Gfn.nWbwithAlignAndCentrePosn("There is no attachment file found", ContentAlignment.MiddleCenter);
                return;
            }
         
            CallViewAttachmentPage();
        }

        private void CallViewAttachmentPage()
        {
            string eqpName = lbl_EqpName.Text;
            frmPmsHistViewAttachments objAttach = new frmPmsHistViewAttachments();
            try
            {
                objAttach.vesselID = vesselID;
                objAttach.eqpName = eqpName;
                objAttach.eq_PmsHistID = eq_PmsHistID;
                objAttach.ShowDialog();
            }
            finally
            {
                objAttach = null;
            }
        }

        private void lnkViewMaintDetails_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmViewMaintDescription viewMaintDesc = new frmViewMaintDescription();
            try
            {
                viewMaintDesc.curVesselID = vesselID;
                viewMaintDesc.curEQUnitID = eqUnitId;
                viewMaintDesc.curEQMaintID = eqMaintenanceID;
                viewMaintDesc.maintType = maintType;
                viewMaintDesc.curPms_DocID = pms_DocID;
                viewMaintDesc.parentMouseXPosn = this.Location.X;
                viewMaintDesc.ShowDialog();
            }
            finally
            {
                viewMaintDesc = null;
            }
        }


        private void fpSpreadAssociatedForms_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            int rowIndex = e.Row;

            if (e.Column == COL_ASSOC_FORMS_MODE)
            {
                CallFormsPage(rowIndex);
            }
        }

        private void fpSpreadAssociatedForms_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        private void CallFormsPage(int rowIndex)
        {
            int xvesselID = -1, xInstanceNo = -1; long xFormInstanceID = 0, xFormListID = 0;
            string xCallMode = "", xParamValueList = "", xReportDueDate = "";
            bool unlockUserAtFinally = false;
            try
            {
                if (rowIndex < 0)
                {
                    return;
                }

                xvesselID = vesselID;
                xInstanceNo = Convert.ToInt32(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_INSTANCENO].Value.ToString());
                xFormInstanceID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSINSTANCEID].Value.ToString());
                xFormListID = Convert.ToInt64(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_FORMSLISTID].Value.ToString());
                xCallMode = "View";
                //xCallMode = ((FarPoint.Win.Spread.CellType.HyperLinkCellType)fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_MODE].CellType).Text.ToString();
                xParamValueList = fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_DEFAULTPARAMVALUE].Value.ToString();
                xReportDueDate = Convert.ToDateTime(fpSpreadAssociatedForms.ActiveSheet.Cells[rowIndex, COL_ASSOC_FORMS_REPORTDUEDATE].Value.ToString()).ToString("dd-MMM-yyyy");

                if (xCallMode == "EDIT")
                {
                    if (VslForms.PG.AnyUserAlreadyLocked(xFormInstanceID.ToString(), "Edit", PG.Gb)) return;

                    VslForms.PG.LockCurrentUser(xFormInstanceID.ToString(), "Edit", PG.Gb);
                    unlockUserAtFinally = true;
                }

                VslForms.PG.FillupThisForm(xCallMode, xvesselID, xFormListID, xFormInstanceID, xInstanceNo, xParamValueList, false, PG.Gb, xReportDueDate,"PMS", -1);

                //GetAssociatedFormsList();
                //DesignAndBindMaintAssociatedForms();
            }
            catch (Exception er)
            {
                Gfn.nWb("Failed to edit pending form instance." + Environment.NewLine + "Please contact Administrator");
                PG.AddToGenErrorLog("frmMaintInput_CheckList.cs", "CallFormsPage", er.Message);
            }
            finally
            {
                if (xCallMode == "EDIT")
                {
                    if (unlockUserAtFinally && xFormInstanceID > 0)
                    {
                        VslForms.PG.UnLockCurrentUser(xFormInstanceID.ToString(), "Edit", PG.Gb);
                    }
                }
            }
        }

        private void GetAssociatedFormsList()
        {
            try
            {
                string script =  " Select F.FormsListID, H.FormsInstancesID, F.FormName, I.Status, I.InstanceNo, F.DefaultParamValue, I.ReportDueDate  " + Environment.NewLine +
                                 " , CASE WHEN I.Status='COMPLETED' THEN 'VIEW' ELSE 'EDIT' END AS Mode " + Environment.NewLine +
                                 " , isnull((select IsCompulsory from EQ_MaintAssociatedForms A where  A.FormsListID=F.FormsListID and A.PMS_DocID=H.PMS_DocID and A.FormsListID=I.FormsListID),1) as IsCompulsory " + Environment.NewLine +
                                 ", '' CompulsoryDisp " +
                                 " , Source, SourceKeyID" + Environment.NewLine +
                                 " from FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                                 " where F.FormsListID=I.FormsListID " + Environment.NewLine +
                                 "   and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                                 "   and H.VesselID =" + vesselID + Environment.NewLine +
                                 "   and H.EQ_PmsHistID = '" + eq_PmsHistID + "'" + Environment.NewLine +
                                 "   and H.PMS_DocID = " + pms_DocID;

                dtAssociateForms = PG.Gb.DBFn.DbRecords(script);
                if (dtAssociateForms != null && dtAssociateForms.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtAssociateForms.Rows)
                    {
                        dr["CompulsoryDisp"] = "No";
                        if (dr["IsCompulsory"].ToString() == "1") dr["CompulsoryDisp"] = "Yes";
                    }
                }

            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to Initialise Associated FormsList");
                PG.AddToGenErrorLog("frmMaintInput_CheckList.cs", "GetAssociatedFormsList", err.Message);
            }
        }        

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (calledMode != VIEW_MODE)
            {
                if (Gfn.nConfBox("Do you want to Cancel changes and Exit?"))
                {                    
                    canCloseThisForm = true;
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            else
            {
                canCloseThisForm = true;
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void frmMaintInput_CheckList_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (canCloseThisForm) return;
            if (calledMode == VIEW_MODE) return;

            //if (Gfn.nConfBoxWithCentrePosn("Do you want to Cancel changes and Exit?", 110, 250))
            //{
            //    CancelMaintInputProcess();
            //}
            //else
            //{
            //    e.Cancel = true;
            //}
        }

        private void btnPmsReportLog_Click(object sender, EventArgs e)
        {
            frmPMSReportLog eventLog = new frmPMSReportLog();
            try
            {
                eventLog.eqpNamePosn = lbl_EqpName.Text;
                eventLog.mntDesc = lbl_Maintenance.Text;
                eventLog.mRepRefNo = refNumber;
                eventLog.vesselID = vesselID;                
                eventLog.DialogResult = eventLog.ShowDialog();
            }
            finally
            {
                eventLog.Dispose();
            }
        }
    }
}
