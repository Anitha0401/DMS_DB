﻿using System;
using System.Windows.Forms;

using Sds.CommonV1;
 
namespace HqSDS_Main
{
    public partial class frmSuptComments : Form
    {
        public string suptComments = "";
        public bool isSuptCommentsCompulsory = false;
        public frmSuptComments()
        {
            InitializeComponent();
        }

        private void frmSuptComments_Load(object sender, EventArgs e)
        {
            txtSuptComments.Text = suptComments;
            //Gfn.SetFormStartupPosition(this, MousePosition.Y, MousePosition.X);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            suptComments = txtSuptComments.Text.Trim();
         
            if (isSuptCommentsCompulsory && suptComments.Trim().Length <= 0)
            {
                Gfn.Wb("Supt Comments cannot be empty");
                return;
            }

            DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
