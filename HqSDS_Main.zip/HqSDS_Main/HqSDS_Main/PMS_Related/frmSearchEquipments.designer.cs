namespace HqSDS_Main
{
    partial class frmSearchEquipments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tStsTotalItems = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grpboxOptions = new System.Windows.Forms.GroupBox();
            this.chkEmbedSearch = new System.Windows.Forms.CheckBox();
            this.chkCaseSensitive = new System.Windows.Forms.CheckBox();
            this.grpboxSearchFields = new System.Windows.Forms.GroupBox();
            this.rdoMaker = new System.Windows.Forms.RadioButton();
            this.rdoModel = new System.Windows.Forms.RadioButton();
            this.rdoEqptName = new System.Windows.Forms.RadioButton();
            this.grpboxSearchScope = new System.Windows.Forms.GroupBox();
            this.rdoAllGroups = new System.Windows.Forms.RadioButton();
            this.rdoCurrentGroup = new System.Windows.Forms.RadioButton();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.btnClear = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOption = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblPartToFind = new System.Windows.Forms.Label();
            this.btnGO = new System.Windows.Forms.Button();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblEqpName = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.pnlMiddle = new System.Windows.Forms.Panel();
            this.fpEquipment = new FarPoint.Win.Spread.FpSpread();
            this.fpEquipment_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.rdoSFICode = new System.Windows.Forms.RadioButton();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.grpboxOptions.SuspendLayout();
            this.grpboxSearchFields.SuspendLayout();
            this.grpboxSearchScope.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.pnlMiddle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpEquipment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpEquipment_Sheet1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tStsTotalItems});
            this.statusStrip1.Location = new System.Drawing.Point(0, 519);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(813, 22);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tStsTotalItems
            // 
            this.tStsTotalItems.ForeColor = System.Drawing.Color.Blue;
            this.tStsTotalItems.Name = "tStsTotalItems";
            this.tStsTotalItems.Size = new System.Drawing.Size(118, 17);
            this.tStsTotalItems.Text = "toolStripStatusLabel1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.grpboxOptions);
            this.panel1.Controls.Add(this.grpboxSearchFields);
            this.panel1.Controls.Add(this.grpboxSearchScope);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 49);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(813, 68);
            this.panel1.TabIndex = 20;
            // 
            // grpboxOptions
            // 
            this.grpboxOptions.Controls.Add(this.chkEmbedSearch);
            this.grpboxOptions.Controls.Add(this.chkCaseSensitive);
            this.grpboxOptions.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxOptions.Location = new System.Drawing.Point(238, 3);
            this.grpboxOptions.Name = "grpboxOptions";
            this.grpboxOptions.Size = new System.Drawing.Size(149, 61);
            this.grpboxOptions.TabIndex = 10;
            this.grpboxOptions.TabStop = false;
            this.grpboxOptions.Text = "Search Using";
            // 
            // chkEmbedSearch
            // 
            this.chkEmbedSearch.AutoSize = true;
            this.chkEmbedSearch.Checked = true;
            this.chkEmbedSearch.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEmbedSearch.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.chkEmbedSearch.Location = new System.Drawing.Point(16, 20);
            this.chkEmbedSearch.Name = "chkEmbedSearch";
            this.chkEmbedSearch.Size = new System.Drawing.Size(114, 16);
            this.chkEmbedSearch.TabIndex = 2;
            this.chkEmbedSearch.Text = "Embedded Search";
            this.chkEmbedSearch.UseVisualStyleBackColor = true;
            // 
            // chkCaseSensitive
            // 
            this.chkCaseSensitive.AutoSize = true;
            this.chkCaseSensitive.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.chkCaseSensitive.Location = new System.Drawing.Point(16, 39);
            this.chkCaseSensitive.Name = "chkCaseSensitive";
            this.chkCaseSensitive.Size = new System.Drawing.Size(100, 16);
            this.chkCaseSensitive.TabIndex = 1;
            this.chkCaseSensitive.Text = "Case Sensitive";
            this.chkCaseSensitive.UseVisualStyleBackColor = true;
            // 
            // grpboxSearchFields
            // 
            this.grpboxSearchFields.Controls.Add(this.rdoSFICode);
            this.grpboxSearchFields.Controls.Add(this.rdoMaker);
            this.grpboxSearchFields.Controls.Add(this.rdoModel);
            this.grpboxSearchFields.Controls.Add(this.rdoEqptName);
            this.grpboxSearchFields.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxSearchFields.Location = new System.Drawing.Point(50, 3);
            this.grpboxSearchFields.Name = "grpboxSearchFields";
            this.grpboxSearchFields.Size = new System.Drawing.Size(174, 61);
            this.grpboxSearchFields.TabIndex = 9;
            this.grpboxSearchFields.TabStop = false;
            this.grpboxSearchFields.Text = "Search Field";
            // 
            // rdoMaker
            // 
            this.rdoMaker.AutoSize = true;
            this.rdoMaker.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.rdoMaker.Location = new System.Drawing.Point(100, 39);
            this.rdoMaker.Name = "rdoMaker";
            this.rdoMaker.Size = new System.Drawing.Size(54, 16);
            this.rdoMaker.TabIndex = 3;
            this.rdoMaker.Text = "Maker";
            this.rdoMaker.UseVisualStyleBackColor = true;
            // 
            // rdoModel
            // 
            this.rdoModel.AutoSize = true;
            this.rdoModel.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.rdoModel.Location = new System.Drawing.Point(16, 39);
            this.rdoModel.Name = "rdoModel";
            this.rdoModel.Size = new System.Drawing.Size(53, 16);
            this.rdoModel.TabIndex = 1;
            this.rdoModel.Text = "Model";
            this.rdoModel.UseVisualStyleBackColor = true;
            // 
            // rdoEqptName
            // 
            this.rdoEqptName.AutoSize = true;
            this.rdoEqptName.Checked = true;
            this.rdoEqptName.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.rdoEqptName.Location = new System.Drawing.Point(16, 20);
            this.rdoEqptName.Name = "rdoEqptName";
            this.rdoEqptName.Size = new System.Drawing.Size(78, 16);
            this.rdoEqptName.TabIndex = 0;
            this.rdoEqptName.TabStop = true;
            this.rdoEqptName.Text = "Eqpt Name";
            this.rdoEqptName.UseVisualStyleBackColor = true;
            // 
            // grpboxSearchScope
            // 
            this.grpboxSearchScope.Controls.Add(this.rdoAllGroups);
            this.grpboxSearchScope.Controls.Add(this.rdoCurrentGroup);
            this.grpboxSearchScope.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxSearchScope.Location = new System.Drawing.Point(404, 3);
            this.grpboxSearchScope.Name = "grpboxSearchScope";
            this.grpboxSearchScope.Size = new System.Drawing.Size(127, 61);
            this.grpboxSearchScope.TabIndex = 12;
            this.grpboxSearchScope.TabStop = false;
            this.grpboxSearchScope.Text = "Search Scope";
            // 
            // rdoAllGroups
            // 
            this.rdoAllGroups.AutoSize = true;
            this.rdoAllGroups.Checked = true;
            this.rdoAllGroups.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.rdoAllGroups.Location = new System.Drawing.Point(16, 39);
            this.rdoAllGroups.Name = "rdoAllGroups";
            this.rdoAllGroups.Size = new System.Drawing.Size(103, 16);
            this.rdoAllGroups.TabIndex = 1;
            this.rdoAllGroups.TabStop = true;
            this.rdoAllGroups.Text = "All Groups/Eqpt";
            this.rdoAllGroups.UseVisualStyleBackColor = true;
            // 
            // rdoCurrentGroup
            // 
            this.rdoCurrentGroup.AutoSize = true;
            this.rdoCurrentGroup.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.rdoCurrentGroup.Location = new System.Drawing.Point(16, 20);
            this.rdoCurrentGroup.Name = "rdoCurrentGroup";
            this.rdoCurrentGroup.Size = new System.Drawing.Size(94, 16);
            this.rdoCurrentGroup.TabIndex = 0;
            this.rdoCurrentGroup.Text = "Current Group";
            this.rdoCurrentGroup.UseVisualStyleBackColor = true;
            // 
            // pnlTitle
            // 
            this.pnlTitle.Controls.Add(this.btnClear);
            this.pnlTitle.Controls.Add(this.label2);
            this.pnlTitle.Controls.Add(this.btnOption);
            this.pnlTitle.Controls.Add(this.label1);
            this.pnlTitle.Controls.Add(this.txtSearch);
            this.pnlTitle.Controls.Add(this.lblPartToFind);
            this.pnlTitle.Controls.Add(this.btnGO);
            this.pnlTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTitle.Location = new System.Drawing.Point(0, 0);
            this.pnlTitle.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(813, 49);
            this.pnlTitle.TabIndex = 11;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.Control;
            this.btnClear.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(450, 5);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(52, 23);
            this.btnClear.TabIndex = 12;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(86, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "*";
            // 
            // btnOption
            // 
            this.btnOption.BackColor = System.Drawing.SystemColors.Control;
            this.btnOption.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOption.Location = new System.Drawing.Point(59, 28);
            this.btnOption.Name = "btnOption";
            this.btnOption.Size = new System.Drawing.Size(23, 19);
            this.btnOption.TabIndex = 10;
            this.btnOption.Text = "+";
            this.btnOption.UseCompatibleTextRendering = true;
            this.btnOption.UseVisualStyleBackColor = false;
            this.btnOption.Click += new System.EventHandler(this.btnOption_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Options";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(106, 6);
            this.txtSearch.MaxLength = 80;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(280, 20);
            this.txtSearch.TabIndex = 7;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // lblPartToFind
            // 
            this.lblPartToFind.AutoSize = true;
            this.lblPartToFind.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPartToFind.Location = new System.Drawing.Point(10, 10);
            this.lblPartToFind.Name = "lblPartToFind";
            this.lblPartToFind.Size = new System.Drawing.Size(74, 13);
            this.lblPartToFind.TabIndex = 6;
            this.lblPartToFind.Text = "Text to Find";
            // 
            // btnGO
            // 
            this.btnGO.BackColor = System.Drawing.SystemColors.Control;
            this.btnGO.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGO.Location = new System.Drawing.Point(392, 5);
            this.btnGO.Name = "btnGO";
            this.btnGO.Size = new System.Drawing.Size(52, 23);
            this.btnGO.TabIndex = 8;
            this.btnGO.Text = "Go";
            this.btnGO.UseVisualStyleBackColor = false;
            this.btnGO.Click += new System.EventHandler(this.btnGO_Click);
            // 
            // pnlBottom
            // 
            this.pnlBottom.Controls.Add(this.lblEqpName);
            this.pnlBottom.Controls.Add(this.btnCancel);
            this.pnlBottom.Controls.Add(this.btnOk);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBottom.Location = new System.Drawing.Point(0, 486);
            this.pnlBottom.Margin = new System.Windows.Forms.Padding(0);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(813, 33);
            this.pnlBottom.TabIndex = 19;
            // 
            // lblEqpName
            // 
            this.lblEqpName.AutoSize = true;
            this.lblEqpName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEqpName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblEqpName.Location = new System.Drawing.Point(6, 9);
            this.lblEqpName.Name = "lblEqpName";
            this.lblEqpName.Size = new System.Drawing.Size(22, 13);
            this.lblEqpName.TabIndex = 17;
            this.lblEqpName.Text = "---";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.SystemColors.Control;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(728, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 25);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.BackColor = System.Drawing.SystemColors.Control;
            this.btnOk.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.Location = new System.Drawing.Point(648, 4);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 25);
            this.btnOk.TabIndex = 15;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // pnlMiddle
            // 
            this.pnlMiddle.Controls.Add(this.fpEquipment);
            this.pnlMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMiddle.Location = new System.Drawing.Point(0, 117);
            this.pnlMiddle.Margin = new System.Windows.Forms.Padding(0);
            this.pnlMiddle.Name = "pnlMiddle";
            this.pnlMiddle.Size = new System.Drawing.Size(813, 369);
            this.pnlMiddle.TabIndex = 18;
            // 
            // fpEquipment
            // 
            this.fpEquipment.AccessibleDescription = "fpEquipment, Sheet1, Row 0, Column 0, ";
            this.fpEquipment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpEquipment.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpEquipment.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpEquipment.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpEquipment.HorizontalScrollBar.Name = "";
            this.fpEquipment.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpEquipment.HorizontalScrollBar.TabIndex = 0;
            this.fpEquipment.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpEquipment.Location = new System.Drawing.Point(0, 0);
            this.fpEquipment.Name = "fpEquipment";
            this.fpEquipment.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpEquipment_Sheet1});
            this.fpEquipment.Size = new System.Drawing.Size(813, 369);
            this.fpEquipment.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpEquipment.TabIndex = 93;
            this.fpEquipment.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpEquipment.VerticalScrollBar.Name = "";
            this.fpEquipment.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpEquipment.VerticalScrollBar.TabIndex = 1;
            this.fpEquipment.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpEquipment.VisualStyles = FarPoint.Win.VisualStyles.On;
            this.fpEquipment.ColumnWidthChanged += new FarPoint.Win.Spread.ColumnWidthChangedEventHandler(this.fpEquipment_ColumnWidthChanged);
            this.fpEquipment.SelectionChanged += new FarPoint.Win.Spread.SelectionChangedEventHandler(this.fpEquipment_SelectionChanged);
            this.fpEquipment.CellDoubleClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpEquipment_CellDoubleClick);
            // 
            // fpEquipment_Sheet1
            // 
            this.fpEquipment_Sheet1.Reset();
            this.fpEquipment_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpEquipment_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpEquipment_Sheet1.ColumnCount = 5;
            this.fpEquipment_Sheet1.RowCount = 4;
            this.fpEquipment_Sheet1.AllowNoteEdit = false;
            this.fpEquipment_Sheet1.AutoCalculation = false;
            this.fpEquipment_Sheet1.AutoGenerateColumns = false;
            this.fpEquipment_Sheet1.AutoSortFrozenRows = false;
            this.fpEquipment_Sheet1.AutoSortTrailingFrozenRows = false;
            this.fpEquipment_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpEquipment_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpEquipment_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpEquipment_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpEquipment_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpEquipment_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpEquipment_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpEquipment_Sheet1.DataAutoSizeColumns = false;
            this.fpEquipment_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpEquipment_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), System.Drawing.SystemColors.ControlLightLight, System.Drawing.SystemColors.ControlDark, 1);
            this.fpEquipment_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;
            this.fpEquipment_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpEquipment_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpEquipment_Sheet1.RowHeader.Visible = false;
            this.fpEquipment_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpEquipment_Sheet1.SelectionFont = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpEquipment_Sheet1.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpEquipment_Sheet1.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors;
            this.fpEquipment_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpEquipment_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpEquipment_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpEquipment_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), System.Drawing.SystemColors.ControlLightLight, System.Drawing.SystemColors.ControlDark, 1);
            this.fpEquipment_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.pnlTitle, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnlMiddle, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pnlBottom, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 68F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(813, 519);
            this.tableLayoutPanel1.TabIndex = 19;
            // 
            // rdoSFICode
            // 
            this.rdoSFICode.AutoSize = true;
            this.rdoSFICode.Font = new System.Drawing.Font("Verdana", 6.75F);
            this.rdoSFICode.Location = new System.Drawing.Point(100, 20);
            this.rdoSFICode.Name = "rdoSFICode";
            this.rdoSFICode.Size = new System.Drawing.Size(70, 16);
            this.rdoSFICode.TabIndex = 4;
            this.rdoSFICode.Text = "SFI Code";
            this.rdoSFICode.UseVisualStyleBackColor = true;
            // 
            // frmSearchEquipments
            // 
            this.ClientSize = new System.Drawing.Size(813, 541);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.statusStrip1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSearchEquipments";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "  Search Equipments";
            this.Load += new System.EventHandler(this.frmSearchEquipments_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.grpboxOptions.ResumeLayout(false);
            this.grpboxOptions.PerformLayout();
            this.grpboxSearchFields.ResumeLayout(false);
            this.grpboxSearchFields.PerformLayout();
            this.grpboxSearchScope.ResumeLayout(false);
            this.grpboxSearchScope.PerformLayout();
            this.pnlTitle.ResumeLayout(false);
            this.pnlTitle.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.pnlMiddle.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpEquipment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpEquipment_Sheet1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tStsTotalItems;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grpboxOptions;
        private System.Windows.Forms.CheckBox chkEmbedSearch;
        private System.Windows.Forms.CheckBox chkCaseSensitive;
        private System.Windows.Forms.GroupBox grpboxSearchFields;
        private System.Windows.Forms.RadioButton rdoMaker;
        private System.Windows.Forms.RadioButton rdoModel;
        private System.Windows.Forms.RadioButton rdoEqptName;
        private System.Windows.Forms.GroupBox grpboxSearchScope;
        private System.Windows.Forms.RadioButton rdoAllGroups;
        private System.Windows.Forms.RadioButton rdoCurrentGroup;
        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Button btnOption;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblPartToFind;
        private System.Windows.Forms.Button btnGO;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblEqpName;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel pnlMiddle;
        private FarPoint.Win.Spread.FpSpread fpEquipment;
        private FarPoint.Win.Spread.SheetView fpEquipment_Sheet1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.RadioButton rdoSFICode;
    }
}

