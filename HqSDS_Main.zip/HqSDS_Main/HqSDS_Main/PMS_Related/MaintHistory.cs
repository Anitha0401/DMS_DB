﻿using System;
using System.Data;

using Sds.CommonV1;

namespace HqSDS_Main
{
    class MaintHistory
    {
        public long curEQUnitID, maintFormNo = -1, curEQMaintID = -1, curPMS_DocID = -1;
        int curVesselID =-1;
        public DataTable dtHist = null;
        public string eqpName = "", maintDesc = "", maintType = "", pmsCode = "", sfiCode = "", intervalType = "", intervalValue = "", strToReplaceMaintDue = "";
        public bool isAllowedToSelectandFill_RequiredPmsForms = false;
        
        public MaintHistory(int xcurVesselID, long xCurEqUnitId, long xCurEQMaintID, long xCurPMS_DocID)
        {
            curEQUnitID = xCurEqUnitId;
            curEQMaintID = xCurEQMaintID;
            curVesselID = xcurVesselID;
            curPMS_DocID = xCurPMS_DocID;
            InitialiseEqpNameAndMaintDescription();
            InitialisePmsHistDataTable();
        }

        protected void InitialiseEqpNameAndMaintDescription()
        {
            eqpName = ""; maintDesc = ""; maintType = "";
            DataTable dtMaint = null; string script;
            try
            {
                script = " select rtrim(EqpUnitDescription + ' ' + positionDesc) " +
                         " from EQ_Units " +
                         " where VesselId=" + curVesselID + " and EQ_UnitsID=" + curEQUnitID;
                eqpName = PG.Gb.DBFn.Aqr(script).ToString();

                script = " select isnull(MaintDescription,'') as MaintDescription , MaintType , isnull(FormsListID,-1) FormsListID, PmsCode, IntervalType, IntervalValue, SFICodeDisplay " +
                         ", AllowedToSelectandFill_RequiredPmsForms , strToReplaceMaintDue " +
                         " from PmsDetails_V " +
                         " where GroupType=" + Gfn.Qss(PG.defaultEqpGroup) + " and VesselId=" + curVesselID +
                         "    and EQ_UnitsID=" + curEQUnitID + " and EQ_MaintenanceID=" + curEQMaintID;
                dtMaint = PG.Gb.DBFn.DbRecords(script);
                if (dtMaint != null)
                {
                    maintDesc = dtMaint.Rows[0]["MaintDescription"].ToString();
                    maintType = dtMaint.Rows[0]["MaintType"].ToString().ToUpper();
                    if (dtMaint.Rows[0]["FormsListID"] != null && dtMaint.Rows[0]["FormsListID"].ToString().Trim().Length > 0)
                    {
                        maintFormNo = Convert.ToInt64(dtMaint.Rows[0]["FormsListID"].ToString());
                    }

                    pmsCode = dtMaint.Rows[0]["PmsCode"].ToString().ToUpper();
                    sfiCode = dtMaint.Rows[0]["SFICodeDisplay"].ToString().ToUpper();
                    intervalType = dtMaint.Rows[0]["IntervalType"].ToString().ToUpper();
                    intervalValue = dtMaint.Rows[0]["IntervalValue"].ToString().ToUpper();
                    isAllowedToSelectandFill_RequiredPmsForms = (Convert.ToInt32(dtMaint.Rows[0]["AllowedToSelectandFill_RequiredPmsForms"].ToString()) == 1);
                    strToReplaceMaintDue = dtMaint.Rows[0]["strToReplaceMaintDue"].ToString().ToUpper();
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MaintHistory.cs", "InitialiseEqpNameAndMaintDescription", err.Message);
            }
            finally
            {
                dtMaint = null;
            }
        }

        protected void InitialisePmsHistDataTable()
        {
            string script;
            try
            {
                script = " Select U.PositionDesc, U.EqpUnitDescription as EqpName, M.AddlMaintDescription, replace(convert (varchar(11), H.nmdate, 13),' ','-') nmdateDisplay, H.*  " + Environment.NewLine +
                         "    , -1 as logCnt, M.FormsListID, (select count(*) from EQ_PmsHist_Attachments where EQ_PmsHistID=H.EQ_PmsHistID and IsDeleted=0) as AttachCnt  " + Environment.NewLine +
                         "    , case when LEN(ReportedByRank)>0 THEN ReportedByRank+' - '+ReportedByName ELSE ReportedByName END as DoneBy  " + Environment.NewLine +
                         "    , (Select COUNT(*) from EQ_PmsHist_MaintCheckListDetails where VesselID=U.VesselID and EQ_PmsHistID =H.EQ_PmsHistID) as MaintCheckListHistoryCnt " + Environment.NewLine +
                         "    , P.MaintDescription, P.IntervalType, P.IntervalValue " + Environment.NewLine +
                         "    , case when(Verified =1) then 'Ok' when(Verified =0) then 'Not Accepted' when(Verified =-1) then '? (C/E or MAS Verify)'  else '' end CE_MAS_Verify " + Environment.NewLine +
                         "    , case when (IsMaintPostponed>0) then replace(convert (varchar(11), H.PostponeDate, 13),' ','-') else '' end as PostponeDateDisplay " + Environment.NewLine +
                         "    , replace(convert (varchar(11), H.MdueDATE, 13),' ','-') MdueDATEDisplay " + Environment.NewLine +
                         "    , ActualRunningHrsAtMaint " + Environment.NewLine +
                         " from EQ_PmsHist H, EQ_Units U, EQ_Maintenance M, EQ_PMSList P  " + Environment.NewLine +
                         " where H.VesselID=U.VesselID and H.EQ_EquipmentID= U.EQ_EquipmentID and H.EQ_UnitsID=U.EQ_UnitsID    " + Environment.NewLine +
                         "    and U.VesselID =M.VesselID  and H.EQ_MaintenanceID =M.EQ_MaintenanceID   " + Environment.NewLine +
                         "    and U.VesselID=P.VesselID and U.Eq_UnitsID=P.Eq_UnitsID and M.EQ_MaintenanceID=P.EQ_MaintenanceID " + Environment.NewLine +
                         "    and H.VesselID=P.VesselID and H.Eq_UnitsID=P.Eq_UnitsID and H.EQ_MaintenanceID=P.EQ_MaintenanceID " + Environment.NewLine +
                         "    and U.IsDisabled=0 and P.IsDisabled=0 " + Environment.NewLine +
                         "    and H.VesselId= " + curVesselID.ToString() + Environment.NewLine +
                         "    and H.EQ_UnitsID=" + curEQUnitID + Environment.NewLine +
                         "    and H.EQ_MaintenanceID =" + curEQMaintID + Environment.NewLine;
                script = script + " order by H.NMdate desc, H.EQ_PmsHistID desc ";
              
                dtHist = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to get PMS Maintenance History List");
                PG.AddToGenErrorLog("MaintHistory.cs", "InitialisePmsHistDataTable", err.Message);
            }
        }

        public DataTable GetPMSConsumedDataTable(int mRepRefNo)
        {
            DataTable dtPmsConsumed = null;

            string script = " Select M.MakerCode, M.Itemdetail, isnull(C.ConsQty,0) as ConsQty " + Environment.NewLine +
                            " FROM EQ_SPConsumed C, Proc_ItemMaster M  " + Environment.NewLine +
                            " where C.Proc_ItemMasterID=M.Proc_ItemMasterID " + Environment.NewLine +
                            "    and C.VesselID =" + curVesselID + Environment.NewLine +
                            "    and C.EQ_MaintenanceID=" + curEQMaintID + Environment.NewLine +
                            "    and C.EQ_UnitsID=" + curEQUnitID + Environment.NewLine +
                            "    and C.mRepRefNo = " + mRepRefNo + Environment.NewLine +
                            " Order By C.EQ_SPConsumedID";
            try
            {
                dtPmsConsumed = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to get PMS Maintenance Spares Consumed List");
                PG.AddToGenErrorLog("MaintHistory.cs", "GetPMSConsumedDataTable", err.Message);
            }

            return (dtPmsConsumed);
        }

        public bool IsAssociatedFormsExists(long eq_PmsHistID)
        {
            bool result = false;
            string script;
            try
            {  
                script = " SELECT count(*) " + Environment.NewLine +
                         " FROM FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                         " where  F.FormsListID=I.FormsListID " + Environment.NewLine +
                         "    and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                         "    and H.VesselID =" + curVesselID + Environment.NewLine +
                         "    and H.EQ_PmsHistID = " + eq_PmsHistID + Environment.NewLine +
                         "    and H.PMS_DocID = " + curPMS_DocID;
                result = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
            }
            catch (Exception err)
            {
                result = false;
                Gfn.Eb("Failed to check is Associated Forms Exists");
                PG.AddToGenErrorLog("MaintHistory.cs", "IsAssociatedFormsExists", err.Message);
            }
            return result;
        }

        public DataTable GetAssociatedFormsList(long eq_PmsHistID)
        {
            DataTable dtAssociateForms = null;
            string script;
            try
            {
                script = " Select F.FormsListID, H.FormsInstancesID, F.FormName, I.Status, I.InstanceNo, F.DefaultParamValue,  I.ReportDueDate  " + Environment.NewLine +
                         " , CASE WHEN I.Status='COMPLETED' THEN 'VIEW' ELSE 'EDIT' END AS Mode " + Environment.NewLine +
                         " , isnull((select IsCompulsory from EQ_MaintAssociatedForms A where  A.FormsListID=F.FormsListID and A.PMS_DocID=H.PMS_DocID and A.FormsListID=I.FormsListID),1) as IsCompulsory " + Environment.NewLine +
                         ", '' CompulsoryDisp " +
                         " , Source, SourceKeyID" + Environment.NewLine +
                         " from FormsList F, EQ_PmsHist_AssociatedForms H, FormsInstances I " + Environment.NewLine +
                         " where F.FormsListID=I.FormsListID " + Environment.NewLine +
                         "   and H.FormsInstancesID=I.FormsInstancesID " + Environment.NewLine +
                         "   and H.VesselID =" + curVesselID + Environment.NewLine +
                         "   and H.EQ_PmsHistID = '" + eq_PmsHistID + "'" + Environment.NewLine +
                         "   and H.PMS_DocID = " + curPMS_DocID;

                dtAssociateForms = PG.Gb.DBFn.DbRecords(script);
                if (dtAssociateForms != null && dtAssociateForms.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtAssociateForms.Rows)
                    {
                        dr["CompulsoryDisp"] = "No";
                        if (dr["IsCompulsory"].ToString() == "1") dr["CompulsoryDisp"] = "Yes";
                    }
                }
            }
            catch (Exception err)
            {
                dtAssociateForms = null;
                Gfn.Eb("Failed to Initialise Associated FormsList");
                PG.AddToGenErrorLog("MaintHistory.cs", "GetAssociatedFormsList", err.Message);
            }
            return dtAssociateForms;
        }

        public bool CheckMaintHistExists()
        {
            bool result = false;
            try
            {
                result = (dtHist != null && dtHist.Rows.Count > 0);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MaintHistory.cs", "CheckMaintHistExists", err.Message);
            }
            return (result);
        }

        public int GetInstanceNo(long formsInstancesID)
        {
            int result = -1;
            try
            {
                string script = " select isnull(InstanceNo,-1) from FormsInstances " +
                             " where VesselID=" +curVesselID + " and FormsInstancesID=" + formsInstancesID;
                string sx1 = PG.Gb.DBFn.Aqr(script).ToString().Trim();
                if (sx1.Length > 0) result = Convert.ToInt32(sx1);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to get PMS Maintenance Forms InstancesID");
                PG.AddToGenErrorLog("MaintHistory.cs", "GetInstanceNo", err.Message);
            }
            return (result);
        }

        public DataTable GetExportDataTable()
        {
            DataTable dt = null;
            string script;

            string workDoneProcedure = "";
            if (maintType == PG.MAINTTYPE_PMS) workDoneProcedure = "Maintenance done as per Maintenance procedures";
            else if (maintType == PG.MAINTTYPE_ALARMS_ROUTINE) workDoneProcedure = "Alarms and Routines done as per Alarms and Routines procedures";
            else if (maintType == PG.MAINTTYPE_CONDN_MONITORING_ROUTINE) workDoneProcedure = "CM Routines done as per CM Routines procedures";

            script = " Select replace(convert (varchar(11), H.nmdate, 13),' ','-') nmdateDisplay, U.PositionDesc, U.EqpUnitDescription as eqpname, mType, mPlace " + Environment.NewLine +
                     "    , mreason, miCond, mCompl, H.VerifiedBy, H.Verified, H.MMHRS, H.VslComments, H.SuptComments, MeasuredValue " + Environment.NewLine +
                     "    , case when LEN(ReportedByRank)>0 THEN ReportedByRank+' - '+ReportedByName ELSE ReportedByName END as DoneBy  " + Environment.NewLine +
                     "    , case when H.AddlIntField = 1  then '" + workDoneProcedure + "  ' + VslComments " + Environment.NewLine +
                     "           else VslComments  " + Environment.NewLine +
                     "      end as WorkDoneProcedure  " + Environment.NewLine +
                     "    , M.IntervalType, M.IntervalValue, case when(Verified =1) then 'Ok' when(Verified =0) then 'Not Accepted' when(Verified =-1) then '? (C/E or MAS Verify)'  else '' end   CE_MAS_Verify " + Environment.NewLine +
                     "    , case when (IsMaintPostponed>0) then  replace(convert (varchar(11), H.PostponeDate, 13),' ','-') else '' end as PostponeDateDisplay " + Environment.NewLine +
                     "    , replace(convert (varchar(11), H.MdueDATE, 13),' ','-') MdueDATEDisplay " + Environment.NewLine +
                     " from EQ_PmsHist H, EQ_Units U, EQ_Maintenance M  " + Environment.NewLine +
                     " where H.VesselID=U.VesselID and H.EQ_EquipmentID= U.EQ_EquipmentID and H.EQ_UnitsID=U.EQ_UnitsID    " + Environment.NewLine +
                     "    and U.VesselID =M.VesselID  and H.EQ_MaintenanceID =M.EQ_MaintenanceID   " + Environment.NewLine +
                     "    and H.EQ_UnitsID =U.EQ_UnitsID  " + Environment.NewLine +
                     "    and H.VesselId= " + curVesselID.ToString() + Environment.NewLine +
                     "    and H.EQ_UnitsID=" + curEQUnitID + Environment.NewLine +
                     "    and H.EQ_MaintenanceID =" + curEQMaintID + Environment.NewLine +
                     " order by H.NMdate desc, H.EQ_PmsHistID desc ";
            try
            {
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                Gfn.Eb("Failed to get PMS Maintenance History List for Export XLS");
                PG.AddToGenErrorLog("MaintHistory.cs", "GetExportDataTable", err.Message);
            }
            return (dt);
        }
    }
}
