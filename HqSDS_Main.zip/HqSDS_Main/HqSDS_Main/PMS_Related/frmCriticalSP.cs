﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmCriticalSP : Form
    {
        public int vesselID = -1;
        public string callMode = "";
        string groupType = "";

        const int COL_PRIORITY = 0,
                  COL_RQNREF = 1,
                  COL_PRCREATIONDATEDISPLAY = 2,
                  COL_STATUSSTRING = 3,
                  COL_EQPNAME = 4,
                  COL_TOTALCOST = 5,
                  COL_READINESSDATEDISPLAY = 6,
                  COL_RQNMASTERID = 7,
                  COL_PRCREATIONDATE = 8,
                  COL_READINESSDATE = 9,
                  COL_PROCSTATUSID = 10,
                  COL_EQEQUIPMENTID = 11,
                  COL_EQMODELSID = 12,
                  COL_ORIGIN = 13,
                  COL_EQ_UNITSID = 14,
                  COL_EQPTYPE = 15,
                  COL_EQPSUBTYPE = 16,
                  COL_PROC_SUBSTATUSID = 17;

        const int COL_RQNDETAILS_ORDQTY = 5,
                  COL_RQNDETAILS_APPRQTY = 6,
                  COL_RQNDETAILS_QTYRECVD = 7,
                  COL_RQNDETAILS_ISCRITICAL = 9;
        
        const int COL_ISCRITICAL = 0, COL_IsForSafety = 1, COL_IsForOPerational = 2, COL_IsForEnvironment = 3;

        public frmCriticalSP()
        {
            InitializeComponent();
        }

        private void frmCriticalSP_Load(object sender, EventArgs e)
        {
            Gfn.SetFormWidthAndHeight(this, 10, 10, 700, 1024);
            string vslname = PG.Gb.DBFn.Aqr("select vslName from v_vessels where vesselID=" + vesselID).ToString();

            Text = "Critical Spares";
            lblTitle.Text =vslname;

            PG.InitialiseVesselSettings(vesselID);

            groupType = PG.defaultEqpGroup;

            DesignCriticalSparesDetailsGrid();
            if (callMode.ToUpper() == "CriticalSPBelowMinQty".ToUpper())
            {  
                BindCriticalSparesDetailsGrid();
                splitContainer1.Visible = false;                
                lblFilter.Text = "Filter";
            }
            else if (callMode.ToUpper() == "CriticalSpRqns".ToUpper())
            {
                Text = "Critical Spares Requisitions";
                DesignRqnMasterGrid();
                DesignRqnDetailsDetails();
                BindCriticalSparesDetailsGrid();
                splitContainer1.Visible = true;
                lblFilter.Text = "Reqn No:";
            }
            this.Cursor = Cursors.Default;
        }

        private void DesignCriticalSparesDetailsGrid()
        {
            List<DgvInits> sparesColList = new List<DgvInits>();
            try
            {
                
                Color bkColor = Color.FromArgb(235, 255, 235);
                sparesColList.Add(new DgvInits("IsForNoGroup", "Is Critical", 0, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("IsForSafety", "Critical Safety", 41, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("IsForOPerational", "Critical Opertn", 50, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("IsForEnvironment", "Critical Envirmnt Health", 53, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));

                sparesColList.Add(new DgvInits("rqnRef", "Reqn No.", 125, Color.Black, Color.LightGray, false, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("StatusString", "Status", 100, Color.Black, Color.LightGray, false, true, bkColor, Color.Black));

                sparesColList.Add(new DgvInits("AssemblyName", "Equipment / Assembly", 160, Color.Black, SystemColors.ButtonFace, false, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("EqpName", "Equipment", 175, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("ItemDetail", "Part Name", 260, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("MakerCode", "Maker Code", 100, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("DwgNo", "DwgNo", 75, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("UOM", "uom", 32, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("ROB", "ROB", 35, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("WkgQty", "Total Wkg Qty", 55, Color.Black, SystemColors.ButtonFace, (!PG.isToHideSparesWkg_Qty), true, bkColor, Color.Black));
                
                sparesColList.Add(new DgvInits("MinQtyDisp", "Min Qty", 42, Color.Black, SystemColors.ButtonFace, (!PG.isToHideSparesMinQty), true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("MaxQtyDisp", "Max Qty", 45, Color.Black, SystemColors.ButtonFace, (!PG.isToHideSparesMaxQty), true, bkColor, Color.Black));
                sparesColList.Add(new DgvInits("Origin", "Origin", 55, Color.Black, SystemColors.ButtonFace, false, true));
                sparesColList.Add(new DgvInits("ItemCode", "Item Code", 90, Color.Black, SystemColors.ButtonFace, false, true));
                sparesColList.Add(new DgvInits("Proc_ItemMasterID", "Internal ID", 80, Color.Black, SystemColors.ButtonFace, false, true));
                sparesColList.Add(new DgvInits("Location", "Location", 150, Color.Black, SystemColors.ButtonFace, true, true, bkColor, Color.Black));

                fpSpread_CriticalSP.SuspendLayout();
                FarPtColCtrls.GenerateFarPointGridView(fpSpread_CriticalSP, sparesColList, null, false, true, true);

                if (PG.enableCriticalSparesFeature)
                {
                    FarPtColCtrls.AssignTextBoxColumnToFarPointGrid(fpSpread_CriticalSP, false, "IsForNoGroup", "Is Critical", COL_ISCRITICAL, 45, true, bkColor, true, 0);
                    FarPtColCtrls.AssignTextBoxColumnToFarPointGrid(fpSpread_CriticalSP, false, "IsForSafety", "Critical Safety", COL_IsForSafety, 41, true, bkColor, true, 0);
                    FarPtColCtrls.AssignTextBoxColumnToFarPointGrid(fpSpread_CriticalSP, false, "IsForOPerational", "Critical Opertn", COL_IsForOPerational, 49, true, bkColor, true, 0);
                    FarPtColCtrls.AssignTextBoxColumnToFarPointGrid(fpSpread_CriticalSP, false, "IsForEnvironment", "Critical Envirmnt Health", COL_IsForEnvironment, 53, true, bkColor, true, 0);

                    fpSpread_CriticalSP.ActiveSheet.Columns[COL_ISCRITICAL].Visible = false;
                    fpSpread_CriticalSP.ActiveSheet.Columns[COL_IsForSafety].Visible = false;
                    fpSpread_CriticalSP.ActiveSheet.Columns[COL_IsForOPerational].Visible = false;
                    fpSpread_CriticalSP.ActiveSheet.Columns[COL_IsForEnvironment].Visible = false;

                    if (!PG.isCriticalSparesGroups) fpSpread_CriticalSP.ActiveSheet.Columns[COL_ISCRITICAL].Visible = true;
                    else
                    {
                        fpSpread_CriticalSP.ActiveSheet.Columns[COL_IsForSafety].Visible = true;
                        fpSpread_CriticalSP.ActiveSheet.Columns[COL_IsForOPerational].Visible = true;
                        fpSpread_CriticalSP.ActiveSheet.Columns[COL_IsForEnvironment].Visible = true;
                    }
                }

                fpSpread_CriticalSP.ActiveSheet.Columns[12,17].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;
                fpSpread_CriticalSP.ActiveSheet.FrozenColumnCount = 6;                
                fpSpread_CriticalSP.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread_CriticalSP.ActiveSheet.ColumnHeader.Rows[0].Height = 40;
               // fpSpread_CriticalSP.ActiveSheet.DisplayZero = false;
                fpSpread_CriticalSP.ActiveSheet.RowHeader.Columns[0].Width = 15;
                fpSpread_CriticalSP.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                fpSpread_CriticalSP.ActiveSheet.Columns[COL_ISCRITICAL, COL_IsForEnvironment].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread_CriticalSP.ActiveSheet.Columns[COL_ISCRITICAL, COL_IsForEnvironment].AllowAutoSort = false;

            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmCriticalSP.cs", "DesignSparesDetailsGrid", err.Message);
            }
            finally
            {
                sparesColList = null;
                fpSpread_CriticalSP.ResumeLayout();
            }
        }

        private void DesignRqnMasterGrid()
        {
            List<DgvInits> colListRqnMaster = new List<DgvInits>();
            try
            {
                colListRqnMaster.Add(new DgvInits("Priority", "Priority", 45, Color.Black, Color.LightGray, true, true));
                colListRqnMaster.Add(new DgvInits("rqnRef", "Reqn No.", 140, Color.Black, Color.LightGray, true, true));
                colListRqnMaster.Add(new DgvInits("PRCreationDateDisplay", "Rqn Date", 90, Color.Black, Color.LightGray, true, true));
                colListRqnMaster.Add(new DgvInits("StatusString", "Status", 140, Color.Black, Color.LightGray, true, true));
                colListRqnMaster.Add(new DgvInits("EqpName", "Equipment", 330, Color.Black, Color.LightGray, true, true));
                colListRqnMaster.Add(new DgvInits("Total_cost", "Value $", 100, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("ReadinessDateDisplay", "Readiness Date", 100, Color.Black, Color.LightGray, true, true));
                colListRqnMaster.Add(new DgvInits("Proc_RqnMasterID", "InternalNo", 95, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("PRCreationDate", "PR Creation Date", 100, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("ReadinessDate", "Readiness Date", 100, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("Proc_StatusID", "Status", 40, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("EQ_EquipmentID", "EQ_EquipmentID", 40, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("EQ_ModelsID", "EQ_ModelsID", 40, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("Origin", "Origin", 40, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("EQ_UnitsID", "EQ_UnitsID", 40, Color.Black, Color.LightGray, false, true));
                colListRqnMaster.Add(new DgvInits("Proc_SubStatusID", "Proc_SubStatusID", 40, Color.Black, Color.LightGray, false, true));

                fpSpread_Master.SuspendLayout();
                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Master, colListRqnMaster, null, false, false, false);

                fpSpread_Master.ActiveSheet.RowHeader.Columns[0].Width = 15;
                fpSpread_Master.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread_Master.ActiveSheet.DisplayZero = false;
                FarPtColCtrls.AssignNumberTextBoxColumnToFarPointGrid(fpSpread_Master, false, "Total_cost", "Value (USD)", COL_TOTALCOST, FarPoint.Win.Spread.CellHorizontalAlignment.Right, 85, true, fpSpread_Master.ActiveSheet.Columns[COL_TOTALCOST].BackColor, true, 11, 2, ",");
            }
            finally
            {
                fpSpread_Master.ResumeLayout();
                colListRqnMaster = null;
            }
        }

        private void DesignRqnDetailsDetails()
        {
            List<DgvInits> colListRqnDetails = new List<DgvInits>();
            try
            {
                colListRqnDetails.Add(new DgvInits("LineItemNo", "#", 30, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("RItemDetail", "Part Name", 350, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("RMAKERCODE", "Maker Code", 100, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("RDwgNo", "DwgNo", 85, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("UOM", "UOM", 40, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("RqnQty", "Reqd", 35, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("ApprQty", "Appr", 35, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("QtyReceivedByVSL", "Qty Recvd", 65, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("ItemRemarks", "Deliv Remarks", 165, Color.Black, Color.LightGray, true, true));
                colListRqnDetails.Add(new DgvInits("IsCritical", "IsCritical", 125, Color.Black, Color.LightGray, false, true));
                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Details, colListRqnDetails, null, false, false, false);

                FarPtColCtrls.AssignNumberTextBoxColumnToFarPointGrid(fpSpread_Details, false, "RqnQty", "Reqd Qty", COL_RQNDETAILS_ORDQTY, FarPoint.Win.Spread.CellHorizontalAlignment.Right, 58, true, Color.Empty, true, 7, 4);
                FarPtColCtrls.AssignNumberTextBoxColumnToFarPointGrid(fpSpread_Details, false, "ApprQty", "Appr Qty", COL_RQNDETAILS_APPRQTY, FarPoint.Win.Spread.CellHorizontalAlignment.Right, 58, true, Color.Empty, true, 5, 4);
                FarPtColCtrls.AssignNumberTextBoxColumnToFarPointGrid(fpSpread_Details, false, "QtyReceivedByVSL", "Qty Recvd", COL_RQNDETAILS_QTYRECVD, FarPoint.Win.Spread.CellHorizontalAlignment.Right, 65, true, Color.Empty, true, 5, 4);

                fpSpread_Details.ActiveSheet.RowHeader.Visible = false;
                fpSpread_Details.ActiveSheet.GrayAreaBackColor = SystemColors.ButtonFace;
                fpSpread_Details.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
            }
            finally
            {
                colListRqnDetails = null;
            }
        }
        
        private void BindCriticalSparesDetailsGrid()
        {
            DataTable dt = null;
            fpSpread_CriticalSP.SuspendLayout();
            try
            {
                fpSpread_CriticalSP.ActiveSheet.RowCount = 0;
                fpSpread_Master.ActiveSheet.RowCount = 0;
                fpSpread_Details.ActiveSheet.RowCount = 0;
                ToolStripStatus.Text = "";

                if (callMode.ToUpper() == "CriticalSPBelowMinQty".ToUpper())
                {
                    dt = GetCriticalSPBelowMinQty();
                    fpSpread_CriticalSP.ActiveSheet.DataSource = dt;

                    if (fpSpread_CriticalSP.ActiveSheet.RowCount > 0)
                    {
                        fpSpread_CriticalSP.ActiveSheet.SetActiveCell(0, 0);
                        if (!PG.isCriticalSparesGroups)
                        {
                            for (int row = 0; row < fpSpread_CriticalSP.ActiveSheet.RowCount; row++)
                            {
                                if (fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_ISCRITICAL].Value != null && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_ISCRITICAL].Value.ToString() == "0")
                                {
                                    fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_ISCRITICAL].Text = "";
                                }
                            }
                        }
                        else
                        {
                            for (int row = 0; row < fpSpread_CriticalSP.ActiveSheet.RowCount; row++)
                            {
                                if (fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_ISCRITICAL].Value != null && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_ISCRITICAL].Value.ToString() == "0"
                                    && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_IsForSafety].Value != null && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_IsForSafety].Value.ToString() == "0"
                                    && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_IsForOPerational].Value != null && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_IsForOPerational].Value.ToString() == "0"
                                    && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_IsForEnvironment].Value != null && fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_IsForEnvironment].Value.ToString() == "0")
                                {
                                    fpSpread_CriticalSP.ActiveSheet.Cells[row, COL_ISCRITICAL, row, COL_IsForEnvironment].Text = "";
                                }
                            }
                        }
                    }
                    fpSpread_CriticalSP_ColumnWidthChanged(null, null);
                }
                else
                {
                    dt = GetRqnMasterDataTable();
                    fpSpread_Master.ActiveSheet.DataSource = dt;
                    fpSpread_Master_SelectionChanged(null, null);
                }

                ToolStripStatus.Text = "No Records Found";
                if (dt != null && dt.Rows.Count > 0)
                {
                    ToolStripStatus.Text = "Total Item(s) = " + dt.Rows.Count;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmCriticalSP.cs", "BindCriticalSparesDetailsGrid", callMode + " - " + err.Message);
            }
            finally
            {
                fpSpread_CriticalSP.ResumeLayout();
            }
        }

        public DataTable GetCriticalSPBelowMinQty()
        {
            string basicSql = "", addlCondition = "", orderByClause = "", addlFields = "";
            DataTable dt = null;
            try
            {
                addlFields = "    , isnull(( select  case when (IsForNoGroup =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForNoGroup " +
                             "    , 0 as IsForSafety, 0 as IsForOperational, 0 as IsForEnvironment " + Environment.NewLine;
                
                if (PG.isCriticalSparesGroups)
                {
                    addlFields = "    , 0 as IsForNoGroup, isnull(( select  case when (IsForSafety =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForSafety " + Environment.NewLine +
                                 "    , isnull(( select case when (IsForOperational =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForOperational " + Environment.NewLine +
                                 "    , isnull(( select case when (IsForEnvironment =1) then 'Yes' else ' ' end from Proc_ItemMaster_Critical where VesselID = M.VesselID and Proc_ItemMasterID = M.Proc_ItemMasterID),0) as IsForEnvironment " + Environment.NewLine;
                }

                basicSql = " select  '' as rqnRef " + Environment.NewLine +
                           "    , '' as Proc_StatusID " + Environment.NewLine +
                           "    , '' as StatusString " + Environment.NewLine +
                           "    , (select top 1 E.GroupSortOrder from EQ_Equipment_V E, EQ_Units U where U.IsDisabled=0 and E.EQ_EquipmentID=U.EQ_EquipmentID  and E.GroupType='" + groupType + "' and U.VesselID=M.VesselId and U.EqpType=M.EqpType and U.EqpSubType=M.EqpSubType and U.EQ_ModelsID=M.EQ_ModelsID ) as GroupSortOrder " +
                           "    , (select top 1 (EqpUnitDescription + ' ' + PositionDesc) from EQ_Units where IsDisabled=0 and VesselID=M.VesselId and EqpType=M.EqpType and EqpSubType=M.EqpSubType and EQ_ModelsID=M.EQ_ModelsID ) as EqpName " +
                           "    , AssemblyName, ItemDetail, MakerCode, DwgNo, UOM, ROB, WkgQty, MinQty, MaxQty, M.Origin, ItemCode, M.Proc_ItemMasterID, Location" +
                            addlFields +
                           "    , case when (I.MinQty =0) then null else I.MinQty end MinQtyDisp " + Environment.NewLine +
                           "    , case when (I.MaxQty =0) then null else I.MaxQty end MaxQtyDisp " + Environment.NewLine +
                           " from Proc_ItemMaster_V M, Proc_Inventory I " + Environment.NewLine +
                           " Where M.VesselID = I.VesselID  " + Environment.NewLine +
                           "    and M.Proc_ItemMasterID= I.Proc_ItemMasterID " + Environment.NewLine +
                           "    and M.VesselID= " + vesselID +
                           "    and ROB<(MinQty + " + PG.criticalSpAlert_NoOfQtyToAddWithMinQty + ") " + Environment.NewLine +
                           "    and M.Proc_ItemMasterID  not in (Select Proc_ItemMasterID from Proc_ItemMaster_ExcludeFromROBAlert where VesselID = M.VesselID and IsDisabled = 0)" + 
                           "    and M.IsCritical= 1 " + Environment.NewLine +
                           "    and exists (select * from EQ_Units where IsDisabled=0 and VesselID=M.VesselId and EqpType=M.EqpType and EqpSubType=M.EqpSubType and EQ_ModelsID = M.EQ_ModelsID) " + Environment.NewLine +
                           "    and not exists (select * from Proc_RqnDetails D, SP_Register_V X " +
                           "            where D.VesselId=X.VesselID and D.Proc_RqnMasterID=X.Proc_RqnMasterID and D.VesselId=M.VesselID and D.Proc_ItemMasterID=M.Proc_ItemMasterID and X.Proc_StatusID not in (70,80) and D.ApprQty >0)";
              
                if (txtFilter.Text.Trim().Length > 0)
                {
                    addlCondition = addlCondition + "    and (   ( " + PG.GetSearchCombination(" ItemDetail ", txtFilter.Text.Trim()) + " ) " +
                                                    "         or ( " + PG.GetSearchCombination(" MakerCode ", txtFilter.Text.Trim()) + " )  " +
                                                    "         or ( " + PG.GetSearchCombination(" DwgNo ", txtFilter.Text.Trim()) + " )  " +
                                                    "         or ( " + PG.GetSearchCombination(" AssemblyName ", txtFilter.Text.Trim()) + " )  " +
                                                    "         or ( " + PG.GetSearchCombination(" (select top 1 EqpUnitDescription from EQ_Units  where IsDisabled=0 and VesselID=M.VesselId and EqpType=M.EqpType and EqpSubType=M.EqpSubType and EQ_ModelsID=M.EQ_ModelsID ) ", txtFilter.Text.Trim()) + " )  " +
                                                    "        )  ";
                }

                orderByClause = "  order by 4 ";
                string sqlScript = basicSql + addlCondition + orderByClause;
                dt = PG.Gb.DBFn.DbRecords(sqlScript);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmCriticalSP.cs", "GetCriticalSPBelowMinQty", callMode + " - " + err.Message);
            }

            return (dt);
        }

        public DataTable GetRqnMasterDataTable()
        {
            string sqlScript = "";
            DataTable dt = null;
            try
            {
                // Reqn ref filter
                string reqnRefFilter = txtFilter.Text.Trim();
                reqnRefFilter = reqnRefFilter.Substring(reqnRefFilter.IndexOf("-") + 1).Replace("-", "");
                if (reqnRefFilter.Trim().Length > 0) reqnRefFilter = " and (replace(M.ProcCode, '-','')  like '%" + reqnRefFilter + "%')";

                sqlScript = " select distinct M.Origin, M.Proc_RqnMasterID, M.ProcCode, X.EqpName, M.Priority, X.RqnRef, X.SubStatusString as StatusString " + Environment.NewLine +
                            "     , M.PRCreationDate, X.PRCreationDateDisplay,  M.ReadinessDate,  X.ReadinessDateDisplay " + Environment.NewLine +
                            "     , Convert(Decimal(20,2),((M.TOTALCOST*M.CurrencyEX) + (M.DELVCHARGE * M.CurrencyEX) - (M.Disct_Amount*M.CurrencyEX))) as Total_cost " + Environment.NewLine +
                            "     , M.Proc_StatusID, M.Proc_SubStatusID, M.VesselId, M.EQ_EquipmentID " + Environment.NewLine +
                            " FROM Proc_RqnMaster M, Proc_RqnDetails D, SP_Register_V X, Proc_ItemMaster M1" + Environment.NewLine +
                            " where  M.VesselID=D.VesselID and M.Proc_RqnMasterID=D.Proc_RqnMasterID  " + Environment.NewLine +
                            "    and M.VesselId=X.VesselID and M.Proc_RqnMasterID=X.Proc_RqnMasterID " + Environment.NewLine +
                            "    and D.VesselId=M1.VesselID and D.Proc_ItemMasterID=M1.Proc_ItemMasterID " + Environment.NewLine +
                            "    and M.Category='SP' and M.VesselId=" + vesselID + Environment.NewLine +
                            "    and M1.IsCritical= 1 " + Environment.NewLine +
                            "    and M.Proc_StatusID not in (70, 80) " + Environment.NewLine +
                            "    and D.ApprQty <> isnull((select QtyReceived from Proc_Receipts where VesselID = D.VesselID and Proc_RqnMasterID = D.Proc_RqnMasterID and Proc_RqnDetailsID = D.Proc_RqnDetailsID),0) ";

                string orderClause = " Order by M.Proc_StatusID ";
                if (reqnRefFilter.Trim().Length > 0) sqlScript = sqlScript + reqnRefFilter;

                sqlScript = sqlScript + orderClause;

                dt = PG.Gb.DBFn.DbRecords(sqlScript);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmCriticalSP.cs", "GetCriticalSpRqns", callMode + " - " + err.Message);
            }

            return (dt);
        }

        private void fpSpread_CriticalSP_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpread_CriticalSP.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void fpSpread_Master_SelectionChanged(object sender, FarPoint.Win.Spread.SelectionChangedEventArgs e)
        {
            BindRqnDetails();
        }

        private void BindRqnDetails()
        {
            if (fpSpread_Master.ActiveSheet.ActiveCell == null) return;
            DataTable dt = null;
            try
            {
                int rowIndex = fpSpread_Master.ActiveSheet.ActiveRowIndex;
                string rqnMasterId = fpSpread_Master.ActiveSheet.Cells[rowIndex, COL_RQNMASTERID].Value.ToString();
                long procStatusId = -1;
                string sx = fpSpread_Master.ActiveSheet.Cells[rowIndex, COL_PROCSTATUSID].Value.ToString();
                if (sx.Length > 0) procStatusId = Convert.ToInt64(sx);

                fpSpread_Details.SuspendLayout();
                fpSpread_Details.ActiveSheet.RowCount = 0;

                dt = GetRqnDetailsDataTable(rqnMasterId, procStatusId);
                fpSpread_Details.DataSource = dt;

                for (int row = 0; row < fpSpread_Details.ActiveSheet.RowCount; row++)
                {
                    if (fpSpread_Details.ActiveSheet.Cells[row, COL_RQNDETAILS_ISCRITICAL].Value != null && fpSpread_Details.ActiveSheet.Cells[row, COL_RQNDETAILS_ISCRITICAL].Value.ToString() == "1")
                    {
                        fpSpread_Details.ActiveSheet.Rows[row].ForeColor = Color.FromArgb(255, 0, 255);
                    }
                }

                fpSpread_Details_ColumnWidthChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmCriticalSP.cs", "BindRqnDetails", err.Message);
            }
            finally
            {
                fpSpread_Details.ResumeLayout();
            }
        }

        private DataTable GetRqnDetailsDataTable(string proc_RqnMasterIDStr, long procStatusId)
        {
            DataTable dt = null;
            try
            {
                string script = " SELECT OriginalLineItemNo as LineItemNo, RItemCode, RMAKERCODE, RDwgNo, UOM, OrdQty, ApprQty, RqnQty " + Environment.NewLine +
                                "    , (Select isNull(sum(isNull(QtyReceived,0)),0) from Proc_Receipts " + Environment.NewLine +
                                "       where VesselID=D.VesselId " + Environment.NewLine +
                                "         and Proc_RqnMasterID=" + Gfn.Qs(proc_RqnMasterIDStr) +
                                "         and Proc_RqnDetailsId=D.Proc_RqnDetailsId) as QtyReceivedByVSL, '' as ItemRemarks, AssemblyName " + Environment.NewLine +
                                "    , RItemDetail + " + Environment.NewLine +
                                "      case when LEN(LTRIM(RTRIM(AssemblyName)))> 0 then CHAR(13)+CHAR(10)+ '(AssemblyName: '+ AssemblyName + ')' else '' end +   " + Environment.NewLine +
                                "      case when LEN(LTRIM(RTRIM(ItemRemarks)))> 0 then CHAR(13)+CHAR(10)+ '(Vendor Remarks: '+ ItemRemarks + ')' else '' end as RItemDetail  " + Environment.NewLine +
                                "    , isnull((Select IsCritical from Proc_ItemMaster where VesselID=D.VesselId and Proc_ItemMasterID=D.Proc_ItemMasterID),0) as IsCritical " + Environment.NewLine +
                                " FROM Proc_RqnDetails D " +
                                " WHERE VesselId= " + vesselID+ " and  Proc_RqnMasterId=" + Gfn.Qs(proc_RqnMasterIDStr);
                string orderClause = " order by D.OriginalLineItemNo";

                script = script + orderClause;
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                Gfn.Wb("Failed to get requisition item details");
                PG.AddToGenErrorLog("frmCriticalSP.cs", "GetRqnDetailsDataTable", err.Message);
            }
            return dt;
        }

        private void fpSpread_Details_ColumnWidthChanged(object sender, FarPoint.Win.Spread.ColumnWidthChangedEventArgs e)
        {
            foreach (FarPoint.Win.Spread.Row row in fpSpread_Details.ActiveSheet.Rows)
            {
                row.Height = row.GetPreferredHeight();
            }
        }

        private void fpSpread_Details_MouseDown(object sender, MouseEventArgs e)
        {
            if (fpSpread_Details.ActiveSheet.RowCount > 0) fpSpread_Details.ActiveSheet.Cells[0, 0, fpSpread_Details.ActiveSheet.RowCount - 1, fpSpread_Details.ActiveSheet.ColumnCount - 1].ResetBackColor();
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread_Details.HitTest(e.X, e.Y).ViewportInfo == null) return;
                int row = fpSpread_Details.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread_Details.HitTest(e.X, e.Y).ViewportInfo.Column;
                if ((row < 0) || (col < 0)) return;

                fpSpread_Details.ActiveSheet.SetActiveCell(row, col);

                fpSpread_Details.ActiveSheet.Cells[row, 0, row, fpSpread_Details.ActiveSheet.ColumnCount - 1].BackColor = fpSpread_Details.ActiveSheet.SelectionBackColor;
            }
        }

        private void btnLocate_Click(object sender, EventArgs e)
        {
            BindCriticalSparesDetailsGrid();
        }

        private void txtFilter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) BindCriticalSparesDetailsGrid();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFilter.Text = "";
            BindCriticalSparesDetailsGrid();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Close();
        }
    }
}
