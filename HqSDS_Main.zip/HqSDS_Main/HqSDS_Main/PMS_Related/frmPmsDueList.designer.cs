﻿namespace HqSDS_Main
{
    partial class frmPmsDueList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer1 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer1 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle1 = new FarPoint.Win.Spread.NamedStyle("ColumnHeaderSunburst");
            FarPoint.Win.Spread.NamedStyle namedStyle2 = new FarPoint.Win.Spread.NamedStyle("RowHeaderSunburst");
            FarPoint.Win.Spread.NamedStyle namedStyle3 = new FarPoint.Win.Spread.NamedStyle("CornerSunburst");
            FarPoint.Win.Spread.CellType.EnhancedCornerRenderer enhancedCornerRenderer1 = new FarPoint.Win.Spread.CellType.EnhancedCornerRenderer();
            FarPoint.Win.Spread.NamedStyle namedStyle4 = new FarPoint.Win.Spread.NamedStyle("DataAreaDefault");
            FarPoint.Win.Spread.CellType.GeneralCellType generalCellType1 = new FarPoint.Win.Spread.CellType.GeneralCellType();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer2 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.ToolStripStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.fpSpread_PMS = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread_PMS_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkShowLinkedMaintenance = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTotalOutstanding = new System.Windows.Forms.Label();
            this.lblTotalDoneMaint = new System.Windows.Forms.Label();
            this.lblTotalPlannedMaint = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnGo = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_PMS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_PMS_Sheet1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(839, 541);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.statusStrip1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 512);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(831, 25);
            this.panel3.TabIndex = 2;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(831, 25);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // ToolStripStatus
            // 
            this.ToolStripStatus.Name = "ToolStripStatus";
            this.ToolStripStatus.Size = new System.Drawing.Size(19, 20);
            this.ToolStripStatus.Text = "....";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.fpSpread_PMS);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(4, 56);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(831, 449);
            this.panel1.TabIndex = 0;
            // 
            // fpSpread_PMS
            // 
            this.fpSpread_PMS.AccessibleDescription = "fpSpread_PMS, Sheet1, Row 0, Column 0, ";
            this.fpSpread_PMS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread_PMS.FocusRenderer = defaultFocusIndicatorRenderer1;
            this.fpSpread_PMS.Font = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_PMS.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_PMS.HorizontalScrollBar.Name = "";
            this.fpSpread_PMS.HorizontalScrollBar.Renderer = defaultScrollBarRenderer1;
            this.fpSpread_PMS.HorizontalScrollBar.TabIndex = 0;
            this.fpSpread_PMS.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread_PMS.Location = new System.Drawing.Point(0, 0);
            this.fpSpread_PMS.Name = "fpSpread_PMS";
            namedStyle1.BackColor = System.Drawing.Color.DarkOrange;
            namedStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle1.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle1.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle1.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle2.BackColor = System.Drawing.Color.DarkOrange;
            namedStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle2.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle2.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle2.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle3.BackColor = System.Drawing.Color.OrangeRed;
            namedStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            namedStyle3.HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
            namedStyle3.NoteIndicatorColor = System.Drawing.Color.Red;
            enhancedCornerRenderer1.ActiveBackgroundColor = System.Drawing.Color.OrangeRed;
            enhancedCornerRenderer1.GridLineColor = System.Drawing.Color.Empty;
            enhancedCornerRenderer1.NormalBackgroundColor = System.Drawing.Color.Orange;
            namedStyle3.Renderer = enhancedCornerRenderer1;
            namedStyle3.VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
            namedStyle4.BackColor = System.Drawing.SystemColors.Window;
            namedStyle4.CellType = generalCellType1;
            namedStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            namedStyle4.NoteIndicatorColor = System.Drawing.Color.Red;
            namedStyle4.Renderer = generalCellType1;
            this.fpSpread_PMS.NamedStyles.AddRange(new FarPoint.Win.Spread.NamedStyle[] {
            namedStyle1,
            namedStyle2,
            namedStyle3,
            namedStyle4});
            this.fpSpread_PMS.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread_PMS_Sheet1});
            this.fpSpread_PMS.Size = new System.Drawing.Size(831, 449);
            this.fpSpread_PMS.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread_PMS.TabIndex = 14;
            this.fpSpread_PMS.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread_PMS.VerticalScrollBar.Name = "";
            this.fpSpread_PMS.VerticalScrollBar.Renderer = defaultScrollBarRenderer2;
            this.fpSpread_PMS.VerticalScrollBar.TabIndex = 11;
            this.fpSpread_PMS.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded;
            this.fpSpread_PMS.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread_PMS.CellClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread_PMS_CellClick);
            this.fpSpread_PMS.AutoSortingColumn += new FarPoint.Win.Spread.AutoSortingColumnEventHandler(this.fpSpread_PMS_AutoSortingColumn);
            // 
            // fpSpread_PMS_Sheet1
            // 
            this.fpSpread_PMS_Sheet1.Reset();
            this.fpSpread_PMS_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread_PMS_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread_PMS_Sheet1.ColumnCount = 5;
            this.fpSpread_PMS_Sheet1.RowCount = 5;
            this.fpSpread_PMS_Sheet1.AllowNoteEdit = false;
            this.fpSpread_PMS_Sheet1.AutoCalculation = false;
            this.fpSpread_PMS_Sheet1.AutoGenerateColumns = false;
            this.fpSpread_PMS_Sheet1.AutoSortFrozenRows = false;
            this.fpSpread_PMS_Sheet1.AutoSortTrailingFrozenRows = false;
            this.fpSpread_PMS_Sheet1.AutoUpdateNotes = false;
            this.fpSpread_PMS_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_PMS_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_PMS_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_PMS_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_PMS_Sheet1.ColumnHeader.DefaultStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_PMS_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_PMS_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread_PMS_Sheet1.DataAutoSizeColumns = false;
            this.fpSpread_PMS_Sheet1.GrayAreaBackColor = System.Drawing.Color.White;
            this.fpSpread_PMS_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
            this.fpSpread_PMS_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_PMS_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread_PMS_Sheet1.RowHeader.Visible = false;
            this.fpSpread_PMS_Sheet1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(227)))), ((int)(((byte)(254)))));
            this.fpSpread_PMS_Sheet1.SelectionFont = new System.Drawing.Font("Verdana", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread_PMS_Sheet1.SelectionPolicy = FarPoint.Win.Spread.Model.SelectionPolicy.Single;
            this.fpSpread_PMS_Sheet1.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors;
            this.fpSpread_PMS_Sheet1.SelectionUnit = FarPoint.Win.Spread.Model.SelectionUnit.Row;
            this.fpSpread_PMS_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread_PMS_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread_PMS_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.YellowGreen);
            this.fpSpread_PMS_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chkShowLinkedMaintenance);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblTotalOutstanding);
            this.panel2.Controls.Add(this.lblTotalDoneMaint);
            this.panel2.Controls.Add(this.lblTotalPlannedMaint);
            this.panel2.Controls.Add(this.btnClear);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.btnGo);
            this.panel2.Controls.Add(this.txtSearch);
            this.panel2.Controls.Add(this.lblTitle);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(837, 51);
            this.panel2.TabIndex = 3;
            // 
            // chkShowLinkedMaintenance
            // 
            this.chkShowLinkedMaintenance.AutoSize = true;
            this.chkShowLinkedMaintenance.Location = new System.Drawing.Point(594, 30);
            this.chkShowLinkedMaintenance.Name = "chkShowLinkedMaintenance";
            this.chkShowLinkedMaintenance.Size = new System.Drawing.Size(173, 17);
            this.chkShowLinkedMaintenance.TabIndex = 87;
            this.chkShowLinkedMaintenance.Text = "Show Associated Maintenance";
            this.chkShowLinkedMaintenance.UseVisualStyleBackColor = true;
            this.chkShowLinkedMaintenance.CheckedChanged += new System.EventHandler(this.chkShowLinkedMaintenance_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 14);
            this.label4.TabIndex = 86;
            this.label4.Text = "Vessel Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(298, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 85;
            this.label1.Text = "Total Outstanding %:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(297, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 84;
            this.label2.Text = "Total Overdue Items:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(262, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 13);
            this.label3.TabIndex = 83;
            this.label3.Text = "Total Planned Maintenance:";
            // 
            // lblTotalOutstanding
            // 
            this.lblTotalOutstanding.AutoSize = true;
            this.lblTotalOutstanding.ForeColor = System.Drawing.Color.Blue;
            this.lblTotalOutstanding.Location = new System.Drawing.Point(403, 34);
            this.lblTotalOutstanding.Name = "lblTotalOutstanding";
            this.lblTotalOutstanding.Size = new System.Drawing.Size(19, 13);
            this.lblTotalOutstanding.TabIndex = 82;
            this.lblTotalOutstanding.Text = "....";
            // 
            // lblTotalDoneMaint
            // 
            this.lblTotalDoneMaint.AutoSize = true;
            this.lblTotalDoneMaint.ForeColor = System.Drawing.Color.Blue;
            this.lblTotalDoneMaint.Location = new System.Drawing.Point(403, 19);
            this.lblTotalDoneMaint.Name = "lblTotalDoneMaint";
            this.lblTotalDoneMaint.Size = new System.Drawing.Size(19, 13);
            this.lblTotalDoneMaint.TabIndex = 81;
            this.lblTotalDoneMaint.Text = "....";
            // 
            // lblTotalPlannedMaint
            // 
            this.lblTotalPlannedMaint.AutoSize = true;
            this.lblTotalPlannedMaint.ForeColor = System.Drawing.Color.Blue;
            this.lblTotalPlannedMaint.Location = new System.Drawing.Point(403, 5);
            this.lblTotalPlannedMaint.Name = "lblTotalPlannedMaint";
            this.lblTotalPlannedMaint.Size = new System.Drawing.Size(19, 13);
            this.lblTotalPlannedMaint.TabIndex = 80;
            this.lblTotalPlannedMaint.Text = "....";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnClear.Location = new System.Drawing.Point(788, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(39, 22);
            this.btnClear.TabIndex = 77;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(591, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 13);
            this.label12.TabIndex = 76;
            this.label12.Text = "Filter:";
            // 
            // btnGo
            // 
            this.btnGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btnGo.Location = new System.Drawing.Point(760, 4);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(29, 22);
            this.btnGo.TabIndex = 75;
            this.btnGo.Text = "Go";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtSearch.Location = new System.Drawing.Point(626, 5);
            this.txtSearch.MaxLength = 30;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(132, 20);
            this.txtSearch.TabIndex = 74;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Blue;
            this.lblTitle.Location = new System.Drawing.Point(11, 28);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(32, 13);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Title";
            // 
            // frmPmsDueList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 541);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmPmsDueList";
            this.Text = "PMS Due List";
            this.Load += new System.EventHandler(this.frmPmsDueList_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_PMS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread_PMS_Sheet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel ToolStripStatus;
        private FarPoint.Win.Spread.FpSpread fpSpread_PMS;
        private FarPoint.Win.Spread.SheetView fpSpread_PMS_Sheet1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblTotalDoneMaint;
        private System.Windows.Forms.Label lblTotalPlannedMaint;
        private System.Windows.Forms.Label lblTotalOutstanding;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkShowLinkedMaintenance;
    }
}