﻿using System;
using System.Data;
using System.Collections;
using System.Windows.Forms;

using Sds.CommonV1;


namespace HqSDS_Main
{
    class Common
    {
        public Common()
        {
            InitialiseVslStatus();
        }

        public void BindVslDropDownList(ComboBox cboBox, string companyID, bool isToAddAllUser)
        {
            ArrayList objArrLst = new ArrayList();
            try
            {
                objArrLst = GetVslFilterArrayList(companyID, isToAddAllUser);

                cboBox.DisplayMember = "Key";
                cboBox.ValueMember = "Value";
                cboBox.DataSource = objArrLst;

                // Note :Default to CurrentUser - Vsl Selection 
                if (cboBox.Items.Count > 0)
                {   
                    cboBox.SelectedValue = "user-" + PG.Gb.User.CurUserID;
                    if (cboBox.SelectedIndex <= 0) cboBox.SelectedIndex = 0;                    
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "BindVslDropDownList", err.Message);
            }
            finally
            {
                objArrLst = null;
            }
        }

        public ArrayList GetVslFilterArrayList(string companyID, bool isToAddAllUser)
        {
            string userId = "";
            DataTable dt = null, dtUser = null;
            ArrayList objArr = new ArrayList();
            try
            {
                string script = " select isnull(Ltrim(RTrim(settingValue)),'') from Proc_settings " +
                                " where C_CompanyID = " + companyID +
                                "   and ltrim(Rtrim(settingName))='ShowOnlyOwnVsls_UserList_InVslFilter'";
                string userIDListToShowCurrentUserOnly = PG.Gb.DBFn.Aqr(script).ToString().Trim();

                bool isToShowCurrentUserOnly = Gfn.IsStringExistsCommaSeparatedString(userIDListToShowCurrentUserOnly, PG.Gb.User.CurUserID);
                string addlCond = "";
                if (isToShowCurrentUserOnly)
                {
                    addlCond = "  and U.UserId = " + Gfn.Qss(PG.Gb.User.CurUserID);
                }
                else
                {
                    #region Group / Ops By
                    script = " select distinct G.GroupCode, GroupName, G.V_Op_GroupsID, G.SortOrder " +
                             " from V_Vessels V, V_Op_Groups_VSL_I I, V_Op_Groups G " +
                             " where V.VesselID=I.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID " +
                             "    and V.C_CompanyID = G.C_CompanyID";
                    if (PG.isToEnableThirdPartyVesselsFeature)
                    {
                        script = script + " and G.GroupCode not in ('ALL') ";
                    }
                    else
                    {
                        script = script + " and G.GroupCode not in ('ALL','" + PG.THIRDPARTYVSL + "') ";
                    }

                    if (!PG.userAllowedToSeeTrainVsl)
                    {
                        script = script + " and not exists (select * from v_Trainee where VesselID=V.VesselID) ";
                    }

                    if (companyID.Trim().Length > 0 && companyID != "-99")
                    {
                        script = script + "    and V.C_CompanyID=" + companyID;
                    }

                    script = script + " order by G.SortOrder, GroupName, G.V_Op_GroupsID";
                    dt = PG.Gb.DBFn.DbRecords(script);

                    objArr.Insert(0, new DictionaryEntry("All Vessels", "-1"));

                    if (dt != null)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string svsl = dt.Rows[i]["GroupName"].ToString();
                            objArr.Add(new DictionaryEntry(svsl, dt.Rows[i]["V_Op_GroupsID"].ToString()));
                        }
                        objArr.Add(new DictionaryEntry("OPS BY HQ", "-3"));
                        objArr.Add(new DictionaryEntry("OPS BY VSL", "-2"));
                        objArr.Add(new DictionaryEntry("RETIRED VSLS", "-4"));
                    } 
                    #endregion
                }

                // Add all User has Vsl Selection 
                if (PG.usersToHideShowinVslFilterList.Trim().Length > 0)
                {
                    addlCond = addlCond + " and U.UserId not in('" + PG.usersToHideShowinVslFilterList.Trim().Replace(",", "','") + "')";
                }

                // Exclude roles
                addlCond = addlCond + " and U.Role not in ('GENMANAGER', 'ADMINISTRATOR', 'HQTRAINEE', 'VSLTRAINEE', 'VENDOR') ";

                if (companyID.Trim().Length > 0 && companyID != "-99")
                {
                    addlCond = addlCond + "    and U.C_CompanyID=" + companyID;
                }

                script = " select distinct V.UserID, U.Role, U.sortOrder, R.ShortCodeForDisplay, U.HQDept " +
                         " from Proc_UserDisplayVsls V, HQ_Users_V U , HQ_UserRoles R " +
                         " where V.UserID=U.UserId and U.Role=R.UserRole and U.HQDept=R.HQDept " + addlCond +
                         "    and V.C_CompanyID = U.C_CompanyID " +
                         "    and V.VesselID in (Select VesselID from V_Vessels) " +
                         " order by U.sortOrder, U.Role, U.HQDept, V.UserID ";
                dtUser = PG.Gb.DBFn.DbRecords(script);
                if (dtUser != null)
                {
                    string displayStr, shortCodeDisplay;
                    foreach (DataRow dr in dtUser.Rows)
                    {
                        userId = dr["UserID"].ToString();
                        shortCodeDisplay = dr["ShortCodeForDisplay"].ToString();
                        displayStr = shortCodeDisplay.PadRight(6, ' ');
                        objArr.Add(new DictionaryEntry(displayStr + " - " + userId, "user-" + userId));
                    }
                }
                dtUser = null;
            }
            catch (Exception err)
            {
                objArr = null;
                PG.AddToGenErrorLog("MainPage.cs", "GetVslFilterArrayList", err.Message);
            }
            finally
            {
                dt = null;
                dtUser = null;
            }
            return (objArr);
        }


        public void BindVslDropDownList_MarineDept(ComboBox cboBox, bool isToAddAllUser, string companyID)
        {
            ArrayList objArrLst = new ArrayList();
            try
            {
                objArrLst = GetVslFilterArrayList_MarineDept(isToAddAllUser, companyID, PG.HSQE_DeptName);
                cboBox.DisplayMember = "Key";
                cboBox.ValueMember = "Value";
                cboBox.DataSource = objArrLst;

                // Note :Default to CurrentUser - Vsl Selection 
                if (cboBox.Items.Count > 0)
                {
                    cboBox.SelectedValue = "user-" + PG.Gb.User.CurUserID;
                    if (cboBox.SelectedIndex <= 0) cboBox.SelectedIndex = 0;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "BindVslDropDownList_MarineDept", err.Message);
            }
            finally
            {
                objArrLst = null;
            }
        }

        public void BindVslDropDownList_CrewDept(ComboBox cboBox, bool isToAddAllUser, string companyID)
        {
            ArrayList objArrLst = new ArrayList();
            try
            {
                objArrLst = GetVslFilterArrayList_MarineDept(isToAddAllUser, companyID, "Crew");
                cboBox.DisplayMember = "Key";
                cboBox.ValueMember = "Value";
                cboBox.DataSource = objArrLst;

                // Note :Default to CurrentUser - Vsl Selection 
                if (cboBox.Items.Count > 0)
                {
                    cboBox.SelectedValue = "user-" + PG.Gb.User.CurUserID;
                    if (cboBox.SelectedIndex <= 0) cboBox.SelectedIndex = 0;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "BindVslDropDownList", err.Message);
            }
            finally
            {
                objArrLst = null;
            }
        }

        public ArrayList GetVslFilterArrayList_MarineDept(bool isToAddAllUser, string companyID, string hqDept)
        {
            string userId = "";
            DataTable dt = null, dtUser = null;
            ArrayList objArr = new ArrayList();
            try
            {
                string script = " select isnull(Ltrim(RTrim(settingValue)),'') from Proc_settings " +
                               " where C_CompanyID = " + companyID +
                               "   and ltrim(Rtrim(settingName))='ShowOnlyOwnVsls_UserList_InVslFilter'";
                string userIDListToShowCurrentUserOnly = PG.Gb.DBFn.Aqr(script).ToString().Trim();

                bool isToShowCurrentUserOnly = Gfn.IsStringExistsCommaSeparatedString(userIDListToShowCurrentUserOnly, PG.Gb.User.CurUserID);
                string addlCond = "";
                if (isToShowCurrentUserOnly)
                {
                    addlCond = "  and U.UserId = " + Gfn.Qss(PG.Gb.User.CurUserID);
                }
                else
                {
                    // Add Vsl Groups in operation
                    script = " select distinct G.GroupCode, GroupName, G.V_Op_GroupsID, G.SortOrder " +
                             " from V_Vessels V, V_Op_Groups_VSL_I I, V_Op_Groups G " +
                             " where V.VesselID=I.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID " +
                             "   and V.C_CompanyID = G.C_CompanyID " +
                             "   and G.GroupCode not in ('ALL','" + PG.THIRDPARTYVSL + "') ";
                    if (!PG.userAllowedToSeeTrainVsl)
                    {
                        script = script + " and not exists (select * from v_Trainee where VesselID=V.VesselID) ";
                    }
                    if (companyID != "-99")
                    {
                        script = script + " and V.C_CompanyID=" + companyID;
                    }
                    script = script + " order by G.SortOrder, GroupName, G.V_Op_GroupsID";
                    dt = PG.Gb.DBFn.DbRecords(script);

                    objArr.Insert(0, new DictionaryEntry("All Vessels", "-1"));

                    if (dt != null)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string svsl = dt.Rows[i]["GroupName"].ToString();
                            objArr.Add(new DictionaryEntry(svsl, dt.Rows[i]["V_Op_GroupsID"].ToString()));
                        }
                        objArr.Add(new DictionaryEntry("OPS BY HQ", "-3"));
                        objArr.Add(new DictionaryEntry("OPS BY VSL", "-2"));
                        objArr.Add(new DictionaryEntry("RETIRED VSLS", "-4"));
                    }

                    string hqDeptCond = "";
                    if (hqDept.Trim().ToUpper() == PG.HSQE_DeptName.ToUpper()) hqDeptCond = "  U.HQDept in ('" + PG.HSQE_DeptName + "', 'HSQE') or ";
                    else if (hqDept.Trim().Length > 0) hqDeptCond = " U.HQDept='" + hqDept + "' or ";
                    addlCond = addlCond + "    and (" + hqDeptCond + " U.Role in ('Director','ViewOnly') ) ";
                }

                // Add all User has Vsl Selection 
                if (PG.usersToHideShowinVslFilterList.Trim().Length > 0)
                {
                    addlCond = addlCond + " and U.UserId not in('" + PG.usersToHideShowinVslFilterList.Trim().Replace(",", "','") + "')";
                }

                // Exclude roles
                addlCond = addlCond + " and U.Role not in ('GENMANAGER', 'ADMINISTRATOR', 'HQTRAINEE', 'VSLTRAINEE', 'VENDOR') ";

                if (companyID != "-99")
                {
                    addlCond = addlCond + " and U.C_CompanyID=" + companyID;
                }

                script = " select distinct V.UserID, U.Role, U.sortOrder, R.ShortCodeForDisplay " +
                         " from Proc_UserDisplayVsls V, HQ_Users_V U , HQ_UserRoles R " +
                         " where V.UserID=U.UserId and U.Role=R.UserRole and U.HQDept=R.HQDept " + addlCond +
                         "    and V.C_CompanyID = U.C_CompanyID " +
                         "    and V.VesselID in (Select VesselID from V_Vessels) " +
                         " order by U.sortOrder, U.Role, V.UserID ";
                dtUser = PG.Gb.DBFn.DbRecords(script);
                if (dtUser != null)
                {
                    string displayStr, shortCodeDisplay;
                    foreach (DataRow dr in dtUser.Rows)
                    {
                        userId = dr["UserID"].ToString();
                        shortCodeDisplay = dr["ShortCodeForDisplay"].ToString();
                        displayStr = shortCodeDisplay.PadRight(6, ' ');
                        objArr.Add(new DictionaryEntry(displayStr + " - " + userId, "user-" + userId));
                    }
                }
                dtUser = null;
            }
            catch (Exception err)
            {
                objArr = null;
                PG.AddToGenErrorLog("MainPage.cs", "GetVslFilterArrayList", err.Message);
            }
            finally
            {
                dt = null;
                dtUser = null;
            }
            return (objArr);
        }


        public bool InitialiseVslStatus()
        {
            bool result = false;
            try
            {
                string script = " select count(*) from V_Vessels S " +
                                " where VesselID<>-1 " +
                                "    and not exists (select * from Dashboard_HQ_Main_Tech_Status where VesselID=S.VesselID) ";
                int noOfRecs = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());
                if (noOfRecs > 0)
                {
                    script = " insert into Dashboard_HQ_Main_Tech_Status (Dashboard_HQ_Main_Tech_StatusID, VesselID) " +
                             " select (select isnull( max(Dashboard_HQ_Main_Tech_StatusID),0) from Dashboard_HQ_Main_Tech_Status) + Row_Number() over (order by Vslcode) Dashboard_HQ_Main_Tech_StatusID, VesselID " +
                             " from V_Vessels S " +
                             " where VesselID<>-1 and not exists (select * from Dashboard_HQ_Main_Tech_Status where VesselID=S.VesselID) ";
                    PG.Gb.DBFn.Xqry(script);
                }

                script = " select count(*) from V_Vessels S " +
                         " where VesselID<>-1 " +
                         "    and not exists (select * from Dashboard_HQ_Main_Marine_Status where VesselID=S.VesselID) ";
                noOfRecs = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());
                if (noOfRecs > 0)
                {
                    script = " insert into Dashboard_HQ_Main_Marine_Status (Dashboard_HQ_Main_Marine_StatusID, VesselID) " +
                             " select (select isnull( max(Dashboard_HQ_Main_Marine_StatusID),0) from Dashboard_HQ_Main_Marine_Status) + Row_Number() over (order by Vslcode) Dashboard_HQ_Main_Marine_StatusID, VesselID " +
                             " from V_Vessels S " +
                             " where VesselID<>-1 and not exists (select * from Dashboard_HQ_Main_Marine_Status where VesselID=S.VesselID) ";
                    PG.Gb.DBFn.Xqry(script);
                }

                script = " select count(*) from V_Vessels S " +
                         " where VesselID<>-1 " +
                         "    and not exists (select * from Dashboard_HQ_Main_Crew_Status where VesselID=S.VesselID) ";
                noOfRecs = Convert.ToInt32(PG.Gb.DBFn.Aqr(script).ToString());
                if (noOfRecs > 0)
                {
                    script = " insert into Dashboard_HQ_Main_Crew_Status (Dashboard_HQ_Main_Crew_StatusID, VesselID) " +
                             " select (select isnull( max(Dashboard_HQ_Main_Crew_StatusID),0) from Dashboard_HQ_Main_Crew_Status) + Row_Number() over (order by Vslcode) Dashboard_HQ_Main_Crew_StatusID, VesselID " +
                             " from V_Vessels S " +
                             " where VesselID<>-1 and not exists (select * from Dashboard_HQ_Main_Crew_Status where VesselID=S.VesselID) ";
                    PG.Gb.DBFn.Xqry(script);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "InitialseVslStatus", err.Message);
                Gfn.Wb("Failed to Initialse Vsl Status ");
            }
            return (result);
        }

        public DataTable GetDashBoardDataTable_Tech_SingleVsl(int vesselID)
        {
            DataTable dt = null;
            try
            {
                string script = " select S.* " + Environment.NewLine +
                                " from Dashboard_HQ_Main_Tech_Status_V S" + Environment.NewLine +
                                " where S.VesselID='" + vesselID + "'";
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetDashBoardDataTable_Tech_SingleVsl", err.Message);
                dt = null;
            }

            return (dt);
        }

        public DataTable GetDashBoardDataTable_Tech(string vslFilter, string companyID)
        {
            DataTable dt = null;
            try
            {
                string vslTableName = "V_Vessels";
                if (vslFilter.ToUpper() == "-4".ToUpper()) vslTableName = "V_Vessels_Removed";

                string basicSql = " select *, replace(convert(varchar(12),DelivDate,106),' ','-') as DelivDateDisplay " + Environment.NewLine +
                                  "    , (Select O.GroupName from V_Op_Groups_VSL_I I, V_Op_Groups O where O.C_CompanyID = V.C_CompanyID and I.V_Op_GroupsID=O.V_Op_GroupsID and I.VesselID=V.VesselID) as GroupName " + Environment.NewLine +
                                  "    , (select Top 1 replace(Convert(varchar(10),TransDate,6),' ','-') from DTF_HQ_Inwards where VesselId=V.VesselId order by TransDate desc) as VslToHQ" + Environment.NewLine +
                                  "    , (select Top 1 replace(Convert(varchar(10),TransDate,6),' ','-') from DTF_HQ_Outwards where VesselId=V.VesselId order by TransDate desc) as HQtoVsl " + Environment.NewLine +
                                  "    , (select top 1 isNull(UserName,'') from V_Staff_V where IsDisabled=0 and UserRank='MAS' and VesselID=V.VesselID order by SignInDate desc) as MASTERNAME " + Environment.NewLine +
                                  "    , (select top 1 isNull(UserName,'') from V_Staff_V where IsDisabled=0 and UserRank='C/E' and VesselID=V.VesselID order by SignInDate desc) as CENAME " + Environment.NewLine +
                                  "    , (select COUNT(*) from Proc_UserActionVsls where C_CompanyID=V.C_CompanyID and UserID=" + Gfn.Qss(PG.Gb.User.CurUserID) + " and VesselID=v.VesselID) as userVsl " +
                                  "    , CompanyCode " + Environment.NewLine +
                                  " from " + vslTableName + " V, Dashboard_HQ_Main_Tech_Status_V S, C_Company C " + Environment.NewLine +
                                  " where V.VesselID<>-1 and V.vesselID = S.VesselID " + Environment.NewLine +
                                  "    and C.C_CompanyID=V.C_CompanyID ";

                string addlCondition = GetVslFilterAddlCondition(vslFilter, companyID);

                if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
                {
                    addlCondition = addlCondition + "  and V.C_CompanyID='" + companyID + "'";
                }

                // Order clause
                string orderclause = " Order By V.IsOffice desc, V.VslName asc";

                string sql = basicSql + addlCondition + orderclause;

                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetDashBoardDataTable_Tech", err.Message);
                dt = null;
            }

            return (dt);
        }
               
        public void InitialiseUserVsl(string vslFilter, ref bool isUserVsl, ref string selectedUserID)
        {
            string[] vslType = vslFilter.Split('-');
            if (vslType.Length > 1)
            {
                isUserVsl = (vslType[0].ToString().Trim().ToUpper() == "USER");
                if (isUserVsl) selectedUserID = vslType[1].ToString();
            }
        }

        public string GetVslFilterAddlCondition(string vslFilter, string companyID)
        {
            bool isUserVsl = false;  string selectedUserID = "xxx";
            InitialiseUserVsl(vslFilter, ref isUserVsl, ref selectedUserID);

            string addlCondition = "";
            if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
            {
                addlCondition = addlCondition + "  and V.C_CompanyID= " + companyID;
            }

            if (!PG.userAllowedToSeeTrainVsl)
            {
                addlCondition = addlCondition + "  and not exists (select * FROM V_Trainee where vesselID=V.vesselID) ";
            }

            if (vslFilter == "-1") // All Vessles - exclude Third Party vsls
            {
                addlCondition = addlCondition + " and not exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (Select V_Op_GroupsID from V_Op_Groups where C_CompanyID = V.C_CompanyID and GroupCode ='3RD-PARTY'))" + Environment.NewLine;
            }
            else if (isUserVsl)
            {
                addlCondition = addlCondition + " and exists (select * from Proc_UserDisplayVsls where C_CompanyID = V.C_CompanyID and UserID= " + Gfn.Qss(selectedUserID) + " and VesselID=V.VesselID )" + Environment.NewLine;
            }
            else if (vslFilter.Length > 0 && vslFilter != "-1" && vslFilter != "-2" && vslFilter != "-3" && vslFilter != "-4")
            {
                string groupList = Gfn.GetCommaTxtWithsingleQuotes(vslFilter, ",", -1, PG.Gb.DBFn);
                addlCondition = addlCondition + " and exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (" + groupList + "))" + Environment.NewLine;
            }
            else if (vslFilter == "-2") // Ops by VSL
            {
                addlCondition = addlCondition + " and OperateBy ='VSL'";
            }
            else if (vslFilter == "-3") // Ops by HQ
            {
                addlCondition = addlCondition + " and OperateBy ='HQ' and not exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (Select V_Op_GroupsID from V_Op_Groups where C_CompanyID = V.C_CompanyID and GroupCode ='3RD-PARTY'))" + Environment.NewLine;
            }
            else if (vslFilter != "-4") // retiredvsl
            {
                addlCondition = addlCondition + " and IsRetired =0 ";
            }

            return (addlCondition);
        }

        public DataTable GetDashBoardDataTable_Marine(string vslFilter, string fieldName, string companyID)
        {
            DataTable dt = null;
            try
            {              
                string vslTableName = "V_Vessels";
                if (vslFilter.ToUpper() == "-4".ToUpper()) vslTableName = "V_Vessels_Removed";

                string basicSql = " select * " + Environment.NewLine +
                                  "    , (select COUNT(*) from Proc_UserActionVsls where C_CompanyID=V.C_CompanyID and UserID=" + Gfn.Qss(PG.Gb.User.CurUserID) + " and VesselID=v.VesselID) as userVsl " +
                                  "    , (select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " + Environment.NewLine +
                                  " from " + vslTableName + " V, Dashboard_HQ_Main_Marine_Status_V S " + Environment.NewLine +
                                  " where V.VesselID<>-1 and V.vesselID = S.VesselID " + Environment.NewLine+
                                  "   and not exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (Select V_Op_GroupsID from V_Op_Groups where C_CompanyID = V.C_CompanyID and GroupCode ='3RD-PARTY'))" + Environment.NewLine;

                string addlCondition = GetVslFilterAddlCondition(vslFilter, companyID);

                if (fieldName.Trim().Length > 0) addlCondition = addlCondition + " and " + fieldName + ">0";

                if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
                {
                    addlCondition = addlCondition + "  and V.C_CompanyID='" + companyID + "'";
                }

                // Order clause
                string orderclause = " Order By V.IsOffice desc, V.VslName asc";

                string sql = basicSql + addlCondition + orderclause;

                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetDashBoardDataTable_Marine", err.Message);
                dt = null;
            }

            return (dt);
        }

        public DataTable GetVslDetailsDataTable_Marine(string vslFilter, string companyID)
        {
            DataTable dt = null;
            try
            {
                string vslTableName = "V_Vessels";
                if (vslFilter.ToUpper() == "-4".ToUpper()) vslTableName = "V_Vessels_Removed";

                string basicSql = " select V.* " + Environment.NewLine +
                                  "    , (select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " + Environment.NewLine +
                                  " from " + vslTableName + " V, Dashboard_HQ_Main_Marine_Status S " + Environment.NewLine +
                                  " where V.VesselID<>-1 and V.vesselID = S.VesselID " + Environment.NewLine;

                string addlCondition = GetVslFilterAddlCondition(vslFilter, companyID);

                if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
                {
                    addlCondition = addlCondition + "  and V.C_CompanyID='" + companyID + "'";
                }

                // Order clause
                string orderclause = " Order By V.IsOffice desc, V.VslName asc";

                string sql = basicSql + addlCondition + orderclause;

                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetVslDetailsDataTable_Marine", err.Message);
                dt = null;
            }

            return (dt);
        }


        public DataTable GetVslDetailsDataTable_Crew(string vslFilter, string companyID)
        {
            DataTable dt = null;
            try
            {
                string vslTableName = "V_Vessels";
                if (vslFilter.ToUpper() == "-4".ToUpper()) vslTableName = "V_Vessels_Removed";

                string basicSql = " select V.* " + Environment.NewLine +
                                  "    , (select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " + Environment.NewLine +
                                  " from " + vslTableName + " V, Dashboard_HQ_Main_Crew_Status S " + Environment.NewLine +
                                  " where V.VesselID<>-1 and V.vesselID = S.VesselID " + Environment.NewLine;

                string addlCondition = GetVslFilterAddlCondition(vslFilter, companyID);

                if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
                {
                    addlCondition = addlCondition + "  and V.C_CompanyID='" + companyID + "'";
                }

                // Order clause
                string orderclause = " Order By V.IsOffice desc, V.VslName asc";

                string sql = basicSql + addlCondition + orderclause;

                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetVslDetailsDataTable_Crew", err.Message);
                dt = null;
            }

            return (dt);
        }

        public DataTable GetDashBoardDataTable_Crew(string vslFilter, string fieldName, string companyID)
        {
            DataTable dt = null;
            try
            {
                string vslTableName = "V_Vessels";
                if (vslFilter.ToUpper() == "-4".ToUpper()) vslTableName = "V_Vessels_Removed";

                string basicSql = " select * " + Environment.NewLine +
                                  "    , (select COUNT(*) from Proc_UserActionVsls where C_CompanyID=V.C_CompanyID and UserID=" + Gfn.Qss(PG.Gb.User.CurUserID) + " and VesselID=v.VesselID) as userVsl " +
                                  "    , (select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " + Environment.NewLine +
                                  " from " + vslTableName + " V, Dashboard_HQ_Main_Crew_Status S " + Environment.NewLine +
                                  " where V.VesselID<>-1 and V.vesselID = S.VesselID " + Environment.NewLine +
                                  "   and not exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (Select V_Op_GroupsID from V_Op_Groups where C_CompanyID = V.C_CompanyID and GroupCode ='3RD-PARTY'))" + Environment.NewLine;

                string addlCondition = GetVslFilterAddlCondition(vslFilter, companyID);

                if (fieldName.Trim().Length > 0) addlCondition = addlCondition + " and " + fieldName + ">0";

                if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
                {
                    addlCondition = addlCondition + "  and V.C_CompanyID='" + companyID + "'";
                }

                // Order clause
                string orderclause = " Order By V.IsOffice desc, V.VslName asc";

                string sql = basicSql + addlCondition + orderclause;

                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetDashBoardDataTable_Crew", err.Message);
                dt = null;
            }

            return (dt);
        }


        public DataTable GetNCRDataTable(string vslFilter, string statusFilter, string companyID)
        {
            bool isUserVsl = false; string selectedUserID = "";
            DataTable dt = null;
            try
            {
                // initialise
                InitialiseUserVsl(vslFilter, ref isUserVsl, ref selectedUserID);

                string userAllowedToSeeTrainVsl = "NO";
                if (PG.userAllowedToSeeTrainVsl) userAllowedToSeeTrainVsl = "YES";

                string sp_name = "HQ_NCR_GetData_4_Marine_Dashboard";
                string[] paramField = { "@VslFilter", "@StatusOption", "@selectedUserID", "@UserAllowedToSeeTrainVsl", "@CompanyID" };
                string[] paramValue = { vslFilter, statusFilter, selectedUserID, userAllowedToSeeTrainVsl, companyID };
                PG.Gb.DBFn.SpAqr(sp_name, paramField, paramValue, ref dt);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetNCRDataTable", err.Message);
                dt = null;
            }

            return (dt);
        }

        public DataTable GetDashBoardDataTable_MonthEnd(string vslFilter, string companyID, int selectedVesselID)
        {
            DataTable dt = null;
            try
            {
                string vslTableName = "V_Vessels";
                if (vslFilter.ToUpper() == "-4".ToUpper()) vslTableName = "V_Vessels_Removed";

                string basicSql = " select V.VesselID, V.VslCode, V.VslName, V.OperateBy, X.MonthEndDoc_OverDue " + Environment.NewLine +
                                  "    , (select COUNT(*) from Proc_UserActionVsls where C_CompanyID=V.C_CompanyID and UserID=" + Gfn.Qss(PG.Gb.User.CurUserID) + " and VesselID=v.VesselID) as userVsl " +
                                  "    , (select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " + Environment.NewLine +
                                  " from " + vslTableName + " V, Dashboard_HQ_Main_Tech_Status S, Dashboard_HQ_Main_Tech_Status_Ext X " + Environment.NewLine +
                                  " where V.VesselID<>-1 and V.vesselID = S.VesselID " + Environment.NewLine +
                                  "   and S.VesselId = X.VesselID " + Environment.NewLine +
                                  "   and not exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (Select V_Op_GroupsID from V_Op_Groups where C_CompanyID = V.C_CompanyID and GroupCode ='3RD-PARTY'))" + Environment.NewLine;

                string addlCondition = "";
                if (selectedVesselID > 0)
                {
                    addlCondition = addlCondition + "  and V.VesselID='" + selectedVesselID + "'";
                }
                else
                {
                    addlCondition = GetVslFilterAddlCondition(vslFilter, companyID);

                    if (companyID.Trim().Length > 0 && companyID.Trim() != "-99")
                    {
                        addlCondition = addlCondition + "  and V.C_CompanyID='" + companyID + "'";
                    }
                }

                // Order clause
                string orderclause = " Order By V.IsOffice desc, V.VslName asc";

                string sql = basicSql + addlCondition + orderclause;

                dt = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("MainPage.cs", "GetDashBoardDataTable_MonthEnd", err.Message);
                dt = null;
            }

            return (dt);
        }

    }

    public class PMS
    {
        public bool CallSuptQPage(int vesselID, string xcallMode)
        {
            frmSuptReview objSuptQ = new frmSuptReview();
            try
            {
                objSuptQ.vesselID = vesselID;
                objSuptQ.callMode = xcallMode;
                objSuptQ.ShowDialog();

                return (objSuptQ.isMaintAckDone);
            }
            finally
            {
                objSuptQ = null;
            }
        }

        public bool CallSuptToApproveMaintPage(int vesselID)
        {
            frmSuptToApproveMaint objSuptQ = new frmSuptToApproveMaint();
            try
            {
                objSuptQ.vesselID = vesselID;
                objSuptQ.ShowDialog();

                return (objSuptQ.isMaintAckDone);
            }
            finally
            {
                objSuptQ = null;
            }
        }

        public void CallPmsandSvyPage(int vesselID, string xcallMode)
        {
            frmPmsDueList objPmdDue = new frmPmsDueList();
            try
            {
                objPmdDue.callMode = xcallMode;
                objPmdDue.vesselID = vesselID;
                objPmdDue.ShowDialog();
            }
            finally
            {

                objPmdDue = null;
            }
        }

        public void CallCriticalSPPage(int vesselID, string xcallMode)
        {
            frmCriticalSP objPmdDue = new frmCriticalSP();
            try
            {
                objPmdDue.callMode = xcallMode;
                objPmdDue.vesselID = vesselID;
                objPmdDue.ShowDialog();
            }
            finally
            {

                objPmdDue = null;
            }
        }
    }

}