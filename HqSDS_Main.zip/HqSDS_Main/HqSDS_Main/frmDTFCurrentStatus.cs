﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmDTFCurrentStatus : Form
    {
        int COL_OUTWARDS_TRANSDATEDISPLAY = 4, COL_OUTWARDS_TRANSDATE = 6;
        int COL_INWARDS_TRANSDATEDISPLAY = 4, COL_INWARDS_TRANSDATE = 5;

        bool isFormInitialised = false;
        public frmDTFCurrentStatus()
        {
            InitializeComponent();
        }

        private void frmDTFCurrentStatus_Load(object sender, EventArgs e)
        {
            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, false);
            rdoHQOutwards.Checked = true;

            isFormInitialised = true;

            cboCompany_Filter_SelectedIndexChanged(null, null);
        }

        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            rdo_CheckedChanged(null, null);
        }

        private void rdo_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoHQInwards.Checked)
            {
                DesignAndBindHQInwards();
            }
            else if (rdoHQOutwards.Checked)
            {
                DesignAndBindHQOutwards();
            }
        }

        private void DesignAndBindHQInwards()
        {
            List<DgvInits> colList = new List<DgvInits>();
            DataTable dt = null;
            try
            {
                tsLblTotalVessels.Text = "";

                colList.Add(new DgvInits("VesselID", "Vsl ID", 45, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslCode", "Vsl Code", 60, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslName", "Vsl Name", 190, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransLotNo", "Last DTF#", 50, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDateDisplay", "DTF Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDate", "DTF Date", 140, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                
                dt = GetHQInwards();
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadDTF, colList, dt, false, false, false);

                if (dt != null) tsLblTotalVessels.Text = "Total Vessel(s): " + dt.Rows.Count;

                fpSpreadDTF.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpreadDTF.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpreadDTF.ActiveSheet.RowHeader.Columns[0].Width = 20;
                fpSpreadDTF.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;

                fpSpreadDTF.ActiveSheet.SelectionBackColor = Color.FromArgb(255, 255, 128);
                fpSpreadDTF.ActiveSheet.SelectionForeColor = Color.Maroon;
                fpSpreadDTF.ActiveSheet.SelectionFont = new Font("Verdana", 8F, FontStyle.Regular);
            }
            catch (Exception ex)
            {
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "DesignAndBindHQInwards", ex.Message);
            }
            finally
            {
                colList = null;
                dt = null;
            }
        }

        private DataTable GetHQInwards()
        {
            DataTable dt = null;
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string addlCond = "";
                if (companyID != "-99") addlCond = addlCond + "  and V.C_CompanyID=" + companyID;

                string script = " select (Select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " + 
                                "   , VesselID, VslCode, VslName, (select max(TransLotNo) from DTF_HQ_Inwards where VesselID=V.VesselID) TransLotNo " +
                                "   , (select replace(convert ( varchar(12), max(TransDate), 6),' ','') from DTF_HQ_Inwards where VesselID=V.VesselID ) TransDateDisplay " +
                                "   , (select max(TransDate) from DTF_HQ_Inwards where VesselID=V.VesselID ) TransDate " +
                                " from V_vessels V " +
                                " where VesselID<>-1  " +
                                "    and OperateBy='VSL' " +
                                addlCond +
                                " order by VslName";
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "GetHQInwards", err.Message);
            }
            return (dt);
        }

        private void DesignAndBindHQOutwards()
        {
            List<DgvInits> colList = new List<DgvInits>();
            DataTable dt = null;
            try
            {
                tsLblTotalVessels.Text = "";

                colList.Add(new DgvInits("VesselID", "Vsl ID", 45, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslCode", "Vsl Code", 60, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslName", "Vsl Name", 190, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));

                colList.Add(new DgvInits("TransLotNo", "Last DTF#", 50, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDateDisplay", "DTF Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VSLAckedDate", "VSL Ack Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDate", "DTF Date", 85, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));

                dt = GetHQOutwards();
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadDTF, colList, dt, false, false, false);

                if (dt != null) tsLblTotalVessels.Text = "Total Vessel(s): " + dt.Rows.Count;

                fpSpreadDTF.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpreadDTF.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpreadDTF.ActiveSheet.RowHeader.Columns[0].Width = 20;
                fpSpreadDTF.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;

                fpSpreadDTF.ActiveSheet.SelectionBackColor = Color.FromArgb(255, 255, 128);
                fpSpreadDTF.ActiveSheet.SelectionForeColor = Color.Maroon;
                fpSpreadDTF.ActiveSheet.SelectionFont = new Font("Verdana", 8F, FontStyle.Regular);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "DesignAndBindHQInwards", err.Message);
            }
            finally
            {
                colList = null;
                dt = null;
            }
        }

        private DataTable GetHQOutwards()
        {
            DataTable dt = null;
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string addlCond = "";
                if (companyID != "-99") addlCond = addlCond + "  and V.C_CompanyID=" + companyID;

                string script = " select (Select CompanyCode from C_Company where C_CompanyID=V.C_CompanyID) as CompanyCode " +
                                "  , VesselID, VslCode, VslName, (select max(TransLotNo) from DTF_HQ_Outwards where VesselID=V.VesselID) TransLotNo " +
                                "  , (select replace(convert ( varchar(12), max(TransDate), 6),' ','')  + ' ' + replace(convert ( varchar(5), max(TransDate), 108),' ','') from DTF_HQ_Outwards where VesselID=V.VesselID ) TransDateDisplay " +
                                "  , (select max(TransDate) + ' ' + replace(convert ( varchar(5), max(TransDate), 108),' ','') from DTF_HQ_Outwards where vesselID=V.vesselID ) TransDate " +
                                "  , (select replace(convert ( varchar(12), TransDate, 6),' ','')+ ' ' + replace(convert ( varchar(5),TransDate, 108),' ','')  from DTF_VSL_Inwards where VesselID=V.VesselID and " +
                                "	  TransLotNo = isnull((select max(TransLotNo) from DTF_HQ_Outwards where VesselID=V.VesselID),0)) as VSLAckedDate " +
                                " from V_Vessels V " +
                                " where VesselID<>-1 " +
                                "    and OperateBy='VSL' " +
                                 addlCond +
                                " order by VslName";
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "GetHQOutwards", err.Message);
            }
            return (dt);
        }


        private void fpSpreadDTF_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                int colDisplay = COL_INWARDS_TRANSDATEDISPLAY, col = COL_INWARDS_TRANSDATE;
                if (rdoHQOutwards.Checked)
                {
                    colDisplay = COL_OUTWARDS_TRANSDATEDISPLAY; 
                    col = COL_OUTWARDS_TRANSDATE;
                }

                fpSpreadDTF.ActiveSheet.Columns[col].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

                if (e.Column == colDisplay)
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(col);
                else
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(e.Column);
                fpSpreadDTF.ActiveSheet.Columns[colDisplay].SortIndicator = fpSpreadDTF.ActiveSheet.Columns[col].SortIndicator;
            }
        }

        private void fpSpreadDTF_AutoSortingColumn(object sender, FarPoint.Win.Spread.AutoSortingColumnEventArgs e)
        {
            int colDisplay = COL_INWARDS_TRANSDATEDISPLAY, col = COL_INWARDS_TRANSDATE;
            if (rdoHQOutwards.Checked)
            {
                colDisplay = COL_OUTWARDS_TRANSDATEDISPLAY;
                col = COL_OUTWARDS_TRANSDATE;
            }

            fpSpreadDTF.ActiveSheet.Columns[colDisplay].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

            if (e.Column == colDisplay)
            {
                if (e.Ascending)
                {
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(col);
                    fpSpreadDTF.ActiveSheet.Columns[colDisplay].SortIndicator = fpSpreadDTF.ActiveSheet.Columns[col].SortIndicator;
                }
                e.Cancel = true;
            }
        }

        private void btnExportXL_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            DataTable dt = null;
            FarPoint.Win.Spread.FpSpread fs = new FarPoint.Win.Spread.FpSpread();
            try
            {
                DateTime todaysDate = PG.GetDbServerDate();
                if (rdoHQInwards.Checked) dt = GetHQInwards();
                else if (rdoHQOutwards.Checked) dt = GetHQOutwards();
                if (dt == null)
                {
                    Gfn.nMbwithAlignAndCentrePosn("No rows to export", ContentAlignment.MiddleCenter, 100, 250);
                    return;
                }

                string filter = "HQ Inwards", fileNamePrefix = "Inwards";
                if (rdoHQOutwards.Checked)
                {
                    filter = "HQ Outwards";
                    fileNamePrefix = "Outwards";
                }

                DesignAndFillupExportGrid(fs, dt, todaysDate, filter);

                string fileName = PG.xlsOutputFolderPath + "\\" + PG.hqAppFolder + "_DTFCurrentStatus_" + fileNamePrefix + "_" + todaysDate.ToString("ddMMMyyyy_hhmmssff") + ".xls";
                if (fileName.Length == 0) return;
                if (!Gfn.DeleteFileIfExists(fileName)) return;
                bool hasExportedSuccessfully = (fs.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception err)
            {
                Gfn.Wb("Failed to export DTF current status");
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "btnExportXL_Click", err.Message);
            }
            finally
            {
                fs = null;
                dt = null;
                this.Cursor = Cursors.Default;
            }
        }

        private void DesignAndFillupExportGrid(FarPoint.Win.Spread.FpSpread fs, DataTable dt, DateTime todaysDate, string filter)
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                fs.SuspendLayout();

                FarPoint.Win.Spread.SheetView fs_Sheet1 = new FarPoint.Win.Spread.SheetView();
                fs.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] { fs_Sheet1 });
                FarPoint.Win.Spread.DefaultSpreadSkins.Classic.Apply(fs);
                fs.Font = new Font("Verdana", 8, FontStyle.Regular);

                colList.Add(new DgvInits("VesselID", "Vsl ID", 45, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("VslCode", "Vsl Code", 60, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("VslName", "Vsl Name", 190, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("TransLotNo", "Last DTF#", 50, Color.Black, SystemColors.ButtonFace, true, true));
                colList.Add(new DgvInits("TransDateDisplay", "DTF Date", 100, Color.Black, SystemColors.ButtonFace, true, true));

                if (rdoHQOutwards.Checked)
                {
                    colList.Add(new DgvInits("VSLAckedDate", "VSL Ack Date", 100, Color.Black, SystemColors.ButtonFace, true, true));
                }

                FarPtColCtrls.GenerateFarPointGridView(fs, colList, dt, false, true, false);

                fs.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fs.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fs.ActiveSheet.RowHeader.Columns[0].Width = 20;
                fs.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;

                fs.ActiveSheet.SelectionBackColor = Color.FromArgb(255, 255, 128);
                fs.ActiveSheet.SelectionForeColor = Color.Maroon;
                fs.ActiveSheet.SelectionFont = new Font("Verdana", 8F, FontStyle.Regular);

                fs.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, Color.Empty);
                fs.ActiveSheet.VerticalGridLine = gdln;
                fs.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                if ((fs.ActiveSheet.RowCount > 0) && (fs.ActiveSheet.ColumnCount > 0))
                {
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].VisualStyles = FarPoint.Win.VisualStyles.Off;

                    fs.ActiveSheet.Cells[0, 0, fs.ActiveSheet.RowCount - 1, fs.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                }

                //Heading + Date
                fs.ActiveSheet.ColumnHeader.Rows[0].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].Text = this.Text + "       " + todaysDate.ToString("dd-MMM-yyyy");
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 14, FontStyle.Bold);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].ForeColor = Color.Blue;
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fs.ActiveSheet.ColumnHeader.Rows[0].Height = 25;

                //Filter
                fs.ActiveSheet.ColumnHeader.Rows[1].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(1, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].Text = filter;
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 10, FontStyle.Bold);
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
                fs.ActiveSheet.ColumnHeader.Rows[1].Height = 25;

                if (fs.ActiveSheet.RowCount > 0 && fs.ActiveSheet.ColumnCount > 0)
                {
                    for (int row = 0; row < fs.ActiveSheet.RowCount; row++)
                    {
                        fs.ActiveSheet.Rows[row].Height = fs.ActiveSheet.Rows[row].GetPreferredHeight();
                    }
                    fs.ActiveSheet.Cells[0, 0, fs.ActiveSheet.RowCount - 1, fs.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.Info;
                }
                fs.ActiveSheet.Protect = false;
            }
            catch (Exception err)
            {
                Gfn.nMb("Failed to export DTF Current Status " + err.Message);
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "DesignAndFillupExportGrid", err.Message);
            }
            finally
            {
                fs.ResumeLayout();
                colList = null;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
