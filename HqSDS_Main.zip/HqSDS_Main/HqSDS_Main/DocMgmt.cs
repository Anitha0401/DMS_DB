﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace HqSDS_Main
{
    class DocMgmt
    {
        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsWow64Process([In] IntPtr hProcess, [Out] out bool lpSystemInfo);
        public static string GetUserOSPlatform()
        {
            string curOsPlatform = "";
            try
            {
                curOsPlatform = "32";
                using (Process p = Process.GetCurrentProcess())
                {
                    bool retVal;
                    if (IntPtr.Size == 8 || (IntPtr.Size == 4 && IsWow64Process(p.Handle, out retVal) && retVal))
                    {
                        return curOsPlatform = "64";
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("DocMgmt.cs", "GetUserOSPlatform", err.Message);
            }

            return (curOsPlatform);
        }


        public static bool DeleteHqProgs_DM(string curOsPlatform)
        {
            bool result = false; string script;
            DataTable dtProgs = null;
            string progNameWithPath;
            try
            {
                script = " select ProgName+FileType as ProgNameWithExt, DownloadPath " +
                         " from H_HQProgs_DM " +
                         " where OS_Platform in ('','" + curOsPlatform + "') " +
                         " order by ProgName";
                dtProgs = PG.Gb.DBFn.DbRecords(script);

                if (dtProgs == null) return (result);
                if (dtProgs.Rows.Count == 0) return (result);

                foreach (DataRow dr in dtProgs.Rows)
                {
                    progNameWithPath = dr["DownloadPath"].ToString().Trim();
                    if (progNameWithPath.Length <= 0) progNameWithPath = PG.winSdsRootDir;
                    if (!Directory.Exists(progNameWithPath)) Directory.CreateDirectory(progNameWithPath);

                    progNameWithPath = progNameWithPath + "\\" + dr["ProgNameWithExt"].ToString();

                    if (File.Exists(progNameWithPath))
                    {
                        File.Delete(progNameWithPath);
                    }
                }

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("DocMgmt.cs", "DeleteHqProgs_DM", err.Message);
            }
            finally
            {
                dtProgs = null;
            }

            return (result);
        }

        public static bool DeleteFilesFromCefCacheFolder()
        {
            bool result = false; 
            try
            {
                string CefCacheFolder = PG.Gb.WinSdsAppDir + @"\CefCache\";

                if (!Directory.Exists(CefCacheFolder)) return (true);
                
                System.IO.DirectoryInfo di = new DirectoryInfo(CefCacheFolder);

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("DocMgmt.cs", "DeleteFilesFromCefCacheFolder", err.Message);
            }
            
            return (result);
        }


        public static bool DownloadHqProgs_DM(string curOsPlatform)
        {
            bool result = false; string script;
            DataTable dtProgs = null;
            string progNameWithPath; DateTime dbProgDate, existingAppProgdate;
            try
            {
                script = " select ProgName, Progdate, ProgName+FileType as ProgNameWithExt, DownloadPath, H_HQProgs_DMID " +
                         " from H_HQProgs_DM " +
                         " where OS_Platform in ('','" + curOsPlatform + "') " +
                         " order by ProgName";
                dtProgs = PG.Gb.DBFn.DbRecords(script);

                if (dtProgs == null) return (result);
                if (dtProgs.Rows.Count == 0) return (result);


                foreach (DataRow dr in dtProgs.Rows)
                {
                    Application.DoEvents();
                    progNameWithPath = dr["DownloadPath"].ToString().Trim();
                    if (progNameWithPath.Length <= 0) progNameWithPath = PG.winSdsRootDir; ///????
                    if (!Directory.Exists(progNameWithPath)) Directory.CreateDirectory(progNameWithPath);

                    progNameWithPath = progNameWithPath + "\\" + dr["ProgNameWithExt"].ToString();

                    dbProgDate = DateTime.MinValue;
                    if (dr["Progdate"].ToString().Length > 0) dbProgDate = Convert.ToDateTime(dr["Progdate"].ToString());


                    if (File.Exists(progNameWithPath))
                    {

                        existingAppProgdate = File.GetLastWriteTime(progNameWithPath);
                        if (existingAppProgdate < dbProgDate)
                        {

                            if (!PG.DownLoadThisAppFile("H_HQProgs_DM", dr["H_HQProgs_DMID"].ToString(), progNameWithPath, dbProgDate, 500)) return (result);
                        }
                    }
                    else
                    {
                        if (!PG.DownLoadThisAppFile("H_HQProgs_DM", dr["H_HQProgs_DMID"].ToString(), progNameWithPath, dbProgDate, 500)) return (result);
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("DocMgmt.cs", "DownloadHqProgs_DM", err.Message);
            }
            finally
            {
                dtProgs = null;
            }
            return result;
        }

        public static bool GetDownloadPathAndExecuteApp(string exename, string param)
        {
            bool result = false;
            string filename = "";
            try
            {
                string script = " Select DownloadPath from H_HQProgs_DM where ProgName='" + exename + "' and FileType='.exe'";
                string downloadPath = PG.Gb.DBFn.Aqr(script).ToString();
                if (downloadPath.Trim().Length <= 0) downloadPath = PG.winSdsRootDir;

                filename = downloadPath + "\\" + exename + ".exe";
                if (!File.Exists(filename))
                {
                    MessageBox.Show(exename + Environment.NewLine + " Called Module not found in " + downloadPath);
                    return (result);
                }

                // Run the App with cmd line parameters if any
                if (param.Length > 0)
                {
                    ProcessStartInfo startInfo = new ProcessStartInfo();
                    startInfo.FileName = filename;
                    startInfo.Arguments = param.Trim();
                    Process.Start(startInfo);
                    startInfo = null;
                }
                else
                    Process.Start(filename);

                result = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("DocMgmt.CS", "GetDownloadPathAndExecuteApp", er.Message);
            }
            return (result);
        }
    }
}
