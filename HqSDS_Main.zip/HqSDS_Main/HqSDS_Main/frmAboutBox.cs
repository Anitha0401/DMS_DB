﻿using System;
using System.Data;
using System.Windows.Forms;

namespace HqSDS_Main
{
    public partial class frmAboutBox : Form
    {
        public frmAboutBox()
        {
            InitializeComponent();
        }

        private void frmAboutBox_Load(object sender, EventArgs e)
        {
            InitialisePageControls();
        }

        private void InitialisePageControls()
        {
            try
            {
                string script = " select * from C_Settings where SettingName in ('WinSdsVersion','WinSdsVersionDate') ";
                DataTable dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    string settingName = dr["SettingName"].ToString();
                    string settingValue = dr["SettingValue"].ToString();
                    string description = dr["Description"].ToString();

                    if (settingName.ToUpper() == "WinSdsVersion".ToUpper())
                    {
                        if (description.Trim().Length > 0) description = description + ": ";
                        lblVerionNumber.Text = description + settingValue;
                    }
                    else if (settingName.ToUpper() == "WinSdsVersionDate".ToUpper())
                    {
                        if (description.Trim().Length > 0) description = description + ": ";
                        lblVersionDate.Text = description + settingValue;
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmAboutBox.cs", "InitialisePageControls", err.Message);
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
