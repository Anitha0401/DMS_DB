﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HqSDS_Main
{
    public partial class frmUnderMaintenance : Form
    {
        public string formTitle = "";
        public frmUnderMaintenance()
        {
            InitializeComponent();
        }

        private void frmUnderMaintenance_Load(object sender, EventArgs e)
        {
            this.Text = formTitle;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
