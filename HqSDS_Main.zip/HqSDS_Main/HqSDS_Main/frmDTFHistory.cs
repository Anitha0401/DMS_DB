﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmDTFHistory : Form
    {
        int COL_TRANSLOTNO = 3, COL_TRANSDATEDISPLAY = 4, COL_ACKDISPLAY = 5, COL_TRANSDATE = 7, COL_VSLACK = 8;
        public string callMode = "", operateBy = "", companyID = "-1";
        public int vslId = -1;

        bool isFormInitialised = false;

        public frmDTFHistory()
        {
            InitializeComponent();
        }

        private void frmDTFHistory_Load(object sender, EventArgs e)
        {
            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, false);
            cboCompany_Filter.SelectedValue = companyID;
            rdoHQOutwards.Checked = true;

            ClearControls();
            fpSpreadDTF.ActiveSheet.ColumnCount = 0;
            fpSpreadDTF.ActiveSheet.RowCount = 0;

            isFormInitialised = true;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            cboCompany_Filter_SelectedIndexChanged(null, null);
        }

        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            try
            {
                isFormInitialised = false;

                btnInwards.Visible = false;
                btnOutwards.Visible = false;

                BindVslDropDownList(cboVesselFilter);
                if (cboVesselFilter.Items.Count > 0) cboVesselFilter.SelectedIndex = 0;

                if (callMode == "DTF")
                {
                    string companyID = "-99";
                    if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                    string script = " Select SettingValue from HQ_Settings where SettingName='ALLOWEDUSERTODODTF' and C_CompanyID=" + companyID;
                    string settingValue = PG.Gb.DBFn.Aqr(script).ToString();
                    bool isAllowedUserToDoDTF = Gfn.IsStringExistsCommaSeparatedString(settingValue, PG.Gb.User.CurUserID);

                    btnInwards.Visible = (PG.isAllowedUserToDoDTF);
                    btnOutwards.Visible = (PG.isAllowedUserToDoDTF);
                    cboVesselFilter.SelectedValue = "vsl-" + vslId;
                    cboVesselFilter.Enabled = false;
                    cboCompany_Filter.Enabled = false;
                    Text = cboVesselFilter.Text + " - Data Sync ";
                }

                if (operateBy == "HQ")
                {
                    btnInwards.Visible = false;
                    btnOutwards.Visible = false;
                }

                isFormInitialised = true;
                cboVesselFilter_SelectedIndexChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFHistory.cs", "cboCompany_Filter_SelectedIndexChanged", err.Message);
            }
            finally
            {
                isFormInitialised = true;
            }
        }

        public void BindVslDropDownList(ComboBox cboBox)
        {
            ArrayList objArrLst = new ArrayList();
            try
            {
                objArrLst = GetVslFilterArrayList();
                cboBox.DisplayMember = "Key";
                cboBox.ValueMember = "Value";
                cboBox.DataSource = objArrLst;

                if (cboBox.SelectedIndex <= 0) cboBox.SelectedIndex = 0;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFHistory.CS", "BindVslDropDownList", err.Message);
            }
            finally
            {
                objArrLst = null;
            }
        }

        public ArrayList GetVslFilterArrayList()
        {
            DataTable dt = null;
            ArrayList objArr = new ArrayList();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objArr.Insert(0, new DictionaryEntry("All Vessels", "-1"));

                //Vsl Groups 
                string script = " select distinct G.GroupCode, GroupName, G.V_Op_GroupsID, G.SortOrder " +
                                " from V_Vessels V, V_Op_Groups_VSL_I I, V_Op_Groups G " +
                                " where V.VesselID=I.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID " +
                                "    and V.C_CompanyID = G.C_CompanyID ";
                if (PG.isToEnableThirdPartyVesselsFeature)
                    script = script + " and G.GroupCode not in ('ALL') ";
                else
                    script = script + " and G.GroupCode not in ('ALL','" + PG.THIRDPARTYVSL + "') ";

                if (!PG.userAllowedToSeeTrainVsl) 
                {
                    script = script + " and not exists (select * from V_Trainee where VesselID=V.VesselID) ";
                }
                if (companyID != "-99")
                {
                    script = script + "  and V.C_CompanyID=" + companyID;
                }

                script = script + " order by G.SortOrder, GroupName, G.V_Op_GroupsID";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string svsl = dr["GroupName"].ToString();
                        objArr.Add(new DictionaryEntry(svsl, dr["V_Op_GroupsID"].ToString()));
                    }
                }

                // Individual Vessels
                script = " select distinct V.VslName, V.VesselId, V.VslCode " +
                         " from  V_Vessels V, V_Op_Groups_VSL_I I, V_Op_Groups G " +
                         " where V.VesselID=I.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID " +
                         "    and V.VesselId>0 and V.IsRetired=0  " +
                         "    and V.C_CompanyID = G.C_CompanyID " +
                         "    and V.IsOffice=0";
                if (PG.isToEnableThirdPartyVesselsFeature)
                    script = script + " and G.GroupCode not in ('ALL') ";
                else
                    script = script + " and G.GroupCode not in ('ALL','" + PG.THIRDPARTYVSL + "') ";

                if (!PG.userAllowedToSeeTrainVsl)
                {
                    script = script + " and not exists (select * from v_Trainee where VesselID=V.VesselID) ";
                }
                if (companyID != "-99")
                {
                    script = script + "  and V.C_CompanyID=" + companyID;
                }
                script = script + " order by V.VslName";
                dt = PG.Gb.DBFn.DbRecords(script);

                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string vslName = dr["VslName"].ToString();
                        string vesselId = dr["VesselId"].ToString();
                        objArr.Add(new DictionaryEntry(vslName, "vsl-" + vesselId));
                    }
                }
            }
            catch (Exception err)
            {
                objArr = null;
                PG.AddToGenErrorLog("frmDTFHistory.CS", "GetVslFilterArrayList", err.Message);
            }
            finally
            {
                dt = null;
            }
            return (objArr);
        }

        private void DesignDTFHistory_InwardsGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            DataTable dt;
            try
            {
                colList.Add(new DgvInits("VesselID", "Vsl ID", 45, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslCode", "Vsl Code", 60, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslName", "Vsl Name", 190, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));

                colList.Add(new DgvInits("TransLotNo", "Trans No.", 55, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VSLAckedDateDisplay", "VSL Sent Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDateDisplay", "HQ Recvd Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("NoDaysToAck", "No. days To Ack", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDate", "DTF Date", 85, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VSLAckedDate", "VSL Ack", 80, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));

                dt = GetDTFHistory_InwardsDataTable();
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadDTF, colList, dt, false, true, false);

                fpSpreadDTF.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpreadDTF.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpreadDTF.ActiveSheet.RowHeader.Columns[0].Width = 20;
                fpSpreadDTF.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;

                fpSpreadDTF.ActiveSheet.SelectionBackColor = Color.FromArgb(255, 255, 128);
                fpSpreadDTF.ActiveSheet.SelectionForeColor = Color.Maroon;
                fpSpreadDTF.ActiveSheet.SelectionFont = new Font("Verdana", 8F, FontStyle.Regular);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFHistory.cs", "DesignDTFHistory_InwardsGrid", err.Message);
            }
            finally
            {
                colList = null;
            }
        }

        private void DesignDTFHistory_OutwardsGrid()
        {
            List<DgvInits> colList = new List<DgvInits>();
            DataTable dt;
            try
            {
                colList.Add(new DgvInits("VesselID", "Vsl ID", 45, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslCode", "Vsl Code", 60, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslName", "Vsl Name", 190, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));

                colList.Add(new DgvInits("TransLotNo", "Trans No.", 55, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDateDisplay", "HQ Sent Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VSLAckedDateDisplay", "VSL Recvd Date", 95, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("NoDaysToAck", "No. days To Ack", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransDate", "DTF Date", 85, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VSLAckedDate", "VSL Ack", 80, Color.Black, SystemColors.ButtonFace, false, true, SystemColors.Info, Color.Black));

                dt = GetDTFHistory_OutwardsDataTable();
                FarPtColCtrls.GenerateFarPointGridView(fpSpreadDTF, colList, dt, false, true, false);

                fpSpreadDTF.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpreadDTF.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpreadDTF.ActiveSheet.RowHeader.Columns[0].Width = 20;
                fpSpreadDTF.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.SingleSelect;

                fpSpreadDTF.ActiveSheet.SelectionBackColor = Color.FromArgb(255, 255, 128);
                fpSpreadDTF.ActiveSheet.SelectionForeColor = Color.Maroon;
                fpSpreadDTF.ActiveSheet.SelectionFont = new Font("Verdana", 8F, FontStyle.Regular);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFHistory.cs", "DesignDTFHistory_OutwardsGrid", err.Message);
            }
            finally
            {
                colList = null;
                dt = null;
            }
        }


        private void rdoHQOutwards_CheckedChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            btnInwards.Enabled = (rdoHQInwards.Checked);
            btnOutwards.Enabled = (rdoHQOutwards.Checked);
            BindDTFHistoryGrids();
        }

        private void BindDTFHistoryGrids()
        {
            try
            {
                tsLblTotalItems.Text = "";
                fpSpreadDTF.ActiveSheet.RowCount = 0;
                pnlProcessing.Visible = true;
                Application.DoEvents();

                fpSpreadDTF.SuspendLayout();

                if (rdoHQInwards.Checked)
                {
                    DesignDTFHistory_InwardsGrid();
                }
                else if (rdoHQOutwards.Checked)
                {
                    DesignDTFHistory_OutwardsGrid();
                }

                if (fpSpreadDTF.ActiveSheet.RowCount > 0) tsLblTotalItems.Text = "Total DTF(s): " + fpSpreadDTF.ActiveSheet.RowCount;

                /*
                dt = GetDTFHistoryDataTable();
                fpSpreadDTF.DataSource = dt;

                fpSpreadDTF.ActiveSheet.ColumnHeader.Cells[0, COL_TRANSDATEDISPLAY].Text = "HQ Sent Date";
                fpSpreadDTF.ActiveSheet.ColumnHeader.Cells[0, COL_VSLACKDISPLAY].Text = "VSL Recvd Date";
                if (rdoHQInwards.Checked)
                {
                    fpSpreadDTF.ActiveSheet.ColumnHeader.Cells[0, COL_TRANSDATEDISPLAY].Text = "VSL Sent Date";
                    fpSpreadDTF.ActiveSheet.ColumnHeader.Cells[0, COL_VSLACKDISPLAY].Text = "HQ Recvd Date";
                }

                if (dt != null) tsLblTotalItems.Text = "Total DTF(s): " + dt.Rows.Count;
                 * */
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFCurrentStatus.cs", "BindDTFHistoryGrids", err.Message);
            }
            finally
            {
                pnlProcessing.Visible = false;
                fpSpreadDTF.ResumeLayout();
            }
        }

        private DataTable GetDTFHistory_InwardsDataTable()
        {
            DataTable dt = null;
            try
            {
                string addlCond = "";

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (companyID != "-99") addlCond = addlCond + "  and V.C_CompanyID=" + companyID;

                string vslFilter = "";
                if (cboVesselFilter.SelectedValue != null) vslFilter = cboVesselFilter.SelectedValue.ToString().Trim();
                string[] vslType = vslFilter.Split('-');

                bool isToExcludeThirdParty = true;
                if (vslType[0].ToString().Trim().ToUpper() == "VSL")
                {
                    addlCond = addlCond + "    and V.VesselID=" + Gfn.Qss(vslType[1].ToString().Trim()) + Environment.NewLine;
                    isToExcludeThirdParty = false;
                }
                else
                {
                    addlCond = addlCond + "    and not exists (Select * from V_Vessels_Removed where VesselId=V.VesselID ) " +
                                          "    and V.OperateBy='VSL' ";

                    if (vslFilter != "-1" && vslFilter.Length > 0)
                    {
                        string groupList = Gfn.GetCommaTxtWithsingleQuotes(vslFilter, ",", -1, PG.Gb.DBFn);
                        addlCond = addlCond + " and exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (" + groupList + "))" + Environment.NewLine;
                        isToExcludeThirdParty = false;
                    }
                }

                if (isToExcludeThirdParty)
                {
                    addlCond = addlCond +
                                 "      and not exists (select * from V_Op_Groups_VSL_I I, V_Op_Groups G " +
                                 "           where I.VesselID=V.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID and G.C_CompanyID=V.C_CompanyID and G.GroupCode in ('" + PG.THIRDPARTYVSL + "') ) " + Environment.NewLine;
                }

                addlCond = addlCond + "    and ( (DATEADD(dd, 0, DATEDIFF(dd, 0, H.TransDate)))>=" + Gfn.Qs(dtpFrom.Value.ToString("yyyy.MM.dd")) +
                                      "      and (DATEADD(dd, 0, DATEDIFF(dd, 0, H.TransDate)))<=" + Gfn.Qs(dtpTo.Value.ToString("yyyy.MM.dd")) + ")" + Environment.NewLine;

                if (txtNoOfDays.Text.Trim().Length > 0)
                {
                    string cond = "=";
                    if (cboVesselFilter.SelectedIndex >= 0) cond = cboNoOfDays.Text;
                    addlCond = addlCond +
                               "    and Datediff ( day, (select TransDate from DTF_VSL_Outwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo), H.TransDate) " + cond + " " + txtNoOfDays.Text.Trim();
                }

                string script = " Select H.VesselID, V.VslName, V.VslCode, H.TransLotNo, H.TransDate " +
                                "    , replace(convert ( varchar(12), H.TransDate, 6),' ','')  + ' ' + replace(convert ( varchar(5), H.TransDate, 108),' ','') as TransDateDisplay " +
                                "    , (select TransDate from DTF_VSL_Outwards  where VesselID=V.VesselID and TransLotNo = H.TransLotNo ) VSLAckedDate " +
                                "    , (select replace(convert ( varchar(12), TransDate, 6),' ','')  + ' ' + replace(convert ( varchar(5), TransDate, 108),' ','') from DTF_VSL_Outwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo ) VSLAckedDateDisplay " +
                                "    , Datediff ( day, (select TransDate from DTF_VSL_Outwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo), H.TransDate) as NoDaysToAck " +
                                " from DTF_HQ_Inwards H, V_Vessels V " +
                                " where H.VesselID=V.VesselID " +
                                addlCond +
                                " order by H.TransDate desc, V.VslName, H.TransLotNo desc ";
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFHistory.cs", "GetDTFHistory_InwardsDataTable", err.Message);
            }
            return (dt);
        }

        private DataTable GetDTFHistory_OutwardsDataTable()
        {
            DataTable dt = null;
            try
            {
                string addlCond = "";

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (companyID != "-99") addlCond = addlCond + "  and V.C_CompanyID=" + companyID;

                string vslFilter = "";
                if (cboVesselFilter.SelectedValue != null) vslFilter = cboVesselFilter.SelectedValue.ToString().Trim();
                string[] vslType = vslFilter.Split('-');

                bool isToExcludeThirdParty = true;
                if (vslType[0].ToString().Trim().ToUpper() == "VSL")
                {
                    addlCond = addlCond + "    and V.VesselID=" + Gfn.Qss(vslType[1].ToString().Trim()) + Environment.NewLine;
                    isToExcludeThirdParty = false;
                }
                else
                {
                    addlCond = addlCond + "    and not exists (Select * from V_Vessels_Removed where VesselId=V.VesselID ) " +
                                          "    and V.OperateBy='VSL' ";

                    if (vslFilter != "-1" && vslFilter.Length > 0)
                    {
                        string groupList = Gfn.GetCommaTxtWithsingleQuotes(vslFilter, ",", -1, PG.Gb.DBFn);
                        addlCond = addlCond + " and exists (select * from V_Op_Groups_VSL_I where VesselID=V.VesselID and V_Op_GroupsID in (" + groupList + "))" + Environment.NewLine;
                        isToExcludeThirdParty = false;
                    }
                }

                if (isToExcludeThirdParty)
                {
                    addlCond = addlCond +
                                 "      and not exists (select * from V_Op_Groups_VSL_I I, V_Op_Groups G " +
                                 "           where I.VesselID=V.VesselId and I.V_Op_GroupsId=G.V_Op_GroupsID and G.C_CompanyID=V.C_CompanyID and G.GroupCode in ('" + PG.THIRDPARTYVSL + "') ) " + Environment.NewLine;
                }

                addlCond = addlCond + "    and ( (DATEADD(dd, 0, DATEDIFF(dd, 0, H.TransDate)))>=" + Gfn.Qs(dtpFrom.Value.ToString("yyyy.MM.dd")) +
                                      "      and (DATEADD(dd, 0, DATEDIFF(dd, 0, H.TransDate)))<=" + Gfn.Qs(dtpTo.Value.ToString("yyyy.MM.dd")) + ")" + Environment.NewLine;

                if (txtNoOfDays.Text.Trim().Length > 0)
                {
                    string cond = "=";
                    if (cboVesselFilter.SelectedIndex >= 0) cond = cboNoOfDays.Text;
                    addlCond = addlCond +
                               "    and Datediff ( day, H.TransDate, (select TransDate from DTF_VSL_Inwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo)) " + cond + " " + txtNoOfDays.Text.Trim();
                }

                string script = " Select H.VesselID, V.VslName, V.VslCode, H.TransLotNo, H.TransDate " +
                                "    , replace(convert ( varchar(12), H.TransDate, 6),' ','')  + ' ' + replace(convert ( varchar(5), H.TransDate, 108),' ','') as TransDateDisplay " +
                                "    , (select TransDate from DTF_VSL_Inwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo ) VSLAckedDate " +
                                "    , (select replace(convert ( varchar(12), TransDate, 6),' ','')  + ' ' + replace(convert ( varchar(5), TransDate, 108),' ','') from DTF_VSL_Inwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo ) VSLAckedDateDisplay " +
                                "    , Datediff ( day, H.TransDate, (select TransDate from DTF_VSL_Inwards where VesselID=V.VesselID and TransLotNo = H.TransLotNo)) as NoDaysToAck " +
                                " from DTF_HQ_Outwards H, V_Vessels V " +
                                " where H.VesselID=V.VesselID " +
                                addlCond +
                                " order by H.TransDate desc, V.VslName, H.TransLotNo desc ";
                dt = PG.Gb.DBFn.DbRecords(script);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmDTFHistory.cs", "GetDTFHistory_OutwardsDataTable", err.Message);
            }
            return (dt);
        }

        private void cboVesselFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            btnGo_Click(null, null);
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            if (!Validation())
            {
                tsLblTotalItems.Text = "";
                fpSpreadDTF.ActiveSheet.RowCount = 0;
            }

            BindDTFHistoryGrids();
        }

        private bool Validation()
        {
            DateTime fromDate = dtpFrom.Value;
            DateTime toDate = dtpTo.Value;
          
            TimeSpan ts = toDate - fromDate;
            if (ts.Days < 0)
            {
                Gfn.nMb("To Date cannot be less than From Date");
                return (false);
            }

            if (txtNoOfDays.Text.Trim().Length > 0)
            {
                try
                {
                    Convert.ToInt32(txtNoOfDays.Text.Trim());
                }
                catch {
                    Gfn.nMb("Invalid No. of days");
                    return (false);
                }
            }

            return (true);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearControls();
         
            BindDTFHistoryGrids();
        }

        private void ClearControls()
        {
            pnlProcessing.Visible = false;
            
            DateTime todaysDate = PG.GetDbServerDate();
            dtpFrom.Value = todaysDate.AddMonths(-1);
            if (callMode == "DTF")
            {
                dtpFrom.Value = todaysDate.AddMonths(-3);
            }
            dtpTo.Value = todaysDate;
            txtNoOfDays.Text = "";
            if (cboNoOfDays.Items.Count > 0) cboNoOfDays.SelectedIndex = 0;
        }

        private void txtNoOfDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Gfn.AllowOnlyNumeric(e);
        }


        private void fpSpreadDTF_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.ColumnHeader)
            {
                fpSpreadDTF.ActiveSheet.Columns[COL_TRANSDATE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
                fpSpreadDTF.ActiveSheet.Columns[COL_VSLACK].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;

                if (e.Column == COL_TRANSDATEDISPLAY)
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(COL_TRANSDATE);
                else if (e.Column == COL_ACKDISPLAY)
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(COL_VSLACK);
                else
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(e.Column);

                fpSpreadDTF.ActiveSheet.Columns[COL_TRANSDATEDISPLAY].SortIndicator = fpSpreadDTF.ActiveSheet.Columns[COL_TRANSDATE].SortIndicator;
                fpSpreadDTF.ActiveSheet.Columns[COL_ACKDISPLAY].SortIndicator = fpSpreadDTF.ActiveSheet.Columns[COL_VSLACK].SortIndicator;
            }
        }

        private void fpSpreadDTF_AutoSortingColumn(object sender, FarPoint.Win.Spread.AutoSortingColumnEventArgs e)
        {
            fpSpreadDTF.ActiveSheet.Columns[COL_TRANSDATE].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
            fpSpreadDTF.ActiveSheet.Columns[COL_VSLACK].SortIndicator = FarPoint.Win.Spread.Model.SortIndicator.None;
           
            int colToSort = -1;
            if (e.Column == COL_TRANSDATEDISPLAY) colToSort = COL_TRANSDATE;
            else if (e.Column == COL_ACKDISPLAY) colToSort = COL_VSLACK;

            if (colToSort > 0)
            {
                fpSpreadDTF.ActiveSheet.AutoSortColumn(colToSort);
                fpSpreadDTF.ActiveSheet.Columns[e.Column].SortIndicator = fpSpreadDTF.ActiveSheet.Columns[colToSort].SortIndicator;
                if (!e.Ascending)
                {
                    fpSpreadDTF.ActiveSheet.AutoSortColumn(colToSort);
                    fpSpreadDTF.ActiveSheet.Columns[e.Column].SortIndicator = fpSpreadDTF.ActiveSheet.Columns[colToSort].SortIndicator;
                }
                e.Cancel = true;
            }
            if (fpSpreadDTF.ActiveSheet.RowCount > 0)
            {
                fpSpreadDTF.ActiveSheet.SetActiveCell(0, 0);
                fpSpreadDTF.SetViewportTopRow(0, 0);
            }
        }


        private void btnExportXL_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            DataTable dt = null;
            FarPoint.Win.Spread.FpSpread fs = new FarPoint.Win.Spread.FpSpread();
            try
            {
                DateTime todaysDate = PG.GetDbServerDate();
                if (rdoHQInwards.Checked) dt = GetDTFHistory_InwardsDataTable();
                else dt = GetDTFHistory_OutwardsDataTable();
                if (dt == null)
                {
                    Gfn.nMbwithAlignAndCentrePosn("No rows to export", ContentAlignment.MiddleCenter, 100, 250);
                    return;
                }

                string filter = "HQ Inwards", fileNamePrefix = "Inwards";
                if (rdoHQOutwards.Checked)
                {
                    filter = "HQ Outwards";
                    fileNamePrefix = "Outwards";
                }

                filter = "Filter: " + filter + Environment.NewLine;
                if (cboVesselFilter.SelectedValue != null) filter = filter + "  Vessel: " + cboVesselFilter.Text + ", ";

                filter = filter + "  Trans Date: From " + dtpFrom.Value.ToString("dd-MMM-yyyy") + " to " + dtpTo.Value.ToString("dd-MMM-yyyy") + Environment.NewLine;

                if (txtNoOfDays.Text.Trim().Length > 0)
                {
                    filter = filter + "  No of days to ack  " + cboNoOfDays.Text  + " " + txtNoOfDays.Text.Trim() + " day(s)" + Environment.NewLine;
                }

                DesignAndFillupExportGrid(fs, dt, todaysDate, filter);

                string fileName = PG.xlsOutputFolderPath + "\\" + PG.hqAppFolder + "_DTFHistory_" + fileNamePrefix + "_" + todaysDate.ToString("ddMMMyyyy_hhmmssff") + ".xls";
                if (fileName.Length == 0) return;
                if (!Gfn.DeleteFileIfExists(fileName)) return;
                bool hasExportedSuccessfully = (fs.SaveExcel(fileName, FarPoint.Excel.ExcelSaveFlags.SaveCustomColumnHeaders));
                if (hasExportedSuccessfully) System.Diagnostics.Process.Start(fileName);
            }
            finally 
            {
                fs = null;
                dt = null;
                this.Cursor = Cursors.Default;
            }
        }

        private void DesignAndFillupExportGrid(FarPoint.Win.Spread.FpSpread fs, DataTable dt, DateTime todaysDate, string filter)
        {
            List<DgvInits> colList = new List<DgvInits>();
            try
            {
                fs.SuspendLayout();

                FarPoint.Win.Spread.SheetView fs_Sheet1 = new FarPoint.Win.Spread.SheetView();
                fs.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] { fs_Sheet1 });
                FarPoint.Win.Spread.DefaultSpreadSkins.Classic.Apply(fs);
                fs.Font = new Font("Verdana", 8, FontStyle.Regular);

                colList.Add(new DgvInits("VesselID", "Vsl ID", 45, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslCode", "Vsl Code", 60, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("VslName", "Vsl Name", 190, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                colList.Add(new DgvInits("TransLotNo", "Trans No.", 55, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));

                if (rdoHQInwards.Checked)
                {
                    colList.Add(new DgvInits("VSLAckedDateDisplay", "VSL Sent Date", 100, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                    colList.Add(new DgvInits("TransDateDisplay", "HQ Recvd Date", 100, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                }
                else
                {
                    colList.Add(new DgvInits("TransDateDisplay", "HQ Sent Date", 100, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                    colList.Add(new DgvInits("VSLAckedDateDisplay", "VSL Recvd Date", 100, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));
                }

                colList.Add(new DgvInits("NoDaysToAck", "No. days To Ack", 70, Color.Black, SystemColors.ButtonFace, true, true, SystemColors.Info, Color.Black));

                FarPtColCtrls.GenerateFarPointGridView(fs, colList, dt, false, true, false);

                fs.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fs.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fs.ActiveSheet.RowHeader.Columns[0].Width = 20;
                fs.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;

                fs.ActiveSheet.SelectionBackColor = Color.FromArgb(255, 255, 128);
                fs.ActiveSheet.SelectionForeColor = Color.Maroon;
                fs.ActiveSheet.SelectionFont = new Font("Verdana", 8F, FontStyle.Regular);
              
                fs.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, Color.Empty);
                fs.ActiveSheet.VerticalGridLine = gdln;
                fs.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                if ((fs.ActiveSheet.RowCount > 0) && (fs.ActiveSheet.ColumnCount > 0))
                {
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                    fs.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fs.ActiveSheet.ColumnCount - 1].VisualStyles = FarPoint.Win.VisualStyles.Off;

                    fs.ActiveSheet.Cells[0, 0, fs.ActiveSheet.RowCount - 1, fs.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.LightGray, 1, true, true, true, true);
                }

                //Heading + Date
                fs.ActiveSheet.ColumnHeader.Rows[0].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(0, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].Text= this.Text + "       " + todaysDate.ToString("dd-MMM-yyyy");
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].Font = new Font("Arial", 14, FontStyle.Bold);
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].ForeColor = Color.Blue;
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[0, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fs.ActiveSheet.ColumnHeader.Rows[0].Height = 25;
                
                //Filter
                fs.ActiveSheet.ColumnHeader.Rows[1].Add();
                fs.ActiveSheet.AddColumnHeaderSpanCell(1, 0, 1, fs.ActiveSheet.ColumnCount);
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].Text = filter;
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].Font = new Font("Arial", 10, FontStyle.Regular);
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                fs.ActiveSheet.ColumnHeader.Cells[1, 0].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                fs.ActiveSheet.ColumnHeader.Rows[1].Height = 51;

                if (fs.ActiveSheet.RowCount > 0)
                {
                    for (int row = 0; row < fs.ActiveSheet.RowCount; row++)
                    {
                        fs.ActiveSheet.Rows[row].Height = fs.ActiveSheet.Rows[row].GetPreferredHeight();
                    }

                }
                fs.ActiveSheet.Protect = false;
            }
            catch (Exception err)
            {
                Gfn.nMb("Failed to export DTF History " + err.Message);
                PG.AddToGenErrorLog("frmDTFHistory.cs", "DesignAndFillupExportGrid", err.Message);
            }
            finally
            {
                fs.ResumeLayout();
                colList = null;
            }
        }


        private void btnInwards_Click(object sender, EventArgs e)
        {
            if (!Gfn.nConfBox("Are you sure do you want to Update DTF from Vessel?")) return;

            string companyCode = cboCompany_Filter.Text.ToUpper();
            if (companyCode.Trim().Length <= 0) companyCode = PG.Gb.Companycode;

            string param = PG.GetAppParam(companyCode, vslId, true);

            string[] args = { "HqDtf", param, " INWARDS|INWARDS|YES|" + vslId };
            HqDtf.DirectAccess.HQDTFApplication(args);
            BindDTFHistoryGrids();
        }

        private void btnOutwards_Click(object sender, EventArgs e)
        {
            if (!Gfn.nConfBox("Are you sure do you want to Send DTF to Vessel?")) return;

            string companyCode = cboCompany_Filter.Text.ToUpper();
            if (companyCode.Trim().Length <= 0) companyCode = PG.Gb.Companycode;

            string param = PG.GetAppParam(companyCode, vslId, true);

            string[] args = { "HqDtf", param, " OUTWARDS|OUTWARDS|YES|" + vslId };
            HqDtf.DirectAccess.HQDTFApplication(args);
            BindDTFHistoryGrids();
        }

        private void tsMnuSendDTFToVsl_Click(object sender, EventArgs e)
        {
            btnOutwards_Click(sender, e);
        }

        private void tsMnuReSendDTF_Click(object sender, EventArgs e)
        {
            int resend_translotno = -1;
            int rowIndex = fpSpreadDTF.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;
            resend_translotno = Convert.ToInt32(fpSpreadDTF.ActiveSheet.Cells[rowIndex, COL_TRANSLOTNO].Value.ToString());

            if (!Gfn.nConfBox("Are you sure do you want to Re-Send "+Environment.NewLine+" the Selected DTF No.: " + resend_translotno + " to Vessel?")) return;
            
            string companyCode = cboCompany_Filter.Text.ToUpper();
            if (companyCode.Trim().Length <= 0) companyCode = PG.Gb.Companycode;

            string param = PG.GetAppParam(companyCode, vslId, true);

            string[] args = { "HqDtf", param, " RESEND_OUTWARDS|RESEND_OUTWARDS|YES|" + vslId + "|" + resend_translotno };
            HqDtf.DirectAccess.HQDTFApplication(args);

            BindDTFHistoryGrids();
        }

        private void fpSpreadDTF_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpreadDTF.ContextMenuStrip = null;
            if (e.Button == MouseButtons.Right)
            {
                if (fpSpreadDTF.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpreadDTF.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpreadDTF.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;
                fpSpreadDTF.ActiveSheet.SetActiveCell(row, col);
                fpSpreadDTF.ContextMenuStrip = null;
                if (rdoHQOutwards.Checked) fpSpreadDTF.ContextMenuStrip = contextMenuStrip1;
            }
        }

        
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
