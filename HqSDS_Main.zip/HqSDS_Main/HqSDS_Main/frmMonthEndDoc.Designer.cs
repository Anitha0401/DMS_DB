﻿namespace HqSDS_Main
{
    partial class frmMonthEndDoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            FarPoint.Win.Spread.DefaultFocusIndicatorRenderer defaultFocusIndicatorRenderer2 = new FarPoint.Win.Spread.DefaultFocusIndicatorRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer3 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            FarPoint.Win.Spread.DefaultScrollBarRenderer defaultScrollBarRenderer4 = new FarPoint.Win.Spread.DefaultScrollBarRenderer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.fpSpread1 = new FarPoint.Win.Spread.FpSpread();
            this.fpSpread1_Sheet1 = new FarPoint.Win.Spread.SheetView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsLblSvrName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLblUserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tlsStatuslblTotalVessels = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMonthEndDocument = new System.Windows.Forms.Button();
            this.cboCompany_Filter = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lnkRefresh = new System.Windows.Forms.LinkLabel();
            this.cboVslFilter = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.VslApps_toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmu_VslDashBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsMnuVslMonthEndDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.fpSpread1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(422, 672);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // fpSpread1
            // 
            this.fpSpread1.AccessibleDescription = "fpSpread1, Sheet1, Row 0, Column 0, ";
            this.fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
            this.fpSpread1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fpSpread1.FocusRenderer = defaultFocusIndicatorRenderer2;
            this.fpSpread1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fpSpread1.HorizontalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.HorizontalScrollBar.Name = "";
            this.fpSpread1.HorizontalScrollBar.Renderer = defaultScrollBarRenderer3;
            this.fpSpread1.HorizontalScrollBar.TabIndex = 14;
            this.fpSpread1.Location = new System.Drawing.Point(3, 82);
            this.fpSpread1.Name = "fpSpread1";
            this.fpSpread1.Sheets.AddRange(new FarPoint.Win.Spread.SheetView[] {
            this.fpSpread1_Sheet1});
            this.fpSpread1.Size = new System.Drawing.Size(416, 567);
            this.fpSpread1.Skin = FarPoint.Win.Spread.DefaultSpreadSkins.Classic;
            this.fpSpread1.TabIndex = 22;
            this.fpSpread1.VerticalScrollBar.Buttons = new FarPoint.Win.Spread.FpScrollBarButtonCollection("BackwardLineButton,ThumbTrack,ForwardLineButton");
            this.fpSpread1.VerticalScrollBar.Name = "";
            this.fpSpread1.VerticalScrollBar.Renderer = defaultScrollBarRenderer4;
            this.fpSpread1.VerticalScrollBar.TabIndex = 15;
            this.fpSpread1.VisualStyles = FarPoint.Win.VisualStyles.Off;
            this.fpSpread1.CellDoubleClick += new FarPoint.Win.Spread.CellClickEventHandler(this.fpSpread1_CellDoubleClick);
            this.fpSpread1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fpSpread1_MouseDown);
            // 
            // fpSpread1_Sheet1
            // 
            this.fpSpread1_Sheet1.Reset();
            this.fpSpread1_Sheet1.SheetName = "Sheet1";
            // Formulas and custom names must be loaded with R1C1 reference style
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1;
            this.fpSpread1_Sheet1.ColumnCount = 4;
            this.fpSpread1_Sheet1.RowCount = 10;
            this.fpSpread1_Sheet1.AutoGenerateColumns = false;
            this.fpSpread1_Sheet1.AutoUpdateNotes = false;
            this.fpSpread1_Sheet1.Cells.Get(0, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(1, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(2, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(3, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(4, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(4, 0).Font = new System.Drawing.Font("Calibri", 9F);
            this.fpSpread1_Sheet1.Cells.Get(4, 0).ForeColor = System.Drawing.Color.Black;
            this.fpSpread1_Sheet1.Cells.Get(5, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(5, 0).Font = new System.Drawing.Font("Calibri", 9F);
            this.fpSpread1_Sheet1.Cells.Get(5, 0).ForeColor = System.Drawing.Color.Maroon;
            this.fpSpread1_Sheet1.Cells.Get(6, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(7, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(8, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.Cells.Get(9, 0).BackColor = System.Drawing.Color.Wheat;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnFooterSheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault";
            this.fpSpread1_Sheet1.Columns.Get(0).BackColor = System.Drawing.SystemColors.ControlLight;
            this.fpSpread1_Sheet1.Columns.Get(0).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(0).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(0).Width = 160F;
            this.fpSpread1_Sheet1.Columns.Get(1).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Columns.Get(1).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(1).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(1).Width = 48F;
            this.fpSpread1_Sheet1.Columns.Get(2).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Columns.Get(2).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(2).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(2).Width = 48F;
            this.fpSpread1_Sheet1.Columns.Get(3).BackColor = System.Drawing.Color.White;
            this.fpSpread1_Sheet1.Columns.Get(3).Font = new System.Drawing.Font("Arial", 8F);
            this.fpSpread1_Sheet1.Columns.Get(3).ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.fpSpread1_Sheet1.Columns.Get(3).Width = 48F;
            this.fpSpread1_Sheet1.DisplayZero = false;
            this.fpSpread1_Sheet1.HorizontalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))));
            this.fpSpread1_Sheet1.RowHeader.Columns.Default.Resizable = false;
            this.fpSpread1_Sheet1.RowHeader.Columns.Get(0).Width = 33F;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.RowHeader.DefaultStyle.Parent = "RowHeaderDefault";
            this.fpSpread1_Sheet1.RowHeader.Visible = false;
            this.fpSpread1_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red;
            this.fpSpread1_Sheet1.SheetCornerStyle.Parent = "CornerDefault";
            this.fpSpread1_Sheet1.VerticalGridLine = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.Flat, System.Drawing.Color.SandyBrown);
            this.fpSpread1_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsLblSvrName,
            this.tsLblUserId,
            this.toolStripStatusLabel2,
            this.tlsStatuslblTotalVessels});
            this.statusStrip1.Location = new System.Drawing.Point(0, 652);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(422, 20);
            this.statusStrip1.TabIndex = 25;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsLblSvrName
            // 
            this.tsLblSvrName.AutoSize = false;
            this.tsLblSvrName.Margin = new System.Windows.Forms.Padding(3, 3, 0, 2);
            this.tsLblSvrName.Name = "tsLblSvrName";
            this.tsLblSvrName.Size = new System.Drawing.Size(150, 15);
            this.tsLblSvrName.Text = "Svr                            ";
            // 
            // tsLblUserId
            // 
            this.tsLblUserId.AutoSize = false;
            this.tsLblUserId.Name = "tsLblUserId";
            this.tsLblUserId.Size = new System.Drawing.Size(100, 15);
            this.tsLblUserId.Text = "User";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.AutoSize = false;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(10, 15);
            this.toolStripStatusLabel2.Text = "                                             ";
            // 
            // tlsStatuslblTotalVessels
            // 
            this.tlsStatuslblTotalVessels.AutoSize = false;
            this.tlsStatuslblTotalVessels.ForeColor = System.Drawing.Color.Blue;
            this.tlsStatuslblTotalVessels.Name = "tlsStatuslblTotalVessels";
            this.tlsStatuslblTotalVessels.Size = new System.Drawing.Size(100, 15);
            this.tlsStatuslblTotalVessels.Text = "Total Vessel(s):";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Beige;
            this.panel1.Controls.Add(this.cboCompany_Filter);
            this.panel1.Controls.Add(this.cboVslFilter);
            this.panel1.Controls.Add(this.btnMonthEndDocument);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lnkRefresh);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 20);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(422, 59);
            this.panel1.TabIndex = 23;
            // 
            // btnMonthEndDocument
            // 
            this.btnMonthEndDocument.Location = new System.Drawing.Point(310, 8);
            this.btnMonthEndDocument.Name = "btnMonthEndDocument";
            this.btnMonthEndDocument.Size = new System.Drawing.Size(75, 45);
            this.btnMonthEndDocument.TabIndex = 55;
            this.btnMonthEndDocument.Text = "Month End Document";
            this.btnMonthEndDocument.UseVisualStyleBackColor = true;
            this.btnMonthEndDocument.Click += new System.EventHandler(this.btnMonthEndDocument_Click);
            // 
            // cboCompany_Filter
            // 
            this.cboCompany_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCompany_Filter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCompany_Filter.FormattingEnabled = true;
            this.cboCompany_Filter.Location = new System.Drawing.Point(70, 4);
            this.cboCompany_Filter.MaxDropDownItems = 15;
            this.cboCompany_Filter.Name = "cboCompany_Filter";
            this.cboCompany_Filter.Size = new System.Drawing.Size(94, 23);
            this.cboCompany_Filter.TabIndex = 54;
            this.cboCompany_Filter.SelectedIndexChanged += new System.EventHandler(this.cboCompany_Filter_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 15);
            this.label2.TabIndex = 53;
            this.label2.Text = "Company : ";
            // 
            // lnkRefresh
            // 
            this.lnkRefresh.AutoSize = true;
            this.lnkRefresh.Location = new System.Drawing.Point(245, 11);
            this.lnkRefresh.Name = "lnkRefresh";
            this.lnkRefresh.Size = new System.Drawing.Size(44, 13);
            this.lnkRefresh.TabIndex = 52;
            this.lnkRefresh.TabStop = true;
            this.lnkRefresh.Text = "Refresh";
            this.lnkRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRefresh_LinkClicked);
            // 
            // cboVslFilter
            // 
            this.cboVslFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVslFilter.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboVslFilter.FormattingEnabled = true;
            this.cboVslFilter.Location = new System.Drawing.Point(70, 31);
            this.cboVslFilter.MaxDropDownItems = 15;
            this.cboVslFilter.Name = "cboVslFilter";
            this.cboVslFilter.Size = new System.Drawing.Size(231, 23);
            this.cboVslFilter.TabIndex = 49;
            this.cboVslFilter.SelectedIndexChanged += new System.EventHandler(this.cboVslFilter_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(21, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 15);
            this.label9.TabIndex = 48;
            this.label9.Text = "Vessel :";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(422, 20);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuExit});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 16);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(92, 22);
            this.mnuExit.Text = "Exit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.VslApps_toolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(229, 26);
            // 
            // VslApps_toolStripMenuItem1
            // 
            this.VslApps_toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmu_VslDashBoard,
            this.toolStripSeparator3,
            this.tsMnuVslMonthEndDoc});
            this.VslApps_toolStripMenuItem1.Name = "VslApps_toolStripMenuItem1";
            this.VslApps_toolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.VslApps_toolStripMenuItem1.Text = "Vsl Applications ( View Only )";
            // 
            // tsmu_VslDashBoard
            // 
            this.tsmu_VslDashBoard.Name = "tsmu_VslDashBoard";
            this.tsmu_VslDashBoard.Size = new System.Drawing.Size(192, 22);
            this.tsmu_VslDashBoard.Text = "Vsl Dashboard";
            this.tsmu_VslDashBoard.Click += new System.EventHandler(this.tsmu_VslDashBoard_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(189, 6);
            // 
            // tsMnuVslMonthEndDoc
            // 
            this.tsMnuVslMonthEndDoc.Name = "tsMnuVslMonthEndDoc";
            this.tsMnuVslMonthEndDoc.Size = new System.Drawing.Size(192, 22);
            this.tsMnuVslMonthEndDoc.Text = "Month End Document";
            this.tsMnuVslMonthEndDoc.Click += new System.EventHandler(this.tsMnuVslMonthEndDoc_Click);
            // 
            // frmMonthEndDoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 672);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmMonthEndDoc";
            this.Text = "Month End Document";
            this.Load += new System.EventHandler(this.frmMonthEndDoc_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fpSpread1_Sheet1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private FarPoint.Win.Spread.FpSpread fpSpread1;
        private FarPoint.Win.Spread.SheetView fpSpread1_Sheet1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cboVslFilter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem VslApps_toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsmu_VslDashBoard;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem tsMnuVslMonthEndDoc;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsLblUserId;
        private System.Windows.Forms.ToolStripStatusLabel tlsStatuslblTotalVessels;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.LinkLabel lnkRefresh;
        private System.Windows.Forms.ComboBox cboCompany_Filter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripStatusLabel tsLblSvrName;
        private System.Windows.Forms.Button btnMonthEndDocument;
    }
}