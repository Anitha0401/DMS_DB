﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMainForm_NCR : Form
    {
        public int formLeft = 20, formTop = 20;
        Common common = null;
        bool isFormInitialised = false;

        int COL_COMPANYCODE = 0,
            COL_VSLCODE = 1,
            COL_VSLNAME = 2,
            COL_NCR_VSLPENDING = 3,
            COL_NCR_DPA_PENDING = 4,
            COL_NCR_CREW_PENDING = 5,
            COL_NCR_TECH_PENDING = 6,
            COL_NCR_VSL_AMEND_ACK = 7,
            COL_NCR_RECENTLYCLOSED = 8,
            COL_VESSELID = 9;

        const int NCR_STATUS_VSLPENDING = 10, NCR_STATUS_VSLAMEND = 30, NCR_STATUS_DPAPENDING = 50, NCR_STATUS_TECHPENDING = 60, NCR_STATUS_CREWPENDING = 70, NCR_STATUS_CLOSED = 100;

        public frmMainForm_NCR()
        {
            InitializeComponent();
        }

        private void frmMainForm_NCR_Load(object sender, EventArgs e)
        {
            PG.SetFormWidthAndHeight(this, formLeft, formTop, 650, 615);

            common = new Common();

            if (PG.Gb.IsToConnecDirectDB) tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();
            tsLblUserId.Text = "User: " + PG.Gb.User.CurUserName;

            string fileName = PG.Gb.WinSDSrootDir + "\\Images\\" + PG.Gb.Companycode + "HQ_SDS.ico";
            if (File.Exists(fileName))
            {
                Icon ic = new Icon(fileName);
                this.Icon = ic;
            }

            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, false);
            
            DesignNCRGridDetails();
            SelectDefaultOption();

            isFormInitialised = true;

            cboCompany_Filter_SelectedIndexChanged(null, null);
        }

        protected void DesignNCRGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();
            try
            {
                Color rowHeaderForeColor = Color.Blue;
                particularsColList.Add(new DgvInits("CompanyCode", "Company", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 160, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Vsl_Pending", "Vessel", 50, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("NCR_DPA_Pending", "DPA", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Crew_Pending", "Crew", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Tech_Pending", "Tech", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Vsl_Amend_Ack", "Vsl To Amend & Ack", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Recently_Closed", "Recently Closed NCRs", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, false, true));

                fpSpread1.SuspendLayout();

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, particularsColList, null, false, false, false);

                fpSpread1.ActiveSheet.ColumnHeader.RowCount = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_COMPANYCODE].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_VSLCODE].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_VSLNAME].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSL_AMEND_ACK].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_RECENTLYCLOSED].RowSpan = 2;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, COL_NCR_VSLPENDING].Text = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].Text;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, COL_NCR_DPA_PENDING].Text = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_DPA_PENDING].Text;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, COL_NCR_CREW_PENDING].Text = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_PENDING].Text;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, COL_NCR_TECH_PENDING].Text = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TECH_PENDING].Text;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].ColumnSpan = 4;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].Text = "Count of NCRs Pending";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].ForeColor = Color.Blue;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].Font = new Font("Verdana", 10, FontStyle.Bold);
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                if (fpSpread1.ActiveSheet.ColumnCount > 0)
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].ForeColor = Color.Black;
                    fpSpread1.ActiveSheet.Columns[COL_NCR_VSLPENDING, COL_NCR_RECENTLYCLOSED].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                    fpSpread1.ActiveSheet.ColumnHeader.Columns[COL_NCR_VSLPENDING, COL_NCR_TECH_PENDING].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                }
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_VSLPENDING].ForeColor = Color.Blue;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 30;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Height = 40;

                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;
                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;
                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread1.ActiveSheet.DisplayZero = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMainForm_NCR.cs", "DesignNCRGridDetails", er.Message);
                Gfn.Mb("Failed to design NCR Grid");
            }
            finally
            {
                fpSpread1.ResumeLayout();
                particularsColList = null;
            }
        }

        private void SelectDefaultOption()
        {
            try
            {
                rdoAll.Checked = true;
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SUPT" || PG.Gb.User.CurrentUserRole.ToUpper() == "MANAGER")
                {
                    string hqDept = PG.Gb.DBFn.Aqr("Select HQDept from HQ_Users where UserID=" + Gfn.Qss(PG.Gb.User.CurUserID)).ToString().Trim();
                    if (hqDept.ToUpper() == PG.HSQE_DeptName.ToUpper() || hqDept.ToUpper() == "Marine".ToUpper()) rdoDPAPending.Checked = true;
                    else if (hqDept.ToUpper() == "CREW") rdoCrewPending.Checked = true;
                    else if (hqDept.ToUpper() == "TECH") rdoTechPending.Checked = true;
                }
            }
            catch(Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_NCR.cs", "SelectDefaultOption", err.Message);
            }
        }

        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (!PG.InitialiseCommonSettings(companyID)) return;

                common.BindVslDropDownList(cboVslFilter, companyID, true);

                cboVslFilter_SelectedIndexChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_NCR.cs", "cboCompany_Filter_SelectedIndexChanged", err.Message);
            }
        }

        private void cboVslFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;
            try
            {
                fpSpread1.SuspendLayout();

                tlsStatuslblTotalVessels.Text = "Total Vessel(s): 0";
                fpSpread1.ActiveSheet.RowCount = 0;

                if (cboVslFilter.SelectedValue == null || common == null) return;

                string vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string statusFilter = "";
                if (rdoVSLPending.Checked) statusFilter = NCR_STATUS_VSLPENDING.ToString();
                else if (rdoDPAPending.Checked) statusFilter = NCR_STATUS_DPAPENDING.ToString();
                else if (rdoCrewPending.Checked) statusFilter = NCR_STATUS_CREWPENDING.ToString();
                else if (rdoTechPending.Checked) statusFilter = NCR_STATUS_TECHPENDING.ToString();
                else if (rdoVslAmend_Ack.Checked) statusFilter = "-90";

                fpSpread1.ActiveSheet.DataSource = common.GetNCRDataTable(vslFilter, statusFilter, companyID);

                fpSpread1.ActiveSheet.Columns[COL_COMPANYCODE].Visible = (cboCompany_Filter.SelectedValue != null && cboCompany_Filter.SelectedValue.ToString() == "-99");

                if (fpSpread1.ActiveSheet.RowCount > 0 && fpSpread1.ActiveSheet.ColumnCount > 0)
                {
                    int rowCount = fpSpread1.ActiveSheet.RowCount - 1;
                    fpSpread1.ActiveSheet.Cells[0, 0, rowCount, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.FromArgb(244,164,96), 1, false, false, true, true);
                    fpSpread1.ActiveSheet.Cells[0, COL_COMPANYCODE, rowCount, COL_VSLNAME].BackColor = Color.FromArgb(245,222,179);
                    fpSpread1.ActiveSheet.Cells[0, COL_COMPANYCODE, rowCount, COL_VSLNAME].ForeColor = Color.Black;
                    
                    tlsStatuslblTotalVessels.Text = "Total Vessel(s):" + fpSpread1.ActiveSheet.RowCount;

                    for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
                    {
                        if ((fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSLPENDING].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSLPENDING].Value.ToString() == "0") || fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSLPENDING].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSLPENDING].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSLPENDING].Text = "0";
                        }

                        if ((fpSpread1.ActiveSheet.Cells[row, COL_NCR_DPA_PENDING].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_NCR_DPA_PENDING].Value.ToString() == "0") || fpSpread1.ActiveSheet.Cells[row, COL_NCR_DPA_PENDING].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_DPA_PENDING].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_DPA_PENDING].Text = "0";
                        }

                        if ((fpSpread1.ActiveSheet.Cells[row, COL_NCR_CREW_PENDING].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_NCR_CREW_PENDING].Value.ToString() == "0") || fpSpread1.ActiveSheet.Cells[row, COL_NCR_CREW_PENDING].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_CREW_PENDING].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_CREW_PENDING].Text = "0";
                        }

                        if ((fpSpread1.ActiveSheet.Cells[row, COL_NCR_TECH_PENDING].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_NCR_TECH_PENDING].Value.ToString() == "0") || fpSpread1.ActiveSheet.Cells[row, COL_NCR_TECH_PENDING].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_TECH_PENDING].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_TECH_PENDING].Text = "0";
                        }

                        if ((fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSL_AMEND_ACK].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSL_AMEND_ACK].Value.ToString() == "0") || fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSL_AMEND_ACK].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSL_AMEND_ACK].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_VSL_AMEND_ACK].Text = "0";
                        }

                        if ((fpSpread1.ActiveSheet.Cells[row, COL_NCR_RECENTLYCLOSED].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_NCR_RECENTLYCLOSED].Value.ToString() == "0") || fpSpread1.ActiveSheet.Cells[row, COL_NCR_RECENTLYCLOSED].Value == null)
                        {
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_RECENTLYCLOSED].ForeColor = Color.DarkGray;
                            fpSpread1.ActiveSheet.Cells[row, COL_NCR_RECENTLYCLOSED].Text = "0";
                        }
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_NCR.cs", "cboVslFilter_SelectedIndexChanged", err.Message);
                Gfn.Eb("Failed to refresh grid");
            }
            finally
            {
                fpSpread1.ResumeLayout();
            }
        }

        private void rdoOption_CheckedChanged(object sender, EventArgs e)
        {
            cboVslFilter_SelectedIndexChanged(null, null);
        }

        private void fpSpread1_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0 || e.ColumnHeader) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                this.Cursor = Cursors.Default;
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            int cnt = 0;
            if (e.Column == COL_NCR_VSLPENDING)
            {
                #region Pending NCR
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_VSLPENDING].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_VSLPENDING].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no VSL Pending NCR.");
                    return;
                }

                string addlParameter = "VslPending";
                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_NCR_DPA_PENDING)
            {
                #region NCR for DPA Supt to APPR
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_DPA_PENDING].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_DPA_PENDING].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no NCR for DPA Supt to Approve.");
                    return;
                }

                string addlParameter = "DPAPending";
                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_NCR_CREW_PENDING)
            {
                #region NCR for Crew Supt to APPR
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_CREW_PENDING].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_CREW_PENDING].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no NCR for Crew Supt to Approve.");
                    return;
                }

                string addlParameter = "CrewPending";
                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_NCR_TECH_PENDING)
            {
                #region NCR for Tech Supt to APPR
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_TECH_PENDING].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_TECH_PENDING].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no NCR for Tech Supt to Approve.");
                    return;
                }

                string addlParameter = "TechPending";
                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_NCR_VSL_AMEND_ACK)
            {
                #region NCR for Vsl to Amend or Ack
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_VSL_AMEND_ACK].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_VSL_AMEND_ACK].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no NCR for Vsl to Amend/Ack.");
                    return;
                }

                string addlParameter = "VslAmend_Ack";
                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_NCR_RECENTLYCLOSED)
            {
                #region NCR Closed
                if (fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_RECENTLYCLOSED].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_NCR_RECENTLYCLOSED].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no NCR Closed.");
                    return;
                }

                string addlParameter = "RecentlyClosed";
                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
        }

        private void fpSpread1_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread1.ContextMenuStrip = null;
            if (fpSpread1.ActiveSheet.RowCount > 0) fpSpread1.ActiveSheet.Rows[0, fpSpread1.ActiveSheet.RowCount - 1].ResetBackColor();

            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread1.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;

                fpSpread1.ActiveSheet.SetActiveCell(row, col);
                fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;

                fpSpread1.ContextMenuStrip = contextMenuStrip1;
            }
        }

        private void tsmu_VslDashBoard_Click(object sender, EventArgs e)
        {
            CallVslApplication("VslDashBoard");
        }

        private void tsMnuVslNCR_Click(object sender, EventArgs e)
        {
            CallVslApplication("NCR");
        }

        private void tsMnuNCR_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallNCRApplication(vesselID, "NCR", true, false);
        }


        private void CallVslApplication(string exeName)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            string param = GetParam(vesselID, true);

            if (exeName.ToUpper() == "NCR".ToUpper())
            {
                CallNCRApplication(vesselID, "", false, true);
            }
            else
            {
                if (exeName.ToUpper() == "PmsMain".ToUpper())
                {
                    exeName = "VslDashBoard";
                    param = param + " PmsMain";
                }
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
            }
            FocusSelectedVessel(vesselID);
        }

        private void CallNCRApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim();
            NCR.NCRstartup ncrStartup = new NCR.NCRstartup(arg.Split(' '));

            try
            {
                if (!ncrStartup.isVslInitSuccessfully)
                {
                    return;
                }

                ncrStartup.CallNCRRegisterMainPage();
            }
            finally
            {
                ncrStartup = null;
            }

            if (isToRefresh)
            {
                PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_NCR, vesselID);
                cboVslFilter_SelectedIndexChanged(null, null);
                FocusSelectedVessel(vesselID);
            }
        }

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = PG.hqAppFolder + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = PG.hqAppFolder + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            return param;

        }

        private void FocusSelectedVessel(int vesselID)
        {
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                int curVesselID = -1;
                if (fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value != null) curVesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value);
                if (curVesselID == vesselID)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(row, 0);
                    int topRow = row;
                    if (topRow > 10) topRow = topRow - 10;
                    fpSpread1.SetViewportTopRow(0, topRow);

                    fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    break;
                }
            }
        }

        private void lnkRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                string addlCond = "";
                if (PG.laidupVessels.Trim().Length > 0)
                {
                    addlCond = addlCond + "   and V.VslCode not in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                }

                string script = " Select V.VesselID from Dashboard_HQ_Main_Marine_Status S, V_Vessels V " +
                                " Where S.VesselID=V.VesselID " +
                                "   and V.VesselID<>-1" +
                                addlCond;
                DataTable dt = PG.Gb.DBFn.DbRecords(script);

                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    PG.Refresh_HQ_Dashboard_Tech(PG.REFRESH_CALLEDMODE_TECH_NCR, Convert.ToInt32(dr["VesselID"].ToString()));
                }

                cboVslFilter_SelectedIndexChanged(null, null);
                Gfn.Mb("Refresh Completed");
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_NCR.cs", "lnkRefresh_LinkClicked", err.Message);
            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
