﻿using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Security.AccessControl;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    class MainFrm
    {
        DataTable dtTemp = null;

        public int GetGroupMaxColCnt(string dashboardType, string companyID)
        {
            int maxGrpCol = 0;
            try
            {
                string addCond = "";
                if(companyID != "-99") addCond = "   and C_CompanyID = " + companyID;

                string sql = " Select isnull(max(colNo),0) MaxCol from VUI_Groups_HQ " +
                             " where DashboardType='" + dashboardType + "' " +
                            addCond;
                maxGrpCol = Convert.ToInt32(PG.Gb.DBFn.Aqr(sql));
            }
            catch (Exception err)
            {

                PG.AddToGenErrorLog("mainFrm.cs", "GetGroupMaxColCnt", err.Message);
            }
            return (maxGrpCol);
        }

        public DataTable GetGroupDataTable(string dashboardType, string companyID)
        {
            DataTable dtGroup = null;
            try
            {
                string addCond = "";
                if (companyID != "-99") addCond = "   and C_CompanyID = " + companyID;
                string sql = " select * from VUI_Groups_HQ " +
                             " where VUI_Groups_HQID >0 and DashboardType='" + dashboardType + "' " +
                             addCond + 
                             " order by rowNo, ColNo ";
                dtGroup = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "GetGroupDataTable", err.Message);
            }
            return (dtGroup);
        }

        public DataTable GetGroupItemWiseDataTable(string dashboardType, string companyID)
        {
            DataTable dtGroupItem = null;
            try
            {
                string addCond = "";
                if (companyID != "-99") addCond = "   and I.C_CompanyID = " + companyID;

                string sql = " select I.* from VUI_GroupItems_HQ I, VUI_Groups_HQ G " +
                             " where I.VUI_Groups_HQID=G.VUI_Groups_HQID " +
                             "   and G.VUI_Groups_HQid >0 " +
                             "   and G.DashboardType=I.DashboardType " +
                             "   and G.DashboardType = '" + dashboardType + "' " +
                             "   and I.C_companyid = G.C_companyid "  +
                             addCond+
                             " order by I.SortOrder ";
                dtGroupItem = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "GetGroupItemWiseDataTable", err.Message);
            }
            return (dtGroupItem);
        }

        public void InitialiseGrpItem_RowAndGroupWiseCnt(string dashboardType, string companyID)
        {
            try
            {
                string addCond = "";
                if (companyID != "-99") addCond = "   and I.C_CompanyID = " + companyID;

                string sql = " select isnull(Sum(NoOfRowsToMerge),0) cnt, I.VUI_Groups_HQID, G.RowNo, G.IsGroupMerge  " +
                             " from VUI_GroupItems_HQ I, VUI_Groups_HQ G " +
                             " where I.VUI_Groups_HQID=G.VUI_Groups_HQID " +
                             "   and G.DashboardType=I.DashboardType " +
                             "   and G.DashboardType = '" + dashboardType + "' " +
                             "   and I.C_companyid = G.C_companyid " + 
                             addCond +
                             " group by I.VUI_Groups_HQID, G.RowNo, G.IsGroupMerge " +
                             " order by G.RowNo ";
                dtTemp = PG.Gb.DBFn.DbRecords(sql);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "InitialiseGrpItem_RowAndGroupWiseCnt", err.Message);
                dtTemp = null;
            }
        }


        public int GetMaxItem_ForPrevRows(int rowNo)
        {
            int maxGrpItemRowCount = 0;
            try
            {
                if (dtTemp == null) return (maxGrpItemRowCount);

                for (int r = 1; r < rowNo; r++)
                {
                    maxGrpItemRowCount = maxGrpItemRowCount +  Convert.ToInt32(dtTemp.Compute(" Max(cnt) ", " RowNo=" + r + " and IsGroupMerge=0 "));
                }

                maxGrpItemRowCount = maxGrpItemRowCount + ((rowNo - 1) * 2); // GroupName + separator
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "GetMaxItem_ForThisRow", err.Message);
                maxGrpItemRowCount = 0;
            }

            return (maxGrpItemRowCount);
        }

        public int GetMaxItem_ForThisRowAndGroup(int rowNo, long vUI_Groups_HQID)
        {
            int maxGrpItemRowCount = 0;
            try
            {
                if (dtTemp == null) return (maxGrpItemRowCount);

                maxGrpItemRowCount = Convert.ToInt32(dtTemp.Compute(" Max(cnt) ", " RowNo=" + rowNo+ " and VUI_Groups_HQID=" + vUI_Groups_HQID));
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "GetMaxItem_ForThisRow", err.Message);
                maxGrpItemRowCount = 0;
            }

            return (maxGrpItemRowCount);
        }

        public int GetMaxItem_ForThisRow(int rowNo)
        {
            int maxGrpItemRowCount = 0;
            try
            {
                if (dtTemp == null) return (maxGrpItemRowCount);

                maxGrpItemRowCount = Convert.ToInt32(dtTemp.Compute(" Max(cnt) ", " RowNo=" + rowNo));
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "GetMaxItem_ForThisRow", err.Message);
                maxGrpItemRowCount = 0;
            }

            return (maxGrpItemRowCount);
        }

        public int GetMaxItem_ForThisRowWithoutMerge(int rowNo)
        {
            int maxGrpItemRowCount = 0;
            try
            {
                if (dtTemp == null) return (maxGrpItemRowCount);

                DataRow[] dr = dtTemp.Select(" RowNo=" + rowNo + "  and IsGroupMerge=0 ");
                maxGrpItemRowCount = Convert.ToInt32(dr[0]["Cnt"].ToString());
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("mainFrm.cs", "GetMaxItem_ForThisRow", err.Message);
                maxGrpItemRowCount = 0;
            }

            return (maxGrpItemRowCount);
        }
    }
}
