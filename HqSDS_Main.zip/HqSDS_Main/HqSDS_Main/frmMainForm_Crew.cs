﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMainForm_Crew : Form
    {
        public string vslFilter = "", companyID = "";
        public bool isToShowTECHDashboard = true, isToShowSQEDashboard = true;
        Common common = null; MainFrm mainObj = null;

        string calledFrom = "", fieldName = "", excludeColList = "";
        bool isFormInitialised = false, isLinkClicked = false, isExpanded = false;
        DataTable dtCrewDashboard = null;

        const int GROUP_HEADER_ROWCOUNT = 1;
        const int GROUP_SEPARATOR_ROWCOUNT = 1;

        const int PER_GROUP_WIDTH = 162;
        const int GROUP_ITEM_DISPLAY_WIDTH = 88;
        const int GROUP_ITEM_VALUE_WIDTH = 30;
        const int GROUP_ITEM_BUTTON_WIDTH = 21;
        const int GROUP_COLUMN_SEPARATOR_WIDTH = 3;

        const int GROUP_NAME_HEIGHT = 17;
        const int GROUP_ITEM_HEIGHT = 17;
        const int SEPARATOR_HEIGHT = 5;

        int constcol = 3;

        #region Details Grid Column ID
        const int
                COL_COMPANYCODE = 0,
                COL_VSLCODE = 1,
                COL_INDICATOR = 2,
                COL_VSLNAME = 3,
                COL_OPERATEBY = 4,
                COL_SEPARATOR_VESSELDETAILS = 5,

                COL_DOCMGMT_MANUALS_UNREAD = 6,
                COL_DOCMGMT_CIRCULARS_UNREAD = 7,
                COL_SEPARATOR_DOCMGMT = 8,

                COL_CERTIFICATE_OVERDUE = 9,
                COL_CERTIFICATE_WINDOW = 10,
                COL_CERTIFICATE_PENDING = 11,
                COL_CERTIFICATE_HQTOUPDATE = 12,
                COL_CERTIFICATE_VSLTOUPDATE = 13,
                COL_CERTIFICATE_TORENEW = 14,
                COL_CERTIFICATE_RENEWALINPROGRESS = 15,
                COL_SEPARATOR_CERTIFICATES = 16,

                COL_FORMS_ODUE = 17,
                COL_FORMS_VSL_PENDING = 18,
                COL_FORMS_VSL_TO_FINALISE = 19,
                COL_FORMS_VSL_TO_APPR = 20,
                COL_FORMS_VSL_TO_AMEND = 21,
                COL_FORMS_HQ_PENDING = 22,
                COL_FORMS_HQ_TO_AMEND = 23,
                COL_FORMS_TO_APPR = 24,
                COL_FORMS_SUPT_TO_FINALISE = 25,
                COL_FORMS_MGR_TO_FINALISE = 26,
                COL_FORMS_GENMGR_TO_FINALISE = 27,
                COL_FORMS_DIR_TO_FINALISE = 28,
                COL_FORMS_TA_TO_APPR = 29,
                COL_FORMS_SUPT_TO_APPR = 30,
                COL_FORMS_MGR_TO_APPR = 31,
                COL_FORMS_SENMGR_TO_APPR = 32,
                COL_FORMS_GENMGR_TO_APPR = 33,
                COL_FORMS_DIR_TO_APPR = 34,
                COL_FORMS_RECENTLY_CLOSED = 35,
                COL_SEPARATOR_FORMS = 36,

                COL_CCMSLEARNING_ODUE = 37,
                COL_CCMSLEARNING_INPROGRESS = 38,
                COL_CCMSLEARNING_VSLTASKTOAPPROVE = 39,
                COL_CCMSLEARNING_HQINPROGRESS = 40,
                COL_CCMSLEARNING_HQTASKTOAPPROVE = 41,
                COL_CCMSLEARNING_VSLTOAPPROVEMODULE = 42,
                COL_CCMSLEARNING_SUPTTOAPPROVEMODULE = 43,
                COL_CCMSLEARNING_MGRTOAPPROVEMODULE = 44,
                COL_CCMSLEARNING_GENMGRTOAPPROVEMODULE = 45,
                COL_CCMSLEARNING_SRMGRTOAPPROVEMODULE = 46,
                COL_CCMSLEARNING_DIRECTORTOAPPROVEMODULE = 47,
                COL_CCMSLEARNING_CLOSED = 48,
                COL_SEPARATOR_CREWLEARNINGMODULE = 49,

                COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT = 50,
                COL_CREWRESTHOURS_NOOFNCSIN30DAYS = 51,
                COL_SEPARATOR_CREWRESTHOURS = 52,

                COL_TASKLIST_OVERDUE = 53,
                COL_TASKLIST_HQTOSUBMIT = 54,
                COL_TASKLIST_CREW_PENDING = 55,
                COL_SEPARATOR_TASK = 56,

                COL_NCR_CREW_TO_FINALISE = 57,
                COL_NCR_CREW_PENDING = 58,
                COL_SEPARATOR_NCR = 59,

                COL_DEFECT_CREW_TO_FINALISE = 60,
                COL_SEPARATOR_DEFECT = 61,

                COL_INCIDENT_REPORT_CREW_PENDING = 62,
                COL_SEPARATOR_INCIDENT_REPORT = 63,

                COL_MINUTES_OF_SAFETY_CREW_PENDING = 64,
                COL_SEPARATOR_MINUTES_OF_SAFETY = 65,

                COL_AWARENESS_REPORT_CREW_PENDING = 66,
                COL_SEPARATOR_AWARENESS_REPORT = 67,

                COL_MASTERS_REVIEW_CREW_PENDING = 68,
                COL_SEPARATOR_MASTERS_REVIEW = 69,

                COL_RISKASSEMENTS_TASK_ODUE = 70,
                COL_RISKASSEMENTS_REPORT_ODUE = 71,
                COL_RISKASSEMENTS_ACTIVEITEMS = 72,
                COL_RISKASSEMENTS_VSL_PENDING = 73,
                COL_RISKASSEMENTS_VSL_TO_AMEND = 74,
                COL_RISKASSEMENTS_HQ_PENDING = 75,
                COL_RISKASSEMENTS_HQ_TO_AMEND = 76,
                COL_RISKASSEMENTS_VSL_TO_ACK = 77,
                COL_RISKASSEMENTS_TO_APPR = 78,
                COL_RISKASSEMENTS_TA_TO_APPR = 79,
                COL_RISKASSEMENTS_SUPT_TO_APPR = 80,
                COL_RISKASSEMENTS_MGR_TO_APPR = 81,
                COL_RISKASSEMENTS_SENMGR_TO_APPR = 82,
                COL_RISKASSEMENTS_GENMGR_TO_APPR = 83,
                COL_RISKASSEMENTS_DIR_TO_APPR = 84,
                COL_RISKASSEMENTS_RECENTLY_CLOSED = 85,
                COL_SEPARATOR_RISKASSEMENTS = 86,

                COL_VESSELID = 87,
                COL_ISUSERVESSEL = 88,
                COL_ISOFFICEVSL = 89;

        int startCol = COL_DOCMGMT_MANUALS_UNREAD, endCol = COL_RISKASSEMENTS_DIR_TO_APPR;

        const int COL_DETAILS_COMPANYCODE = 0,
                  COL_DETAILS_VSLCODE = 1,
                  COL_DETAILS_VSLNAME = 2,
                  COL_DETAILS_IMONO = 3,
                  COL_DETAILS_OPERATEBY = 4,
                  COL_DETAILS_LAST_DATA_TO_VSL = 5,
                  COL_DETAILS_LAST_DATA_FROM_VSL = 6,
                  COL_DETAILS_MASTERNAME = 7,
                  COL_DETAILS_CENAME = 8,
                  COL_DETAILS_BUILDER = 9,
                  COL_DETAILS_HULLNO = 10,
                  COL_DETAILS_DELIVDATEDISPLAY = 11,
                  COL_DETAILS_DWT = 12,
                  COL_DETAILSL_GRT = 13,
                  COL_DETAILS_NRT = 14,
                  COL_DETAILS_CALLSIGN = 15,
                  COL_DETAILS_CLASSNO = 16,
                  COL_DETAILS_OFFICIALNO = 17,
                  COL_DETAILS_OWNER = 18,
                  COL_DETAILS_VSLTYPE = 19,
                  COL_DETAILS_FLEET_VESSELID = 20;


        #endregion

       
        public frmMainForm_Crew()
        {
            InitializeComponent();
        }

        private void frmMainForm_Crew_Load(object sender, EventArgs e)
        {

            this.Text = " Crew Dashboard ";

            common = new Common();
            mainObj = new MainFrm();

            DesignDashBoardGridDetails();
            DesignParticularsGridDetails();

            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, true);

            FocusCompany();

            AssignTopPanelGridGeneralProperties();

            btnTechDashboard.Visible = false;
            btnSQEDashboard.Visible = false;

            isFormInitialised = true;

            PG.SetFormWidthAndHeight(this, 10, 10, 900, 1420);

            if (PG.Gb.IsToConnecDirectDB)
                tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else
                tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();

            tsLblUserId.Text = "User: " + PG.Gb.User.CurUserName;
            fpSpread1.Visible = false;

            timer1.Enabled = true;

            excludeColList = "" + COL_CCMSLEARNING_ODUE + "," + COL_SEPARATOR_CREWLEARNINGMODULE +
                             "," + COL_CERTIFICATE_OVERDUE + "," + COL_SEPARATOR_CERTIFICATES +
                             "," + COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT  + "," + COL_SEPARATOR_CREWRESTHOURS + //+ "," + COL_CREWRESTHOURS_NOOFNCSIN30DAYS
                             "," + COL_TASKLIST_OVERDUE + "," + COL_SEPARATOR_TASK;
                             //"," + COL_NCR_CREW_PENDING + "," + COL_SEPARATOR_NCR +
                             //"," + COL_INCIDENT_REPORT_CREW_PENDING + "," + COL_SEPARATOR_INCIDENT_REPORT +
                             //"," + COL_AWARENESS_REPORT_CREW_PENDING + "," + COL_SEPARATOR_AWARENESS_REPORT +
                             //"," + COL_MASTERS_REVIEW_CREW_PENDING + "," + COL_SEPARATOR_MASTERS_REVIEW +
                             //"," + COL_MINUTES_OF_SAFETY_CREW_PENDING + "," + COL_SEPARATOR_MINUTES_OF_SAFETY;
        }

        protected void DesignDashBoardGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();
            try
            {
                Color rowHeaderForeColor = Color.Blue;
                particularsColList.Add(new DgvInits("CompanyCode", "Comp Code", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 35, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Indicator", "", 15, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 160, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OperateBy", "Ops By", 32, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("DocMgmt_Manuals_Unread", "Manuals Unread", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DocMgmt_Circulars_Unread", "Circulars Unread", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Certificates_ODue", "O'Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_Window", "Window", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_Pending", "Pending", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_HQToUpdate", "HQ To Update", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_VSLToUpdate", "VSL To Update", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_ToRenew", "To Renew", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_RenewalInProgress", "Renewal In Progress", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Forms_ODue", "ODue", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_Pending", "Vsl Pending", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_To_Finalise", "Vsl To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_To_Appr", "Vsl To Approve", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_to_Amend", "Vsl To Amend", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Hq_Pending", "HQ Pending", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Hq_to_Amend", "HQ To Amend", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_To_Appr", "Forms\nTo Appr", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Supt_To_Finalise", "Supt To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Mgr_To_Finalise", "Mgr To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_GenMgr_To_Finalise", "GenMgr To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Dir_To_Finalise", "Dir To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_TA_To_Appr", "TA To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Supt_To_Appr", "Supt To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Mgr_To_Appr", "Mgr To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_SenMgr_To_Appr", "SenMgr To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_GenMgr_To_Appr", "GenMgr To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Dir_To_Appr", "Dir To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Recently_Closed", "Recently Closed", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("CCMSLearning_ODue", "Module \nO'Due", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_InProgress", "Task \n InProgress\n by VSL", 57, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_VSLToApprove", "Task \nTo Appr \n by VSL", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_HQInProgress", "Task \nInProgress \n by HQ", 57, rowHeaderForeColor, SystemColors.ButtonFace, true, true));                
                particularsColList.Add(new DgvInits("CCMSLearning_HQTaskToApprove", "Task \nTo Appr \n by HQ", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));                
                particularsColList.Add(new DgvInits("CCMSLearning_VslToApproveModule", "Vsl \nTo Appr\nModule", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_SuptToApprove", "Supt \nTo Appr\nModule", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_MgrToApprove", "Mgr. \nTo Appr\nModule", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_GenMgrToApprove", "Gen Mgr.\nTo Appr\nModule", 49, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_SrMgrToApprove", "Sr Mgr \nTo Appr\nModule", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_DirectorToApprove", "Director\nTo Appr\nModule", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CCMSLearning_Closed", "Closed", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("CrewRestHours_NoOfDaysPendingInput", "No Of days \nO’Due", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CrewRestHours_NoOfDaysPendingNC", "No Of NCs \nin 30 days", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("TaskList_OverDue", "O’Due", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_HQToSubmit", "HQ To Submit/\nReSubmit", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Crew_Pending", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("NCR_Crew_ToFinalise", "Crew \nTo \nFinalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Crew_Pending", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("DF_Crew_To_Verify", "Crew \nTo \nFinalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("IncidentReport_Crew_to_Approve", "Crew To Appr", 63, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Minutes_of_Safety_Crew_Pending", "Crew To Appr", 63, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Awareness_Report_Crew_Pending", "Crew To Appr", 63, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Masters_Review_Crew_Pending", "Crew To Appr", 63, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("RiskAssements_Task_ODue", "Task O'Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Report_ODue", "Report O'Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_ActiveItems", "Active Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_VSL_Pending", "Vsl Pending", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_to_Amend", "Vsl To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Hq_Pending", "HQ Pending", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Hq_to_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_To_Ack", "Vsl To Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_To_Appr", "To Review", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_TA_To_Appr", "TA To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Supt_To_Appr", "Supt To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Mgr_To_Appr", "Mgr To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_SenMgr_To_Appr", "SenMgr To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_GenMgr_To_Appr", "GenMgr To Review", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Dir_To_Appr", "Dir To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Recently_Closed", "Recently Closed", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("userVsl", "userVsl", 130, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("IsOffice", "IsOffice", 130, rowHeaderForeColor, SystemColors.ButtonFace, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, particularsColList, null, false, false, false);

                fpSpread1.ActiveSheet.ColumnHeader.RowCount = 2;
                fpSpread1.Sheets[0].FrozenColumnCount = 4;

                for (int col = COL_COMPANYCODE; col <= COL_SEPARATOR_VESSELDETAILS; col++)
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].RowSpan = 2;
                }

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_VESSELDETAILS].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_DOCMGMT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_CREWLEARNINGMODULE].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_CREWRESTHOURS].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_FORMS].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_TASK].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_NCR].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_INCIDENT_REPORT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_AWARENESS_REPORT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MASTERS_REVIEW].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MINUTES_OF_SAFETY].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_CERTIFICATES].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_VESSELID].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ISUSERVESSEL].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ISOFFICEVSL].RowSpan = 2;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_VSLCODE].ColumnSpan = 2;

                for (int col = 0; col < fpSpread1.ActiveSheet.ColumnCount; col++)
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Text = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].Text;
                }
                fpSpread1.ActiveSheet.Columns[COL_VSLNAME].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;

                fpSpread1.ActiveSheet.Columns[COL_INDICATOR].ForeColor = Color.Red;
                fpSpread1.ActiveSheet.Columns[COL_INDICATOR].Font = new Font("Verdana", 8, FontStyle.Regular);

                Font headerFont = new Font("Verdana", 8, FontStyle.Bold); Color headerForeColor = Color.Maroon;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].ColumnSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].Text = "Document  Management";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD, 0, COL_DOCMGMT_CIRCULARS_UNREAD].Tag = "DocMgmt";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].ColumnSpan = 7;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].Text = "Certificates";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_OVERDUE, 0, COL_CERTIFICATE_OVERDUE].Tag = "Certificates";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].ColumnSpan = 19;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].Text = "Forms";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE, 0, COL_FORMS_TO_APPR].Tag = "Forms";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CCMSLEARNING_ODUE].ColumnSpan = 12;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CCMSLEARNING_ODUE].Text = "CCMS Task";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CCMSLEARNING_ODUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CCMSLEARNING_ODUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CCMSLEARNING_ODUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CCMSLEARNING_ODUE, 0, COL_CCMSLEARNING_DIRECTORTOAPPROVEMODULE].Tag = "CCMSLearning";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT].ColumnSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT].Text = "Crew Rest Hours";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT, 0, COL_CREWRESTHOURS_NOOFNCSIN30DAYS].Tag = "CreRestHours";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].ColumnSpan = 3;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].Text = "Task";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE, 0, COL_TASKLIST_CREW_PENDING].Tag = "Task";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_TO_FINALISE].ColumnSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_TO_FINALISE].Text = "NCR";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_TO_FINALISE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_TO_FINALISE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_TO_FINALISE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_CREW_TO_FINALISE, 0, COL_NCR_CREW_PENDING].Tag = "NCR";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DEFECT_CREW_TO_FINALISE].ColumnSpan = 1;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DEFECT_CREW_TO_FINALISE].Text = "Defects";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DEFECT_CREW_TO_FINALISE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DEFECT_CREW_TO_FINALISE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DEFECT_CREW_TO_FINALISE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DEFECT_CREW_TO_FINALISE, 0, COL_DEFECT_CREW_TO_FINALISE].Tag = "Defects";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_CREW_PENDING].ColumnSpan = 1;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_CREW_PENDING].Text = "Incidnt Report";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_CREW_PENDING].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_CREW_PENDING].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_CREW_PENDING].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_CREW_PENDING, 0, COL_INCIDENT_REPORT_CREW_PENDING].Tag = "Incident Report";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_CREW_PENDING].ColumnSpan = 1;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_CREW_PENDING].Text = "Safety Meeting";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_CREW_PENDING].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_CREW_PENDING].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_CREW_PENDING].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_CREW_PENDING, 0, COL_MINUTES_OF_SAFETY_CREW_PENDING].Tag = "Safety Meeting";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_CREW_PENDING].ColumnSpan = 1;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_CREW_PENDING].Text = "Aware. Report";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_CREW_PENDING].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_CREW_PENDING].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_CREW_PENDING].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_CREW_PENDING, 0, COL_AWARENESS_REPORT_CREW_PENDING].Tag = "Aware. Report";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_CREW_PENDING].ColumnSpan = 1;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_CREW_PENDING].Text = "Master Review";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_CREW_PENDING].ForeColor = headerForeColor;// Color.Blue;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_CREW_PENDING].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_CREW_PENDING].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_CREW_PENDING, 0, COL_MASTERS_REVIEW_CREW_PENDING].Tag = "Master Review";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE].ColumnSpan = 16;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE].Text = "Risk Assements";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE, 0, COL_RISKASSEMENTS_DIR_TO_APPR].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE, 0, COL_RISKASSEMENTS_DIR_TO_APPR].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE, 0, COL_RISKASSEMENTS_DIR_TO_APPR].Tag = "Risk Assements";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_TASK_ODUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                if (fpSpread1.ActiveSheet.ColumnCount > 0)
                {
                    fpSpread1.ActiveSheet.Columns[startCol, endCol].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                    fpSpread1.ActiveSheet.ColumnHeader.Columns[startCol, endCol].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, startCol, 1, endCol].Font = new Font("Microsoft sans serif", 7.5f, FontStyle.Regular);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, startCol, 1, endCol].CellPadding = new FarPoint.Win.Spread.CellPadding(0, 0, 0, 0);

                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].ForeColor = Color.Blue;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_VESSELDETAILS].ForeColor = Color.Blue;
                    fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].Resizable = false;
                }

                Color fixedColBKColor = Color.FromArgb(202, 232, 253), otherColBKColor = Color.White, sepColBKColor = SystemColors.ButtonFace, //Color.FromArgb(255, 224, 192),
                      fixedColForeColor = Color.Black, otherColForeColor = Color.Black;

                fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = otherColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_COMPANYCODE, COL_OPERATEBY].BackColor = fixedColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_VESSELDETAILS].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_CREWLEARNINGMODULE].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_CREWRESTHOURS].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_NCR].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_AWARENESS_REPORT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_MASTERS_REVIEW].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_MINUTES_OF_SAFETY].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_CERTIFICATES].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_DOCMGMT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_FORMS].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_INCIDENT_REPORT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_TASK].BackColor = sepColBKColor;

                fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].Font = new Font("Calibri", 9, FontStyle.Regular);
                fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].ForeColor = otherColForeColor;
                fpSpread1.ActiveSheet.Columns[COL_VSLCODE, COL_VSLNAME].ForeColor = fixedColForeColor;
                fpSpread1.ActiveSheet.Columns[COL_INDICATOR].ForeColor = Color.Red;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 40;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Height = 50;

                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;

                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread1.ActiveSheet.DisplayZero = true;

                fpSpread1.ActiveSheet.Columns[COL_VESSELID, COL_ISOFFICEVSL].Visible = false;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.CS", "DesignDashBoardGridDetails", er.Message);
                Gfn.Mb("Failed to design dashboard Grid");
            }
            finally
            {
                particularsColList = null;
            }
        }

        protected void DesignParticularsGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();

            try
            {
                Color rowHeaderForeColor = Color.Black;
                particularsColList.Add(new DgvInits("CompanyCode", "Company", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 160, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("ImoNo", "IMO Number", 80, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OperateBy", "Operate By", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("HQtoVsl", "HQ to Vsl Data Transfer", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VsltoHQ", "Vsl to HQ Data Transfer", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("MASTERNAME", "Master Name", 110, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CENAME", "CE Name", 110, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("BUILDER", "Builder", 150, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("HullNo", "Hull No", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DelivDateDisplay", "Deliv Date", 70, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DWT", "DWT", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("GRT", "GRT", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NRT", "NRT", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CallSign", "Call Sign", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("ClassNo", "Class No", 85, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OfficialNo", "Official No", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Owner", "Owner", 200, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslType", "Vessel Type", 130, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                fpSpread_Particulars.SuspendLayout();

                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Particulars, particularsColList, null, false, false, false);

                fpSpread_Particulars.ActiveSheet.FrozenColumnCount = 3;

                fpSpread_Particulars.ActiveSheet.Columns[COL_DETAILS_LAST_DATA_FROM_VSL].ForeColor = Color.Fuchsia;
                fpSpread_Particulars.ActiveSheet.Columns[COL_DETAILS_LAST_DATA_TO_VSL].ForeColor = Color.Blue;

                if (fpSpread_Particulars.ActiveSheet.ColumnCount > 0)
                {
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].ForeColor = Color.Black;
                }

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].Height = 50;

                fpSpread_Particulars.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;

                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread_Particulars.ActiveSheet.VerticalGridLine = gdln;
                fpSpread_Particulars.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                fpSpread_Particulars.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread_Particulars.ActiveSheet.DisplayZero = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "DesignParticularsGridDetails", er.Message);
                Gfn.Mb("Failed to initilize Particulars Tab");
            }
            finally
            {
                fpSpread_Particulars.ResumeLayout();
                particularsColList = null;
            }
        }

        protected void FocusCompany()
        {
            try
            {
                if (companyID.Trim().Length > 0 && companyID != "-1")
                {
                    cboCompany_Filter.SelectedValue = companyID;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "FocusCompany", err.Message);
            }
        }

        private void InitialiseHQDashboardFieldSetup(DataTable dt)
        {
            try
            {
                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                    if (columnNo >= fpSpread1.ActiveSheet.ColumnCount) break;

                    int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                    int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());
                    fpSpread1.ActiveSheet.Columns[columnNo].Visible = (isToHide == 0 && isToShowAlways == 1);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "InitialiseHQDashboardFieldSetup", err.Message);
                Gfn.Mb("Failed to initilize Dashboard grid ");
            }
        }

        private DataTable GetCrewDashboardDataTable()
        {
            string companyID = "-99";
            if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

            string addlCond = "  ";
            if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";

            string script = " select Distinct ColumnNo, ColumnName, IsToHide, isToShowAlways, GroupName " +
                            " from Dashboard_HQ_Main_Crew_Setup " + Environment.NewLine +
                            " where ColumnNo>=0 " +
                             addlCond +
                            " order by ColumnNo";
            DataTable dt = PG.Gb.DBFn.DbRecords(script);

            return (dt);
        }



        private void EnableDisableControls(DataTable dt)
        {
            DataRow[] dr;
            DataTable dtGrouItems;
            try
            {
                bool isToVisibleNCR = false, isToVisibleTasks = false, isToVisibleIncidentReport = false,
                     isToVisibleAwarenessReport = false, isToVisibleMastersReview = false, isToVisibleMinutesofSafety = false, isToVisibleCCMSLearning = false, isToEnableVslCertificate = false;
                if (dt != null)
                {
                    dr = dt.Select("IsToHide = 0 and GroupName='Task'");
                    isToVisibleTasks = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName in ('Incident Report','Investigation Report')");
                    isToVisibleIncidentReport = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='NCR'");
                    isToVisibleNCR = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Aware. Report'");
                    isToVisibleAwarenessReport = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Master Review'");
                    isToVisibleMastersReview = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Safety Meeting'");
                    isToVisibleMinutesofSafety = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='CCMS Task'");
                    isToVisibleCCMSLearning = (dr != null && dr.Length > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='Certificates'");
                    isToEnableVslCertificate = (dr != null && dr.Length > 0);
                }

                tsMnuNCR.Visible = isToVisibleNCR;
                tsMnuVslNCR.Visible = isToVisibleNCR;

                tsMnuTaskList.Visible = isToVisibleTasks;
                tsMnuVslTaskList.Visible = isToVisibleTasks;

                tsMnuIncidentReport.Visible = isToVisibleIncidentReport;
                tsMnuVslIncidentReport.Visible = isToVisibleIncidentReport;

                tsMnuAwarenessReport.Visible = isToVisibleAwarenessReport;
                tsMnuVslAwarenessReport.Visible = isToVisibleAwarenessReport;

                tsMnuMastersReview.Visible = isToVisibleMastersReview;
                tsMnuVslMastersReview.Visible = isToVisibleMastersReview;

                tsMnuMinutesOfSafety.Visible = isToVisibleMinutesofSafety;
                tsMnuVslMinutesOfSafety.Visible = isToVisibleMinutesofSafety;

                tsMnuCCMSLearning.Visible = isToVisibleCCMSLearning;
                tsMnuVSLCCMSLearning.Visible = isToVisibleCCMSLearning;
                tsMnuVslCertificate.Visible = isToEnableVslCertificate;
                //----------------------------------------------------------------------------------------------------

                bool isToEnableCCMSTask = false, isToEnableCrewRestHours = false, isToEnableNCR = false, isToEnableTasks = false, isToEnableIncidentReport = false,
                     isToEnableAwarenessReport = false, isToEnableMastersReview = false, isToEnableMinutesofSafety = false;

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                dtGrouItems = mainObj.GetGroupItemWiseDataTable(PG.DASHBOARDTYPE_CREW, companyID);

                if (dtGrouItems != null)
                {
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='CCMS Task'");
                    isToEnableCCMSTask = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Crew Rest Hours'");
                    isToEnableCrewRestHours = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Task'");
                    isToEnableTasks = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg in ('Incident Report','Investigation Report','Incidnt Report','Invest Report')");
                    isToEnableIncidentReport = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='NCR'");
                    isToEnableNCR = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Aware. Report'");
                    isToEnableAwarenessReport = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Master Review'");
                    isToEnableMastersReview = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg in ('Safety Meeting','Safety Meetng')");
                    isToEnableMinutesofSafety = (dr != null && dr.Length > 0);
                }

                tsMnuNCR.Enabled = isToEnableNCR;
                tsMnuVslNCR.Enabled = isToEnableNCR;

                tsMnuTaskList.Enabled = isToEnableTasks;
                tsMnuVslTaskList.Enabled = isToEnableTasks;

                tsMnuIncidentReport.Enabled = isToEnableIncidentReport;
                tsMnuVslIncidentReport.Enabled = isToEnableIncidentReport;

                tsMnuAwarenessReport.Enabled = isToEnableAwarenessReport;
                tsMnuVslAwarenessReport.Enabled = isToEnableAwarenessReport;

                tsMnuMastersReview.Enabled = isToEnableMastersReview;
                tsMnuVslMastersReview.Enabled = isToEnableMastersReview;

                tsMnuMinutesOfSafety.Enabled = isToEnableMinutesofSafety;
                tsMnuVslMinutesOfSafety.Enabled = isToEnableMinutesofSafety;

                tsMnuCCMSLearning.Enabled = isToEnableCCMSTask;
                tsMnuVSLCCMSLearning.Enabled = isToEnableCCMSTask;

                //-----TOP Controls-----------------------------------------------------------------------------------------------
                btnProcurement.Visible = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_ProcurementWeb);
                btnDMS.Visible = (PG.isToEnableDocMgmt && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DocMgmt_Cef));

                btnTechDashboard.Visible = true;
                btnTechDashboard.Enabled = (isToShowTECHDashboard);
                btnSQEDashboard.Enabled = (isToShowSQEDashboard);
                btnSQEDashboard.Visible = (PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_MARINEDASHBOARD));
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "EnableDisableControls", err.Message);
                Gfn.Mb("Failed to initilize Dashboard grid ");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            pictureBox1.BringToFront();
            Application.DoEvents();
            try
            {
                fpSpread1.Visible = true;
                cboCompany_Filter_SelectedIndexChanged(null, null);

                if (PG.CheckAppUnderMaintenance(this.Text))
                {
                    DialogResult = DialogResult.OK;
                    this.Close();
                }

                string fileName = PG.Gb.WinSDSrootDir + "\\Images\\" + PG.hqAppFolder + "HQ_SDS.ico";
                if (File.Exists(fileName))
                {
                    Icon ic = new Icon(fileName);
                    this.Icon = ic;
                }

                PG.DownloadStarter();

                fpSpread_TopPanel_SizeChanged(null, null);
                
            }
            finally
            {
                pictureBox1.Visible = false;
            }
        }


        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;
            try
            {
                companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (!PG.InitialiseCommonSettings(companyID)) return;
                
                PG.Initialise_AllowedUserForAccessRights(companyID);
                dtCrewDashboard = GetCrewDashboardDataTable();

                isFormInitialised = false;
                                
                InitialiseHQDashboardFieldSetup(dtCrewDashboard);
                EnableDisableControls(dtCrewDashboard);

                if (common != null) common.BindVslDropDownList_CrewDept(cboVslFilter, true, companyID);

                if (vslFilter.Trim().Length > 0 && cboVslFilter.FindString(vslFilter) >= 0) cboVslFilter.SelectedIndex = cboVslFilter.FindString(vslFilter);
                isFormInitialised = true;

                cboVslFilter_SelectedIndexChanged(null, null);
                this.Text = cboCompany_Filter.Text.ToUpper() + " Crew Dashboard ";
                chkShowOnlyActionColumns_CheckedChanged(null, null);

                fpSpread1.ActiveSheet.Columns[COL_COMPANYCODE].Visible = (companyID == "-99");
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "cboCompany_Filter_SelectedIndexChanged", err.Message);
            }
            finally
            {
                isFormInitialised = true;
            }
        }

        private void cboVslFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            fieldName = "";
            LoadData();
        }

        private void LoadData()
        {
            if (cboVslFilter.SelectedValue == null || common == null) return;

            BindTopPanelDashboardData();
            BindDashBoardGrid();
            //BindVslDetailsGrid();            
        }

        private void BindDashBoardGrid()
        {
            fpSpread1.SuspendLayout();

            try
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
                Application.DoEvents();

                tlsStatuslblTotalVessels.Text = "Total Vessel(s): 0";
                fpSpread1.ActiveSheet.RowCount = 0;

                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (common != null) fpSpread1.ActiveSheet.DataSource = common.GetDashBoardDataTable_Crew(vslFilter, fieldName, companyID);

                if (fpSpread1.ActiveSheet.RowCount <= 0 || fpSpread1.ActiveSheet.ColumnCount <= 0) return;

                int lastRow = fpSpread1.ActiveSheet.RowCount - 1;

                #region Bordre / BackColor / Font
                Color borderColor = Color.FromArgb(81, 160, 181);
                fpSpread1.ActiveSheet.Cells[0, 0, lastRow, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(borderColor, 1, false, false, true, true);
                fpSpread1.ActiveSheet.Cells[0, COL_VSLCODE, lastRow, COL_VSLCODE].Border = new FarPoint.Win.LineBorder(borderColor, 1, false, false, false, true);

                #endregion

                tlsStatuslblTotalVessels.Text = "Total Vessel(s):" + fpSpread1.ActiveSheet.RowCount;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].Tag = null;

                //DataTable dt = GetCrewDashboardDataTable();

                for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
                {
                    string isUserVsl = fpSpread1.ActiveSheet.Cells[row, COL_ISUSERVESSEL].Text.Trim();
                    fpSpread1.ActiveSheet.Cells[row, COL_INDICATOR].Text = "";
                    if (isUserVsl == "1") fpSpread1.ActiveSheet.Cells[row, COL_INDICATOR].Text = "*";

                    for (int col = COL_SEPARATOR_VESSELDETAILS; col < COL_VESSELID; col++)
                    {
                        #region cell style
                        if (col == COL_SEPARATOR_VESSELDETAILS || col == COL_SEPARATOR_CREWLEARNINGMODULE || col == COL_SEPARATOR_CREWRESTHOURS || col == COL_SEPARATOR_TASK || col == COL_SEPARATOR_NCR ||
                            col == COL_SEPARATOR_INCIDENT_REPORT || col == COL_SEPARATOR_AWARENESS_REPORT || col == COL_SEPARATOR_MASTERS_REVIEW || col == COL_SEPARATOR_MINUTES_OF_SAFETY ||
                            col == COL_SEPARATOR_CERTIFICATES || col == COL_SEPARATOR_CREWLEARNINGMODULE || col == COL_SEPARATOR_CREWRESTHOURS || col == COL_SEPARATOR_DOCMGMT || col == COL_SEPARATOR_FORMS)
                        {
                            fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag = "-1";
                            continue;
                        }

                        string cellValue = "";
                        if (fpSpread1.ActiveSheet.Cells[row, col].Value != null) cellValue = fpSpread1.ActiveSheet.Cells[row, col].Text.ToString().Trim();

                        if (cellValue == "0" || cellValue == "")
                        {
                            fpSpread1.ActiveSheet.Cells[row, col].ForeColor = Color.FromArgb(224, 224, 224);
                            fpSpread1.ActiveSheet.Cells[row, col].Text = "0";
                        }
                        else
                        {
                            if (col >= COL_DOCMGMT_MANUALS_UNREAD && col <= COL_SEPARATOR_RISKASSEMENTS && cellValue.Length > 0
                                && fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag == null)
                            {
                                DataRow[] dr = dtCrewDashboard.Select("ColumnNo=" + col);
                                if (dr != null && dr.Length > 0)
                                {
                                    if (dr[0]["IsToHide"].ToString() == "0")
                                    {
                                        fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, col].Text);
                                    }
                                }
                            }
                        }
                        #endregion
                    }

                    if (fpSpread1.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value.ToString() == "1")
                    {
                        fpSpread1.ActiveSheet.Cells[row, COL_VSLCODE, row, COL_VSLNAME].BackColor = Color.FromArgb(143, 194, 207);
                    }
                }
                fpSpread1.ActiveSheet.Columns[COL_VESSELID, COL_ISOFFICEVSL].Visible = false;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "BindDashBoardGrid", err.Message);
                Gfn.Eb("Failed to refresh dashboard grid");
            }
            finally
            {
                fpSpread1.ResumeLayout();
                pictureBox1.Visible = false;
            }
        }

        private void BindVslDetailsGrid()
        {
            try
            {
                fpSpread_Particulars.SuspendLayout();
                fpSpread_Particulars.ActiveSheet.RowCount = 0;

                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (common != null) fpSpread_Particulars.ActiveSheet.DataSource = common.GetVslDetailsDataTable_Crew(vslFilter, companyID);

                if (fpSpread_Particulars.ActiveSheet.RowCount > 0 && fpSpread_Particulars.ActiveSheet.ColumnCount > 0)
                {
                    int rowCount = fpSpread_Particulars.ActiveSheet.RowCount - 1;
                    fpSpread_Particulars.ActiveSheet.Cells[0, 0, rowCount, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.FromArgb(244, 164, 96), 1, false, false, true, true);
                    fpSpread_Particulars.ActiveSheet.Cells[0, COL_DETAILS_VSLCODE, rowCount, COL_DETAILS_VSLNAME].BackColor = Color.FromArgb(245, 222, 179);
                    fpSpread_Particulars.ActiveSheet.Cells[0, COL_DETAILS_VSLCODE, rowCount, COL_DETAILS_VSLNAME].ForeColor = Color.Black;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "BindVslDetailsGrid", err.Message);
                Gfn.Eb("Failed to refresh vsl details grid");
            }
            finally
            {
                fpSpread_Particulars.ResumeLayout();
            }
        }

        private void BindTopPanelDashboardData()
        {
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (common == null) return;

                string addlCondition = common.GetVslFilterAddlCondition(vslFilter, companyID);

                string spName = "RefreshDashBoardValues_HQ_Crew";
                string[] paramField = new string[] { "@addlCond", "@VesselID", "@C_CompanyID" };
                object[] paramValue = new object[] { addlCondition, -1, companyID };
                PG.Gb.DBFn.SpXqry(spName, paramField, paramValue);

                DesignAndBindDashBoard();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "BindTopPanelDashboardData", err.Message);
                Gfn.Eb("Failed to bind top dashboard values");
            }
        }

        #region Top Dashboard Panel
        private void AssignTopPanelGridGeneralProperties()
        {
            fpSpread_TopPanel.ActiveSheet.RowCount = 0;
            fpSpread_TopPanel.ActiveSheet.ColumnCount = 0;
            FarPtColCtrls.SetFarPointGridGeneralProperties(fpSpread_TopPanel);
            fpSpread_TopPanel.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;
            fpSpread_TopPanel.FocusRenderer = null;
            fpSpread_TopPanel.ActiveSheet.GrayAreaBackColor = Color.LightSkyBlue;// SystemColors.ControlLight;
        }

        private void DesignAndBindDashBoard()
        {
            fpSpread_TopPanel.SuspendLayout();
            try
            {
                fpSpread_TopPanel.ActiveSheet.RowCount = 0;
                fpSpread_TopPanel.ActiveSheet.ColumnCount = 0;

                if (!AssignRowCountAndColCountToTopPanelGrid()) return;

                FillupDashBoardGrid();
            }
            finally
            {
                fpSpread_TopPanel.ResumeLayout();
            }
        }

        protected bool AssignRowCountAndColCountToTopPanelGrid()
        {
            int maxRow = 0, maxCol = 0, maxGrpCol = 0;
            bool result = false;
            try
            {
                if (mainObj == null) return (result);

                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                maxGrpCol = mainObj.GetGroupMaxColCnt(PG.DASHBOARDTYPE_CREW, companyID);
                maxCol = (maxGrpCol * constcol) + maxGrpCol;

                fpSpread_TopPanel.ActiveSheet.RowCount = maxRow;
                fpSpread_TopPanel.ActiveSheet.ColumnCount = maxCol;

                //if (maxGrpCol > 0) this.Width = (maxGrpCol * PER_GROUP_WIDTH) + 8 + 35;

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "AssignRowCountAndColCountToTopPanelGrid", err.Message);
            }

            return (result);
        }

        private void FillupDashBoardGrid()
        {
            DataTable dtGroup = null, dtGroupItem = null;
            DataRow[] drGrpItem = null;
            int xRowNo = -1, colNo = 0, rowNo = 0, currentRow = 0, mergeItemDescAndStatusValue = 0, maxGrpItemRowCount = 0;
            long vUI_Groups_HQID, refNo; int totalHeight = 0;
            string groupName, itemDesc, statusValue, actionBtnColor;
            bool isprgDisabled = false;
            Color grpItemBkColor, grpHeadingBkColor, backColor, grpHeaderforeColor;
            try
            {
                backColor = Color.LightSkyBlue;
                grpHeadingBkColor = Color.Navy;
                grpItemBkColor = Color.FromArgb(247, 247, 247);
                grpHeaderforeColor = Color.White;

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                dtGroup = mainObj.GetGroupDataTable(PG.DASHBOARDTYPE_CREW, companyID);
                if (dtGroup == null) return;

                dtGroupItem = mainObj.GetGroupItemWiseDataTable(PG.DASHBOARDTYPE_CREW, companyID);
                InitialiseCCMSLearningCount(ref dtGroupItem);

                mainObj.InitialiseGrpItem_RowAndGroupWiseCnt(PG.DASHBOARDTYPE_CREW, companyID);

                fpSpread_TopPanel.ActiveSheet.Columns[0, fpSpread_TopPanel.ActiveSheet.ColumnCount - 1].Width = 0;
                fpSpread_TopPanel.ActiveSheet.Columns[0, fpSpread_TopPanel.ActiveSheet.ColumnCount - 1].BackColor = backColor;
                foreach (DataRow dr in dtGroup.Rows) // Group Level
                {
                    vUI_Groups_HQID = Convert.ToInt64(dr["VUI_Groups_HQID"]);
                    groupName = dr["GroupName"].ToString();
                    rowNo = Convert.ToInt32(dr["rowNo"]);
                    colNo = Convert.ToInt32(dr["ColNo"]) - 1;

                    if (rowNo != xRowNo)
                    {
                        currentRow = fpSpread_TopPanel.ActiveSheet.RowCount;
                        if (xRowNo != -1) currentRow = mainObj.GetMaxItem_ForPrevRows(rowNo); // Max Group Items in that row
                        xRowNo = rowNo;

                        maxGrpItemRowCount = mainObj.GetMaxItem_ForThisRow(rowNo);  // Max Group Items in that row
                        fpSpread_TopPanel.ActiveSheet.RowCount = currentRow + GROUP_HEADER_ROWCOUNT + maxGrpItemRowCount + GROUP_SEPARATOR_ROWCOUNT;

                        int maxGrpItemCntWithoutMerge = mainObj.GetMaxItem_ForThisRowWithoutMerge(rowNo);
                        totalHeight = totalHeight + ((maxGrpItemCntWithoutMerge * GROUP_ITEM_HEIGHT) + GROUP_NAME_HEIGHT + SEPARATOR_HEIGHT);
                    }

                    rowNo = currentRow;  // Next Group Starts then assign the start rowindex
                    if (colNo > 0)
                    {
                        colNo = (colNo * constcol) + colNo; // ColNo + constant row + separator
                    }

                    if ((colNo + 2) >= fpSpread_TopPanel.ActiveSheet.ColumnCount) continue;
                    if (rowNo >= fpSpread_TopPanel.ActiveSheet.RowCount) continue;

                    #region Column Width
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH;     // Grp Item Name 
                    if (groupName.ToUpper() == "FORMS") fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH - 3;     // Grp Item Name
                    else if (groupName.ToUpper() == "CREW REST HOURS") fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH + 15;     // Grp Item Name
                    else if (groupName.ToUpper() == "CERTIFICATES") fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH - 35;     // Grp Item Name
                    else if (groupName.ToUpper() == "DOCUMENT") fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH - 8;     // Grp Item Name
                    else if (groupName.ToUpper() == "CCMS MODULE") fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH - 28;     // Grp Item Name
                    else if (groupName.ToUpper() == "RISK ASSESSMENT" || groupName.ToUpper() == "AWARE. REPORT") fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH - 15;     // Grp Item Name
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo + 1].Width = GROUP_ITEM_VALUE_WIDTH;   // Value
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo + 2].Width = GROUP_ITEM_BUTTON_WIDTH;  //Button

                    // Separator Column
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].Locked = true;
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].Width = GROUP_COLUMN_SEPARATOR_WIDTH;
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].BackColor = backColor;
                    #endregion

                    #region Group Name Row
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Value = groupName;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Font = new Font("Verdana", 8, FontStyle.Bold);
                    fpSpread_TopPanel.ActiveSheet.Rows[rowNo].Height = GROUP_NAME_HEIGHT;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ColumnSpan = constcol - 1;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].BackColor = grpHeadingBkColor;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].ForeColor = grpHeaderforeColor;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].Locked = true;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].Border = new FarPoint.Win.LineBorder(Color.LightSteelBlue, 1, true, true, true, false);

                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].CellType = FarPtColCtrls.GetButtonCellType(Color.YellowGreen);
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].CellPadding = new FarPoint.Win.Spread.CellPadding(0, 0, 0, 0);
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Tag = groupName;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Locked = false;

                    #endregion

                    #region Group Items
                    if (dtGroupItem != null && dtGroupItem.Rows.Count > 0)
                    {
                        drGrpItem = dtGroupItem.Select(" VUI_Groups_HQID=" + vUI_Groups_HQID);
                        if (drGrpItem != null)
                        {
                            #region isItemexists
                            rowNo = rowNo + 1;
                            for (int r = 0; r < drGrpItem.Length; r++)
                            {
                                //rowNo = rowNo + 1;
                                refNo = Convert.ToInt64(drGrpItem[r]["RefNo"].ToString());
                                itemDesc = drGrpItem[r]["ItemDesc"].ToString();
                                statusValue = drGrpItem[r]["StatusValue"].ToString();
                                actionBtnColor = drGrpItem[r]["ActionButtonColor"].ToString();
                                isprgDisabled = (drGrpItem[r]["IsPrgDisabled"].ToString() == "1");

                                int noOfRowsToMerge = Convert.ToInt32(drGrpItem[r]["NoOfRowsToMerge"].ToString());
                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].RowSpan = noOfRowsToMerge;

                                mergeItemDescAndStatusValue = Convert.ToInt32(drGrpItem[r]["mergeItemDescAndStatusValue"].ToString());

                                if (mergeItemDescAndStatusValue == 1)
                                {
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ColumnSpan = 2;
                                    itemDesc = itemDesc + ": " + statusValue;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ForeColor = Color.Blue;
                                }
                                else
                                {
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Font = new Font("Microsoft Sans Serif", 8, FontStyle.Regular);
                                }

                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Value = itemDesc;
                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Locked = true;

                                if ((!isprgDisabled) && (itemDesc.Length > 0) && (mergeItemDescAndStatusValue == 0))
                                {
                                    //Value
                                    FarPoint.Win.Spread.CellType.HyperLinkCellType lnk = new FarPoint.Win.Spread.CellType.HyperLinkCellType();
                                    lnk.Text = statusValue.ToString();
                                    lnk.LinkColor = Color.FromArgb(51, 29, 248);
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].CellType = lnk;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].Locked = false;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].ForeColor = Color.Blue;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].Font = new Font("Arial", 8, FontStyle.Bold);
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                                }

                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].RowSpan = noOfRowsToMerge;

                                if (isprgDisabled)
                                {
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ForeColor = Color.Gray;
                                }

                                if (itemDesc.Length > 0)
                                {
                                    Color btnBkColor = GetCorrespondingColor(actionBtnColor, isprgDisabled);
                                    if (noOfRowsToMerge > 1)
                                    {
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo + 1, colNo + 2].CellType = FarPtColCtrls.GetButtonCellType(btnBkColor);
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo + 1, colNo + 2].Tag = refNo;
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Tag = refNo;
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo + 1, colNo + 2].Locked = false;
                                    }
                                    else
                                    {
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].CellType = FarPtColCtrls.GetButtonCellType(btnBkColor);
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Tag = refNo;
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Locked = false;
                                    }
                                }

                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;

                                fpSpread_TopPanel.ActiveSheet.Rows[rowNo].Height = GROUP_ITEM_HEIGHT;
                                if (noOfRowsToMerge > 1)
                                {
                                    fpSpread_TopPanel.ActiveSheet.Rows[rowNo].Height = SEPARATOR_HEIGHT;
                                    fpSpread_TopPanel.ActiveSheet.Rows[rowNo + 1].Height = GROUP_ITEM_HEIGHT;

                                }
                                rowNo = rowNo + noOfRowsToMerge;
                            }
                            #endregion
                        }
                    }

                    int groupLastRow = rowNo - 1;
                    AssignOutlineBorderToGroupItems(currentRow + 1, colNo, groupLastRow, colNo + 2);
                    fpSpread_TopPanel.ActiveSheet.Cells[currentRow + 1, colNo, groupLastRow, colNo + 2].BackColor = grpItemBkColor;

                    //Separator Row
                    groupLastRow = groupLastRow + 1;
                    //fpSpread_TopPanel.ActiveSheet.Rows[groupLastRow].Height = SEPARATOR_HEIGHT;
                    fpSpread_TopPanel.ActiveSheet.Rows[groupLastRow].Locked = true;
                    fpSpread_TopPanel.ActiveSheet.Cells[groupLastRow, colNo, groupLastRow, colNo + 2].BackColor = backColor;
                    #endregion
                }

                fpSpread_TopPanel.ActiveSheet.Columns.Add(0, 1);
                fpSpread_TopPanel.ActiveSheet.Rows.Add(0, 1);
                fpSpread_TopPanel.ActiveSheet.Rows[0].Height = 2;
                fpSpread_TopPanel.ActiveSheet.Columns[0].Width = 6;
                fpSpread_TopPanel.ActiveSheet.Rows[0].BackColor = backColor;
                fpSpread_TopPanel.ActiveSheet.Columns[0].BackColor = backColor;

                tableLayoutPanel1.RowStyles[2].Height = totalHeight + 40;
            }
            catch (Exception err)
            {
                Gfn.Wb("Failed to Load DashBoard");
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "FillupDashBoardGrid", err.Message);
                return;
            }
            finally
            {
                drGrpItem = null;
                dtGroup = null;
                dtGroupItem = null;
            }
        }

        private void InitialiseCCMSLearningCount(ref DataTable dt)
        {
            DataRow[] dr;
            try
            {
                string prg = "CCMS Task";
                dr = dt.Select(" Prg='"+ prg + "' and IsPrgDisabled =0 ");
                int cnt = 0;
                if (dr != null) cnt = dr.Length;

                if (cnt == 0) return;

                int refNo_SuptToApprove = 14, refNo_MgrToApprove = 15;

                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                string addlCond = "";

                addlCond = addlCond + common.GetVslFilterAddlCondition(vslFilter, companyID);
                
                if (PG.laidupVessels.Trim().Length > 0)
                {
                    addlCond = addlCond + "   and V.VslCode not in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                }

                int cntModule_SuptToApprove = 0, cntModule_MgrToApprove = 0;
                string script = " select count(Distinct CCMS_SubmittedModulesID) " + Environment.NewLine +
                                " from CCMS_M_UserAccessRightsSetup A, CCMS_SubmittedModules SM, V_Vessels V  " + Environment.NewLine +
                                " Where A.CCMS_ModulesID = Sm.CCMS_ModulesID and A.CurCCMS_M_StatusID = SM.CCMS_M_StatusID  " + Environment.NewLine +
                                "   and A.C_CompanyID = V.C_CompanyID " + Environment.NewLine +
                                "   and SM.VesselID = V.VesselID " + Environment.NewLine +
                                "   and CurUser_Origin = 'HQ' and CurUser_Dept = '" + PG.currentUserDept + "' " + Environment.NewLine +
                                addlCond +
                                "   and SM.CCMS_M_StatusID = 20 " + Environment.NewLine +
                                "   and SM.Action_Depts = A.CurUser_Dept and SM.Action_Roles = A.CurUser_Role " + Environment.NewLine +
                                "   and Case when ((SM.Fleet_CrewId)>0) then (select IsDisabled from V_Staff_V where Fleet_CrewId=SM.Fleet_CrewId and VesselID=SM.VesselID) else 0 end = 0  ";
                cntModule_SuptToApprove = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

                script = " select count(Distinct CCMS_SubmittedModulesID) " + Environment.NewLine +
                                " from CCMS_M_UserAccessRightsSetup A,  CCMS_SubmittedModules SM, V_Vessels V  " + Environment.NewLine +
                                " Where A.CCMS_ModulesID = Sm.CCMS_ModulesID and A.CurCCMS_M_StatusID = SM.CCMS_M_StatusID  " + Environment.NewLine +
                                "   and A.C_CompanyID = V.C_CompanyID " + Environment.NewLine +
                                "   and SM.VesselID = V.VesselID " + Environment.NewLine +
                                "   and CurUser_Origin = 'HQ' and CurUser_Dept = '" + PG.currentUserDept + "' " + Environment.NewLine +
                                addlCond +
                                "   and SM.CCMS_M_StatusID = 25 " + Environment.NewLine +
                                "   and SM.Action_Depts = A.CurUser_Dept and SM.Action_Roles = A.CurUser_Role " + Environment.NewLine +
                                "   and Case when ((SM.Fleet_CrewId)>0) then (select IsDisabled from V_Staff_V where Fleet_CrewId=SM.Fleet_CrewId and VesselID=SM.VesselID) else 0 end = 0  ";
                cntModule_MgrToApprove = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

                string cntModule_SuptToApproveStr = "", cntModule_MgrToApproveStr = "",
                       module_SuptToApproveActionColor = "G", module_MgrToApproveColor = "G";
                if (cntModule_SuptToApprove > 0)
                {
                    module_SuptToApproveActionColor = "R";
                    cntModule_SuptToApproveStr = cntModule_SuptToApprove.ToString();
                }

                if (cntModule_MgrToApprove > 0)
                {
                    module_MgrToApproveColor = "R";
                    cntModule_MgrToApproveStr = cntModule_MgrToApprove.ToString();
                }

                dr = dt.Select(" Prg='" + prg + "' and RefNo = " + refNo_SuptToApprove);
                if (dr != null && dr.Length > 0)
                {
                    dr[0]["StatusValue"] = cntModule_SuptToApproveStr;
                    dr[0]["ActionButtonColor"] = module_SuptToApproveActionColor;
                }

                dr = dt.Select(" Prg='" + prg + "' and RefNo = " + refNo_MgrToApprove);
                if (dr != null && dr.Length > 0)
                {
                    dr[0]["StatusValue"] = cntModule_MgrToApproveStr;
                    dr[0]["ActionButtonColor"] = module_MgrToApproveColor;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMain.cs", "InitialiseCCMSLearningCount", err.Message);
            }
        }


        private Color GetCorrespondingColor(string actionButtonColor, bool isprgDisabled)
        {
            Color bkColor = Color.FromArgb(0, 192, 0);
            if (isprgDisabled)
            {
                bkColor = Color.LightGray;
            }
            else
            {
                if (actionButtonColor == "G") bkColor = Color.FromArgb(0, 192, 0);  //Color.FromArgb(14, 204, 38); //Color.Green;                                                                
                else if (actionButtonColor == "R") bkColor = Color.Red;             // Color.FromArgb(234, 0, 0); //Color.Red;                            
                else if (actionButtonColor == "Y") bkColor = Color.Yellow;// Color.Gold;            //Yellow; //Color.FromArgb(255, 255, 0);// Color.Yellow;
                else if (actionButtonColor == "GR") bkColor = Color.FromArgb(128, 128, 128); //Color.Gray;
            }
            return (bkColor);
        }

        protected void AssignOutlineBorderToGroupItems(int row1, int col1, int row2, int col2)
        {
            FarPoint.Win.Spread.Model.DefaultSheetSelectionModel defselModel = null;
            try
            {
                int rowCnt = row2 - row1 + 1;
                int colCnt = col2 - col1 + 1;
                defselModel = new FarPoint.Win.Spread.Model.DefaultSheetSelectionModel();
                defselModel.AddSelection(row1, col1, rowCnt, colCnt);
                fpSpread_TopPanel.ActiveSheet.Models.Selection = defselModel;
                fpSpread_TopPanel.ActiveSheet.SetOutlineBorder(fpSpread_TopPanel.ActiveSheet.GetSelection(0), new FarPoint.Win.RoundedLineBorder(Color.LightSteelBlue, 1, true, true, true, true));
                defselModel.RemoveSelection(row1, col1, rowCnt, colCnt);
            }
            finally
            {
                defselModel = null;
            }
        }

        private void fpSpread_TopPanel_ButtonClicked(object sender, FarPoint.Win.Spread.EditorNotifyEventArgs e)
        {
            if (e.Row < 0) return;
            if (isLinkClicked) return;

            try
            {
                int row = e.Row, col = e.Column; long refNo = -1;

                if (fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag == null) return;

                string tagValue = fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag.ToString().Trim();

                try
                {
                    if (fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag != null) Convert.ToInt32(fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag.ToString());
                }
                catch
                {
                    companyID = "-99";
                    if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();
                    if (companyID == "-99") companyID = PG.Gb.CompanyId;

                    if (tagValue.Trim().Length > 0 && fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag != null)
                    {
                        string script = " select count(*)  " +
                                        " from VUI_GroupItems_HQ I " +
                                        " where I.IsPrgDisabled = 0 and I.VUI_Groups_HQID > 0 and I.Prg=" + Gfn.Qss(tagValue) +
                                        "   and C_CompanyID = " + companyID  +
                                        "   and I.DashboardType = '" + PG.DASHBOARDTYPE_CREW + "'";
                        int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

                        if (cnt <= 0)
                        {
                            Gfn.nMbwithAlignAndCentrePosn("This program is not enabled", ContentAlignment.MiddleCenter, 110, 200);
                            return;
                        }

                        CallCorrespondingAppAllVessels(tagValue);
                        return;
                    }
                }

                if (tagValue.Length > 0)
                {
                    refNo = Convert.ToInt64(tagValue);
                }

                if (!InitialiseFieldName_CheckPrgDisabled(refNo)) return;

                if (fieldName.ToUpper() == "CCMSMODULES_PENDING" || fieldName.ToUpper() == "CCMSMODULES_TOAMEND" || fieldName.ToUpper() == "CCMSMODULES_TOAPPROVE")
                {
                    CallCorrespondingApplication(fieldName);
                    return;
                }

                if (fieldName.ToUpper() == "CCMSLEARNING_SEARCH")
                {
                    CallCorrespondingApplication(fieldName);
                    return;
                }

                BindAndFocusSelectedFieldColumn();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "fpSpread_TopPanel_ButtonClicked", err.Message);
            }
        }

        private void fpSpread_TopPanel_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            try
            {
                int row = e.Row, col = e.Column; long refNo = -1;

                string tagValue = fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag.ToString().Trim();
                if (tagValue.Length > 0)
                {
                    refNo = Convert.ToInt64(tagValue);
                }
                if (refNo < 0) return;

                isLinkClicked = true;

                if (!InitialiseFieldName_CheckPrgDisabled(refNo)) return;

                CallCorrespondingApplication(fieldName);

                fieldName = "";
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "fpSpread_TopPanel_HyperLinkClicked", err.Message);
            }
            finally
            {
                isLinkClicked = false;
            }
        }

        private void fpSpread_TopPanel_TextTipFetch(object sender, FarPoint.Win.Spread.TextTipFetchEventArgs e)
        {
            int row = e.Row; int col = e.Column;
            if (row < 0 || col < 0) return;
            try
            {
                if (((FarPoint.Win.Spread.CellType.HyperLinkCellType)(fpSpread_TopPanel.ActiveSheet.Cells[row, col].CellType)) != null) { }
            }
            catch { return; }

            for (int row1 = 0; row1 < fpSpread_TopPanel.ActiveSheet.RowCount; row1++)
            {
                for (int col1 = 0; col1 < fpSpread_TopPanel.ActiveSheet.ColumnCount; col1++)
                {
                    if (fpSpread_TopPanel.ActiveSheet.Cells[row1, col1].BackColor == Color.Yellow)
                    {
                        fpSpread_TopPanel.ActiveSheet.Cells[row1, col1].BackColor = Color.FromArgb(247, 247, 247);
                        fpSpread_TopPanel.ActiveSheet.Cells[row1, col1].ResetBorder();
                    }
                }
            }

            if (((FarPoint.Win.Spread.CellType.HyperLinkCellType)(fpSpread_TopPanel.ActiveSheet.Cells[row, col].CellType)) != null)
            {
                string cntValue = ((FarPoint.Win.Spread.CellType.HyperLinkCellType)(fpSpread_TopPanel.ActiveSheet.Cells[row, col].CellType)).Text.ToString();
                if (cntValue.Trim().Length > 0)
                {
                    fpSpread_TopPanel.ActiveSheet.Cells[row, col].BackColor = Color.Yellow;
                    fpSpread_TopPanel.ActiveSheet.Cells[row, col].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                }
            }
        }

        private void fpSpread_TopPanel_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0) return;
            try
            {
                int row = e.Row, col = e.Column; long refNo = -1;

                string tagValue = "";
                if (fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag != null) tagValue = fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag.ToString().Trim();
                if (tagValue.Length > 0)
                {
                    refNo = Convert.ToInt64(tagValue);
                }
                if (refNo < 0) return;

                if (!InitialiseFieldName_CheckPrgDisabled(refNo)) return;

                CallCorrespondingApplication(fieldName);

                fieldName = "";
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "fpSpread_TopPanel_HyperLinkClicked", err.Message);
            }
        }

        private bool InitialiseFieldName_CheckPrgDisabled(long refNo)
        {
            bool result = false;
            DataTable dt;
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();
                if (companyID.ToString() == "-99") companyID = PG.Gb.CompanyId;

                string script = " select FieldName, IsPrgDisabled " +
                                " from VUI_GroupItems_HQ " +
                                " where RefNo=" + refNo +
                                "   and C_CompanyID = " + companyID +
                                "   and DashboardType = '" + PG.DASHBOARDTYPE_CREW + "'";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt != null && dt.Rows.Count > 0)
                {
                    fieldName = dt.Rows[0]["FieldName"].ToString();
                    string isPrgDisabled = dt.Rows[0]["IsPrgDisabled"].ToString();
                    if (isPrgDisabled == "1")
                    {
                        Gfn.nMbwithAlignAndCentrePosn("This program is not enabled", ContentAlignment.MiddleCenter, 110, 200);
                        return result;
                    }
                }

                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();
                string addlCond = "  ";
                if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";

                script = " select ColumnNo from Dashboard_HQ_Main_Crew_Setup " +
                         " where ColumnName=" + Gfn.Qss(fieldName) +
                         addlCond;
                string columnNoStr = PG.Gb.DBFn.Aqr(script).ToString();
                int colNo = -1;
                if (columnNoStr.Trim().Length > 0) colNo = Convert.ToInt32(columnNoStr);

                if (colNo > 0 && colNo < fpSpread1.ActiveSheet.ColumnCount)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(0, colNo);
                    fpSpread1.SetViewportTopRow(0, 0);
                    fpSpread1.SetViewportLeftColumn(0, colNo);
                }

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "InitialiseFieldName_CheckPrgDisabled", err.Message);
            }

            finally
            {
                dt = null;
            }

            return result;
        }

        private void fpSpread_TopPanel_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        #endregion


        private void BindAndFocusSelectedFieldColumn()
        {
            DataTable dt;
            try
            {
                BindDashBoardGrid();

                if (fieldName.Trim().Length <= 0 || fpSpread1.ActiveSheet.RowCount < 0) return;

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();
                string addlCond = "  ";
                if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";

                string script = " select GroupName, ColumnNo from Dashboard_HQ_Main_Crew_Setup " +
                                " where ColumnName= " + Gfn.Qss(fieldName) +
                                addlCond;
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null) return;

                string groupName = dt.Rows[0]["GroupName"].ToString();
                string sx = dt.Rows[0]["ColumnNo"].ToString();

                int col = -1;
                if (sx.Trim().Length > 0) col = Convert.ToInt32(sx);

                if (col > 0 && col < fpSpread1.ActiveSheet.ColumnCount && fpSpread1.ActiveSheet.RowCount > 0)
                {
                    fpSpread1.ActiveSheet.Cells[0, col, fpSpread1.ActiveSheet.RowCount - 1, col].BackColor = Color.Yellow;
                    fpSpread1.ActiveSheet.Cells[0, col, fpSpread1.ActiveSheet.RowCount - 1, col].ForeColor = Color.Red;
                    fpSpread1.ActiveSheet.Cells[0, col, fpSpread1.ActiveSheet.RowCount - 1, col].Font = new System.Drawing.Font("Microsoft sans serif", 7.5f, FontStyle.Bold);

                    fpSpread1.ActiveSheet.SetActiveCell(0, col);

                    string addlCondCompanyID = "";
                    if (companyID != "-99" && companyID != "-1") addlCondCompanyID = "  and C_CompanyID = " + companyID;

                    script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways " +
                             " from Dashboard_HQ_Main_Crew_Setup " + Environment.NewLine +
                             " where ColumnNo>=0 and  GroupName=" + Gfn.Qss(groupName) +
                             addlCondCompanyID + 
                             " order by ColumnNo";
                    dt = PG.Gb.DBFn.DbRecords(script);

                    if (dt == null) return;

                    foreach (DataRow dr in dt.Rows)
                    {
                        int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                        int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                        int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());
                        if (isToHide == 1 || isToShowAlways == 1) continue;

                        fpSpread1.ActiveSheet.Columns[columnNo].Visible = true;
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "BindAndFocusSelectedFieldColumn", err.Message);
            }
        }

        private void CallCorrespondingApplication(string fieldName)
        {
            #region Initialise Field Name Variables

            string FLD_CERTIFICATE_TORENEW = "CERTIFICATE_TORENEW",
                   FLD_CERTIFICATE_ODUE = "CERTIFICATES_ODUE",

                   FLD_FORMS_ODUE = "FORMS_ODUE",
                   FLD_FORMS_SUPT_TO_APPR = "FORMS_SUPT_TO_APPR",
                   FLD_FORMS_MGR_TO_APPR = "FORMS_MGR_TO_APPR",
                   FLD_FORMS_GENMGR_TO_APPR = "FORMS_GENMGR_TO_APPR",
                   FLD_CCMSMODULES_PENDING = "CCMSMODULES_PENDING",
                   FLD_CCMSMODULES_TOAMEND = "CCMSMODULES_TOAMEND",
                   FLD_CCMSMODULES_TOAPPROVE = "CCMSMODULES_TOAPPROVE",

                   FLD_CCMSLEARNING_SEARCH = "CCMSLEARNING_SEARCH",
                   FLD_CCMSLEARNING_ODUE = "CCMSLEARNING_ODUE",
                   FLD_CCMSLEARNING_INPROGRESS = "CCMSLEARNING_INPROGRESS",
                   FLD_CCMSLEARNING_HQTASKTOAPPROVE = "CCMSLEARNING_HQTASKTOAPPROVE",
                   FLD_CCMSLEARNING_SUPTTOAPPROVEMODULE = "CCMSLEARNING_SUPTTOAPPROVE",
                   FLD_CCMSLEARNING_MGRTOAPPROVEMODULE = "CCMSLEARNING_MGRTOAPPROVE",
                   FLD_CCMSLEARNING_GENMGRTOAPPROVEMODULE = "CCMSLEARNING_GENMGRTOAPPROVE",
                   FLD_CCMSLEARNING_SRMGRTOAPPROVEMODULE = "CCMSLEARNING_SRMGRTOAPPROVE",
                   FLD_CCMSLEARNING_DIRECTORTOAPPROVEMODULE = "CCMSLEARNING_DIRECTORTOAPPROVE",
                   FLD_CCMSLEARNING_VSLTASKTOAPPROVE = "CCMSLEARNING_VSLTOAPPROVE",
                   FLD_CCMSLEARNING_CLOSED = "CCMSLEARNING_CLOSED",

                   FLD_CREWRESTHOURS_NOOFDAYSPENDINGINPUT = "CREWRESTHOURS_NOOFDAYSPENDINGINPUT",
                   FLD_CREWRESTHOURS_NOOFDAYSPENDINGNC = "CREWRESTHOURS_NOOFDAYSPENDINGNC",

                   FLD_NCR_CREW_VSL_TO_FINALISE = "NCR_Crew_ToFinalise",
                   FLD_NCR_CREW_PENDING = "NCR_CREW_PENDING",
                   FLD_INCIDENTREPORT_CREW_TO_APPROVE = "INCIDENTREPORT_CREW_TO_APPROVE",
                   FLD_TASKLIST_OVERDUE = "TASKLIST_OVERDUE",
                   FLD_TASKLIST_HQTOSUBMIT = "TASKLIST_HQTOSUBMIT",
                   FLD_TASKLIST_CREW_PENDING = "TASKLIST_CREW_PENDING",
                   FLD_MINUTES_OF_SAFETY_CREW_PENDING = "MINUTES_OF_SAFETY_CREW_PENDING",
                   FLD_AWARENESS_REPORT_CREW_PENDING = "AWARENESS_REPORT_CREW_PENDING",
                   FLD_MASTERS_REVIEW_CREW_PENDING = "MASTERS_REVIEW_CREW_PENDING",

                   FLD_RISKASSEMENTS_TO_APPR = "RISKASSEMENTS_TO_APPR",
                   FLD_RISKASSEMENTS_SUPT_TO_APPR = "RISKASSEMENTS_SUPT_TO_APPR",
                   FLD_RISKASSEMENTS_MGR_TO_APPR = "RISKASSEMENTS_MGR_TO_APPR";
            #endregion

            if (fieldName.ToUpper() == FLD_CERTIFICATE_ODUE.ToUpper() || fieldName.ToUpper() == FLD_CERTIFICATE_TORENEW.ToUpper())
            {
                #region Certificate
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_CERTIFICATE_ODUE) { addlParameter = "OVERDUE"; }
                else if (fieldName.ToUpper() == FLD_CERTIFICATE_TORENEW) { addlParameter = "TORENEW"; }

                CallCertificateApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_FORMS_ODUE.ToUpper() || fieldName.ToUpper() == FLD_FORMS_SUPT_TO_APPR
                || fieldName.ToUpper() == FLD_FORMS_MGR_TO_APPR || fieldName.ToUpper() == FLD_FORMS_GENMGR_TO_APPR)
            {
                #region Forms
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_FORMS_ODUE) { addlParameter = "OVERDUE|Crew"; }
                else if (fieldName.ToUpper() == FLD_FORMS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Supt"; }
                else if (fieldName.ToUpper() == FLD_FORMS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Manager"; }
                else if (fieldName.ToUpper() == FLD_FORMS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|GeneralManager"; }

                CallFormsApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_CCMSMODULES_PENDING.ToUpper() || fieldName.ToUpper() == FLD_CCMSMODULES_TOAMEND.ToUpper() || fieldName.ToUpper() == FLD_CCMSMODULES_TOAPPROVE.ToUpper())
            {
                #region CCMS
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_CCMSMODULES_PENDING) { addlParameter = "Pending"; }
                else if (fieldName.ToUpper() == FLD_CCMSMODULES_TOAMEND) { addlParameter = "ToAmend"; }
                else if (fieldName.ToUpper() == FLD_CCMSMODULES_TOAPPROVE) { addlParameter = "Finalised"; }

                CallCCMS_ModuleApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_CCMSLEARNING_SEARCH.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_ODUE.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_INPROGRESS.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_HQTASKTOAPPROVE.ToUpper() ||
                     fieldName.ToUpper() == FLD_CCMSLEARNING_SUPTTOAPPROVEMODULE.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_MGRTOAPPROVEMODULE.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_GENMGRTOAPPROVEMODULE || 
                     fieldName.ToUpper() == FLD_CCMSLEARNING_SRMGRTOAPPROVEMODULE.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_DIRECTORTOAPPROVEMODULE.ToUpper() || fieldName.ToUpper() == FLD_CCMSLEARNING_VSLTASKTOAPPROVE || 
                     fieldName.ToUpper() == FLD_CCMSLEARNING_CLOSED.ToUpper())
            {
                #region Crew Learning Modules
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_CCMSLEARNING_SEARCH) { addlParameter = "HQ_Search"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_ODUE) { addlParameter = "VSL_OverDue"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_INPROGRESS) { addlParameter = "HQ_InProgress"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_HQTASKTOAPPROVE) { addlParameter = "HQ_TaskToApprove"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_VSLTASKTOAPPROVE) { addlParameter = "VSL_TaskToApprove"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_SUPTTOAPPROVEMODULE) { addlParameter = "SuptToApproveModule"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_MGRTOAPPROVEMODULE) { addlParameter = "MgrToApproveModule"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_GENMGRTOAPPROVEMODULE) { addlParameter = "GenMgrToApproveModule"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_SRMGRTOAPPROVEMODULE) { addlParameter = "SrMgrToApproveModule"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_DIRECTORTOAPPROVEMODULE) { addlParameter = "DirectorToApproveModule"; }
                else if (fieldName.ToUpper() == FLD_CCMSLEARNING_CLOSED) { addlParameter = "Closed"; }

                CallCCMS_LearningApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_CREWRESTHOURS_NOOFDAYSPENDINGINPUT.ToUpper() || fieldName.ToUpper() == FLD_CREWRESTHOURS_NOOFDAYSPENDINGNC.ToUpper())
            {
                #region Crew Rest Hours
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_CREWRESTHOURS_NOOFDAYSPENDINGINPUT) { addlParameter = "NoOfDaysPendingInput_VSL"; }
                else if (fieldName.ToUpper() == FLD_CREWRESTHOURS_NOOFDAYSPENDINGNC) { addlParameter = "NoOfDaysPendingNC_VSL"; }

                CallCrew_RestHoursApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_NCR_CREW_VSL_TO_FINALISE || fieldName.ToUpper() == FLD_NCR_CREW_PENDING)
            {
                #region NCR

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_NCR_CREW_VSL_TO_FINALISE) { addlParameter = "CrewToFinalise"; }
                else if (fieldName.ToUpper() == FLD_NCR_CREW_PENDING) { addlParameter = "CrewPending"; }

                CallNCRApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_TASKLIST_OVERDUE || fieldName.ToUpper() == FLD_TASKLIST_HQTOSUBMIT || fieldName.ToUpper() == FLD_TASKLIST_CREW_PENDING)
            {
                #region Task List

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_TASKLIST_OVERDUE) { addlParameter = "OverDue"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_HQTOSUBMIT) { addlParameter = "HQToSubmit_Resubmit"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_CREW_PENDING) { addlParameter = "CrewPending_ToApprove"; }

                CallTaskListApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_CREW_TO_APPROVE)
            {
                #region Incident Report
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_INCIDENTREPORT_CREW_TO_APPROVE) { addlParameter = "Incident_CrewPending"; }

                CallIncidentReportApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_CREW_PENDING)
            {
                #region Awareness Report

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_CREW_PENDING) { addlParameter = "CrewPending"; }

                CallAwarenessReportApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW_CREW_PENDING)
            {
                #region Masters Review

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_MASTERS_REVIEW_CREW_PENDING) { addlParameter = "CrewPending"; }

                CallMastersReviewReportApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_CREW_PENDING)
            {
                #region Minutes of Safety

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_CREW_PENDING) { addlParameter = "CrewPending"; }

                CallMinutesOfSafetyReportApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_RISKASSEMENTS_SUPT_TO_APPR || fieldName.ToUpper() == FLD_RISKASSEMENTS_MGR_TO_APPR
                || fieldName.ToUpper() == FLD_RISKASSEMENTS_TO_APPR )
            {
                #region Minutes of Safety

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_RISKASSEMENTS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Supt"; }
                else if (fieldName.ToUpper() == FLD_RISKASSEMENTS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Manager"; }

                CallRiskMgmtApplication(-1, addlParameter, true, false);

                #endregion
            }
            
        }

        private void CallCorrespondingAppAllVessels(string prgName)
        {
            if (prgName.ToUpper() == PG.GROUPNAME_DOCUMENT.ToUpper())
            {
                //
            }
            if (prgName.ToUpper() == PG.GROUPNAME_CERTIFICATE.ToUpper())
            {
                CallCertificateApplication(-1, "ALL", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_FORMS.ToUpper())
            {
                CallFormsApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_CCMS_MODULE.ToUpper())
            {
                CallCCMS_ModuleApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_CCMS_LEARNING.ToUpper())
            {
                CallCCMS_LearningApplication(-1, "HQ_All", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_CREWRESTHOURS.ToUpper())
            {
                CallCrew_RestHoursApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_TASK.ToUpper())
            {
                CallTaskListApplication(-1, "Register", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_NCR.ToUpper())
            {
                CallNCRApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_INCIDENTREPORT.ToUpper() || prgName.ToUpper() == PG.GROUPNAME_INCIDENTREPORT1.ToUpper())
            {
                CallIncidentReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_SAFETYCOMMITTEEMEETING.ToUpper() || prgName.ToUpper() == PG.GROUPNAME_SAFETYCOMMITTEEMEETING1.ToUpper())
            {
                CallMinutesOfSafetyReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_AWARENESSREPORT.ToUpper())
            {
                CallAwarenessReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_MASTERSSAFETYREVIEW.ToUpper())
            {
                CallMastersReviewReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_RISKASSESMENT.ToUpper())
            {
                CallRiskMgmtApplication(-1, "ALL|CREW", true, false);
            }
        }

        private void fpSpread1_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0) return;

            if (e.ColumnHeader)
            {
                if (e.Row != 0) return;

                string groupName = fpSpread1.ActiveSheet.ColumnHeader.Cells[e.Row, e.Column].Text;
                ExpandCollapseColumn(groupName);
                if (isExpanded)
                {
                    chkShowOnlyActionColumns_CheckedChanged(null, null);
                    isExpanded = false;
                }
                else isExpanded = true;
                return;
            }

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                this.Cursor = Cursors.Default;
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            int cnt = 0;
            if (e.Column >= COL_CERTIFICATE_OVERDUE && e.Column <= COL_CERTIFICATE_RENEWALINPROGRESS)
            {
                #region Certificate
                string addlParameter = "";
                if (e.Column == COL_CERTIFICATE_OVERDUE) { addlParameter = "OverDue"; }
                else if (e.Column == COL_CERTIFICATE_WINDOW) { addlParameter = "Window"; }
                else if (e.Column == COL_CERTIFICATE_PENDING) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_CERTIFICATE_HQTOUPDATE) { addlParameter = "HQToUpdate"; }
                else if (e.Column == COL_CERTIFICATE_VSLTOUPDATE) { addlParameter = "VSLToUpdate"; }
                else if (e.Column == COL_CERTIFICATE_TORENEW) { addlParameter = "ToRenew"; }
                else if (e.Column == COL_CERTIFICATE_RENEWALINPROGRESS) { addlParameter = "RenewalInProgress"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallCertificateApplication(vesselID, addlParameter, true, false);
                #endregion
            }
            else if (e.Column == COL_DOCMGMT_MANUALS_UNREAD || e.Column == COL_DOCMGMT_CIRCULARS_UNREAD)
            {
                #region Document Manangement

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    string msg = "no Document Mgmt Unread Manuals";
                    if (e.Column == COL_DOCMGMT_CIRCULARS_UNREAD) msg = "no Document Mgmt Unread Circulars";
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is " + msg + ".");
                    return;
                }

                PG.CallDMS(cboCompany_Filter.Text);

                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_DOCMGMT;
                RefreshHQDashboard(vesselID);
                #endregion
            }
            else if (e.Column >= COL_FORMS_ODUE && e.Column <= COL_FORMS_RECENTLY_CLOSED)
            {
                #region Forms
                string addlParameter = "", msg = "";
                if (e.Column == COL_FORMS_ODUE) { addlParameter = "OVERDUE|Crew";  msg = " OverDue Forms"; }
                else if (e.Column == COL_FORMS_VSL_PENDING) { addlParameter = "VslPending|Crew"; msg = "VSL Pending Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_FINALISE) { addlParameter = "VslToFinalise|Crew"; msg = "VSL To Finalise Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_AMEND) { addlParameter = "VSLTOAMENDMNTS|Crew"; msg = "Forms for Vsl Amend"; }
                else if (e.Column == COL_FORMS_HQ_PENDING) { addlParameter = "HQPending|Crew"; msg = "HQ Pending Forms"; }
                else if (e.Column == COL_FORMS_HQ_TO_AMEND) { addlParameter = "HQAmend|Crew"; msg = "Forms for HQ Amend"; }
                else if (e.Column == COL_FORMS_TO_APPR) { addlParameter = "HQTOAPPR|Crew"; msg = "Forms for Approval"; }
                else if (e.Column == COL_FORMS_SUPT_TO_FINALISE) { addlParameter = "FILLED|Crew|Supt"; msg = "Forms for Supt to finalise"; }
                else if (e.Column == COL_FORMS_MGR_TO_FINALISE) { addlParameter = "FILLED|Crew|Manager"; msg = "Forms for Manager to finalise"; }
                else if (e.Column == COL_FORMS_GENMGR_TO_FINALISE) { addlParameter = "FILLED|Crew|GeneralManager"; msg = "Forms for General Manager to finalise"; }
                else if (e.Column == COL_FORMS_DIR_TO_FINALISE) { addlParameter = "FILLED|Crew|Director"; msg = "Forms for Director to finalise"; }

                else if (e.Column == COL_FORMS_TA_TO_APPR) { addlParameter = "HQTOAPPR|Crew|T.A"; msg = "Forms for T.A to Approve"; }
                else if (e.Column == COL_FORMS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Supt"; msg = "Forms for Supt to Approve"; }
                else if (e.Column == COL_FORMS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Manager"; msg = "Forms for Manager to Approve"; }
                else if (e.Column == COL_FORMS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|GeneralManager"; msg = "Forms for General Manager to Approve"; }
                else if (e.Column == COL_FORMS_SENMGR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|SeniorManager"; msg = "Forms for Senior Manager to Approve"; }
                else if (e.Column == COL_FORMS_DIR_TO_APPR) { addlParameter = "HQTOAPPR|Crew|Director"; msg = "Forms for Director to Approve"; }
                else if (e.Column == COL_FORMS_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed|Crew"; msg = "Forms Recently Closed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallFormsApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_CCMSLEARNING_ODUE && e.Column <= COL_CCMSLEARNING_CLOSED)
            {
                #region CCMS Task
                string addlParameter = "", msg = "";
                if (e.Column == COL_CCMSLEARNING_ODUE) { addlParameter = "HQ_OverDue"; msg = " OverDue"; }
                else if (e.Column == COL_CCMSLEARNING_HQINPROGRESS) { addlParameter = "HQ_InProgress"; msg = " HQ InProgress"; }
                else if (e.Column == COL_CCMSLEARNING_INPROGRESS) { addlParameter = "VSL_InProgress"; msg = " VSL InProgress"; }
                else if (e.Column == COL_CCMSLEARNING_HQTASKTOAPPROVE) { addlParameter = "HQ_TaskToApprove"; msg = " Task To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_VSLTASKTOAPPROVE) { addlParameter = "VSL_TaskToApprove"; msg = " VSL To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_VSLTOAPPROVEMODULE) { addlParameter = "Vsl_ToApproveModule"; msg = " Vsl To Approve Module"; }
                else if (e.Column == COL_CCMSLEARNING_SUPTTOAPPROVEMODULE) { addlParameter = "SuptToApproveModule"; msg = " Supt To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_MGRTOAPPROVEMODULE) { addlParameter = "MgrToApproveModule"; msg = " Mgr To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_GENMGRTOAPPROVEMODULE) { addlParameter = "GenMgrToApproveModule"; msg = " Gen Mgr To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_SRMGRTOAPPROVEMODULE) { addlParameter = "SrMgrToApproveModule"; msg = " Sr Mgr To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_DIRECTORTOAPPROVEMODULE) { addlParameter = "DirectorToApproveModule"; msg = " Director To Approve"; }
                else if (e.Column == COL_CCMSLEARNING_CLOSED) { addlParameter = "Closed"; msg = " Recently Closed"; }
                
                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallCCMS_LearningApplication(vesselID, addlParameter, true, false);
                #endregion
            }
            else if (e.Column == COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT || e.Column == COL_CREWRESTHOURS_NOOFNCSIN30DAYS)
            {
                #region Crew Rest Hours
                string addlParameter = "", msg = "";
                if (e.Column == COL_CREWRESTHOURS_NOOFDAYS_PENDINGINPUT) { addlParameter = "NoOfDaysPendingInput"; msg = " Pending Input"; }
                else if (e.Column == COL_CREWRESTHOURS_NOOFNCSIN30DAYS) { addlParameter = "NoOfDaysPendingNC"; msg = " Pending NC"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallCrew_RestHoursApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (e.Column >= COL_TASKLIST_OVERDUE && e.Column <= COL_TASKLIST_CREW_PENDING)
            {
                #region Task List

                string addlParameter = "";
                if (e.Column == COL_TASKLIST_OVERDUE) { addlParameter = "OverDue"; }
                else if (e.Column == COL_TASKLIST_HQTOSUBMIT) { addlParameter = "HQToSubmit_Resubmit"; }
                else if (e.Column == COL_TASKLIST_CREW_PENDING) { addlParameter = "CrewPending_ToApprove"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallTaskListApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_NCR_CREW_TO_FINALISE || e.Column == COL_NCR_CREW_PENDING)
            {
                #region NCR

                string addlParameter = "";
                if (e.Column == COL_NCR_CREW_TO_FINALISE) { addlParameter = "CrewToFinalise"; }
                else if (e.Column == COL_NCR_CREW_PENDING) { addlParameter = "CrewPending"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_DEFECT_CREW_TO_FINALISE)
            {
                #region Defects

                string addlParameter = "";
                if (e.Column == COL_DEFECT_CREW_TO_FINALISE) { addlParameter = addlParameter = "CREWTOVERIFY|YES"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallDefectsApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_INCIDENT_REPORT_CREW_PENDING)
            {
                #region Incident Report
                string addlParameter = "";
                if (e.Column == COL_INCIDENT_REPORT_CREW_PENDING) { addlParameter = "Incident_CrewPending"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallIncidentReportApplication(vesselID, addlParameter, true, false);
                #endregion
            }
            else if (e.Column == COL_AWARENESS_REPORT_CREW_PENDING)
            {
                #region Awareness Report

                string addlParameter = "";
                if (e.Column == COL_AWARENESS_REPORT_CREW_PENDING) { addlParameter = "CrewPending"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallAwarenessReportApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_MASTERS_REVIEW_CREW_PENDING)
            {
                #region Masters Review

                string addlParameter = "";
                if (e.Column == COL_MASTERS_REVIEW_CREW_PENDING) { addlParameter = "CrewPending"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallMastersReviewReportApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_MINUTES_OF_SAFETY_CREW_PENDING)
            {
                #region Minutes of Safety

                string addlParameter = "";
                if (e.Column == COL_MINUTES_OF_SAFETY_CREW_PENDING) { addlParameter = "CrewPending"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallMinutesOfSafetyReportApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_RISKASSEMENTS_TASK_ODUE && e.Column <= COL_RISKASSEMENTS_RECENTLY_CLOSED)
            {
                #region Risk Assements              
                string addlParameter = "", msg = "";
                if (e.Column == COL_RISKASSEMENTS_TASK_ODUE) { addlParameter = "Task_ODUE"; msg = " Task OverDue Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_REPORT_ODUE) { addlParameter = "Report_ODUE"; msg = "Report OverDue Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_ACTIVEITEMS) { addlParameter = "ActiveItems"; msg = "Active Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_PENDING) { addlParameter = "VslPending"; msg = "VSL Pending Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_TO_AMEND) { addlParameter = "VslAmend"; msg = "Risk Assements for Vsl Amend"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_PENDING) { addlParameter = "HQPending|CREW"; msg = "HQ Pending Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_TO_AMEND) { addlParameter = "HQAmend|CREW"; msg = "Risk Assements for HQ Amend"; }
                else if (e.Column == COL_RISKASSEMENTS_TO_APPR) { addlParameter = "HQTOAPPR|CREW"; msg = "Risk Assements for Review"; }
                else if (e.Column == COL_RISKASSEMENTS_TA_TO_APPR) { addlParameter = "HQTOAPPR|CREW|T.A"; msg = "Risk Assements for T.A to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|CREW|Supt"; msg = "Risk Assements for Supt to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|CREW|Manager"; msg = "Risk Assements for Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR|CREW|GeneralManager"; msg = "Risk Assements for General Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_SENMGR_TO_APPR) { addlParameter = "HQTOAPPR|CREW|SeniorManager"; msg = "Risk Assements for Senior Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_DIR_TO_APPR) { addlParameter = "HQTOAPPR|CREW|Director"; msg = "Risk Assements for Director to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_TO_ACK) { addlParameter = "VslToAck|CREW"; msg = "Risk Assements for Vsl to Ack"; }
                else if (e.Column == COL_RISKASSEMENTS_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed|CREW"; msg = "Risk Assements Closed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallRiskMgmtApplication(vesselID, addlParameter, true, false);

                #endregion
            }

            this.Cursor = Cursors.Default;
            panelLoading.Visible = false;
        }

        private void ExpandCollapseColumn(string groupName)
        {
            DataTable dt;
            try
            {
                if (groupName.ToUpper() == "Audit / Inspection(AI)".ToUpper()) groupName = "Audit / Inspection (AI)";

                string script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways " +
                                " from Dashboard_HQ_Main_Crew_Setup " + Environment.NewLine +
                                " where ColumnNo>=0 and GroupName=" + Gfn.Qss(groupName) +
                                "   and C_CompanyID = " + PG.Gb.CompanyId +
                                " order by ColumnNo";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                    if (columnNo >= fpSpread1.ActiveSheet.ColumnCount) break;

                    int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                    int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());
                    if (isToHide == 1) continue;

                    if (isToShowAlways == 1) fpSpread1.ActiveSheet.Columns[columnNo].Visible = true;
                    else fpSpread1.ActiveSheet.Columns[columnNo].Visible = (!fpSpread1.ActiveSheet.Columns[columnNo].Visible);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "ExpandCollapseColumn", err.Message);
            }
        }

        private void fpSpread1_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread1.ContextMenuStrip = null;
            if (fpSpread1.ActiveSheet.RowCount > 0) fpSpread1.ActiveSheet.Rows[0, fpSpread1.ActiveSheet.RowCount - 1].ResetBackColor();

            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread1.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;

                fpSpread1.ActiveSheet.SetActiveCell(row, col);
                fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;

                int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value);
                string script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='DocMgmt' and IsPrgDisabled = 0";
                bool isToEnableDocMgmt = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                tsMnuDocumentManagement.Visible = (isToEnableDocMgmt && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DocMgmt));

                script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='Circulars_Vsl' and IsPrgDisabled = 0";
                bool isToEnableAlerts_Circulars = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                tsMnuVslAlerts_Circulars.Visible = isToEnableAlerts_Circulars;

                fpSpread1.ContextMenuStrip = contextMenuStrip1;

                if (fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].Tag != null)
                {
                    string groupName = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].Tag.ToString().ToUpper();
                    if (groupName == PG.GROUPNAME_NCR) tsMnuNCR.Select();
                    else if (groupName == PG.GROUPNAME_TASK) tsMnuTaskList.Select();
                    else if (groupName == PG.GROUPNAME_INCIDENTREPORT || groupName == PG.GROUPNAME_INCIDENTREPORT1) tsMnuIncidentReport.Select();
                    else if (groupName == PG.GROUPNAME_INVESTIGATIONREPORT || groupName == PG.GROUPNAME_INVESTIGATIONREPORT1) tsMnuIncidentReport.Select();
                    else if (groupName == PG.GROUPNAME_AWARENESSREPORT) tsMnuAwarenessReport.Select();
                    else if (groupName == PG.GROUPNAME_SAFETYCOMMITTEEMEETING || groupName == PG.GROUPNAME_SAFETYCOMMITTEEMEETING1) tsMnuMinutesOfSafety.Select();
                    else if (groupName == PG.GROUPNAME_MASTERSSAFETYREVIEW) tsMnuMastersReview.Select();
                }
            }
        }

        #region Bottom Dashboard Grid - Right Click menu
        private void tsmu_VslDashBoard_Click(object sender, EventArgs e)
        {
            CallVslApplication("VslDashBoard");
        }


        private void tsMnuForms_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallFormsApplication(vesselID, "All|Crew", true, false);
        }

        private void tsMnuVslForms_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            calledFrom = "";
            CallFormsApplication(vesselID, "All|Crew", false, true);
        }


        private void tsMnuVslNCR_Click(object sender, EventArgs e)
        {
            calledFrom = "";
            CallVslApplication("NCR");
        }

        private void tsMnuNCR_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallNCRApplication(vesselID, "", true, false);
        }

        private void tsMnuDefects_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallDefectsApplication(vesselID, "", true, false);
        }

        private void tsMnuTaskList_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallTaskListApplication(vesselID, "", true, false);
        }

        private void tsMnuVslTaskList_Click(object sender, EventArgs e)
        {
            calledFrom = "";
            CallVslApplication("Task");
        }


        private void tsMnuIncidentReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallIncidentReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslIncidentReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallIncidentReportApplication(vesselID, "", false, true);
        }


        private void tsMnuAwarenessReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallAwarenessReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslAwarenessReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }
            CallAwarenessReportApplication(vesselID, "", false, true);
        }


        private void tsMnuMastersReview_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMastersReviewReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslMastersReview_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMastersReviewReportApplication(vesselID, "", false, true);
        }


        private void tsMnuMinutesOfSafety_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMinutesOfSafetyReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslMinutesOfSafety_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMinutesOfSafetyReportApplication(vesselID, "", false, true);
        }


        private void tsMnuCCMSLearning_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallCCMS_LearningApplication(vesselID, "HQ_All", true, false);
        }

        private void tsMnuCrewRestHours_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallCrew_RestHoursApplication(vesselID, "Register", true, false);
        }

        private void tsMnuVSLCCMSLearning_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallCCMS_LearningApplication(vesselID, "HQ_All", false, true);
        }

        private void tsMnuVslCertificate_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallCertificateApplication(vesselID, "Register", false, true);
        }


        private void tsMnuDocumentManagement_Click(object sender, EventArgs e)
        {
            CallVslApplication("DocMgmt");
        }

        private void tsMnuVslAlerts_Circulars_Click(object sender, EventArgs e)
        {
            CallVslApplication("Circulars_Vsl");
        }


        private void tsMnuVslRiskAssements_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallRiskMgmtApplication(vesselID, "Register|Crew", false, true);
        }

        private void tsMnuRiskAssements_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallRiskMgmtApplication(vesselID, "Register|Crew", true, false);
        }


        private void CallVslApplication(string exeName)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            string param = GetParam(vesselID, true);

            if (exeName.ToUpper() == "NCR".ToUpper())
            {
                CallNCRApplication(vesselID, "", false, true);
            }
            else if (exeName.ToUpper() == "Task".ToUpper())
            {
                CallTaskListApplication(vesselID, "", false, true);
            }
            else
            {
                if (exeName.ToUpper() == "PmsMain".ToUpper())
                {
                    exeName = "VslDashBoard";
                    param = param + " PmsMain";
                }
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
            }

            FocusSelectedVessel(vesselID, 0);
        }

        private void CallCCMS_ModuleApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            CompetencyModuleMgmt.CCMSstartup ccmsStartup;

            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = " " + cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + vslFilter;
                ccmsStartup = new CompetencyModuleMgmt.CCMSstartup(arg.Split(' '));

                if (!ccmsStartup.isInitSuccessfully)
                {
                    return;
                }

                ccmsStartup.CallCCMSMainPage();
            }
            finally
            {
                ccmsStartup = null;
            }

            if (isToRefresh)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_CCMS_MODULE;
                RefreshHQDashboard(vesselID);
            }
        }


        private void CallCertificateApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string hqDept = "Common_Crew";
            if (!PG.isCert_FilterOdueDeptwise && addParam.ToUpper() == "OVERDUE") hqDept = "";
            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|" + hqDept;

            VslCertificates.VslCertificatesStartup vslCertificate = new VslCertificates.VslCertificatesStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!vslCertificate.isVslInitSuccessfully)
                {
                    return;
                }

                vslCertificate.CallVslCertificatesMainPage();
                isDoneAnyChanges = vslCertificate.isDoneAnyChanges;
            }
            finally
            {
                vslCertificate = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_CERTIFICATE;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallRiskMgmtApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            RiskMgmt.RMStartup rmStartup;
            bool isDoneAnyChanges = false;

            try
            {
                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim();
                rmStartup = new RiskMgmt.RMStartup(arg.Split(' '));

                rmStartup.CallRMRegisterPage();
                isDoneAnyChanges = rmStartup.isDoneAnyChanges;
            }
            finally
            {
                rmStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_TECH_RISKASSEMENTS;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }
       
        private void CallCCMS_LearningApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            CCMSLearning.CCMSLearningStartup ccmsStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "xx";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                if (vesselID > 0) vslFilter = "OneVsl-" + vesselID.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + "|" + vslFilter + "|Crew";
                ccmsStartup = new CCMSLearning.CCMSLearningStartup(arg.Split(' '));

                if (!ccmsStartup.isVslInitSuccessfully)
                {
                    return;
                }

                ccmsStartup.CallRegisterMainPage();
                isDoneAnyChanges = ccmsStartup.isDoneAnyChanges;
            }
            finally
            {
                ccmsStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_CCMS_LEARNING;
                fieldName = "";
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallCrew_RestHoursApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = " " + cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess);

                string exeName = "CRH";
                string param = GetParam(vesselID, false);
                param = param + " " + addlParameter;
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
            }
            finally
            {
            }

            if (isToRefresh)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_CREW_RESTHOURS;
                RefreshHQDashboard(vesselID);
            }
        }

        private void CallFormsApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            VslForms.FormsStartup formsStartup;
            bool isChangesDone = true;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = " " + cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + vslFilter;
                formsStartup = new VslForms.FormsStartup(arg.Split(' '));

                if (!formsStartup.isVslInitSuccessfully)
                {
                    return;
                }

                formsStartup.CallFormsListMainPage(arg.Split(' '));

                isChangesDone = formsStartup.isChangesDone;
            }
            finally
            {
                formsStartup = null;
            }

            if (isToRefresh && isChangesDone)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_FORMS;
                RefreshHQDashboard(vesselID);
            }
            isChangesDone = false;
        }

        private void CallNCRApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            NCR.NCRstartup ncrStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Crew";

                ncrStartup = new NCR.NCRstartup(arg.Split(' '));

                if (!ncrStartup.isVslInitSuccessfully)
                {
                    return;
                }

                ncrStartup.CallNCRRegisterMainPage();
                isDoneAnyChanges = ncrStartup.isDoneAnyChanges;
            }
            finally
            {
                ncrStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_NCR;
                fieldName = "";
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallDefectsApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Crew";

            bool isDoneAnyChanges = false;
            VslDefects.DFStartup vslDefects = new VslDefects.DFStartup(arg.Split(' '));
            try
            {
                if (!vslDefects.isVslInitSuccessfully)
                {
                    return;
                }

                vslDefects.CallDefectRegisterMainPage();
                isDoneAnyChanges = vslDefects.isDoneAnyChanges;
            }
            finally
            {
                vslDefects = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_DEFECT;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallIncidentReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Crew";

            IncidentReport.IncidentReportStartup incidentReportStartup = new IncidentReport.IncidentReportStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!incidentReportStartup.isVslInitSuccessfully)
                {
                    return;
                }

                incidentReportStartup.CallVslIncidentReportMainPage();
                isDoneAnyChanges = incidentReportStartup.isDoneAnyChanges;
            }
            finally
            {
                incidentReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_INCIDENTREPORT;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallAwarenessReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Crew";

            AwarenessReport.AwarenessReportstartup awarenessReportStartup = new AwarenessReport.AwarenessReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!awarenessReportStartup.isVslInitSuccessfully)
                {
                    return;
                }
                awarenessReportStartup.CallAwarenessReportRegisterMainPage();
                isDoneAnyChanges = awarenessReportStartup.isDoneAnyChanges;
            }
            finally
            {
                awarenessReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_AWARENESS_REPORT;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallMastersReviewReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Crew";

            MastersReviewReport.MastersReviewReportstartup mastersReviewReportstartup = new MastersReviewReport.MastersReviewReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!mastersReviewReportstartup.isVslInitSuccessfully)
                {
                    return;
                }

                mastersReviewReportstartup.CallMastersReviewRegisterMainPage();
                isDoneAnyChanges = mastersReviewReportstartup.isDoneAnyChanges;
            }
            finally
            {
                mastersReviewReportstartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_MASTERS_REVIEW;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallMinutesOfSafetyReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Crew";

            MinutesofSafetyReport.MinutesofSafetyReportstartup minutesofSafetyReportstartup = new MinutesofSafetyReport.MinutesofSafetyReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!minutesofSafetyReportstartup.isVslInitSuccessfully)
                {
                    return;
                }

                minutesofSafetyReportstartup.CallMinutesofSafetyReportRegisterMainPage();
                isDoneAnyChanges = minutesofSafetyReportstartup.isDoneAnyChanges;
            }
            finally
            {
                minutesofSafetyReportstartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_MINUTES_OF_SAFETY;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallTaskListApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            TaskList.Taskstartup taskStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                string sx = "";
                if (addlParameter.ToUpper() != "CrewPending".ToUpper())
                {
                    sx = "|Crew";
                }

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + "|" + vslFilter + sx;

                taskStartup = new TaskList.Taskstartup(arg.Split(' '));

                if (!taskStartup.isVslInitSuccessfully)
                {
                    return;
                }

                taskStartup.CallTaskRegisterMainPage();
                isDoneAnyChanges = taskStartup.isDoneAnyChanges;
            }
            finally
            {
                taskStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_CREW_TASK;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = cboCompany_Filter.Text + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = cboCompany_Filter.Text + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            return param;
        }

        private void BindDashboardDetailsGrid(int vesselID)
        {
            int col = fpSpread1.ActiveSheet.ActiveColumnIndex;
            fieldName = ""; calledFrom = "";
            BindAndFocusSelectedFieldColumn();
            BindTopPanelDashboardData();
            if (vesselID > 0) FocusSelectedVessel(vesselID, col);
        }

        private void FocusSelectedVessel(int vesselID, int col)
        {
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                int curVesselID = -1;
                if (fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value != null) curVesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value);
                if (curVesselID == vesselID)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(row, col);
                    int topRow = row;
                    if (topRow > 10) topRow = topRow - 10;
                    fpSpread1.SetViewportTopRow(0, topRow);

                    fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    break;
                }
            }
        }
        #endregion


        #region Top links

        private void btnDMS_Click(object sender, EventArgs e)
        {
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (!PG.InitialiseCommonSettings(companyID)) return;

                pictureBox1.Visible = true; pictureBox1.Left = btnDMS.Left - pictureBox1.Width - 10; pictureBox1.Top = 0;
                PG.CallDMS(cboCompany_Filter.Text);
            }
            finally
            {
                pictureBox1.Visible = false;
                pictureBox1.Left = panelLoading.Left; pictureBox1.Top = panelLoading.Top - 10;
            }
        }

        private void btnProcurement_Click_1(object sender, EventArgs e)
        {
            string companyID = "-99";
            if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

            if (!PG.InitialiseCommonSettings(companyID)) return;

            string exeName = PG.default_ProcAppToCall;
            string param = "";
            if (PG.isDirectAppCall)
            {
                param = "DirectAppCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd;
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                param = "RemoteWebSvc " + URLString;
            }

            PG.ExecuteApp(exeName, param);
        }

        private void btnTechDashboard_Click(object sender, EventArgs e)
        {
            frmMainForm_Tech objMainFormTech = new frmMainForm_Tech();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objMainFormTech.companyID = companyID;
                objMainFormTech.isToShowSQEDashboard = isToShowSQEDashboard;
                objMainFormTech.isToShowCREWDashboard = false;
                objMainFormTech.ShowDialog();
            }
            finally
            {
                objMainFormTech = null;
            }
        }

        private void btnSQEDashboard_Click(object sender, EventArgs e)
        {
            frmMainForm_Marine objMainFormMarine = new frmMainForm_Marine();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objMainFormMarine.companyID = companyID;
                objMainFormMarine.isToShowTECHDashboard = isToShowTECHDashboard;
                objMainFormMarine.isToShowCREWDashboard = false;
                objMainFormMarine.Show();

                if (!PG.InitialiseCommonSettings(companyID)) return;
            }
            finally
            {
                objMainFormMarine = null;
            }
        }

        private void btnProcurement_Click(object sender, EventArgs e)
        {
            string exeName = PG.default_ProcAppToCall;
            string param = "";
            if (PG.isDirectAppCall)
            {
                param = "DirectAppCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd;
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                param = "RemoteWebSvc " + URLString;
            }

            PG.ExecuteApp(exeName, param);
        }

        private void lnkRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
                Application.DoEvents();

                calledFrom = "";
                RefreshHQDashboard(-1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "lnkRefresh_LinkClicked", err.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
                pictureBox1.Visible = false;
            }
        }

        private void RefreshHQDashboard(int selectedVesselID)
        {
            string script = "";
            DataTable dt = null;
            try
            {
                this.Cursor = Cursors.WaitCursor;

                if (selectedVesselID == -1)
                {
                    #region All vessels refresh
                    string companyID = "-99";
                    if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                    string addlCond = "";
                    if (PG.laidupVessels.Trim().Length > 0)
                    {
                        addlCond = addlCond + "   and V.VslCode not in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                    }
                    if (companyID != "-99") addlCond = addlCond + " and V.C_CompanyID='" + companyID + "'";

                    script = " Select V.VesselID from Dashboard_HQ_Main_Crew_Status S, V_Vessels V " +
                             " Where S.VesselID=V.VesselID " +
                             "   and V.VesselID<>-1" +
                             addlCond;
                    dt = PG.Gb.DBFn.DbRecords(script);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        progressBarRefresh.Visible = true;
                        if (progressBarRefresh.Value > 0) progressBarRefresh.Value = 1;
                        progressBarRefresh.Step = 1;
                        progressBarRefresh.Minimum = 0;
                        progressBarRefresh.Maximum = dt.Rows.Count;
                        Application.DoEvents();

                        foreach (DataRow dr in dt.Rows)
                        {
                            int vesselID = Convert.ToInt32(dr["VesselID"].ToString());

                            RefreshHQDashboardForThisVessel(vesselID);

                            Application.DoEvents();
                            progressBarRefresh.PerformStep();
                        }
                    }
                    #endregion
                }
                else
                {
                    RefreshHQDashboardForThisVessel(selectedVesselID);
                }

                panelLoading.Visible = false;
                Application.DoEvents();

                BindDashboardDetailsGrid(selectedVesselID);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Crew.cs", "RefreshHQDashboard", err.Message);
            }
            finally
            {
                panelLoading.Visible = false;
                progressBarRefresh.Visible = false;
                this.Cursor = Cursors.Default;
            }
        }

        private void RefreshHQDashboardForThisVessel(int vesselID)
        {
            try
            {
                if (calledFrom.Trim().Length > 0)
                {
                    PG.Refresh_HQ_Dashboard_Crew(calledFrom, vesselID);
                }
                else
                {
                    PG.Refresh_HQ_Dashboard_Crew(PG.REFRESH_CALLEDMODE_CREW_ALL, vesselID);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForms.cs", "RefreshHQDashboardForThisVessel", err.Message);
            }
        }

        private void lnkReset_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            fieldName = "";
            BindDashBoardGrid();
        }

        private void tsMnuNCRTrending_Click(object sender, EventArgs e)
        {
            string exeName = "HQ_Trendings";
            string param = GetParam(-1, false);
            param = param + " NCRTrending";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tsMnuAwarenessReportTrending_Click(object sender, EventArgs e)
        {
            string exeName = "HQ_Trendings";
            string param = GetParam(-1, false);
            param = param + " AWRTrending";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tlsMnuRootCauseAnalysisChartSetup_Click(object sender, EventArgs e)
        {
            string exeName = "MSCat_SetUp";
            string param = GetParam(-1, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }


        #endregion

        private void fpSpread_TopPanel_SizeChanged(object sender, EventArgs e)
        {
            int scrolHeight = fpSpread_TopPanel.GetHorizontalScrollBarRectangle(0).Height;
            
            if (scrolHeight > 0)
            {
                if (this.Width < 1420)
                {
                    this.Height = 910;
                    tableLayoutPanel1.RowStyles[2].Height = 135;
                }
            }
        }

        private void chkShowOnlyActionColumns_CheckedChanged(object sender, EventArgs e)
        {
           // DataTable dt = GetCrewDashboardDataTable();

            ShowOnlyActionColumns(true, dtCrewDashboard);

            ShowMyApproveColumns(dtCrewDashboard);
        }

        private void ShowOnlyActionColumns(bool isToClearFieldName, DataTable dt)
        {
            if (!isFormInitialised) return;

            if (chkShowOnlyActionColumns.Checked)
            {
                string xExcludeColList = "," + excludeColList + ",";
                if (isToClearFieldName) fieldName = "";

                for (int colHeaderIndex = COL_DOCMGMT_MANUALS_UNREAD; colHeaderIndex < fpSpread1.ActiveSheet.ColumnCount - 1; colHeaderIndex++)
                {
                    string sx1 = "," + colHeaderIndex + ",";
                    if (fpSpread1.ActiveSheet.ColumnHeader.Cells[1, colHeaderIndex].Tag == null
                        && (xExcludeColList.IndexOf(sx1) < 0))
                    {
                        fpSpread1.ActiveSheet.Columns[colHeaderIndex].Visible = false;
                    }
                    else
                    {
                        DataRow[] dr = dt.Select("ColumnNo=" + colHeaderIndex);
                        if (dr != null && dr.Length > 0)
                        {
                            if (dr[0]["IsToHide"].ToString() == "0")
                            {
                                fpSpread1.ActiveSheet.Columns[colHeaderIndex].Visible = true;
                            }
                        }
                    }
                }
            }
            else
            {
                int colNo = fpSpread1.ActiveSheet.ActiveColumnIndex;

                InitialiseHQDashboardFieldSetup(dt);

                if (colNo < fpSpread1.ActiveSheet.ColumnCount)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(0, colNo);
                    fpSpread1.SetViewportTopRow(0, 0);
                    fpSpread1.SetViewportLeftColumn(0, colNo);
                }
            }
        }

        private void chkShowMyApproveColumn_CheckedChanged(object sender, EventArgs e)
        {
            //DataTable dt = GetCrewDashboardDataTable();

            ShowMyApproveColumns(dtCrewDashboard);
        }

        private void ShowMyApproveColumns(DataTable dt)
        {
            if (chkShowMyApproveColumn.Checked)
            {
                string colList = "";
                string[] colToHide = PG.showOnlySuptApproveColumns_Crew.Trim().Split(',');
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SUPT" && PG.showOnlySuptApproveColumns_Crew.Trim().Length > 0) colList = colList + "," + PG.showOnlySuptApproveColumns_Crew.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "MANAGER" && PG.showOnlyMgrApproveColumns_Crew.Trim().Length > 0) colList = colList + "," + PG.showOnlyMgrApproveColumns_Crew.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "GENERALMANAGER" && PG.showOnlyGenMgrApproveColumns_Crew.Trim().Length > 0) colList = colList + "," + PG.showOnlyGenMgrApproveColumns_Crew.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SENIORMANAGER" && PG.showOnlySenMgrApproveColumns_Crew.Trim().Length > 0) colList = colList + "," + PG.showOnlySenMgrApproveColumns_Crew.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "DIRECTOR" && PG.showOnlyDirApproveColumns_Crew.Trim().Length > 0) colList = colList + "," + PG.showOnlyDirApproveColumns_Crew.Trim();
                if (colList.Trim().Length > 0)
                {
                    fpSpread1.ActiveSheet.Columns[COL_DOCMGMT_MANUALS_UNREAD, COL_SEPARATOR_RISKASSEMENTS].Visible = false;
                    colToHide = colList.Trim().Split(',');
                    string xExcludeColList = "," + excludeColList + ",";
                    foreach (string str in colToHide)
                    {
                        if (str.Trim().Length > 0)
                        {
                            int col = Convert.ToInt32(str);
                            DataRow[] dr = dt.Select("columnno = " + col + " and istohide =0");
                            if (dr.Length > 0)
                            {
                                if (chkShowOnlyActionColumns.Checked && fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag == null
                                && (xExcludeColList.IndexOf(col.ToString()) < 0)) fpSpread1.ActiveSheet.Columns[col].Visible = false;
                                else
                                    fpSpread1.ActiveSheet.Columns[col].Visible = true;
                            }
                        }
                    }
                }
            }
            else
            {
                ShowOnlyActionColumns(true, dt);
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            BindVslDetailsGrid();
        }


        private void tsMnuCCMSModule_Click(object sender, EventArgs e)
        {

        }

        private void tsMnuAbout_Click(object sender, EventArgs e)
        {
            frmAboutBox objAboutBox = new frmAboutBox();
            try
            {
                objAboutBox.ShowDialog();
            }
            finally
            {
                objAboutBox = null;
            }
        }

        private void tsMnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMainForm_Crew_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (isFormInitialised && (isToShowTECHDashboard && isToShowSQEDashboard))
            //{
            //    string companyText = cboCompany_Filter.Text.ToUpper();
            //    if (companyText == "ALL") companyText = "";
            //    string msg = "Are you sure you want to exit " + companyText + "HQ_SDS ?";

            //    if (!Gfn.nConfBox(msg))
            //    {
            //        e.Cancel = true;
            //        return;
            //    }
            //}
            common = null;
        }
    }
}