﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using Sds.CommonV1;

namespace HqSDS_Main
{
    public partial class frmMainForm_Marine : Form
    {
        public string vslFilter = "", companyID = "";
        public bool isToShowTECHDashboard = true, isToShowCREWDashboard = true;
        Common common = null; MainFrm mainObj = null;

        string calledFrom = "", fieldName = "", excludeColList = "";
        bool isFormInitialised = false, isLinkClicked = false, isExpanded = false;

        const int GROUP_HEADER_ROWCOUNT = 1;
        const int GROUP_SEPARATOR_ROWCOUNT = 1;

        const int PER_GROUP_WIDTH = 162;
        const int GROUP_ITEM_DISPLAY_WIDTH = 100;//90;
        const int GROUP_ITEM_VALUE_WIDTH = 30;
        const int GROUP_ITEM_BUTTON_WIDTH = 21;
        const int GROUP_COLUMN_SEPARATOR_WIDTH = 5;

        const int GROUP_NAME_HEIGHT = 17;
        const int GROUP_ITEM_HEIGHT = 17;
        const int SEPARATOR_HEIGHT = 5;

        int constcol = 3;

        #region Details Grid Column ID
        const int
                COL_COMPANYCODE = 0,
                COL_VSLCODE = 1,
                COL_INDICATOR = 2,
                COL_VSLNAME = 3,
                COL_OPERATEBY = 4,
                COL_SEPARATOR_VESSELDETAILS = 5,

                COL_CERTIFICATE_DUE = 6,
                COL_CERTIFICATE_OVERDUE = 7,
                COL_CERTIFICATE_WINDOW = 8,
                COL_CERTIFICATE_PENDING = 9,
                COL_CERTIFICATE_HQTOUPDATE = 10,
                COL_CERTIFICATE_VSLTOUPDATE = 11,
                COL_CERTIFICATE_TORENEW = 12,
                COL_CERTIFICATE_RENEWALINPROGRESS = 13,
                COL_SEPARATOR_CERTIFICATES = 14,
                COL_PORTSERVICES_PORT = 15,
                COL_PORTSERVICES_DATE = 16,
                COL_SEPARATOR_PORTSERVICES = 17,

                COL_DOCMGMT_MANUALS_UNREAD = 18,
                COL_DOCMGMT_CIRCULARS_UNREAD = 19,
                COL_SEPARATOR_DOCMGMT = 20,

                COL_FORMS_ODUE = 21,
                COL_FORMS_VSL_PENDING = 22,
                COL_FORMS_VSL_TO_FINALISE = 23,
                COL_FORMS_VSL_TO_APPR = 24,
                COL_FORMS_VSL_TO_AMEND = 25,
                COL_FORMS_HQ_PENDING = 26,
                COL_FORMS_HQ_TO_AMEND = 27,
                COL_FORMS_TO_APPR = 28,
                COL_FORMS_SUPT_TO_FINALISE = 29,
                COL_FORMS_MGR_TO_FINALISE = 30,
                COL_FORMS_GENMGR_TO_FINALISE = 31,
                COL_FORMS_DIR_TO_FINALISE = 32,
                COL_FORMS_TA_TO_APPR = 33,
                COL_FORMS_SUPT_TO_APPR = 34,
                COL_FORMS_MGR_TO_APPR = 35,
                COL_FORMS_SENMGR_TO_APPR = 36,
                COL_FORMS_GENMGR_TO_APPR = 37,
                COL_FORMS_DIR_TO_APPR = 38,
                COL_FORMS_RECENTLY_CLOSED = 39,
                COL_SEPARATOR_FORMS = 40,

                COL_ROUTINES_ROUTINES = 41,
                COL_ROUTINES_DRILLS = 42,
                COL_SEPARATOR_ROUTINES = 43,

                COL_RISKASSEMENTS_HQ_REVIEW = 44,
                COL_RISKASSEMENTS_VSLTASKTOMOVE = 45,
                COL_RISKASSEMENTS_TASK_ODUE = 46,
                COL_RISKASSEMENTS_REPORT_ODUE = 47,
                COL_RISKASSEMENTS_ACTIVEITEMS = 48,
                COL_RISKASSEMENTS_VSL_PENDING = 49,
                COL_RISKASSEMENTS_VSL_TO_AMEND = 50,
                COL_RISKASSEMENTS_VSL_TO_APPR = 51,
                COL_RISKASSEMENTS_HQ_PENDING = 52,
                COL_RISKASSEMENTS_HQ_TO_AMEND = 53,
                COL_RISKASSEMENTS_VSL_TO_ACK = 54,
                COL_RISKASSEMENTS_TO_APPR = 55,
                COL_RISKASSEMENTS_TA_TO_APPR = 56,
                COL_RISKASSEMENTS_SUPT_TO_APPR = 57,
                COL_RISKASSEMENTS_MGR_TO_APPR = 58,
                COL_RISKASSEMENTS_SENMGR_TO_APPR = 59,
                COL_RISKASSEMENTS_GENMGR_TO_APPR = 60,
                COL_RISKASSEMENTS_DIR_TO_APPR = 61,
                COL_RISKASSEMENTS_RECENTLY_CLOSED = 62,
                COL_SEPARATOR_RISKASSEMENTS = 63,

                COL_AUDITINSPECTION_RESCHEDULED_TOAPPR = 64,
                COL_AUDITINSPECTION_NOOFWINDOWPERIOD = 65,
                COL_AUDITINSPECTION_NOOFDUE = 66,
                COL_AUDITINSPECTION_NOOFOVERDUE = 67,
                COL_AUDITINSPECTION_DRAFTREPORT = 68,
                COL_AUDITINSPECTION_DRAFT_TOAMEND = 69,
                COL_AUDITINSPECTION_DPATOAPPRVOE = 70,
                COL_AUDITINSPECTION_DRAFTMGRTOAPROVE = 71,
                COL_AUDITINSPECTION_DRAFTSRMGRTOAPROVE = 72,
                COL_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE = 73,
                COL_AUDITINSPECTION_UNDERACTION = 74,
                COL_AUDITINSPECTION_CLOSEOUT_TO_REVIEW = 75,
                COL_AUDITINSPECTION_MGR_TO_APPROVE = 76,
                COL_AUDITINSPECTION_SENIORMGR_TO_APPROVE = 77,
                COL_AUDITINSPECTION_VSL_AMEND_ACK = 78,
                COL_AUDITINSPECTION_RECENTLY_CLOSED = 79,
                COL_SEPARATOR_AUDITINSPECTION = 80,

                COL_NCR_TOEXTEND_TOAPPROVE = 81,
                COL_NCR_EXTENDED = 82,
                COL_NCR_OVERDUE = 83,
                COL_NCR_HQUNDERPREP = 84,
                COL_NCR_HQ_TO_AMEND = 85,
                COL_NCR_DPA_TO_FINALISE = 86,
                COL_NCR_VSL_PENDING = 87,
                COL_NCR_VSL_TO_ACK = 88,
                COL_NCR_UNDERACTION = 89,
                COL_NCR_CLOSEOUT_TO_REVIEW_HQ = 90,
                COL_NCR_CLOSEOUT_TO_REVIEW_VSL = 91,
                COL_NCR_DPA_PENDING = 92,
                COL_NCR_MGR_TO_APPR = 93,
                COL_NCR_CREW_PENDING = 94,
                COL_NCR_TECH_PENDING = 95,
                COL_NCR_VSL_AMEND_ACK = 96,
                COL_NCR_RECENTLY_CLOSED = 97,
                COL_SEPARATOR_NCR = 98,

                COL_DF_ODUEITEMS = 99,
                COL_DF_VSLTOFINALISE = 100,
                COL_DF_DPA_TO_VERIFY = 101,
                COL_DF_ACTIVEITEMS = 102,
                COL_DF_TO_EXTENDED = 103,
                COL_DF_EXTENDED = 104,
                COL_SEPARATOR_DF = 105,

                COL_TASKLIST_OVERDUE = 106,
                COL_TASKLIST_HQUNDERPREP = 107,
                COL_TASKLIST_HQTOSUBMIT = 108,
                COL_TASKLIST_VSLUNDERPREP = 109,
                COL_TASKLIST_INPROGRESS = 110,
                COL_TASKLIST_VSL_TO_ACK = 111,
                COL_TASKLIST_DPA_PENDING = 112,
                COL_TASKLIST_CREW_PENDING = 113,
                COL_TASKLIST_TECH_PENDING = 114,
                COL_TASKLIST_VSL_AMEND_ACK = 115,
                COL_TASKLIST_RECENTLY_CLOSED = 116,
                COL_SEPARATOR_TASK = 117,

                COL_INCIDENT_REPORT_OVERDUE = 118,
                COL_INCIDENT_REPORT_HQUNDERPREP = 119,
                COL_INCIDENT_REPORT_HQ_TO_AMEND = 120,
                COL_INCIDENT_REPORT_VSL_AMEND = 121,
                COL_INCIDENT_REPORT_DPA_PENDING = 122,
                COL_INCIDENT_REPORT_TECH_PENDING = 123,
                COL_INCIDENT_REPORT_CREW_PENDING = 124,
                COL_INCIDENT_REPORT_MGR_TO_APPR = 125,
                COL_INCIDENT_REPORT_SR_MGR_TO_APPR = 126,
                COL_INCIDENT_REPORT_RECENTLY_FINALISED = 127,
                COL_SEPARATOR_INCIDENT_REPORT = 128,

                COL_INVESTIGATION_REPORT_OVERDUE = 129,
                COL_INVESTIGATION_REPORT_HQTOFILLUP_UNDERPREP = 130,
                COL_INVESTIGATION_REPORT_HQTOFILLUP = 131,
                COL_INVESTIGATION_REPORT_HQUNDERPREP = 132,
                COL_INVESTIGATION_REPORT_HQ_TO_AMEND = 133,
                COL_INVESTIGATION_REPORT_DPA_PENDING_DRAFT = 134,
                COL_INVESTIGATION_REPORT_MGR_TO_APPR_DRAFT = 135,
                COL_INVESTIGATION_REPORT_UNDERACTION = 136,
                COL_INVESTIGATION_REPORT_CLOSEOUT = 137,
                COL_INVESTIGATION_REPORT_MGR_TO_APPR = 138,
                COL_INVESTIGATION_REPORT_SR_MGR_TO_APPR = 139,
                COL_INVESTIGATION_REPORT_VSLTOFILLUP = 140,
                COL_INVESTIGATION_REPORT_VSL_AMEND_ACK = 141,
                COL_INVESTIGATION_REPORT_RECENTLY_CLOSED = 142,
                COL_SEPARATOR_INVESTIGATION_REPORT = 143,

                COL_MINUTES_OF_SAFETY_OVERDUE = 144,
                COL_MINUTES_OF_SAFETY_HQUNDERPREP = 145,
                COL_MINUTES_OF_SAFETY_HQ_TO_AMEND = 146,
                COL_MINUTES_OF_SAFETY_VSL_PENDING = 147,
                COL_MINUTES_OF_SAFETY_VSL_TO_ACK = 148,
                COL_MINUTES_OF_SAFETY_DPA_PENDING = 149,
                COL_MINUTES_OF_SAFETY_MGR_TO_APPR = 150,
                COL_MINUTES_OF_SAFETY_CREW_PENDING = 151,
                COL_MINUTES_OF_SAFETY_TECH_PENDING = 152,
                COL_MINUTES_OF_SAFETY_VSL_AMEND_ACK = 153,
                COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED = 154,
                COL_SEPARATOR_MINUTES_OF_SAFETY = 155,

                COL_AWARENESS_REPORT_OVERDUE = 156,
                COL_AWARENESS_REPORT_HQUNDERPREP = 157,
                COL_AWARENESS_REPORT_HQ_TO_AMEND = 158,
                COL_AWARENESS_REPORT_VSL_PENDING = 159,
                COL_AWARENESS_REPORT_VSL_TO_ACK = 160,
                COL_AWARENESS_REPORT_DPA_PENDING = 161,
                COL_AWARENESS_REPORT_MGR_TO_APPR = 162,
                COL_AWARENESS_REPORT_CREW_PENDING = 163,
                COL_AWARENESS_REPORT_TECH_PENDING = 164,
                COL_AWARENESS_REPORT_VSL_AMEND_ACK = 165,
                COL_AWARENESS_REPORT_RECENTLY_CLOSED = 166,
                COL_SEPARATOR_AWARENESS_REPORT = 167,

                COL_MASTERS_REVIEW_OVERDUE = 168,
                COL_MASTERS_REVIEW_HQUNDERPREP = 169,
                COL_MASTERS_REVIEW_HQ_TO_AMEND = 170,
                COL_MASTERS_REVIEW_VSL_PENDING = 171,
                COL_MASTERS_REVIEW_VSL_TO_ACK = 172,
                COL_MASTERS_REVIEW_DPA_PENDING = 173,
                COL_MASTERS_REVIEW_MGR_TO_APPR = 174,
                COL_MASTERS_REVIEW_CREW_PENDING = 175,
                COL_MASTERS_REVIEW_TECH_PENDING = 176,
                COL_MASTERS_REVIEW_VSL_AMEND_ACK = 177,
                COL_MASTERS_REVIEW_RECENTLY_CLOSED = 178,
                COL_SEPARATOR_MASTERS_REVIEW = 179,

                COL_MONTHENDDOC_OVERDUE = 180,
                COL_SEPARATOR_MONTHENDDOC = 181,

                COL_VESSELID = 182,
                COL_ISUSERVESSEL = 183,
                COL_ISOFFICEVSL = 184;

        int endCol = COL_MASTERS_REVIEW_RECENTLY_CLOSED;

        const int COL_DETAILS_COMPANYCODE = 0,
                  COL_DETAILS_VSLCODE = 1,
                  COL_DETAILS_VSLNAME = 2,
                  COL_DETAILS_IMONO = 3,
                  COL_DETAILS_OPERATEBY = 4,
                  COL_DETAILS_LAST_DATA_TO_VSL = 5,
                  COL_DETAILS_LAST_DATA_FROM_VSL = 6,
                  COL_DETAILS_MASTERNAME = 7,
                  COL_DETAILS_CENAME = 8,
                  COL_DETAILS_BUILDER = 9,
                  COL_DETAILS_HULLNO = 10,
                  COL_DETAILS_DELIVDATEDISPLAY = 11,
                  COL_DETAILS_DWT = 12,
                  COL_DETAILSL_GRT = 13,
                  COL_DETAILS_NRT = 14,
                  COL_DETAILS_CALLSIGN = 15,
                  COL_DETAILS_CLASSNO = 16,
                  COL_DETAILS_OFFICIALNO = 17,
                  COL_DETAILS_OWNER = 18,
                  COL_DETAILS_VSLTYPE = 19,
                  COL_DETAILS_FLEET_VESSELID = 20;
        #endregion

        public frmMainForm_Marine()
        {
            InitializeComponent();
        }

        private void frmMainForm_Marine_Load(object sender, EventArgs e)
        {
            this.Text = " SQE Dashboard ";

            common = new Common();
            mainObj = new MainFrm();

            DesignDashBoardGridDetails();
            DesignParticularsGridDetails();

            PG.BindCompany_FilterDropDown(ref cboCompany_Filter, false);

            FocusCompany();

            chkShowDashboard.Checked = true;
            chkShowOnlyActionColumns.Checked = true;

            AssignTopPanelGridGeneralProperties();

            btnTechDashboard.Visible = false;
            btnCrewDashboard.Visible = false;

            isFormInitialised = true;

            PG.SetFormWidthAndHeight(this, 10, 10, 900, 1410);

            if (PG.Gb.IsToConnecDirectDB)
                tsLblSvrName.Text = " Svr:" + PG.Gb.ServerName;
            else
                tsLblSvrName.Text = " Svr:" + PG.Gb.DBFn.GetServerName();

            tsLblUserId.Text = "User: " + PG.Gb.User.CurUserName;
            fpSpread1.Visible = false;

            timer1.Enabled = true;

            excludeColList = "" + COL_FORMS_ODUE + "," + COL_SEPARATOR_FORMS + "," + COL_CERTIFICATE_OVERDUE + "," + COL_SEPARATOR_CERTIFICATES +
                             "," + COL_DF_ODUEITEMS + "," + COL_SEPARATOR_DF + "," + COL_NCR_OVERDUE + "," + COL_SEPARATOR_NCR +
                             "," + COL_AUDITINSPECTION_NOOFWINDOWPERIOD + "," + COL_AUDITINSPECTION_NOOFOVERDUE + "," + COL_SEPARATOR_AUDITINSPECTION +
                             "," + COL_TASKLIST_OVERDUE + "," + COL_SEPARATOR_TASK +
                             "," + COL_INCIDENT_REPORT_OVERDUE + "," + COL_SEPARATOR_INCIDENT_REPORT +
                             "," + COL_INVESTIGATION_REPORT_OVERDUE + "," + COL_SEPARATOR_INVESTIGATION_REPORT +
                             "," + COL_AWARENESS_REPORT_OVERDUE + "," + COL_SEPARATOR_AWARENESS_REPORT +
                             "," + COL_MASTERS_REVIEW_OVERDUE + "," + COL_SEPARATOR_MASTERS_REVIEW +
                             "," + COL_MINUTES_OF_SAFETY_OVERDUE + "," + COL_SEPARATOR_MINUTES_OF_SAFETY +
                             "," + COL_RISKASSEMENTS_VSLTASKTOMOVE + "," + COL_SEPARATOR_RISKASSEMENTS;            
        }

        protected void DesignDashBoardGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();
            try
            {
                Color rowHeaderForeColor = Color.Blue;
                particularsColList.Add(new DgvInits("CompanyCode", "Company", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 35, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Indicator", "", 15, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 160, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OperateBy", "Ops By", 32, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Certificates_Due", "Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificates_ODue", "O'Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_Window", "Window", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_Pending", "Pending", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_HQToUpdate", "HQ To Update", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_VSLToUpdate", "VSL To Update", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_ToRenew", "To Renew", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Certificate_RenewalInProgress", "Renewal In Progress", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("PortServices_Port", "Port", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("PortServices_Date", "Date", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DocMgmt_Manuals_Unread", "Manuals Unread", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DocMgmt_Circulars_Unread", "Circulars Unread", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Forms_ODue", "ODue", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_Pending", "Vsl To Fill", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_To_Finalise", "Vsl To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_To_Appr", "Vsl To Approve", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Vsl_to_Amend", "Vsl To Amend", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Hq_Pending", "HQ Pending", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Hq_to_Amend", "HQ To Amend", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_To_Appr", "Forms\nTo Appr", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Supt_To_Finalise", "Supt To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Mgr_To_Finalise", "Mgr To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_GenMgr_To_Finalise", "GenMgr To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Dir_To_Finalise", "Dir To Finalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_TA_To_Appr", "TA To Appr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Supt_To_Appr", "Supt To Appr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Mgr_To_Appr", "Mgr To Appr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_SenMgr_To_Appr", "SenMgr To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_GenMgr_To_Appr", "GenMgr To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Dir_To_Appr", "Dir To Appr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Forms_Recently_Closed", "Recently Closed", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Routines_Routines", "Routines", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Routines_Drills", "Drills", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("RiskAssements_HQReview", "HQ Review", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_VslTaskToMove", "Recom. to move to all vsl", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Task_ODue", "Task O'Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Report_ODue", "Report O'Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_ActiveItems", "Active Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_VSL_Pending", "Vsl Pending", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_to_Amend", "Vsl To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_to_Appr", "Vsl To Appr", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Hq_Pending", "HQ Pending", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Hq_to_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Vsl_To_Ack", "Vsl To Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_To_Appr", "To Review", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_TA_To_Appr", "TA To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Supt_To_Appr", "Supt To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Mgr_To_Appr", "Mgr To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_SenMgr_To_Appr", "SenMgr To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_GenMgr_To_Appr", "GenMgr To Review", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Dir_To_Appr", "Dir Review Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("RiskAssements_Recently_Closed", "Recently Closed", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("AuditInspection_ReScheduled_ToAppr", "Re-Sched.\nTo Appr", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_NoofWindowPeriod", "Sched. Window \nPeriod", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_NoofDue", "Due", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_NoofOverDue", "Sched. O’Due", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_DraftReport", "Draft Report", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Draft_ToAmend", "Report To Amend", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_DPA_to_Approve", "DPA\nTo Appr Report", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Mgr_to_Approve_Draft", "Mgr To Appr Report", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_SeniorMgr_to_Approve_Draft", "Senior Mgr To Appr Report", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Director_to_Approve_Draft", "Director To Appr Report", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_UnderAction", "Under Action", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_CloseOut_to_Review", "Close Out To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Mgr_to_Approve", "Mgr\nTo Appr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_SeniorMgr_to_Approve", "Senior Mgr To Appr", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Vsl_Amend_Ack", "Vsl To Amend & Ack", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("AuditInspection_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                
                particularsColList.Add(new DgvInits("NCR_ToExtend_ToApprove", "To Extend NCR Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Extended", "Extended NCR Items", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_DPA_ToFinalise", "DPA \nTo \nFinalise", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Vsl_Pending", "Vsl To \nFinalise", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Vsl_to_ACk", "Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_UnderAction", "Under Action", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_CloseOut_to_Review", "Close Out To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_CloseOut_to_Review_VSL", "Close Out To Review Vsl", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_DPA_Pending", "DPA \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Mgr_To_Appr", "Mgr \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Crew_Pending", "Crew \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Tech_Pending", "Tech \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NCR_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("DF_ODueItems", "O’Due", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_VslToFinalise", "Vsl To Finalise", 47, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_DPA_To_Verify", "DPA To Verify", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_ActiveItems", "Active Items", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_TOHQApprove", "To Extend DF Items", 58, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DF_Extended", "Extended DF Items", 58, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("TaskList_OverDue", "O’Due", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_HQUnderPrep", "HQ Under Prep", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_HQToSubmit", "HQ To\nSubmit /\nReSubmit", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_VslUnderPrep", "Vsl Under Prep", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_InProgress", "Vsl To\nSubmit /\nReSubmit", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Vsl_to_Ack", "Vsl To Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_DPA_Pending", "DPA To \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Crew_Pending", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Tech_Pending", "Tech \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("TaskList_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("IncidentReport_OverDue", "O’Due", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_HQ_ToAmend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Vsl_ToAmend", "Vsl To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_DPA_to_Approve", "DPA \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Tech_to_Approve", "Tech \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Crew_to_Approve", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Mgr_to_Approve", "Mgr \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_SeniorMgr_to_Approve", "Senior Mgr \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("IncidentReport_Recently_Finalised", "Recently Finalised", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("InvestigationReport_OverDue", "O’Due", 54, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQFillup_UnderPrep", "HQ To Fillup  / Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQFillupReport", "HQ To Fillup Report", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_HQ_ToAmend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_DPA_to_Approve_Draft", "DPA\nTo Appr Report", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Mgr_to_Approve_Draft", "Mgr\nTo Appr Report", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_UnderAction", "Under Action", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_CloseOut_to_Review", "Close Out To Review", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Mgr_to_Approve", "Mgr \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_SeniorMgr_to_Approve", "Senior Mgr \nTo \nAppr", 42, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_VSlFillupReport", "Vsl To Fillup Report", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("InvestigationReport_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Minutes_of_Safety_OverDue", "O’Due", 54, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Vsl_Pending", "Vsl To \nFinalise", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Vsl_to_Ack", "Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_DPA_Pending", "DPA \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Mgr_To_Appr", "Mgr \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Crew_Pending", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Tech_Pending", "Tech \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Minutes_of_Safety_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Awareness_Report_OverDue", "O’Due", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Vsl_Pending", "Vsl To \nFinalise", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Vsl_to_Ack", "Ack", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_DPA_Pending", "DPA \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Mgr_To_Appr", "Mgr \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Crew_Pending", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Tech_Pending", "Tech \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Awareness_Report_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("Masters_Review_OverDue", "O’Due", 52, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_HQUnderPrep", "HQ Under Prep", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_HQ_To_Amend", "HQ To Amend", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Vsl_Pending", "Vsl To \nFinalise", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Vsl_to_Ack", "Ack", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_DPA_Pending", "DPA \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Mgr_To_Appr", "Mgr \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Crew_Pending", "Crew \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Tech_Pending", "Tech \nTo \nAppr", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Vsl_Amend_Ack", "Vsl To Amend & Ack", 43, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Masters_Review_Recently_Closed", "Recently Closed", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits(" ", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("MonthEndDoc_OverDue", "O'Due", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("", " ", 5, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("userVsl", "userVsl", 130, rowHeaderForeColor, SystemColors.ButtonFace, false, true));
                particularsColList.Add(new DgvInits("IsOffice", "IsOffice", 130, rowHeaderForeColor, SystemColors.ButtonFace, false, true));

                FarPtColCtrls.GenerateFarPointGridView(fpSpread1, particularsColList, null, false, false, false);

                fpSpread1.ActiveSheet.ColumnHeader.RowCount = 2;
                fpSpread1.Sheets[0].FrozenColumnCount = 4;

                for (int col = COL_COMPANYCODE; col <= COL_SEPARATOR_VESSELDETAILS; col++)
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].RowSpan = 2;
                }

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_CERTIFICATES].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_PORTSERVICES].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_DOCMGMT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_FORMS].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_ROUTINES].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_RISKASSEMENTS].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_AUDITINSPECTION].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_NCR].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_DF].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_TASK].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_INCIDENT_REPORT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_INVESTIGATION_REPORT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_AWARENESS_REPORT].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MASTERS_REVIEW].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_MINUTES_OF_SAFETY].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_VESSELID].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ISUSERVESSEL].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ISOFFICEVSL].RowSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_VESSELDETAILS].RowSpan = 2;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_VSLCODE].ColumnSpan = 2;

                for (int col = 0; col < fpSpread1.ActiveSheet.ColumnCount; col++)
                {
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Text = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].Text;
                }
                fpSpread1.ActiveSheet.Columns[COL_VSLNAME].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;

                fpSpread1.ActiveSheet.Columns[COL_INDICATOR].ForeColor = Color.Red;
                fpSpread1.ActiveSheet.Columns[COL_INDICATOR].Font = new Font("Verdana", 8, FontStyle.Regular);

                Font headerFont = new Font("Verdana", 8, FontStyle.Bold); Color headerForeColor = Color.Maroon;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_DUE].ColumnSpan = 8;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_DUE].Text = "Certificates";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_DUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_DUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_CERTIFICATE_DUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_PORTSERVICES_PORT].ColumnSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_PORTSERVICES_PORT].Text = "Port Services";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_PORTSERVICES_PORT].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_PORTSERVICES_PORT].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_PORTSERVICES_PORT].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].ColumnSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].Text = "Document  Management";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DOCMGMT_MANUALS_UNREAD].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].ColumnSpan = 19;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].Text = "Forms";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_FORMS_ODUE, 0, COL_FORMS_DIR_TO_APPR].Tag = "Forms";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ROUTINES_ROUTINES].ColumnSpan = 2;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ROUTINES_ROUTINES].Text = "Routines";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ROUTINES_ROUTINES].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ROUTINES_ROUTINES].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ROUTINES_ROUTINES].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_ROUTINES_ROUTINES, 0, COL_ROUTINES_DRILLS].Tag = "Routines";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_HQ_REVIEW].ColumnSpan = 19;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_HQ_REVIEW].Text = "Risk Assessments";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_HQ_REVIEW].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_HQ_REVIEW].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_HQ_REVIEW].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_RISKASSEMENTS_HQ_REVIEW, 0, COL_RISKASSEMENTS_DIR_TO_APPR].Tag = "Risk Assessments";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].ColumnSpan = 16;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].Text = "Audit / Inspection(AI)";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR, 0, COL_AUDITINSPECTION_RECENTLY_CLOSED].Tag = PG.GROUPNAME_AI_SCHED;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].ColumnSpan = 17;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].Text = "NCR";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_NCR_TOEXTEND_TOAPPROVE, 0, COL_NCR_RECENTLY_CLOSED].Tag = "NCR";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DF_ODUEITEMS].ColumnSpan = 6;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DF_ODUEITEMS].Text = "Defects";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DF_ODUEITEMS].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DF_ODUEITEMS].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DF_ODUEITEMS].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_DF_ODUEITEMS, 0, COL_DF_ACTIVEITEMS].Tag = "Defects";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].ColumnSpan = 11;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].Text = "Task";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_TASKLIST_OVERDUE, 0, COL_TASKLIST_RECENTLY_CLOSED].Tag = "Task";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].ColumnSpan = 10;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].Text = "Incidnt Report";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INCIDENT_REPORT_OVERDUE, 0, COL_INCIDENT_REPORT_RECENTLY_FINALISED].Tag = "Incident Report";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].ColumnSpan = 14;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].Text = "Invest Report";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_INVESTIGATION_REPORT_OVERDUE, 0, COL_INVESTIGATION_REPORT_RECENTLY_CLOSED].Tag = "Investigation Report";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].ColumnSpan = 11;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].Text = "Safety Meetng";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MINUTES_OF_SAFETY_OVERDUE, 0, COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED].Tag = "Safety Meeting";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].ColumnSpan = 11;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].Text = "Aware. Report";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AWARENESS_REPORT_OVERDUE, 0, COL_AWARENESS_REPORT_RECENTLY_CLOSED].Tag = "Aware. Report";

                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].ColumnSpan = 11;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].Text = "Master Review";
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].ForeColor = headerForeColor;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].Font = headerFont;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_MASTERS_REVIEW_OVERDUE, 0, COL_MASTERS_REVIEW_RECENTLY_CLOSED].Tag = "Master Review";

                if (fpSpread1.ActiveSheet.ColumnCount > 0)
                {
                    fpSpread1.ActiveSheet.Columns[COL_CERTIFICATE_DUE, endCol].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                    fpSpread1.ActiveSheet.ColumnHeader.Columns[COL_CERTIFICATE_DUE, endCol].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;

                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, COL_CERTIFICATE_DUE, 1, endCol].Font = new Font("Microsoft sans serif", 7.5f, FontStyle.Regular);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, COL_CERTIFICATE_DUE, 1, endCol].CellPadding = new FarPoint.Win.Spread.CellPadding(0, 0, 0, 0);

                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].ForeColor = Color.Blue;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_SEPARATOR_VESSELDETAILS].ForeColor = Color.Blue;
                    fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].Resizable = false;
                }


                Color fixedColBKColor = Color.FromArgb(196, 223, 230), otherColBKColor = Color.White, sepColBKColor = Color.FromArgb(217, 255, 228),
                      fixedColForeColor = Color.FromArgb(0, 64, 0), otherColForeColor = Color.Black;

                fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].BackColor = otherColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_VSLCODE, COL_OPERATEBY].BackColor = fixedColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_VESSELDETAILS].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_CERTIFICATES].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_PORTSERVICES].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_DOCMGMT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_FORMS].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_ROUTINES].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_RISKASSEMENTS].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_AUDITINSPECTION].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_NCR].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_DF].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_TASK].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_INCIDENT_REPORT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_INVESTIGATION_REPORT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_AWARENESS_REPORT].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_MASTERS_REVIEW].BackColor = sepColBKColor;
                fpSpread1.ActiveSheet.Columns[COL_SEPARATOR_MINUTES_OF_SAFETY].BackColor = sepColBKColor;

                fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].Font = new Font("Calibri", 9, FontStyle.Regular);
                fpSpread1.ActiveSheet.Columns[0, fpSpread1.ActiveSheet.ColumnCount - 1].ForeColor = otherColForeColor;
                fpSpread1.ActiveSheet.Columns[COL_VSLCODE, COL_VSLNAME].ForeColor = fixedColForeColor;
                fpSpread1.ActiveSheet.Columns[COL_INDICATOR].ForeColor = Color.Red;

                fpSpread1.ActiveSheet.ColumnHeader.Rows[0].Height = 40;
                fpSpread1.ActiveSheet.ColumnHeader.Rows[1].Height = 50;

                fpSpread1.ActiveSheet.GrayAreaBackColor = SystemColors.Control;
                fpSpread1.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;

                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread1.ActiveSheet.VerticalGridLine = gdln;
                fpSpread1.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                fpSpread1.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread1.ActiveSheet.DisplayZero = true;

                fpSpread1.ActiveSheet.Columns[COL_VESSELID, COL_ISOFFICEVSL].Visible = false;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "DesignGridDetails", er.Message);
                Gfn.Mb("Failed to design dashboard Grid");
            }
            finally
            {
                particularsColList = null;
            }
        }

        protected void DesignParticularsGridDetails()
        {
            List<DgvInits> particularsColList = new List<DgvInits>();

            try
            {
                Color rowHeaderForeColor = Color.Black;
                particularsColList.Add(new DgvInits("CompanyCode", "Company", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslCode", "Sds Vsl Code", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslName", "Vessel Name", 160, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("ImoNo", "IMO Number", 80, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OperateBy", "Operate By", 50, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("HQtoVsl", "HQ to Vsl Data Transfer", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VsltoHQ", "Vsl to HQ Data Transfer", 65, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("MASTERNAME", "Master Name", 110, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CENAME", "CE Name", 110, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                particularsColList.Add(new DgvInits("BUILDER", "Builder", 150, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("HullNo", "Hull No", 40, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DelivDateDisplay", "Deliv Date", 70, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("DWT", "DWT", 60, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("GRT", "GRT", 48, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("NRT", "NRT", 45, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("CallSign", "Call Sign", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("ClassNo", "Class No", 85, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("OfficialNo", "Official No", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("Owner", "Owner", 200, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VslType", "Vessel Type", 130, rowHeaderForeColor, SystemColors.ButtonFace, true, true));
                particularsColList.Add(new DgvInits("VesselID", "VesselID", 55, rowHeaderForeColor, SystemColors.ButtonFace, true, true));

                fpSpread_Particulars.SuspendLayout();

                FarPtColCtrls.GenerateFarPointGridView(fpSpread_Particulars, particularsColList, null, false, false, false);

                fpSpread_Particulars.ActiveSheet.FrozenColumnCount = 3;

                fpSpread_Particulars.ActiveSheet.Columns[COL_DETAILS_LAST_DATA_FROM_VSL].ForeColor = Color.Fuchsia;
                fpSpread_Particulars.ActiveSheet.Columns[COL_DETAILS_LAST_DATA_TO_VSL].ForeColor = Color.Blue;

                if (fpSpread_Particulars.ActiveSheet.ColumnCount > 0)
                {
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].BackColor = SystemColors.ButtonFace;
                    fpSpread_Particulars.ActiveSheet.ColumnHeader.Cells[0, 0, 0, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].ForeColor = Color.Black;
                }

                fpSpread_Particulars.ActiveSheet.ColumnHeader.Rows[0].Height = 50;

                fpSpread_Particulars.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode;

                FarPoint.Win.Spread.GridLine gdln = new FarPoint.Win.Spread.GridLine(FarPoint.Win.Spread.GridLineType.None);
                fpSpread_Particulars.ActiveSheet.VerticalGridLine = gdln;
                fpSpread_Particulars.ActiveSheet.HorizontalGridLine = gdln;
                gdln = null;

                fpSpread_Particulars.BorderCollapse = FarPoint.Win.Spread.BorderCollapse.Collapse;
                fpSpread_Particulars.ActiveSheet.DisplayZero = true;
            }
            catch (Exception er)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "DesignParticularsGridDetails", er.Message);
                Gfn.Mb("Failed to initilize Particulars Tab");
            }
            finally
            {
                fpSpread_Particulars.ResumeLayout();
                particularsColList = null;
            }
        }

        protected void FocusCompany()
        {
            try
            {
                if (companyID.Trim().Length > 0 && companyID != "-1" && companyID != "-99")
                {
                    cboCompany_Filter.SelectedValue = companyID;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "FocusCompany", err.Message);
            }
        }

        private void InitialiseHQDashboardFieldSetup(DataTable dt)
        {
            try
            {
                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                    if (columnNo >= fpSpread1.ActiveSheet.ColumnCount) break;

                    int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                    int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());

                    fpSpread1.ActiveSheet.Columns[columnNo].Visible = (isToHide == 0 && isToShowAlways == 1);
                }


            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "InitialiseHQDashboardFieldSetup", err.Message);
                Gfn.Mb("Failed to initilize Dashboard grid ");
            }
        }

        private DataTable GetMarineDashboardDataTable()
        {
            string companyID = "-99";
            if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

            string addlCond = "  ";
            if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";
            string script = " select Distinct ColumnNo, ColumnName, IsToHide, isToShowAlways, GroupName " +
                            " from Dashboard_HQ_Main_Marine_Setup " + Environment.NewLine +
                            " where ColumnNo>=0 " +
                             addlCond + 
                            " order by ColumnNo";
            DataTable dt = PG.Gb.DBFn.DbRecords(script);

            return (dt);
        }

        private void EnableDisableControls(DataTable dt)
        {
            DataRow[] dr; DataTable dtGrouItems;
            try
            {
                int formsCnt = 0;

                #region Visible Controls
                bool isToVisibleForms = false, isToVisibleNCR = false, isToVisibleDefects = false, isToVisibleTasks = false, isToVisibleIncidentReport = false, isToVisibleCertificates = false, isToVisibleDocMgmt = false,
                     isToVisiblePortServices = false, isToVisibleRiskAssements = false, isToVisibleRoutines = false, isToVisibleVesselAudits = false,
                     isToVisibleAwarenessReport = false, isToVisibleMastersReview = false, isToVisibleMinutesofSafety = false;
                if (dt != null)
                {
                    dr = dt.Select("IsToHide = 0 and GroupName='Forms'");
                    if (dr != null) formsCnt = dr.Length;
                    isToVisibleForms = (formsCnt > 0);

                    dr = dt.Select("IsToHide = 0 and GroupName='NCR'");
                    isToVisibleNCR = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Defects'");
                    isToVisibleDefects = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Task'");
                    isToVisibleTasks = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName in ('Incident Report','Investigation Report','Incidnt Report','Invest Report')");
                    isToVisibleIncidentReport = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Aware. Report'");
                    isToVisibleAwarenessReport = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Master Review'");
                    isToVisibleMastersReview = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName in ('Safety Meeting','Safety Meetng')");
                    isToVisibleMinutesofSafety = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Certificates'");
                    isToVisibleCertificates = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Document'");
                    isToVisibleDocMgmt = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Port Services'");
                    isToVisiblePortServices = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Risk Assessments'");
                    isToVisibleRiskAssements = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Routines'");
                    isToVisibleRoutines = (dr != null && dr.Length > 0);
                    dr = dt.Select("IsToHide = 0 and GroupName='Vessel Audits'");
                    isToVisibleVesselAudits = (dr != null && dr.Length > 0);
                }

                PG.isToEnableForms = isToVisibleForms;
                tsMnuForms.Visible = isToVisibleForms;
                tsMnuVslForms.Visible = isToVisibleForms;

                tsMnuNCR.Visible = isToVisibleNCR;
                tsMnuVslNCR.Visible = isToVisibleNCR;

                tsMnuDefects.Visible = isToVisibleDefects;

                tsMnuTaskList.Visible = isToVisibleTasks;
                tsMnuVslTaskList.Visible = isToVisibleTasks;

                tsMnuIncidentReport.Visible = isToVisibleIncidentReport;
                tsMnuVslIncidentReport.Visible = isToVisibleIncidentReport;

                tsMnuAwarenessReport.Visible = isToVisibleAwarenessReport;
                tsMnuVslAwarenessReport.Visible = isToVisibleAwarenessReport;

                tsMnuMastersReview.Visible = isToVisibleMastersReview;
                tsMnuVslMastersReview.Visible = isToVisibleMastersReview;

                tsMnuMinutesOfSafety.Visible = isToVisibleMinutesofSafety;
                tsMnuVslMinutesOfSafety.Visible = isToVisibleMinutesofSafety;

                tsMnuRiskAssements.Visible = (isToVisibleRiskAssements);
                tsMnuVslRiskAssements.Visible = (isToVisibleRiskAssements);
                #endregion


                bool isToEnableForms = false, isToEnableNCR = false, isToEnableDefects = false, isToEnableTasks = false, isToEnableIncidentReport = false,
                     isToEnableAwarenessReport = false, isToEnableMastersReview = false, isToEnableMinutesofSafety = false, isToEnableVslCertificate = false;

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                dtGrouItems = mainObj.GetGroupItemWiseDataTable(PG.DASHBOARDTYPE_MARINE, companyID);
                if (dtGrouItems != null)
                {
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Forms'");
                    isToEnableForms = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='NCR'");
                    isToEnableNCR = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Defects'");
                    isToEnableDefects = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Task'");
                    isToEnableTasks = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg in ('Incident Report','Investigation Report')");
                    isToEnableIncidentReport = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Aware. Report'");
                    isToEnableAwarenessReport = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Master Review'");
                    isToEnableMastersReview = (dr != null && dr.Length > 0);
                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Safety Meeting'");
                    isToEnableMinutesofSafety = (dr != null && dr.Length > 0);

                    dr = dtGrouItems.Select("IsPrgDisabled = 0 and Prg='Certificates'");
                    isToEnableVslCertificate = (dr != null && dr.Length > 0);

                }

                tsMnuForms.Enabled = isToEnableForms;
                tsMnuVslForms.Enabled = isToEnableForms;

                tsMnuNCR.Enabled = isToEnableNCR;
                tsMnuVslNCR.Enabled = isToEnableNCR;

                tsMnuDefects.Enabled = isToEnableDefects;

                tsMnuTaskList.Enabled = isToEnableTasks;
                tsMnuVslTaskList.Enabled = isToEnableTasks;

                tsMnuIncidentReport.Enabled = isToEnableIncidentReport;
                tsMnuVslIncidentReport.Enabled = isToEnableIncidentReport;

                tsMnuAwarenessReport.Enabled = isToEnableAwarenessReport;
                tsMnuVslAwarenessReport.Enabled = isToEnableAwarenessReport;

                tsMnuMastersReview.Enabled = isToEnableMastersReview;
                tsMnuVslMastersReview.Enabled = isToEnableMastersReview;

                tsMnuMinutesOfSafety.Enabled = isToEnableMinutesofSafety;
                tsMnuVslMinutesOfSafety.Enabled = isToEnableMinutesofSafety;

                tsMnuVslCertificate.Enabled = isToEnableVslCertificate;

                // ---- TOP Controls------------------------------------------------------------------------------------------------------------
                btnProcurement.Visible = PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_ProcurementWeb);
                btnDMS.Visible = (PG.isToEnableDocMgmt && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DocMgmt_Cef));

                btnTechDashboard.Visible = true;
                btnTechDashboard.Enabled = (isToShowTECHDashboard);
                btnCrewDashboard.Enabled = (isToShowCREWDashboard);
                btnCrewDashboard.Visible = (PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_CREWDASHBOARD));

                tsMnuNCRTrending.Visible = (PG.isToShowNCRTrending);
                tsMnuAwarenessReportTrending.Visible = (PG.isToShowAWRTrending);

                tlsMnuRootCauseAnalysisChartSetup.Visible = (PG.isAllowedUserIDToSetupMSCAT);
                tlsMnuAuditInspectionSetup.Visible = (PG.isAllowedUserIDToSetupAI);

                if (formsCnt == 1 || formsCnt == 2)
                {
                    fpSpread1.ActiveSheet.Columns[COL_FORMS_TO_APPR].Width = 65;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "EnableDisableControls", err.Message);
                Gfn.Mb("Failed to initilize Dashboard grid ");
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            pictureBox1.BringToFront();
            Application.DoEvents();
            try
            {
                fpSpread1.Visible = true;
                cboCompany_Filter_SelectedIndexChanged(null, null);
                chkShowDashboard_CheckedChanged(null, null);
                chkShowOnlyActionColumns.Checked = true;

                if (PG.CheckAppUnderMaintenance(this.Text))
                {
                    DialogResult = DialogResult.OK;
                    this.Close();
                }

                string fileName = PG.Gb.WinSDSrootDir + "\\Images\\" + PG.hqAppFolder + "HQ_SDS.ico";
                if (File.Exists(fileName))
                {
                    Icon ic = new Icon(fileName);
                    this.Icon = ic;
                }

                PG.DownloadStarter();
            }
            finally
            {
                pictureBox1.Visible = false;
            }
        }


        private void cboCompany_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (!PG.InitialiseCommonSettings(companyID)) return;

                PG.Initialise_AllowedUserForAccessRights(companyID);
                DataTable dt = GetMarineDashboardDataTable();

                isFormInitialised = false;
                chkShowOnlyActionColumns.Checked = true;

                InitialiseHQDashboardFieldSetup(dt);
                EnableDisableControls(dt);

                if (common != null) common.BindVslDropDownList_MarineDept(cboVslFilter, true, companyID);

                if (vslFilter.Trim().Length > 0 && cboVslFilter.FindString(vslFilter) >= 0) cboVslFilter.SelectedIndex = cboVslFilter.FindString(vslFilter);
                isFormInitialised = true;

                cboVslFilter_SelectedIndexChanged(null, null);
                this.Text = cboCompany_Filter.Text.ToUpper() + " SQE Dashboard ";
                chkShowOnlyActionColumns_CheckedChanged(null, null);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "cboCompany_Filter_SelectedIndexChanged", err.Message);
            }
            finally
            {
                isFormInitialised = true;
            }
        }

        private void cboVslFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!isFormInitialised) return;

            fieldName = "";
            LoadData();
        }

        private void LoadData()
        {
            if (cboVslFilter.SelectedValue == null || common == null) return;

            BindTopPanelDashboardData();
            BindDashBoardGrid();
            BindVslDetailsGrid();

            fpSpread1.ActiveSheet.Columns[COL_VESSELID, COL_ISOFFICEVSL].Visible = false;
        }

        private void BindDashBoardGrid()
        {
            fpSpread1.SuspendLayout();

            try
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
                Application.DoEvents();

                tlsStatuslblTotalVessels.Text = "Total Vessel(s): 0";
                fpSpread1.ActiveSheet.RowCount = 0;

                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (common != null) fpSpread1.ActiveSheet.DataSource = common.GetDashBoardDataTable_Marine(vslFilter, fieldName, companyID);

                if (fpSpread1.ActiveSheet.RowCount <= 0 || fpSpread1.ActiveSheet.ColumnCount <= 0) return;

                int lastRow = fpSpread1.ActiveSheet.RowCount - 1;

                #region Border
                Color borderColor = Color.FromArgb(81, 160, 181);
                fpSpread1.ActiveSheet.Cells[0, 0, lastRow, fpSpread1.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(borderColor, 1, false, false, true, true);
                fpSpread1.ActiveSheet.Cells[0, COL_VSLCODE, lastRow, COL_VSLCODE].Border = new FarPoint.Win.LineBorder(borderColor, 1, false, false, false, true);

                #endregion

                tlsStatuslblTotalVessels.Text = "Total Vessel(s):" + fpSpread1.ActiveSheet.RowCount;

                fpSpread1.ActiveSheet.ColumnHeader.Cells[1, 0, 1, fpSpread1.ActiveSheet.ColumnCount - 1].Tag = null;

                DataTable dt = GetMarineDashboardDataTable();

                for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
                {
                    string isUserVsl = fpSpread1.ActiveSheet.Cells[row, COL_ISUSERVESSEL].Text.Trim();
                    fpSpread1.ActiveSheet.Cells[row, COL_INDICATOR].Text = "";
                    if (isUserVsl == "1") fpSpread1.ActiveSheet.Cells[row, COL_INDICATOR].Text = "*";

                    for (int col = COL_SEPARATOR_VESSELDETAILS; col < COL_VESSELID; col++)
                    {
                        #region cell style
                        if (col == COL_SEPARATOR_VESSELDETAILS || col == COL_SEPARATOR_CERTIFICATES || col == COL_PORTSERVICES_PORT || col == COL_PORTSERVICES_DATE || col == COL_SEPARATOR_PORTSERVICES || col == COL_SEPARATOR_DOCMGMT ||
                            col == COL_SEPARATOR_FORMS || col == COL_SEPARATOR_ROUTINES || col == COL_SEPARATOR_RISKASSEMENTS || col == COL_SEPARATOR_NCR ||
                            col == COL_SEPARATOR_INCIDENT_REPORT || col == COL_SEPARATOR_INVESTIGATION_REPORT || col == COL_SEPARATOR_AWARENESS_REPORT || col == COL_SEPARATOR_MASTERS_REVIEW || col == COL_SEPARATOR_MINUTES_OF_SAFETY ||
                            col == COL_SEPARATOR_AUDITINSPECTION || col == COL_SEPARATOR_TASK || col == COL_SEPARATOR_DF)
                        {
                            fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag = "-1";
                            continue;
                        }

                        string cellValue = "";
                        if (fpSpread1.ActiveSheet.Cells[row, col].Value != null) cellValue = fpSpread1.ActiveSheet.Cells[row, col].Text.ToString().Trim();

                        if (cellValue == "0" || cellValue == "")
                        {
                            fpSpread1.ActiveSheet.Cells[row, col].ForeColor = Color.FromArgb(224, 224, 224);
                            fpSpread1.ActiveSheet.Cells[row, col].Text = "0";
                        }
                        else if (col >= COL_CERTIFICATE_DUE && col <= COL_SEPARATOR_MONTHENDDOC && cellValue.Length > 0
                                && fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag == null)
                        {
                            if (col != COL_AUDITINSPECTION_VSL_AMEND_ACK && col != COL_AUDITINSPECTION_NOOFWINDOWPERIOD && col != COL_AUDITINSPECTION_NOOFOVERDUE &&
                                col != COL_NCR_VSL_AMEND_ACK && col != COL_NCR_VSL_PENDING && col != COL_NCR_VSL_TO_ACK && col != COL_NCR_RECENTLY_CLOSED &&
                                col != COL_TASKLIST_VSLUNDERPREP && col != COL_TASKLIST_VSL_AMEND_ACK && col != COL_TASKLIST_VSL_TO_ACK && col != COL_TASKLIST_RECENTLY_CLOSED &&
                                col != COL_DF_VSLTOFINALISE && col != COL_FORMS_VSL_PENDING && col != COL_FORMS_VSL_TO_AMEND &&
                                col != COL_INCIDENT_REPORT_VSL_AMEND && col != COL_INCIDENT_REPORT_RECENTLY_FINALISED &&
                                col != COL_INVESTIGATION_REPORT_VSL_AMEND_ACK && col != COL_INVESTIGATION_REPORT_RECENTLY_CLOSED &&
                                col != COL_RISKASSEMENTS_VSL_PENDING && col != COL_RISKASSEMENTS_VSL_TO_ACK && col != COL_RISKASSEMENTS_VSL_TO_AMEND && col != COL_RISKASSEMENTS_VSL_TO_APPR && col != COL_RISKASSEMENTS_RECENTLY_CLOSED &&
                                col != COL_AWARENESS_REPORT_VSL_PENDING && col != COL_AWARENESS_REPORT_VSL_AMEND_ACK && col != COL_AWARENESS_REPORT_VSL_TO_ACK && col != COL_AWARENESS_REPORT_RECENTLY_CLOSED &&
                                col != COL_MASTERS_REVIEW_VSL_AMEND_ACK && col != COL_MASTERS_REVIEW_VSL_PENDING && col != COL_MASTERS_REVIEW_VSL_TO_ACK && col != COL_MASTERS_REVIEW_RECENTLY_CLOSED &&
                                col != COL_MINUTES_OF_SAFETY_VSL_AMEND_ACK && col != COL_MINUTES_OF_SAFETY_VSL_PENDING && col != COL_MINUTES_OF_SAFETY_VSL_TO_ACK && col != COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED)
                            {
                                DataRow[] dr = dt.Select("ColumnNo=" + col);
                                if (dr != null && dr.Length > 0)
                                {
                                    if (dr[0]["IsToHide"].ToString() == "0")
                                    {
                                        fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag = fpSpread1.ActiveSheet.Cells[row, col].Text;
                                    }
                                }
                            }
                        }
                        #endregion
                    }

                    if (fpSpread1.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value != null && fpSpread1.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value.ToString() == "1")
                    {
                        fpSpread1.ActiveSheet.Cells[row, COL_VSLCODE, row, COL_VSLNAME].BackColor = Color.FromArgb(143, 194, 207);
                    }
                }

                if (chkShowOnlyActionColumns.Checked) ShowOnlyActionColumns(false, dt);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "BindDashBoardGrid", err.Message);
                Gfn.Eb("Failed to refresh dashboard grid");
            }
            finally
            {
                fpSpread1.ResumeLayout();
                pictureBox1.Visible = false;
            }
        }

        private void BindVslDetailsGrid()
        {
            try
            {
                fpSpread_Particulars.SuspendLayout();
                fpSpread_Particulars.ActiveSheet.RowCount = 0;

                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (common != null) fpSpread_Particulars.ActiveSheet.DataSource = common.GetVslDetailsDataTable_Marine(vslFilter, companyID);

                if (fpSpread_Particulars.ActiveSheet.RowCount > 0 && fpSpread_Particulars.ActiveSheet.ColumnCount > 0)
                {
                    int rowCount = fpSpread_Particulars.ActiveSheet.RowCount - 1;
                    fpSpread_Particulars.ActiveSheet.Cells[0, 0, rowCount, fpSpread_Particulars.ActiveSheet.ColumnCount - 1].Border = new FarPoint.Win.LineBorder(Color.FromArgb(244, 164, 96), 1, false, false, true, true);
                    fpSpread_Particulars.ActiveSheet.Cells[0, COL_DETAILS_VSLCODE, rowCount, COL_DETAILS_VSLNAME].BackColor = Color.FromArgb(245, 222, 179);
                    fpSpread_Particulars.ActiveSheet.Cells[0, COL_DETAILS_VSLCODE, rowCount, COL_DETAILS_VSLNAME].ForeColor = Color.Black;
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "BindVslDetailsGrid", err.Message);
                Gfn.Eb("Failed to refresh vsl details grid");
            }
            finally
            {
                fpSpread_Particulars.ResumeLayout();
            }
        }

        private void BindTopPanelDashboardData()
        {
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString().Trim();
                string companyID = "-1";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                if (common == null) return;

                string addlCondition = common.GetVslFilterAddlCondition(vslFilter, companyID);

                string spName = "RefreshDashBoardValues_HQ_Marine";
                string[] paramField = new string[] { "@addlCond", "@C_CompanyID" };
                object[] paramValue = new object[] { addlCondition, companyID };
                PG.Gb.DBFn.SpXqry(spName, paramField, paramValue);

                DesignAndBindDashBoard();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "BindTopPanelDashboardData", err.Message);
                Gfn.Eb("Failed to bind top dashboard values");
            }
        }

        #region Top Dashboard Panel
        private void AssignTopPanelGridGeneralProperties()
        {
            fpSpread_TopPanel.ActiveSheet.RowCount = 0;
            fpSpread_TopPanel.ActiveSheet.ColumnCount = 0;
            FarPtColCtrls.SetFarPointGridGeneralProperties(fpSpread_TopPanel);
            fpSpread_TopPanel.ActiveSheet.OperationMode = FarPoint.Win.Spread.OperationMode.Normal;
            fpSpread_TopPanel.FocusRenderer = null;
            fpSpread_TopPanel.ActiveSheet.GrayAreaBackColor = Color.MediumTurquoise;
        }

        private void DesignAndBindDashBoard()
        {
            fpSpread_TopPanel.SuspendLayout();
            try
            {
                fpSpread_TopPanel.ActiveSheet.RowCount = 0;
                fpSpread_TopPanel.ActiveSheet.ColumnCount = 0;

                if (!AssignRowCountAndColCountToTopPanelGrid()) return;

                FillupDashBoardGrid();
            }
            finally
            {
                fpSpread_TopPanel.ResumeLayout();
            }
        }

        protected bool AssignRowCountAndColCountToTopPanelGrid()
        {
            int maxRow = 0, maxCol = 0, maxGrpCol = 0;
            bool result = false;
            try
            {
                if (mainObj == null) return (result);

                maxGrpCol = 2;
                maxCol = (maxGrpCol * constcol) + maxGrpCol;

                fpSpread_TopPanel.ActiveSheet.RowCount = maxRow;
                fpSpread_TopPanel.ActiveSheet.ColumnCount = maxCol;

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "AssignRowCountAndColCountToTopPanelGrid", err.Message);
            }

            return (result);
        }

        private void FillupDashBoardGrid()
        {
            DataTable dtGroup = null, dtGroupItem = null;
            DataRow[] drGrpItem = null;
            int xRowNo = -1, colNo = 0, rowNo = 0, currentRow = 0, mergeItemDescAndStatusValue = 0, maxGrpItemRowCount = 0;
            long vUI_Groups_HQID, refNo; int totalHeight = 0;
            string groupName, itemDesc, statusValue, actionBtnColor;
            bool isprgDisabled = false;
            Color grpItemBkColor, grpHeadingBkColor, backColor;
            try
            {
                backColor = Color.MediumTurquoise;
                grpHeadingBkColor = Color.FromArgb(227, 238, 255);
                grpItemBkColor = Color.FromArgb(247, 247, 247);

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                dtGroup = mainObj.GetGroupDataTable(PG.DASHBOARDTYPE_MARINE, companyID);
                if (dtGroup == null) return;

                dtGroupItem = mainObj.GetGroupItemWiseDataTable(PG.DASHBOARDTYPE_MARINE, companyID);
                mainObj.InitialiseGrpItem_RowAndGroupWiseCnt(PG.DASHBOARDTYPE_MARINE,companyID);

                fpSpread_TopPanel.ActiveSheet.Columns[0, fpSpread_TopPanel.ActiveSheet.ColumnCount - 1].Width = 0;
                fpSpread_TopPanel.ActiveSheet.Columns[0, fpSpread_TopPanel.ActiveSheet.ColumnCount - 1].BackColor = backColor;

                colNo = 0;
                fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH;     // Grp Item Name 
                fpSpread_TopPanel.ActiveSheet.Columns[colNo + 1].Width = GROUP_ITEM_VALUE_WIDTH;   // Value
                fpSpread_TopPanel.ActiveSheet.Columns[colNo + 2].Width = GROUP_ITEM_BUTTON_WIDTH;  //Button
                fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].Width = GROUP_COLUMN_SEPARATOR_WIDTH;

                colNo = colNo + 4;
                fpSpread_TopPanel.ActiveSheet.Columns[colNo].Width = GROUP_ITEM_DISPLAY_WIDTH + 5;     // Grp Item Name 
                fpSpread_TopPanel.ActiveSheet.Columns[colNo + 1].Width = GROUP_ITEM_VALUE_WIDTH;   // Value
                fpSpread_TopPanel.ActiveSheet.Columns[colNo + 2].Width = GROUP_ITEM_BUTTON_WIDTH;  //Button
                fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].Width = GROUP_COLUMN_SEPARATOR_WIDTH;

                foreach (DataRow dr in dtGroup.Rows) // Group Level
                {
                    vUI_Groups_HQID = Convert.ToInt64(dr["VUI_Groups_HQID"]);
                    groupName = dr["GroupName"].ToString();
                    rowNo = Convert.ToInt32(dr["rowNo"]);
                    colNo = Convert.ToInt32(dr["ColNo"]) - 1;

                    if (rowNo != xRowNo)
                    {
                        currentRow = fpSpread_TopPanel.ActiveSheet.RowCount;
                        xRowNo = rowNo;

                        maxGrpItemRowCount = mainObj.GetMaxItem_ForThisRow(rowNo);  // Max Group Items in that row
                        fpSpread_TopPanel.ActiveSheet.RowCount = currentRow + GROUP_HEADER_ROWCOUNT + maxGrpItemRowCount + GROUP_SEPARATOR_ROWCOUNT;

                        totalHeight = totalHeight + ((maxGrpItemRowCount * GROUP_ITEM_HEIGHT) + GROUP_NAME_HEIGHT + SEPARATOR_HEIGHT);
                    }

                    rowNo = currentRow;  // Next Group Starts then assign the start rowindex
                    if (colNo > 0)
                    {
                        colNo = (colNo * constcol) + colNo; // ColNo + constant row + separator
                    }

                    if ((colNo + 2) >= fpSpread_TopPanel.ActiveSheet.ColumnCount) continue;
                    if (rowNo >= fpSpread_TopPanel.ActiveSheet.RowCount) continue;

                    #region Column Width
                    // Separator Column
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].Locked = true;
                    fpSpread_TopPanel.ActiveSheet.Columns[colNo - 1].BackColor = backColor;
                    #endregion

                    #region Group Name Row
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Value = groupName;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Font = new Font("Verdana", 8, FontStyle.Bold);
                    fpSpread_TopPanel.ActiveSheet.Rows[rowNo].Height = GROUP_NAME_HEIGHT;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ColumnSpan = constcol - 1;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].BackColor = grpHeadingBkColor;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].Locked = true;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].Border = new FarPoint.Win.LineBorder(Color.LightSteelBlue, 1, true, true, true, false);

                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].CellType = FarPtColCtrls.GetButtonCellType(Color.YellowGreen);
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].CellPadding = new FarPoint.Win.Spread.CellPadding(0, 0, 0, 0);
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Tag = groupName;
                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Locked = false;

                    #endregion

                    #region Group Items
                    if (dtGroupItem != null && dtGroupItem.Rows.Count > 0)
                    {
                        drGrpItem = dtGroupItem.Select(" VUI_Groups_HQID=" + vUI_Groups_HQID);
                        if (drGrpItem != null)
                        {
                            #region isItemexists
                            rowNo = rowNo + 1;
                            for (int r = 0; r < drGrpItem.Length; r++)
                            {
                                refNo = Convert.ToInt64(drGrpItem[r]["RefNo"].ToString());
                                itemDesc = drGrpItem[r]["ItemDesc"].ToString();
                                statusValue = drGrpItem[r]["StatusValue"].ToString();
                                actionBtnColor = drGrpItem[r]["ActionButtonColor"].ToString();
                                isprgDisabled = (drGrpItem[r]["IsPrgDisabled"].ToString() == "1");

                                int noOfRowsToMerge = 1;
                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].RowSpan = noOfRowsToMerge;

                                mergeItemDescAndStatusValue = Convert.ToInt32(drGrpItem[r]["mergeItemDescAndStatusValue"].ToString());

                                if (mergeItemDescAndStatusValue == 1)
                                {
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ColumnSpan = 2;
                                    itemDesc = itemDesc + ": " + statusValue;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Left;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ForeColor = Color.Blue;
                                }
                                else
                                {
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Right;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Font = new Font("Microsoft Sans Serif", 8, FontStyle.Regular);
                                }

                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Value = itemDesc;
                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].Locked = true;

                                if ((!isprgDisabled) && (itemDesc.Length > 0) && (mergeItemDescAndStatusValue == 0))
                                {
                                    //Value
                                    FarPoint.Win.Spread.CellType.HyperLinkCellType lnk = new FarPoint.Win.Spread.CellType.HyperLinkCellType();
                                    lnk.Text = statusValue.ToString();
                                    lnk.LinkColor = Color.FromArgb(51, 29, 248);
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].CellType = lnk;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].Locked = false;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].ForeColor = Color.Blue;
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].Font = new Font("Arial", 8, FontStyle.Bold);
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].HorizontalAlignment = FarPoint.Win.Spread.CellHorizontalAlignment.Center;
                                }

                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 1].RowSpan = noOfRowsToMerge;

                                if (isprgDisabled)
                                {
                                    fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo].ForeColor = Color.Gray;
                                }

                                if (itemDesc.Length > 0)
                                {
                                    Color btnBkColor = GetCorrespondingColor(actionBtnColor, isprgDisabled);
                                    if (noOfRowsToMerge > 1)
                                    {
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo + 1, colNo + 2].CellType = FarPtColCtrls.GetButtonCellType(btnBkColor);
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo + 1, colNo + 2].Tag = refNo;
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Tag = refNo;
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo + 1, colNo + 2].Locked = false;
                                    }
                                    else
                                    {
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].CellType = FarPtColCtrls.GetButtonCellType(btnBkColor);
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Tag = refNo;
                                        fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo + 2].Locked = false;
                                    }
                                }

                                fpSpread_TopPanel.ActiveSheet.Cells[rowNo, colNo, rowNo, colNo + 2].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;

                                fpSpread_TopPanel.ActiveSheet.Rows[rowNo].Height = GROUP_ITEM_HEIGHT;
                                if (noOfRowsToMerge > 1)
                                {
                                    fpSpread_TopPanel.ActiveSheet.Rows[rowNo].Height = SEPARATOR_HEIGHT;
                                    fpSpread_TopPanel.ActiveSheet.Rows[rowNo + 1].Height = GROUP_ITEM_HEIGHT;
                                }
                                rowNo = rowNo + noOfRowsToMerge;
                            }
                            #endregion
                        }
                    }

                    int groupLastRow = rowNo - 1;
                    AssignOutlineBorderToGroupItems(currentRow + 1, colNo, groupLastRow, colNo + 2);
                    fpSpread_TopPanel.ActiveSheet.Cells[currentRow + 1, colNo, groupLastRow, colNo + 2].BackColor = grpItemBkColor;

                    //Separator Row
                    groupLastRow = groupLastRow + 1;
                    fpSpread_TopPanel.ActiveSheet.Rows[groupLastRow].Height = SEPARATOR_HEIGHT;
                    fpSpread_TopPanel.ActiveSheet.Rows[groupLastRow].Locked = true;
                    fpSpread_TopPanel.ActiveSheet.Cells[groupLastRow, colNo, groupLastRow, colNo + 2].BackColor = backColor;
                    #endregion
                }

                fpSpread_TopPanel.ActiveSheet.Columns.Add(0, 1);
                fpSpread_TopPanel.ActiveSheet.Rows.Add(0, 1);
                fpSpread_TopPanel.ActiveSheet.Rows[0].Height = 2;
                fpSpread_TopPanel.ActiveSheet.Columns[0].Width = 6;
                fpSpread_TopPanel.ActiveSheet.Rows[0].BackColor = backColor;
                fpSpread_TopPanel.ActiveSheet.Columns[0].BackColor = backColor;

                tableLayoutPanel1.RowStyles[2].Height = totalHeight + 6;
            }
            catch (Exception err)
            {
                Gfn.Wb("Failed to Load DashBoard");
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "FillupDashBoardGrid", err.Message);
                return;
            }
            finally
            {
                drGrpItem = null;
                dtGroup = null;
                dtGroupItem = null;
            }
        }

        private Color GetCorrespondingColor(string actionButtonColor, bool isprgDisabled)
        {
            Color bkColor = Color.FromArgb(0, 192, 0);
            if (isprgDisabled)
            {
                bkColor = Color.LightGray;
            }
            else
            {
                if (actionButtonColor == "G") bkColor = Color.FromArgb(0, 192, 0);
                else if (actionButtonColor == "R") bkColor = Color.Red;
                else if (actionButtonColor == "Y") bkColor = Color.Yellow;
                else if (actionButtonColor == "GR") bkColor = Color.FromArgb(128, 128, 128);
            }
            return (bkColor);
        }

        protected void AssignOutlineBorderToGroupItems(int row1, int col1, int row2, int col2)
        {
            FarPoint.Win.Spread.Model.DefaultSheetSelectionModel defselModel = null;
            try
            {
                int rowCnt = row2 - row1 + 1;
                int colCnt = col2 - col1 + 1;
                defselModel = new FarPoint.Win.Spread.Model.DefaultSheetSelectionModel();
                defselModel.AddSelection(row1, col1, rowCnt, colCnt);
                fpSpread_TopPanel.ActiveSheet.Models.Selection = defselModel;
                fpSpread_TopPanel.ActiveSheet.SetOutlineBorder(fpSpread_TopPanel.ActiveSheet.GetSelection(0), new FarPoint.Win.RoundedLineBorder(Color.LightSteelBlue, 1, true, true, true, true));
                defselModel.RemoveSelection(row1, col1, rowCnt, colCnt);
            }
            finally
            {
                defselModel = null;
            }
        }

        private void fpSpread_TopPanel_ButtonClicked(object sender, FarPoint.Win.Spread.EditorNotifyEventArgs e)
        {
            if (e.Row < 0) return;
            if (isLinkClicked) return;

            try
            {
                int row = e.Row, col = e.Column; long refNo = -1;

                if (fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag == null) return;

                string tagValue = fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag.ToString().Trim();

                try
                {
                    if (fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag != null) Convert.ToInt32(fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag.ToString());
                }
                catch
                {
                    if (tagValue.Trim().Length > 0 && fpSpread_TopPanel.ActiveSheet.Cells[row, col].Tag != null)
                    {
                        if (tagValue.ToUpper() == "Forms Fill/Finalise".ToUpper() || tagValue.ToUpper() == "Forms To Approve".ToUpper()) tagValue = "Forms";
                        string script = " select count(*)  " +
                                        " from VUI_GroupItems_HQ I " +
                                        " where I.IsPrgDisabled = 0 and I.VUI_Groups_HQID > 0 and I.Prg=" + Gfn.Qss(tagValue) +
                                        "   and C_CompanyID = " + PG.Gb.CompanyId +
                                        "   and DashboardType = '" + PG.DASHBOARDTYPE_MARINE + "'";
                        int cnt = Convert.ToInt32(PG.Gb.DBFn.Aqr(script));

                        if (cnt <= 0)
                        {
                            Gfn.nMbwithAlignAndCentrePosn("This program is not enabled", ContentAlignment.MiddleCenter, 110, 200);
                            return;
                        }

                        CallCorrespondingAppAllVessels(tagValue);
                        return;
                    }
                }

                if (tagValue.Length > 0)
                {
                    refNo = Convert.ToInt64(tagValue);
                }

                if (!InitialiseFieldName_CheckPrgDisabled(refNo)) return;

                if (fieldName.ToUpper() == "RISKASSEMENTS_HQ_REVIEW")
                {
                    CallCorrespondingApplication(fieldName);
                    return;
                }

                isFormInitialised = false;
                chkShowOnlyActionColumns.Checked = true;
                isFormInitialised = true;

                BindAndFocusSelectedFieldColumn();
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "fpSpread_TopPanel_ButtonClicked", err.Message);
            }
        }

        private void fpSpread_TopPanel_HyperLinkClicked(object sender, FarPoint.Win.Spread.HyperLinkClickedEventArgs e)
        {
            if (e.Row < 0) return;
            try
            {
                int row = e.Row, col = e.Column; long refNo = -1;

                if (fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag == null) return;

                string tagValue = fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag.ToString().Trim();
                if (tagValue.Length > 0)
                {
                    refNo = Convert.ToInt64(tagValue);
                }
                if (refNo < 0) return;

                isLinkClicked = true;

                if (!InitialiseFieldName_CheckPrgDisabled(refNo)) return;

                CallCorrespondingApplication(fieldName);

                fieldName = "";
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "fpSpread_TopPanel_HyperLinkClicked", err.Message);
            }
            finally
            {
                isLinkClicked = false;
            }
        }

        private void fpSpread_TopPanel_TextTipFetch(object sender, FarPoint.Win.Spread.TextTipFetchEventArgs e)
        {
            int row = e.Row; int col = e.Column;
            if (row < 0 || col < 0) return;
            try
            {
                if (((FarPoint.Win.Spread.CellType.HyperLinkCellType)(fpSpread_TopPanel.ActiveSheet.Cells[row, col].CellType)) != null) { }
            }
            catch { return; }

            for (int row1 = 0; row1 < fpSpread_TopPanel.ActiveSheet.RowCount; row1++)
            {
                for (int col1 = 0; col1 < fpSpread_TopPanel.ActiveSheet.ColumnCount; col1++)
                {
                    if (fpSpread_TopPanel.ActiveSheet.Cells[row1, col1].BackColor == Color.Yellow)
                    {
                        fpSpread_TopPanel.ActiveSheet.Cells[row1, col1].BackColor = Color.FromArgb(247, 247, 247);
                        fpSpread_TopPanel.ActiveSheet.Cells[row1, col1].ResetBorder();
                    }
                }
            }

            if (((FarPoint.Win.Spread.CellType.HyperLinkCellType)(fpSpread_TopPanel.ActiveSheet.Cells[row, col].CellType)) != null)
            {
                string cntValue = ((FarPoint.Win.Spread.CellType.HyperLinkCellType)(fpSpread_TopPanel.ActiveSheet.Cells[row, col].CellType)).Text.ToString();
                if (cntValue.Trim().Length > 0)
                {
                    fpSpread_TopPanel.ActiveSheet.Cells[row, col].BackColor = Color.Yellow;
                    fpSpread_TopPanel.ActiveSheet.Cells[row, col].Border = new FarPoint.Win.LineBorder(Color.Gray, 1);
                }
            }
        }

        private void fpSpread_TopPanel_CellClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0) return;
            try
            {
                int row = e.Row, col = e.Column; long refNo = -1;

                string tagValue = "";
                if (fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag != null) tagValue = fpSpread_TopPanel.ActiveSheet.Cells[row, col + 1].Tag.ToString().Trim();
                if (tagValue.Length > 0)
                {
                    refNo = Convert.ToInt64(tagValue);
                }
                if (refNo < 0) return;

                if (!InitialiseFieldName_CheckPrgDisabled(refNo)) return;

                CallCorrespondingApplication(fieldName);

                fieldName = "";
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "fpSpread_TopPanel_HyperLinkClicked", err.Message);
            }
        }

        private bool InitialiseFieldName_CheckPrgDisabled(long refNo)
        {
            bool result = false;
            DataTable dt;
            try
            {
                string script = " select FieldName, IsPrgDisabled " +
                                " from VUI_GroupItems_HQ " +
                                " where RefNo=" + refNo +
                                "   and C_CompanyID = " + PG.Gb.CompanyId + 
                                "   and DashboardType = '" + PG.DASHBOARDTYPE_MARINE + "'";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt != null && dt.Rows.Count > 0)
                {
                    fieldName = dt.Rows[0]["FieldName"].ToString();
                    string isPrgDisabled = dt.Rows[0]["IsPrgDisabled"].ToString();
                    if (isPrgDisabled == "1")
                    {
                        Gfn.nMbwithAlignAndCentrePosn("This program is not enabled", ContentAlignment.MiddleCenter, 110, 200);
                        return result;
                    }
                }

                script = " select ColumnNo from Dashboard_HQ_Main_Marine_Setup " +
                         " where ColumnName=" + Gfn.Qss(fieldName) +
                         "   and C_CompanyID = " + PG.Gb.CompanyId;
                string columnNoStr = PG.Gb.DBFn.Aqr(script).ToString();
                int colNo = -1;
                if (columnNoStr.Trim().Length > 0) colNo = Convert.ToInt32(columnNoStr);

                if (colNo > 0 && colNo < fpSpread1.ActiveSheet.ColumnCount)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(0, colNo);
                    fpSpread1.SetViewportTopRow(0, 0);
                    fpSpread1.SetViewportLeftColumn(0, colNo);
                }

                result = true;
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "InitialiseFieldName_CheckPrgDisabled", err.Message);
            }

            finally
            {
                dt = null;
            }

            return result;
        }

        private void fpSpread_TopPanel_Error(object sender, FarPoint.Win.Spread.ErrorEventArgs e)
        {
            if (e.EditError == FarPoint.Win.Spread.EditError.InvalidHyperlink)
            {
                e.Cancel = true;
            }
        }

        #endregion

        private void fpSpread1_TextTipFetch(object sender, FarPoint.Win.Spread.TextTipFetchEventArgs e)
        {
            if (e.View.TextTipAppearance.BackColor != SystemColors.Info)
            {
                e.View.TextTipAppearance.BackColor = SystemColors.Info;
                e.View.TextTipAppearance.ForeColor = Color.Black;
            }

            if (e.ColumnHeader && e.Row == 0)
            {
                if ((e.Column >= COL_FORMS_ODUE && e.Column <= COL_FORMS_RECENTLY_CLOSED) || 
                    (e.Column >= COL_AUDITINSPECTION_RESCHEDULED_TOAPPR && e.Column <= COL_AUDITINSPECTION_RECENTLY_CLOSED) ||
                    (e.Column >= COL_NCR_OVERDUE && e.Column <= COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED))
                {
                    e.WrapText = false;
                    e.ShowTip = true;
                    e.TipText = "Double click to Show / Hide Columns";
                    e.View.TextTipAppearance.BackColor = Color.LightYellow;
                    e.View.TextTipAppearance.ForeColor = Color.Red;
                    e.View.TextTipAppearance.Font = new Font("Arial", 9, FontStyle.Bold);
                }
            }
        }

        private void BindAndFocusSelectedFieldColumn()
        {
            DataTable dt;
            try
            {
                BindDashBoardGrid();

                if (fieldName.Trim().Length <= 0 || fpSpread1.ActiveSheet.RowCount < 0) return;

                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();
                string addlCond = "  ";
                if (companyID != "-99") addlCond = addlCond + " and C_CompanyID='" + companyID + "'";

                string script = " select GroupName, ColumnNo from Dashboard_HQ_Main_Marine_Setup " +
                                " where ColumnName= " + Gfn.Qss(fieldName) +
                                addlCond;
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null) return;

                string groupName = dt.Rows[0]["GroupName"].ToString();
                string sx = dt.Rows[0]["ColumnNo"].ToString();

                int col = -1;
                if (sx.Trim().Length > 0) col = Convert.ToInt32(sx);

                if (col > 0 && col < fpSpread1.ActiveSheet.ColumnCount && fpSpread1.ActiveSheet.RowCount > 0)
                {
                    fpSpread1.ActiveSheet.Cells[0, col, fpSpread1.ActiveSheet.RowCount - 1, col].BackColor = Color.Yellow;
                    fpSpread1.ActiveSheet.Cells[0, col, fpSpread1.ActiveSheet.RowCount - 1, col].ForeColor = Color.Red;
                    fpSpread1.ActiveSheet.Cells[0, col, fpSpread1.ActiveSheet.RowCount - 1, col].Font = new System.Drawing.Font("Microsoft sans serif", 7.5f, FontStyle.Bold);

                    fpSpread1.ActiveSheet.SetActiveCell(0, col);

                    script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways " +
                             " from Dashboard_HQ_Main_Marine_Setup " + Environment.NewLine +
                             " where ColumnNo>=0 and  GroupName=" + Gfn.Qss(groupName) +
                             "   and C_CompanyID = " + PG.Gb.CompanyId +
                             " order by ColumnNo";
                    dt = PG.Gb.DBFn.DbRecords(script);

                    if (dt == null) return;

                    foreach (DataRow dr in dt.Rows)
                    {
                        int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                        int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                        int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());
                        if (isToHide == 1 || isToShowAlways == 1) continue;

                        fpSpread1.ActiveSheet.Columns[columnNo].Visible = true;
                    }
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "BindAndFocusSelectedFieldColumn", err.Message);
            }
        }

        private void CallCorrespondingApplication(string fieldName)
        {
            #region Initialise Field Name Variables

            string FLD_CERTIFICATES_TORENEW = "CERTIFICATES_TORENEW",
                   FLD_CERTIFICATE_ODUE = "CERTIFICATES_ODUE",
                   FLD_FORMS_ODUE = "FORMS_ODUE",
                   FLD_FORMS_HQ_PENDING = "FORMS_HQ_PENDING",
                   FLD_FORMS_HQ_TO_AMEND = "FORMS_HQ_TO_AMEND", 
                   FLD_FORMS_SUPT_TO_FINALISE = "FORMS_SUPT_TO_FINALISE",
                   FLD_FORMS_MGR_TO_FINALISE = "FORMS_MGR_TO_FINALISE",
                   FLD_FORMS_SUPT_TO_APPR = "FORMS_SUPT_TO_APPR",
                   FLD_FORMS_MGR_TO_APPR = "FORMS_MGR_TO_APPR",
                   FLD_FORMS_GENMGR_TO_APPR = "FORMS_GENMGR_TO_APPR",
                   FLD_FORMS_DIR_TO_APPR = "FORMS_DIR_TO_APPR",
                   FLD_AUDITINSPECTION_NOOFDUE = "AUDITINSPECTION_NOOFDUE",
                   FLD_AUDITINSPECTION_NOOFOVERDUE = "AUDITINSPECTION_NOOFOVERDUE",
                   FLD_AUDITINSPECTION_NOOFWINDOWPERIOD = "AUDITINSPECTION_NOOFWINDOWPERIOD",
                   FLD_AUDITINSPECTION_RESCHEDULED_TOAPPR = "AUDITINSPECTION_RESCHEDULED_TOAPPR",
                   FLD_AUDITINSPECTION_DRAFTREPORT = "AUDITINSPECTION_DRAFTREPORT",
                   FLD_AUDITINSPECTION_DRAFT_TOAMEND = "AUDITINSPECTION_DRAFT_TOAMEND",
                   FLD_AUDITINSPECTION_DPA_TO_APPROVE = "AUDITINSPECTION_DPA_TO_APPROVE",
                   FLD_AUDITINSPECTION_MGR_TO_APPROVE_DRAFT = "AUDITINSPECTION_MGR_TO_APPROVE_DRAFT",
                   FLD_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE = "AUDITINSPECTION_DIRECTOR_TO_APPROVE_DRAFT",
                   FLD_AUDITINSPECTION_UNDERACTION = "UDITINSPECTION_UNDERACTION",
                   FLD_AUDITINSPECTION_CLOSEOUT_TO_REVIEW = "AUDITINSPECTION_CLOSEOUT_TO_REVIEW",
                   FLD_AUDITINSPECTION_MGR_TO_APPROVE = "AUDITINSPECTION_MGR_TO_APPROVE",
                   FLD_AUDITINSPECTION_GENMGRTOAPPROVE = "AUDITINSPECTION_SENIORMGR_TO_APPROVE",
                   FLD_AUDITINSPECTION_VSL_AMEND_ACK = "AUDITINSPECTION_VSL_AMEND_ACK",
                   FLD_AUDITINSPECTION_RECENTLY_CLOSED = "AUDITINSPECTION_RECENTLY_CLOSED",

                   FLD_NCR_OVERDUE = "NCR_OVERDUE",
                   FLD_NCR_HQUNDERPREP = "NCR_HQUNDERPREP",
                   FLD_NCR_HQ_TO_AMEND = "NCR_HQ_TO_AMEND",
                   FLD_NCR_DPA_TO_FINALISE = "NCR_DPA_ToFinalise",
                   FLD_NCR_CLOSEOUT_TO_REVIEW_HQ = "NCR_CLOSEOUT_TO_REVIEW_HQ",
                   FLD_NCR_CLOSEOUT_TO_REVIEW_VSL = "NCR_CLOSEOUT_TO_REVIEW_VSL",
                   FLD_NCR_DPA_PENDING = "NCR_DPA_PENDING",
                   FLD_NCR_CREW_PENDING = "NCR_CREW_PENDING",
                   FLD_NCR_TECH_PENDING = "NCR_TECH_PENDING",
                   FLD_NCR_MGRTOAPPROVE = "NCR_MGR_TO_APPR",
                   FLD_NCR_VSL_AMEND_ACK = "NCR_VSL_AMEND_ACK",
                   FLD_NCR_HQ_TO_FINALISE = "NCR_HQ_TO_FINALISE",
                   FLD_NCR_VSLTOFINALISE = "VSLTOFINALISE",

                   FLD_DEFECTS_ODUE = "DF_ODUEITEMS",
                   FLD_DEFECTS_DF_DPA_TO_VERIFY = "DF_DPA_TO_VERIFY",
                   FLD_DEFECTS_ACTIVEITEMS = "DF_ACTIVEITEMS",
                   FLD_DEFECTS_DF_TOHQAPPROVE = "DF_TOHQAPPROVE",
                   
                   FLD_TASKLIST_OVERDUE = "TASKLIST_OVERDUE",
                   FLD_TASKLIST_UNDERPREP = "TASKLIST_UNDERPREP",
                   FLD_TASKLIST_HQTOSUBMIT = "TASKLIST_HQTOSUBMIT",
                   FLD_TASKLIST_INPROGRESS = "TASKLIST_INPROGRESS",
                   FLD_TASKLIST_DPA_PENDING = "TASKLIST_DPA_PENDING",
                   FLD_TASKLIST_CREW_PENDING = "TASKLIST_CREW_PENDING",
                   FLD_TASKLIST_TECH_PENDING = "TASKLIST_TECH_PENDING",

                  FLD_INCIDENTREPORT_OVERDUE = "INCIDENTREPORT_OVERDUE",
                  FLD_INCIDENTREPORT_HQUNDERPREP = "INCIDENTREPORT_HQUNDERPREP",
                  FLD_INCIDENTREPORT_HQ_TOAMEND = "INCIDENTREPORT_HQ_TOAMEND",
                  FLD_INCIDENTREPORT_DPA_TO_APPROVE = "INCIDENTREPORT_DPA_TO_APPROVE",
                  FLD_INCIDENTREPORT_TECH_TO_APPROVE = "INCIDENTREPORT_TECH_TO_APPROVE",
                  FLD_INCIDENTREPORT_CREW_TO_APPROVE = "INCIDENTREPORT_CREW_TO_APPROVE",
                  FLD_INCIDENTREPORT_MGR_TO_APPROVE = "INCIDENTREPORT_MGR_TO_APPROVE",
                  FLD_INCIDENTREPORT_SENIORMGR_TO_APPROVE = "INCIDENTREPORT_SENIORMGR_TO_APPROVE",
                  FLD_INCIDENTREPORT_VSL_TOAMEND = "INCIDENTREPORT_VSL_TOAMEND",
                  FLD_INCIDENTREPORT_RECENTLY_FINALISED = "INCIDENTREPORT_RECENTLY_FINALISED",

                  FLD_INVESTIGATIONREPORT_OVERDUE = "INVESTIGATIONREPORT_OVERDUE",
                  FLD_INVESTIGATIONREPORT_HQFILLUP_UNDERPREP = "INVESTIGATIONREPORT_HQFILLUP_UNDERPREP",
                  FLD_INVESTIGATIONREPORT_HQFILLUPREPORT = "INVESTIGATIONREPORT_HQFILLUPREPORT",
                  FLD_INVESTIGATIONREPORT_HQUNDERPREP = "INVESTIGATIONREPORT_HQ_UNDERPREP",
                  FLD_INVESTIGATIONREPORT_HQ_TOAMEND = "INVESTIGATIONREPORT_HQ_TOAMEND",
                  FLD_INVESTIGATIONREPORT_DPA_TO_APPROVE_DRAFT = "INVESTIGATIONREPORT_DPA_TO_APPROVE_DRAFT",
                  FLD_INVESTIGATIONREPORT_MGR_TO_APPROVE_DRAFT = "INVESTIGATIONREPORT_MGR_TO_APPROVE_DRAFT",
                  FLD_INVESTIGATIONREPORT_UNDERACTION = "INVESTIGATIONREPORT_UNDERACTION",
                  FLD_INVESTIGATIONREPORT_CLOSEOUT_TO_REVIEW = "INVESTIGATIONREPORT_CLOSEOUT_TO_REVIEW",
                  FLD_INVESTIGATIONREPORT_MGR_TO_APPROVE = "INVESTIGATIONREPORT_MGR_TO_APPROVE",
                  FLD_INVESTIGATIONREPORT_SENIORMGR_TO_APPROVE = "INVESTIGATIONREPORT_SENIORMGR_TO_APPROVE",
                  FLD_INVESTIGATIONREPORT_VSLFILLUPREPORT = "INVESTIGATIONREPORT_VSLFILLUPREPORT",
                  FLD_INVESTIGATIONREPORT_VSL_AMEND_ACK = "INVESTIGATIONREPORT_VSL_AMEND_ACK",
                  FLD_INVESTIGATIONREPORT_RECENTLY_CLOSED = "INVESTIGATIONREPORT_RECENTLY_CLOSED",

                   FLD_AWARENESS_REPORT_OVERDUE = "AWARENESS_REPORT_OVERDUE",
                   FLD_AWARENESS_REPORT_DPA_PENDING = "AWARENESS_REPORT_DPA_PENDING",
                   FLD_AWARENESS_REPORT_CREW_PENDING = "AWARENESS_REPORT_CREW_PENDING",
                   FLD_AWARENESS_REPORT_TECH_PENDING = "AWARENESS_REPORT_TECH_PENDING",
                   FLD_AWARENESS_REPORT_VSL_AMEND_ACK = "AWARENESS_REPORT_VSL_AMEND_ACK",
                   FLD_AWARENESS_REPORT_HQ_TO_FINALISE = "AWARENESS_REPORT_HQ_TO_FINALISE",
                   FLD_AWARENESS_REPORT_HQUNDERPREP = "AWARENESS_REPORT_HQUNDERPREP",
                   FLD_AWARENESS_REPORT_VSLTOFINALISE = "VSLTOFINALISE",
                   FLD_AWARENESS_REPORT_HQ_TO_AMEND = "AWARENESS_REPORT_HQ_TO_AMEND",

                   FLD_MASTERS_REVIEW__OVERDUE = "MASTERS_REVIEW__OVERDUE",
                   FLD_MASTERS_REVIEW_DPA_PENDING = "MASTERS_REVIEW_DPA_PENDING",
                   FLD_MASTERS_REVIEW_CREW_PENDING = "MASTERS_REVIEW_CREW_PENDING",
                   FLD_MASTERS_REVIEW_TECH_PENDING = "MASTERS_REVIEW_TECH_PENDING",
                   FLD_MASTERS_REVIEW_VSL_AMEND_ACK = "MASTERS_REVIEW_VSL_AMEND_ACK",
                   FLD_MASTERS_REVIEW__HQ_TO_FINALISE = "MASTERS_REVIEW__HQ_TO_FINALISE",
                   FLD_MASTERS_REVIEW__HQUNDERPREP = "MASTERS_REVIEW__HQUNDERPREP",
                   FLD_MASTERS_REVIEW__VSLTOFINALISE = "VSLTOFINALISE",
                   FLD_MASTERS_REVIEW__HQ_TO_AMEND = "MASTERS_REVIEW__HQ_TO_AMEND",

                   FLD_MINUTES_OF_SAFETY_OVERDUE = "MINUTES_OF_SAFETY_OVERDUE",
                   FLD_MINUTES_OF_SAFETY_DPA_PENDING = "MINUTES_OF_SAFETY_DPA_PENDING",
                   FLD_MINUTES_OF_SAFETY_CREW_PENDING = "MINUTES_OF_SAFETY_CREW_PENDING",
                   FLD_MINUTES_OF_SAFETY_TECH_PENDING = "MINUTES_OF_SAFETY_TECH_PENDING",
                   FLD_MINUTES_OF_SAFETY_VSL_AMEND_ACK = "MINUTES_OF_SAFETY_VSL_AMEND_ACK",
                   FLD_MINUTES_OF_SAFETY_HQ_TO_FINALISE = "MINUTES_OF_SAFETY_HQ_TO_FINALISE",
                   FLD_MINUTES_OF_SAFETY_HQUNDERPREP = "MINUTES_OF_SAFETY_HQUNDERPREP",
                   FLD_MINUTES_OF_SAFETY_VSLTOFINALISE = "VSLTOFINALISE",
                   FLD_MINUTES_OF_SAFETY_HQ_TO_AMEND = "MINUTES_OF_SAFETY_HQ_TO_AMEND",

                   FLD_RISKASSEMENTS_HQ_REVIEW = "RISKASSEMENTS_HQ_REVIEW",
                   FLD_RISKASSEMENTS_SUPT_TO_APPR = "RISKASSEMENTS_SUPT_TO_APPR",
                   FLD_RISKASSEMENTS_MGR_TO_APPR = "RISKASSEMENTS_MGR_TO_APPR",
                   FLD_RISKASSEMENTS_GENMGR_TO_APPR = "RISKASSEMENTS_GENMGR_TO_APPR";
            #endregion

            if (fieldName.ToUpper() == FLD_CERTIFICATE_ODUE.ToUpper() || fieldName.ToUpper() == FLD_CERTIFICATES_TORENEW.ToUpper())
            {
                #region Certificate
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_CERTIFICATE_ODUE) { addlParameter = "OVERDUE"; }
                else if (fieldName.ToUpper() == FLD_CERTIFICATES_TORENEW) { addlParameter = "TORENEW"; }

                CallCertificateApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_FORMS_ODUE.ToUpper() || fieldName.ToUpper() == FLD_FORMS_HQ_PENDING || fieldName.ToUpper() == FLD_FORMS_HQ_TO_AMEND
                || fieldName.ToUpper() == FLD_FORMS_SUPT_TO_FINALISE || fieldName.ToUpper() == FLD_FORMS_MGR_TO_FINALISE
                || fieldName.ToUpper() == FLD_FORMS_SUPT_TO_APPR  || fieldName.ToUpper() == FLD_FORMS_MGR_TO_APPR || fieldName.ToUpper() == FLD_FORMS_GENMGR_TO_APPR || fieldName.ToUpper() == FLD_FORMS_DIR_TO_APPR) 
            {
                #region Forms
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_FORMS_ODUE) { addlParameter = "OVERDUE|" + PG.HSQE_DeptName; }
                else if (fieldName.ToUpper() == FLD_FORMS_HQ_PENDING) { addlParameter = "HQPENDING|" + PG.HSQE_DeptName; }
                else if (fieldName.ToUpper() == FLD_FORMS_HQ_TO_AMEND) { addlParameter = "HQAMEND|" + PG.HSQE_DeptName; }
                else if (fieldName.ToUpper() == FLD_FORMS_SUPT_TO_FINALISE) { addlParameter = "FILLED|" + PG.HSQE_DeptName + "|Supt"; }
                else if (fieldName.ToUpper() == FLD_FORMS_MGR_TO_FINALISE) { addlParameter = "FILLED|" + PG.HSQE_DeptName + "|Manager"; }
                else if (fieldName.ToUpper() == FLD_FORMS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|Supt"; }
                else if (fieldName.ToUpper() == FLD_FORMS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|Manager"; }
                else if (fieldName.ToUpper() == FLD_FORMS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|GeneralManager"; }
                else if (fieldName.ToUpper() == FLD_FORMS_DIR_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|Director"; }

                CallFormsApplication(-1, addlParameter, true, false, PG.REFRESH_CALLEDMODE_MARINE_FORMS);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_NOOFOVERDUE || fieldName.ToUpper() == FLD_AUDITINSPECTION_NOOFWINDOWPERIOD || fieldName.ToUpper() == FLD_AUDITINSPECTION_RESCHEDULED_TOAPPR ||
                     fieldName.ToUpper() == FLD_AUDITINSPECTION_DRAFTREPORT || fieldName.ToUpper() == FLD_AUDITINSPECTION_DRAFT_TOAMEND ||
                     fieldName.ToUpper() == FLD_AUDITINSPECTION_DPA_TO_APPROVE || fieldName.ToUpper() == FLD_AUDITINSPECTION_MGR_TO_APPROVE_DRAFT || fieldName.ToUpper() == FLD_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE ||
                     fieldName.ToUpper() == FLD_AUDITINSPECTION_CLOSEOUT_TO_REVIEW || fieldName.ToUpper() == FLD_AUDITINSPECTION_MGR_TO_APPROVE || fieldName.ToUpper() == FLD_AUDITINSPECTION_GENMGRTOAPPROVE)
            {
                #region Audit Inspection

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_AUDITINSPECTION_NOOFDUE) { addlParameter = "Due|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_NOOFOVERDUE) { addlParameter = "ODue|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_NOOFWINDOWPERIOD) { addlParameter = "ActionRequired|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_RESCHEDULED_TOAPPR) { addlParameter = "RescheduleHQToApprove|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_DRAFTREPORT) { addlParameter = "DraftReport|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_DRAFT_TOAMEND) { addlParameter = "ToAmend|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_DPA_TO_APPROVE) { addlParameter = "DPAToApprove|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_MGR_TO_APPROVE_DRAFT) { addlParameter = "DraftMgrToAprove|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE) { addlParameter = "DraftDirectorToAprove|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_UNDERACTION) { addlParameter = "UnderActionUnderAction|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_CLOSEOUT_TO_REVIEW) { addlParameter = "CloseOutToReview|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_MGR_TO_APPROVE) { addlParameter = "MgrToApprove|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_GENMGRTOAPPROVE) { addlParameter = "GenMgrToApprove|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_VSL_AMEND_ACK) { addlParameter = "VSLAMEND_ACK|-1"; }
                else if (fieldName.ToUpper() == FLD_AUDITINSPECTION_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED|-1"; }

                CallAuditInspectionApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_NCR_OVERDUE || fieldName.ToUpper() == FLD_NCR_CLOSEOUT_TO_REVIEW_HQ || fieldName.ToUpper() == FLD_NCR_CLOSEOUT_TO_REVIEW_VSL || fieldName.ToUpper() == FLD_NCR_DPA_PENDING ||
                     fieldName.ToUpper() == FLD_NCR_CREW_PENDING || fieldName.ToUpper() == FLD_NCR_TECH_PENDING || fieldName.ToUpper() == FLD_NCR_MGRTOAPPROVE || fieldName.ToUpper() == FLD_NCR_VSL_AMEND_ACK ||
                     fieldName.ToUpper() == FLD_NCR_HQUNDERPREP || fieldName.ToUpper() == FLD_NCR_HQ_TO_AMEND || fieldName.ToUpper() == FLD_NCR_HQ_TO_FINALISE || fieldName.ToUpper() == FLD_NCR_VSLTOFINALISE)
            {
                #region NCR

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_NCR_OVERDUE) { addlParameter = "ODue"; }
                else if (fieldName.ToUpper() == FLD_NCR_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (fieldName.ToUpper() == FLD_NCR_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; }
                else if (fieldName.ToUpper() == FLD_NCR_DPA_TO_FINALISE) { addlParameter = "DPAToFinalise"; }
                else if (fieldName.ToUpper() == FLD_NCR_CLOSEOUT_TO_REVIEW_HQ) { addlParameter = "CloseOutToReview_HQ"; }
                else if (fieldName.ToUpper() == FLD_NCR_CLOSEOUT_TO_REVIEW_VSL) { addlParameter = "CloseOutToReview_VSL"; }
                else if (fieldName.ToUpper() == FLD_NCR_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (fieldName.ToUpper() == FLD_NCR_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (fieldName.ToUpper() == FLD_NCR_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (fieldName.ToUpper() == FLD_NCR_MGRTOAPPROVE) { addlParameter = "MgrToApprove"; }
                else if (fieldName.ToUpper() == FLD_NCR_VSL_AMEND_ACK) { addlParameter = "VslAmend_Ack"; }
                else if (fieldName.ToUpper() == FLD_NCR_HQ_TO_FINALISE) { addlParameter = "HQToFinalise"; }
                else if (fieldName.ToUpper() == FLD_NCR_VSLTOFINALISE) { addlParameter = "VslToFinalise"; }

                CallNCRApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_DEFECTS_ODUE.ToUpper() || fieldName.ToUpper() == FLD_DEFECTS_DF_DPA_TO_VERIFY || fieldName.ToUpper() == FLD_DEFECTS_ACTIVEITEMS
                || fieldName.ToUpper() == FLD_DEFECTS_DF_TOHQAPPROVE.ToUpper())
            {
                #region Defects
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_DEFECTS_ODUE) { addlParameter = "OVERDUEITEMS|YES"; }
                else if (fieldName.ToUpper() == FLD_DEFECTS_DF_DPA_TO_VERIFY) { addlParameter = "DPATOVERIFY|YES"; }
                else if (fieldName.ToUpper() == FLD_DEFECTS_ACTIVEITEMS) { addlParameter = "ACTIVEITEMS|YES"; }
                else if (fieldName.ToUpper() == FLD_DEFECTS_DF_TOHQAPPROVE) { addlParameter = "HQTOAPPROVE|YES"; }

                CallDefectsApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_TASKLIST_OVERDUE || fieldName.ToUpper() == FLD_TASKLIST_UNDERPREP || fieldName.ToUpper() == FLD_TASKLIST_HQTOSUBMIT || fieldName.ToUpper() == FLD_TASKLIST_INPROGRESS ||
                      fieldName.ToUpper() == FLD_TASKLIST_DPA_PENDING || fieldName.ToUpper() == FLD_TASKLIST_CREW_PENDING || fieldName.ToUpper() == FLD_TASKLIST_TECH_PENDING)
            {
                #region Task List

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_TASKLIST_UNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_HQTOSUBMIT) { addlParameter = "HQToSubmit_Resubmit"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_INPROGRESS) { addlParameter = "VslToSubmit_Resubmit"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_DPA_PENDING) { addlParameter = "DPAPending_ToApprove"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (fieldName.ToUpper() == FLD_TASKLIST_OVERDUE) { addlParameter = "OverDue"; }

                CallTaskListApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_OVERDUE || fieldName.ToUpper() == FLD_INCIDENTREPORT_HQUNDERPREP || fieldName.ToUpper() == FLD_INCIDENTREPORT_HQ_TOAMEND ||
                     fieldName.ToUpper() == FLD_INCIDENTREPORT_DPA_TO_APPROVE || fieldName.ToUpper() == FLD_INCIDENTREPORT_CREW_TO_APPROVE || fieldName.ToUpper() == FLD_INCIDENTREPORT_TECH_TO_APPROVE ||
                     fieldName.ToUpper() == FLD_INCIDENTREPORT_MGR_TO_APPROVE || fieldName.ToUpper() == FLD_INCIDENTREPORT_SENIORMGR_TO_APPROVE || fieldName.ToUpper() == FLD_INCIDENTREPORT_VSL_TOAMEND || fieldName.ToUpper() == FLD_INCIDENTREPORT_RECENTLY_FINALISED)
            {
                #region Incident Report
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_INCIDENTREPORT_OVERDUE) { addlParameter = "Incident_ODue"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_HQUNDERPREP) { addlParameter = "Incident_HQPending"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_HQ_TOAMEND) { addlParameter = "Incident_HQToAmendmts"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_DPA_TO_APPROVE) { addlParameter = "Incident_DPAPending"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_CREW_TO_APPROVE) { addlParameter = "Incident_CrewPending"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_TECH_TO_APPROVE) { addlParameter = "Incident_TechPending"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_MGR_TO_APPROVE) { addlParameter = "Incident_MgrToApprove"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_SENIORMGR_TO_APPROVE) { addlParameter = "Incident_GenMgrToApprove"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_VSL_TOAMEND) { addlParameter = "Incident_VslToAmend"; }
                else if (fieldName.ToUpper() == FLD_INCIDENTREPORT_RECENTLY_FINALISED) { addlParameter = "Incident_RecentlyClosed"; }

                CallIncidentReportApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_OVERDUE || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQFILLUP_UNDERPREP || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQFILLUPREPORT || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQUNDERPREP ||
                     fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQ_TOAMEND || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_DPA_TO_APPROVE_DRAFT || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_MGR_TO_APPROVE_DRAFT || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_UNDERACTION ||
                     fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_CLOSEOUT_TO_REVIEW || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_MGR_TO_APPROVE || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_SENIORMGR_TO_APPROVE ||
                     fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_VSLFILLUPREPORT || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_VSL_AMEND_ACK || fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_RECENTLY_CLOSED)
            {
                #region Investigation Report
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_OVERDUE) { addlParameter = "Investigation_ODue"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQFILLUP_UNDERPREP) { addlParameter = "InvestigationReport_HQFillup_UnderPrep"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQFILLUPREPORT) { addlParameter = "Investigation_HQToFillupReport"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQUNDERPREP) { addlParameter = "Investigation_HQPending"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_HQ_TOAMEND) { addlParameter = "Investigation_HQToAmendmts"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_DPA_TO_APPROVE_DRAFT) { addlParameter = "Investigation_DPAToApproveDraft"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_MGR_TO_APPROVE_DRAFT) { addlParameter = "Investigation_MgrToApproveDraft"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_UNDERACTION) { addlParameter = "Investigation_UnderAction"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_CLOSEOUT_TO_REVIEW) { addlParameter = "Investigation_CloseOut"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_MGR_TO_APPROVE) { addlParameter = "Investigation_MgrToApprove"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_SENIORMGR_TO_APPROVE) { addlParameter = "Investigation_GenMgrToApprove"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_VSLFILLUPREPORT) { addlParameter = "Investigation_VSLToFillupReport"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_VSL_AMEND_ACK) { addlParameter = "Investigation_VslAmend_Ack"; }
                else if (fieldName.ToUpper() == FLD_INVESTIGATIONREPORT_RECENTLY_CLOSED) { addlParameter = "Investigation_RecentlyClosed"; }

                CallIncidentReportApplication(-1, addlParameter, true, false);
                #endregion
            }
            else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_OVERDUE || fieldName.ToUpper() == FLD_AWARENESS_REPORT_DPA_PENDING || fieldName.ToUpper() == FLD_AWARENESS_REPORT_CREW_PENDING || fieldName.ToUpper() == FLD_AWARENESS_REPORT_TECH_PENDING || fieldName.ToUpper() == FLD_AWARENESS_REPORT_VSL_AMEND_ACK ||
                     fieldName.ToUpper() == FLD_AWARENESS_REPORT_HQ_TO_FINALISE || fieldName.ToUpper() == FLD_AWARENESS_REPORT_HQUNDERPREP || fieldName.ToUpper() == FLD_AWARENESS_REPORT_HQ_TO_AMEND || fieldName.ToUpper() == FLD_AWARENESS_REPORT_VSLTOFINALISE)
            {
                #region Awareness Report

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_OVERDUE) { addlParameter = "ODue"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_VSL_AMEND_ACK) { addlParameter = "VslToAmend_Ack"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_HQ_TO_FINALISE) { addlParameter = "HQToFinalise"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_VSLTOFINALISE) { addlParameter = "VslToFinalise"; }
                else if (fieldName.ToUpper() == FLD_AWARENESS_REPORT_HQ_TO_AMEND) { addlParameter = "HQToAmendmt"; }

                CallAwarenessReportApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW__OVERDUE || fieldName.ToUpper() == FLD_MASTERS_REVIEW_DPA_PENDING || fieldName.ToUpper() == FLD_MASTERS_REVIEW_CREW_PENDING || fieldName.ToUpper() == FLD_MASTERS_REVIEW_TECH_PENDING || fieldName.ToUpper() == FLD_MASTERS_REVIEW_VSL_AMEND_ACK ||
                     fieldName.ToUpper() == FLD_MASTERS_REVIEW__HQ_TO_FINALISE || fieldName.ToUpper() == FLD_MASTERS_REVIEW__HQUNDERPREP || fieldName.ToUpper() == FLD_MASTERS_REVIEW__HQ_TO_AMEND || fieldName.ToUpper() == FLD_MASTERS_REVIEW__VSLTOFINALISE)
            {
                #region Masters Review

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_MASTERS_REVIEW__OVERDUE) { addlParameter = "ODue"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW_VSL_AMEND_ACK) { addlParameter = "VslToAmend_Ack"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW__HQ_TO_FINALISE) { addlParameter = "HQToFinalise"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW__HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW__VSLTOFINALISE) { addlParameter = "VslToFinalise"; }
                else if (fieldName.ToUpper() == FLD_MASTERS_REVIEW__HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; }

                CallMastersReviewReportApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_OVERDUE || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_DPA_PENDING || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_CREW_PENDING || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_TECH_PENDING || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_VSL_AMEND_ACK ||
                     fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_HQ_TO_FINALISE || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_HQUNDERPREP || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_HQ_TO_AMEND || fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_VSLTOFINALISE)
            {
                #region Minutes of Safety

                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_OVERDUE) { addlParameter = "ODue"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_VSL_AMEND_ACK) { addlParameter = "VslToAmend_Ack"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_HQ_TO_FINALISE) { addlParameter = "HQToFinalise"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_VSLTOFINALISE) { addlParameter = "VslToFinalise"; }
                else if (fieldName.ToUpper() == FLD_MINUTES_OF_SAFETY_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; }

                CallMinutesOfSafetyReportApplication(-1, addlParameter, true, false);

                #endregion
            }
            else if (fieldName.ToUpper() == FLD_RISKASSEMENTS_HQ_REVIEW || fieldName.ToUpper() == FLD_RISKASSEMENTS_SUPT_TO_APPR
                  || fieldName.ToUpper() == FLD_RISKASSEMENTS_MGR_TO_APPR || fieldName.ToUpper() == FLD_RISKASSEMENTS_GENMGR_TO_APPR)
            {
                #region Risk Assements              
                string addlParameter = "";
                if (fieldName.ToUpper() == FLD_RISKASSEMENTS_HQ_REVIEW) { addlParameter = "HQReview"; }
                else if (fieldName.ToUpper() == FLD_RISKASSEMENTS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|Supt"; }
                else if (fieldName.ToUpper() == FLD_RISKASSEMENTS_MGR_TO_APPR) { addlParameter = "MgrToApprove|" + PG.HSQE_DeptName + "|Manager"; }
                else if (fieldName.ToUpper() == FLD_RISKASSEMENTS_GENMGR_TO_APPR) { addlParameter = "GenMgrToApprove|" + PG.HSQE_DeptName + "|GeneralManager"; }

                CallRiskMgmtApplication(-1, addlParameter, true, false);

                #endregion
            }
        }

        private void CallCorrespondingAppAllVessels(string prgName)
        {
            if (prgName.ToUpper() == PG.GROUPNAME_CERTIFICATE.ToUpper())
            {
                CallCertificateApplication(-1, "ALL", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_DOCUMENT.ToUpper())
            {
                //
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_ROUTINES.ToUpper())
            {
                //
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_RISKASSESSMENT.ToUpper())
            {
                CallRiskMgmtApplication(-1, "Register|Marine", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_FORMS.ToUpper())
            {
                CallFormsApplication(-1, "ALL|-1", true, false, "");
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_AI_APPROVAL.ToUpper() || prgName.ToUpper() == PG.GROUPNAME_AI_SCHED.ToUpper())
            {
                CallAuditInspectionApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_NCR.ToUpper())
            {
                CallNCRApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_DEFECTS.ToUpper())
            {
                CallDefectsApplication(-1, "ALL|YES", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_TASK.ToUpper())
            {
                CallTaskListApplication(-1, "Register", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_INCIDENTREPORT.ToUpper() || prgName.ToUpper() == PG.GROUPNAME_INCIDENTREPORT1.ToUpper())
            {
                CallIncidentReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_INVESTIGATIONREPORT.ToUpper() || prgName.ToUpper() == PG.GROUPNAME_INVESTIGATIONREPORT1.ToUpper())
            {
                CallIncidentReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_AWARENESSREPORT.ToUpper())
            {
                CallAwarenessReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_MASTERSSAFETYREVIEW.ToUpper())
            {
                CallMastersReviewReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_SAFETYCOMMITTEEMEETING.ToUpper() || prgName.ToUpper() == PG.GROUPNAME_SAFETYCOMMITTEEMEETING1.ToUpper())
            {
                CallMinutesOfSafetyReportApplication(-1, "ALL|-1", true, false);
            }
            else if (prgName.ToUpper() == PG.GROUPNAME_RISKASSESMENT.ToUpper())
            {
                CallRiskMgmtApplication(-1, "Register|Marine", true, false);
            }
        }

        private void fpSpread1_CellDoubleClick(object sender, FarPoint.Win.Spread.CellClickEventArgs e)
        {
            if (e.Row < 0) return;

            if (e.ColumnHeader)
            {
                if (e.Row != 0) return;

                string groupName = fpSpread1.ActiveSheet.ColumnHeader.Cells[e.Row, e.Column].Text;
                if (groupName.Trim().Length <= 0) return;

                ExpandCollapseColumn(groupName);
                if (isExpanded)
                {
                    chkShowOnlyActionColumns_CheckedChanged(null, null);
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                    isExpanded = false;
                }
                else
                {
                    isExpanded = true;
                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Center;
                }

                return;
            }

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                this.Cursor = Cursors.Default;
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            int cnt = 0;
            if (e.Column >= COL_CERTIFICATE_DUE && e.Column <= COL_CERTIFICATE_RENEWALINPROGRESS)
            {
                #region Certificate
                string addlParameter = "";
                if (e.Column == COL_CERTIFICATE_OVERDUE) { addlParameter = "OverDue"; }
                else if (e.Column == COL_CERTIFICATE_WINDOW) { addlParameter = "Window"; }
                else if (e.Column == COL_CERTIFICATE_PENDING) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_CERTIFICATE_HQTOUPDATE) { addlParameter = "HQToUpdate"; }
                else if (e.Column == COL_CERTIFICATE_VSLTOUPDATE) { addlParameter = "VSLToUpdate"; }
                else if (e.Column == COL_CERTIFICATE_TORENEW) { addlParameter = "ToRenew"; }
                else if (e.Column == COL_CERTIFICATE_RENEWALINPROGRESS) { addlParameter = "RenewalInProgress"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallCertificateApplication(vesselID, addlParameter, true, false);
                #endregion
            }
            else if (e.Column == COL_DOCMGMT_MANUALS_UNREAD || e.Column == COL_DOCMGMT_CIRCULARS_UNREAD)
            {
                #region Document Manangement

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    string msg = "no Document Mgmt Unread Manuals";
                    if (e.Column == COL_DOCMGMT_CIRCULARS_UNREAD) msg = "no Document Mgmt Unread Circulars";
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is " + msg + ".");
                    return;
                }

                PG.CallDMS(cboCompany_Filter.Text);

                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_DOCMGMT;
                RefreshHQDashboard(vesselID);
                #endregion
            }
            else if (e.Column >= COL_FORMS_ODUE && e.Column <= COL_FORMS_RECENTLY_CLOSED)
            {
                #region Forms
                string addlParameter = "", msg = "";
                if (e.Column == COL_FORMS_ODUE) { addlParameter = "OVERDUE|" + PG.HSQE_DeptName + ""; msg = " OverDue Forms"; }
                else if (e.Column == COL_FORMS_VSL_PENDING) { addlParameter = "VslPending"; msg = "VSL Pending Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_FINALISE) { addlParameter = "VslToFinalise|" + PG.HSQE_DeptName; msg = "VSL To Finalise Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_APPR) { addlParameter = "VslToAppr|" + PG.HSQE_DeptName; msg = "VSL To Approve Forms"; }
                else if (e.Column == COL_FORMS_VSL_TO_AMEND) { addlParameter = "VslAmend|" + PG.HSQE_DeptName; msg = "Forms for Vsl Amend"; }
                else if (e.Column == COL_FORMS_HQ_PENDING) { addlParameter = "HQPending|" + PG.HSQE_DeptName; msg = "HQ Pending Forms"; }
                else if (e.Column == COL_FORMS_HQ_TO_AMEND) { addlParameter = "HQAmend|" + PG.HSQE_DeptName; msg = "Forms for HQ Amend"; }
                else if (e.Column == COL_FORMS_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + ""; msg = "Forms for Approval"; }
                else if (e.Column == COL_FORMS_SUPT_TO_FINALISE) { addlParameter = "FILLED|" + PG.HSQE_DeptName + "|Supt"; msg = "Forms for Supt to finalise"; }
                else if (e.Column == COL_FORMS_MGR_TO_FINALISE) { addlParameter = "FILLED|" + PG.HSQE_DeptName + "|Manager"; msg = "Forms for Manager to finalise"; }
                else if (e.Column == COL_FORMS_GENMGR_TO_FINALISE) { addlParameter = "FILLED|" + PG.HSQE_DeptName + "|GeneralManager"; msg = "Forms for General Manager to finalise"; }
                else if (e.Column == COL_FORMS_DIR_TO_FINALISE) { addlParameter = "FILLED|" + PG.HSQE_DeptName + "|Director"; msg = "Forms for Director to finalise"; }
                else if (e.Column == COL_FORMS_TA_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|T.A"; msg = "Forms for T.A to Approve"; }
                else if (e.Column == COL_FORMS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|Supt"; msg = "Forms for Supt to Approve"; }
                else if (e.Column == COL_FORMS_MGR_TO_APPR) { addlParameter = "HQTOAPPR|" + PG.HSQE_DeptName + "|Manager"; msg = "Forms for Manager to Approve"; }
                else if (e.Column == COL_FORMS_GENMGR_TO_APPR) { addlParameter = "HQTOAPPR||GeneralManager"; msg = "Forms for General Manager to Approve"; }
                else if (e.Column == COL_FORMS_SENMGR_TO_APPR) { addlParameter = "HQTOAPPR||SeniorManager"; msg = "Forms for Senior Manager to Approve"; }
                else if (e.Column == COL_FORMS_DIR_TO_APPR) { addlParameter = "HQTOAPPR||Director"; msg = "Forms for Director to Approve"; }
                else if (e.Column == COL_FORMS_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed|" + PG.HSQE_DeptName; msg = "Forms Recently Closed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());
                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallFormsApplication(vesselID, addlParameter, true, false, PG.REFRESH_CALLEDMODE_MARINE_FORMS);

                #endregion
            }
            else if (e.Column >= COL_AUDITINSPECTION_RESCHEDULED_TOAPPR && e.Column <= COL_AUDITINSPECTION_RECENTLY_CLOSED)
            {
                #region Audit Inspection

                string addlParameter = "";
                if (e.Column == COL_AUDITINSPECTION_NOOFDUE) { addlParameter = "DUE|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_NOOFOVERDUE) { addlParameter = "ODUE|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_NOOFWINDOWPERIOD) { addlParameter = "ActionRequired|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_RESCHEDULED_TOAPPR) { addlParameter = "RESCHEDULEHQTOAPPROVE|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTREPORT) { addlParameter = "DraftReport|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFT_TOAMEND) { addlParameter = "ToAmend|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_DPATOAPPRVOE) { addlParameter = "DPAToApprove|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTMGRTOAPROVE) { addlParameter = "DraftMgrToAprove|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTSRMGRTOAPROVE) { addlParameter = "DraftSrMgrToAprove|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_DRAFTDIRECTORTOAPROVE) { addlParameter = "DraftDirectorToAprove|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_UNDERACTION) { addlParameter = "UnderAction|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_CLOSEOUT_TO_REVIEW) { addlParameter = "CloseOutToReview|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_MGR_TO_APPROVE) { addlParameter = "MgrToApprove|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_SENIORMGR_TO_APPROVE) { addlParameter = "GenMgrToApprove|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_VSL_AMEND_ACK) { addlParameter = "VSLAMEND_ACK|-1"; }
                else if (e.Column == COL_AUDITINSPECTION_RECENTLY_CLOSED) { addlParameter = "RECENTLYCLOSED|-1"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallAuditInspectionApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_NCR_TOEXTEND_TOAPPROVE && e.Column <= COL_NCR_RECENTLY_CLOSED)
            {
                #region NCR

                string addlParameter = "";
                if (e.Column == COL_NCR_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_NCR_TOEXTEND_TOAPPROVE) { addlParameter = "ToExtendToApprove"; }
                else if (e.Column == COL_NCR_EXTENDED) { addlParameter = "ExtendedNCR"; }
                else if (e.Column == COL_NCR_HQ_TO_AMEND) { addlParameter = "HQToAmendmts"; }
                else if (e.Column == COL_NCR_DPA_TO_FINALISE) { addlParameter = "DPAToFinalise"; }                
                else if (e.Column == COL_NCR_VSL_PENDING) { addlParameter = "VslToFinalise"; }
                else if (e.Column == COL_NCR_VSL_TO_ACK) { addlParameter = "VslAck"; }
                else if (e.Column == COL_NCR_UNDERACTION) { addlParameter = "UnderAction"; }
                else if (e.Column == COL_NCR_CLOSEOUT_TO_REVIEW_HQ) { addlParameter = "CloseOutToReview_HQ"; }
                else if (e.Column == COL_NCR_CLOSEOUT_TO_REVIEW_VSL) { addlParameter = "CloseOutToReview_VSL"; }
                else if (e.Column == COL_NCR_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (e.Column == COL_NCR_MGR_TO_APPR) { addlParameter = "MgrToAppr"; }
                else if (e.Column == COL_NCR_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (e.Column == COL_NCR_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (e.Column == COL_NCR_VSL_AMEND_ACK) { addlParameter = "VslAmend_Ack"; }
                else if (e.Column == COL_NCR_OVERDUE) { addlParameter = "ODue"; }
                else if (e.Column == COL_NCR_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallNCRApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_DF_ODUEITEMS && e.Column <= COL_DF_EXTENDED)
            {
                #region Defects

                string addlParameter = "";
                if (e.Column == COL_DF_ODUEITEMS) { addlParameter = "OVERDUEITEMS|YES"; }
                else if (e.Column == COL_DF_VSLTOFINALISE) { addlParameter = "VslToFinalise|YES"; }
                else if (e.Column == COL_DF_DPA_TO_VERIFY) { addlParameter = "DPATOVERIFY|YES"; }
                else if (e.Column == COL_DF_ACTIVEITEMS) { addlParameter = "ACTIVEITEMS|YES"; }
                else if (e.Column == COL_DF_TO_EXTENDED) { addlParameter = "HQTOAPPROVE|YES"; }
                else if (e.Column == COL_DF_EXTENDED) { addlParameter = "EXTENDEDDEFECTS|YES"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallDefectsApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_TASKLIST_OVERDUE && e.Column <= COL_TASKLIST_RECENTLY_CLOSED)
            {
                #region Task List

                string addlParameter = "";
                if (e.Column == COL_TASKLIST_OVERDUE) { addlParameter = "OverDue"; }
                else if (e.Column == COL_TASKLIST_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_TASKLIST_HQTOSUBMIT) { addlParameter = "HQToSubmit_Resubmit"; }
                else if (e.Column == COL_TASKLIST_VSLUNDERPREP) { addlParameter = "VslUnderPrep"; }
                else if (e.Column == COL_TASKLIST_INPROGRESS) { addlParameter = "VslToSubmit_Resubmit"; }
                else if (e.Column == COL_TASKLIST_VSL_TO_ACK) { addlParameter = "VslAck"; }
                else if (e.Column == COL_TASKLIST_DPA_PENDING) { addlParameter = "DPAPending_ToApprove"; }
                else if (e.Column == COL_TASKLIST_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (e.Column == COL_TASKLIST_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (e.Column == COL_TASKLIST_VSL_AMEND_ACK) { addlParameter = "VslAmend_Ack"; }
                else if (e.Column == COL_TASKLIST_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallTaskListApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_INCIDENT_REPORT_OVERDUE && e.Column <= COL_INCIDENT_REPORT_RECENTLY_FINALISED)
            {
                #region Incident Report
                string addlParameter = "";
                if (e.Column == COL_INCIDENT_REPORT_OVERDUE) { addlParameter = "Incident_ODue"; }
                else if (e.Column == COL_INCIDENT_REPORT_HQUNDERPREP) { addlParameter = "Incident_HQPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_HQ_TO_AMEND) { addlParameter = "Incident_HQToAmendmts"; }
                else if (e.Column == COL_INCIDENT_REPORT_DPA_PENDING) { addlParameter = "Incident_DPAPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_CREW_PENDING) { addlParameter = "Incident_CrewPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_TECH_PENDING) { addlParameter = "Incident_TechPending"; }
                else if (e.Column == COL_INCIDENT_REPORT_MGR_TO_APPR) { addlParameter = "Incident_MgrToApprove"; }
                else if (e.Column == COL_INCIDENT_REPORT_SR_MGR_TO_APPR) { addlParameter = "Incident_GenMgrToApprove"; }
                else if (e.Column == COL_INCIDENT_REPORT_VSL_AMEND) { addlParameter = "Incident_VslToAmend"; }
                else if (e.Column == COL_INCIDENT_REPORT_RECENTLY_FINALISED) { addlParameter = "Incident_RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallIncidentReportApplication(vesselID, addlParameter, true, false);
                #endregion
            }
            else if (e.Column >= COL_INVESTIGATION_REPORT_OVERDUE && e.Column <= COL_INVESTIGATION_REPORT_RECENTLY_CLOSED)
            {
                #region Investigation Report
                string addlParameter = "";
                if (e.Column == COL_INVESTIGATION_REPORT_OVERDUE) { addlParameter = "Investigation_ODue"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_HQTOFILLUP_UNDERPREP) { addlParameter = "InvestigationReport_HQFillup_UnderPrep"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_HQTOFILLUP) { addlParameter = "Investigation_HQToFillupReport"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_HQUNDERPREP) { addlParameter = "Investigation_HQPending"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_HQ_TO_AMEND) { addlParameter = "Investigation_HQToAmendmts"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_DPA_PENDING_DRAFT) { addlParameter = "Investigation_DPAToApproveDraft"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_MGR_TO_APPR_DRAFT) { addlParameter = "Investigation_MgrToApproveDraft"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_UNDERACTION) { addlParameter = "Investigation_UnderAction"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_CLOSEOUT) { addlParameter = "Investigation_CloseOut"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_MGR_TO_APPR) { addlParameter = "Investigation_MgrToApprove"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_SR_MGR_TO_APPR) { addlParameter = "Investigation_GenMgrToApprove"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_VSLTOFILLUP) { addlParameter = "Investigation_VSLToFillupReport"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_VSL_AMEND_ACK) { addlParameter = "Investigation_VslToAmend_Ack"; }
                else if (e.Column == COL_INVESTIGATION_REPORT_RECENTLY_CLOSED) { addlParameter = "Investigation_RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallIncidentReportApplication(vesselID, addlParameter, true, false);
                #endregion
            }
            else if (e.Column >= COL_AWARENESS_REPORT_OVERDUE && e.Column <= COL_AWARENESS_REPORT_RECENTLY_CLOSED)
            {
                #region Awareness Report

                string addlParameter = "";
                if (e.Column == COL_AWARENESS_REPORT_OVERDUE) { addlParameter = "ODue"; }
                else if (e.Column == COL_AWARENESS_REPORT_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_AWARENESS_REPORT_HQ_TO_AMEND) { addlParameter = "HQToAmend"; }
                else if (e.Column == COL_AWARENESS_REPORT_VSL_PENDING) { addlParameter = "VslToFinalise"; }
                else if (e.Column == COL_AWARENESS_REPORT_VSL_TO_ACK) { addlParameter = "VslToAck"; }
                else if (e.Column == COL_AWARENESS_REPORT_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (e.Column == COL_AWARENESS_REPORT_MGR_TO_APPR) { addlParameter = "MgrToAppr"; }
                else if (e.Column == COL_AWARENESS_REPORT_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (e.Column == COL_AWARENESS_REPORT_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (e.Column == COL_AWARENESS_REPORT_VSL_AMEND_ACK) { addlParameter = "VslToAmend_Ack"; }
                else if (e.Column == COL_AWARENESS_REPORT_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallAwarenessReportApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_MASTERS_REVIEW_OVERDUE && e.Column <= COL_MASTERS_REVIEW_RECENTLY_CLOSED)
            {
                #region Masters Review

                string addlParameter = "";
                if (e.Column == COL_MASTERS_REVIEW_OVERDUE) { addlParameter = "ODue"; }
                else if (e.Column == COL_MASTERS_REVIEW_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_MASTERS_REVIEW_HQ_TO_AMEND) { addlParameter = "HQToAmend"; }
                else if (e.Column == COL_MASTERS_REVIEW_VSL_PENDING) { addlParameter = "VslToFinalise"; }
                else if (e.Column == COL_MASTERS_REVIEW_VSL_TO_ACK) { addlParameter = "VslToAck"; }
                else if (e.Column == COL_MASTERS_REVIEW_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (e.Column == COL_MASTERS_REVIEW_MGR_TO_APPR) { addlParameter = "MgrToAppr"; }
                else if (e.Column == COL_MASTERS_REVIEW_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (e.Column == COL_MASTERS_REVIEW_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (e.Column == COL_MASTERS_REVIEW_VSL_AMEND_ACK) { addlParameter = "VslToAmend_Ack"; }
                else if (e.Column == COL_MASTERS_REVIEW_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallMastersReviewReportApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column >= COL_MINUTES_OF_SAFETY_OVERDUE && e.Column <= COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED)
            {
                #region Minutes of Safety

                string addlParameter = "";
                if (e.Column == COL_MINUTES_OF_SAFETY_OVERDUE) { addlParameter = "ODue"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_HQUNDERPREP) { addlParameter = "HQUnderPrep"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_HQ_TO_AMEND) { addlParameter = "HQToAmend"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_VSL_PENDING) { addlParameter = "VslToFinalise"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_VSL_TO_ACK) { addlParameter = "VslToAck_CancelledVslNotAck"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_DPA_PENDING) { addlParameter = "DPAPending"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_MGR_TO_APPR) { addlParameter = "MgrToAppr"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_CREW_PENDING) { addlParameter = "CrewPending"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_TECH_PENDING) { addlParameter = "TechPending"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_VSL_AMEND_ACK) { addlParameter = "VslToAmend_Ack"; }
                else if (e.Column == COL_MINUTES_OF_SAFETY_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                CallMinutesOfSafetyReportApplication(vesselID, addlParameter, true, false);

                #endregion
            }
            else if (e.Column == COL_PORTSERVICES_PORT || e.Column == COL_PORTSERVICES_DATE)
            {
                #region Port Services
                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                string exeName = "";
                string param = "";
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);

                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_DOCMGMT;
                RefreshHQDashboard(vesselID);
                #endregion;
            }
            else if (e.Column == COL_ROUTINES_DRILLS || e.Column == COL_ROUTINES_ROUTINES)
            {
                #region Routines
                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    return;
                }

                string exeName = "";
                string param = "";
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);

                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_DOCMGMT;
                RefreshHQDashboard(vesselID);
                # endregion
            }
            else if (e.Column >= COL_RISKASSEMENTS_HQ_REVIEW && e.Column <= COL_RISKASSEMENTS_RECENTLY_CLOSED)
            {
                #region Risk Assements              
                string addlParameter = "", msg = "";
                if (e.Column == COL_RISKASSEMENTS_HQ_REVIEW) { addlParameter = "HQReview"; msg = "HQ Review Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSLTASKTOMOVE) { addlParameter = "VslTaskToMove"; msg = "HQ Review Risk Assements"; }
                else if(e.Column == COL_RISKASSEMENTS_TASK_ODUE) { addlParameter = "Task_ODUE"; msg = " Task OverDue Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_REPORT_ODUE) { addlParameter = "Report_ODUE"; msg = "Report OverDue Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_ACTIVEITEMS) { addlParameter = "ActiveItems"; msg = "Active Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_PENDING) { addlParameter = "VslPending"; msg = "VSL Pending Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_TO_AMEND) { addlParameter = "VslAmend"; msg = "Risk Assements for Vsl Amend"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_PENDING) { addlParameter = "HQPending|Marine"; msg = "HQ Pending Risk Assements"; }
                else if (e.Column == COL_RISKASSEMENTS_HQ_TO_AMEND) { addlParameter = "HQAmend|Marine"; msg = "Risk Assements for HQ Amend"; }
                else if (e.Column == COL_RISKASSEMENTS_TO_APPR) { addlParameter = "HQTOAPPR"; msg = "Risk Assements for Review"; }
                else if (e.Column == COL_RISKASSEMENTS_TA_TO_APPR) { addlParameter = "HQTOAPPR|Marine|T.A"; msg = "Risk Assements for T.A to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_SUPT_TO_APPR) { addlParameter = "HQTOAPPR|Marine|Supt"; msg = "Risk Assements for Supt to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_MGR_TO_APPR) { addlParameter = "MgrToApprove|Marine|Manager"; msg = "Risk Assements for Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_GENMGR_TO_APPR) { addlParameter = "MgrToApprove|Marine|GeneralManager"; msg = "Risk Assements for General Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_SENMGR_TO_APPR) { addlParameter = "HQTOAPPR|Marine|SeniorManager"; msg = "Risk Assements for Senior Manager to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_DIR_TO_APPR) { addlParameter = "HQTOAPPR|Marine|Director"; msg = "Risk Assements for Director to Review"; }
                else if (e.Column == COL_RISKASSEMENTS_VSL_TO_ACK) { addlParameter = "VslToAck|Marine"; msg = "Risk Assements for Vsl to Ack"; }
                else if (e.Column == COL_RISKASSEMENTS_RECENTLY_CLOSED) { addlParameter = "RecentlyClosed|Marine"; msg = "Risk Assements Recently Closed"; }

                if (fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value != null)
                    cnt = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, e.Column].Value.ToString());

                if (cnt == 0)
                {
                    this.Cursor = Cursors.Default;
                    Gfn.Mb("There is no " + msg + ".");
                    return;
                }

                CallRiskMgmtApplication(vesselID, addlParameter, true, false);

                #endregion
            }

            this.Cursor = Cursors.Default;
            panelLoading.Visible = false;
        }

        private void ExpandCollapseColumn(string groupName)
        {
            DataTable dt;
            try
            {
                if (groupName.ToUpper() == "Audit / Inspection(AI)".ToUpper()) groupName = "Audit / Inspection (AI)";
                if (groupName.ToUpper() == "Risk Asses".ToUpper()) groupName = "Risk Assessments";

                string script = " select ColumnNo, ColumnName, IsToHide, isToShowAlways " +
                                " from Dashboard_HQ_Main_Marine_Setup " + Environment.NewLine +
                                " where ColumnNo>=0 and GroupName=" + Gfn.Qss(groupName) +
                                "   and C_CompanyID = " + PG.Gb.CompanyId +
                                " order by ColumnNo";
                dt = PG.Gb.DBFn.DbRecords(script);
                if (dt == null) return;

                foreach (DataRow dr in dt.Rows)
                {
                    int columnNo = Convert.ToInt32(dr["ColumnNo"]);
                    if (columnNo >= fpSpread1.ActiveSheet.ColumnCount) break;

                    int isToHide = Convert.ToInt32(dr["IsToHide"].ToString());
                    int isToShowAlways = Convert.ToInt32(dr["isToShowAlways"].ToString());
                    if (isToHide == 1) continue;

                    if (isToShowAlways == 1) fpSpread1.ActiveSheet.Columns[columnNo].Visible = true;
                    else fpSpread1.ActiveSheet.Columns[columnNo].Visible = (!fpSpread1.ActiveSheet.Columns[columnNo].Visible);
                }
                
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "ExpandCollapseColumn", err.Message);
            }
        }

        private void fpSpread1_MouseDown(object sender, MouseEventArgs e)
        {
            fpSpread1.ContextMenuStrip = null;
            if (fpSpread1.ActiveSheet.RowCount > 0) fpSpread1.ActiveSheet.Rows[0, fpSpread1.ActiveSheet.RowCount - 1].ResetBackColor();

            if (e.Button == MouseButtons.Right)
            {
                if (fpSpread1.HitTest(e.X, e.Y).ViewportInfo == null) return;

                int row = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Row;
                int col = fpSpread1.HitTest(e.X, e.Y).ViewportInfo.Column;
                if (row < 0 || col < 0) return;

                fpSpread1.ActiveSheet.SetActiveCell(row, col);
                fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;

                int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value);
                string script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='DocMgmt' and IsPrgDisabled = 0";
                bool isToEnableDocMgmt = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                tsMnuDocumentManagement.Visible = (isToEnableDocMgmt && PG.IsAllowedUserForAccessRightsApplication(PG.APPNAME_DocMgmt));

                script = " select count(*) from VUI_GroupItems where VesselID = " + vesselID + " and Prg='Circulars_Vsl' and IsPrgDisabled = 0";
                bool isToEnableAlerts_Circulars = (Convert.ToInt32(PG.Gb.DBFn.Aqr(script)) > 0);
                tsMnuVslAlerts_Circulars.Visible = isToEnableAlerts_Circulars;

                fpSpread1.ContextMenuStrip = contextMenuStrip1;

                VslApps_toolStripMenuItem1.Enabled = (fpSpread1.ActiveSheet.Cells[row, COL_ISOFFICEVSL].Value.ToString() == "0");

                if (fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].Tag != null)
                {
                    string groupName = fpSpread1.ActiveSheet.ColumnHeader.Cells[0, col].Tag.ToString().ToUpper();
                    if (groupName == PG.GROUPNAME_FORMS) tsMnuForms.Select();
                    else if (groupName == PG.GROUPNAME_AI_SCHED || groupName == PG.GROUPNAME_AI_APPROVAL) tsMnuAuditInspection.Select();
                    else if (groupName == PG.GROUPNAME_NCR) tsMnuNCR.Select();
                    else if (groupName == PG.GROUPNAME_DEFECTS) tsMnuDefects.Select();
                    else if (groupName == PG.GROUPNAME_TASK) tsMnuTaskList.Select();
                    else if (groupName == PG.GROUPNAME_INCIDENTREPORT || groupName == PG.GROUPNAME_INCIDENTREPORT1) tsMnuIncidentReport.Select();
                    else if (groupName == PG.GROUPNAME_INVESTIGATIONREPORT || groupName == PG.GROUPNAME_INVESTIGATIONREPORT1) tsMnuIncidentReport.Select();
                    else if (groupName == PG.GROUPNAME_AWARENESSREPORT) tsMnuAwarenessReport.Select();
                    else if (groupName == PG.GROUPNAME_SAFETYCOMMITTEEMEETING || groupName == PG.GROUPNAME_SAFETYCOMMITTEEMEETING1) tsMnuMinutesOfSafety.Select();
                    else if (groupName == PG.GROUPNAME_MASTERSSAFETYREVIEW) tsMnuMastersReview.Select();
                }
            }
        }

        #region Bottom Dashboard Grid - Right Click menu
        private void tsmu_VslDashBoard_Click(object sender, EventArgs e)
        {
            CallVslApplication("VslDashBoard");
        }

        private void tsMnuForms_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallFormsApplication(vesselID, "All|" + PG.HSQE_DeptName, true, false, PG.REFRESH_CALLEDMODE_MARINE_FORMS);
        }

        private void tsMnuVslForms_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            calledFrom = "";
            CallFormsApplication(vesselID, "All|" + PG.HSQE_DeptName, false, true, PG.REFRESH_CALLEDMODE_MARINE_FORMS);
        }


        private void tsMnuVslNCR_Click(object sender, EventArgs e)
        {
            calledFrom = "";
            CallVslApplication("NCR");
        }

        private void tsMnuNCR_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallNCRApplication(vesselID, "", true, false);
        }

        private void tsMnuDefects_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallDefectsApplication(vesselID, "", true, false);
        }

        private void tsMnuTaskList_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallTaskListApplication(vesselID, "", true, false);
        }

        private void tsMnuVslTaskList_Click(object sender, EventArgs e)
        {
            calledFrom = "";
            CallVslApplication("Task");
        }


        private void tsMnuIncidentReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallIncidentReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslIncidentReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallIncidentReportApplication(vesselID, "", false, true);
        }


        private void tsMnuAwarenessReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallAwarenessReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslAwarenessReport_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }
            CallAwarenessReportApplication(vesselID, "", false, true);
        }


        private void tsMnuMastersReview_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMastersReviewReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslMastersReview_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMastersReviewReportApplication(vesselID, "", false, true);
        }


        private void tsMnuMinutesOfSafety_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMinutesOfSafetyReportApplication(vesselID, "", true, false);
        }

        private void tsMnuVslMinutesOfSafety_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallMinutesOfSafetyReportApplication(vesselID, "", false, true);
        }


        private void tsMnuDocumentManagement_Click(object sender, EventArgs e)
        {
            CallVslApplication("DocMgmt");
        }

        private void tsMnuVslAlerts_Circulars_Click(object sender, EventArgs e)
        {
            CallVslApplication("Circulars_Vsl");
        }

        private void tsMnuRiskAssements_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallRiskMgmtApplication(vesselID, "Register", true, false);
        }

        private void tsMnuVslRiskAssements_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallRiskMgmtApplication(vesselID, "Register|Marine", false, true);
        }

        private void tsMnuVslCertificate_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }

            CallCertificateApplication(vesselID, "Register", false, true);
        }

        private void CallVslApplication(string exeName)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for vessels.");
                return;
            }

            string param = GetParam(vesselID, true);

            if (exeName.ToUpper() == "NCR".ToUpper())
            {
                CallNCRApplication(vesselID, "", false, true);
            }
            else if (exeName.ToUpper() == "Task".ToUpper())
            {
                CallTaskListApplication(vesselID, "", false, true);
            }
            else
            {
                if (exeName.ToUpper() == "PmsMain".ToUpper())
                {
                    exeName = "VslDashBoard";
                    param = param + " PmsMain";
                }
                Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, vesselID, PG.Gb.DBFn);
            }
            FocusSelectedVessel(vesselID);
        }

        private void CallAuditInspectionApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            AuditInspection.AuditInspectionStartup aiStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

                aiStartup = new AuditInspection.AuditInspectionStartup(arg.Split(' '));

                if (!aiStartup.isVslInitSuccessfully)
                {
                    return;
                }

                aiStartup.CallVslAuditInspectionMainPage();
                isDoneAnyChanges = aiStartup.isDoneAnyChanges;
            }
            finally
            {
                aiStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_AUDITINSPECTION;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallNCRApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            NCR.NCRstartup ncrStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

                ncrStartup = new NCR.NCRstartup(arg.Split(' '));

                if (!ncrStartup.isVslInitSuccessfully)
                {
                    return;
                }

                ncrStartup.CallNCRRegisterMainPage();
                isDoneAnyChanges = ncrStartup.isDoneAnyChanges;
            }
            finally
            {
                ncrStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_NCR;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallCertificateApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string hqDept = "Common_Marine";
            if (!PG.isCert_FilterOdueDeptwise && addParam.ToUpper() == "OVERDUE") hqDept = "";

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|" + hqDept;

            VslCertificates.VslCertificatesStartup vslCertificate = new VslCertificates.VslCertificatesStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!vslCertificate.isVslInitSuccessfully)
                {
                    return;
                }

                vslCertificate.CallVslCertificatesMainPage();
                isDoneAnyChanges = vslCertificate.isDoneAnyChanges;
            }
            finally
            {
                vslCertificate = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_CERTIFICATE;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallDefectsApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

            bool isDoneAnyChanges = false;
            VslDefects.DFStartup vslDefects = new VslDefects.DFStartup(arg.Split(' '));
            try
            {
                if (!vslDefects.isVslInitSuccessfully)
                {
                    return;
                }

                vslDefects.CallDefectRegisterMainPage();
                isDoneAnyChanges = vslDefects.isDoneAnyChanges;
            }
            finally
            {
                vslDefects = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_DEFECTS;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallIncidentReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

            IncidentReport.IncidentReportStartup incidentReportStartup = new IncidentReport.IncidentReportStartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!incidentReportStartup.isVslInitSuccessfully)
                {
                    return;
                }

                incidentReportStartup.CallVslIncidentReportMainPage();
                isDoneAnyChanges = incidentReportStartup.isDoneAnyChanges;
            }
            finally
            {
                incidentReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_INCIDENTREPORT;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallAwarenessReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

            AwarenessReport.AwarenessReportstartup awarenessReportStartup = new AwarenessReport.AwarenessReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;

            try
            {
                if (!awarenessReportStartup.isVslInitSuccessfully)
                {
                    return;
                }
                awarenessReportStartup.CallAwarenessReportRegisterMainPage();
                isDoneAnyChanges = awarenessReportStartup.isDoneAnyChanges;
            }
            finally
            {
                awarenessReportStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_AWARENESS_REPORT;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallMastersReviewReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            /*
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

            MastersReviewReport.MastersReviewReportstartup mastersReviewReportstartup = new MastersReviewReport.MastersReviewReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!mastersReviewReportstartup.isVslInitSuccessfully)
                {
                    return;
                }

                mastersReviewReportstartup.CallMastersReviewRegisterMainPage();
                isDoneAnyChanges = mastersReviewReportstartup.isDoneAnyChanges;
            }
            finally
            {
                mastersReviewReportstartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_MASTERS_REVIEW;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
            */
        }

        private void CallMinutesOfSafetyReportApplication(int vesselID, string addParam, bool isToRefresh, bool isHQAccess)
        {
            string vslFilter = "";
            if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

            string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addParam.Trim() + "|" + vslFilter + "|Marine";

            MinutesofSafetyReport.MinutesofSafetyReportstartup minutesofSafetyReportstartup = new MinutesofSafetyReport.MinutesofSafetyReportstartup(arg.Split(' '));
            bool isDoneAnyChanges = false;
            try
            {
                if (!minutesofSafetyReportstartup.isVslInitSuccessfully)
                {
                    return;
                }

                minutesofSafetyReportstartup.CallMinutesofSafetyReportRegisterMainPage();
                isDoneAnyChanges = minutesofSafetyReportstartup.isDoneAnyChanges;
            }
            finally
            {
                minutesofSafetyReportstartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                panelLoading.Visible = true;
                Application.DoEvents();
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_MINUTES_OF_SAFETY;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallFormsApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess, string xCalledFrom)
        {
            VslForms.FormsStartup formsStartup;
            bool isChangesDone = false;
            try
            {
                string vslFilter = "";

                if (cboVslFilter.SelectedValue != null) vslFilter = " " + cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + vslFilter;
                formsStartup = new VslForms.FormsStartup(arg.Split(' '));

                formsStartup.CallFormsListMainPage(arg.Split(' '));
                isChangesDone = formsStartup.isChangesDone;
            }
            finally
            {
                formsStartup = null;
            }

            if (isToRefresh && isChangesDone)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_FORMS;
                RefreshHQDashboard(vesselID);
            }
            isChangesDone = false;
        }

        private void CallRiskMgmtApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            RiskMgmt.RMStartup rmStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = " " + cboVslFilter.SelectedValue.ToString();

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + vslFilter;
                rmStartup = new RiskMgmt.RMStartup(arg.Split(' '));

                if (addlParameter.Trim().ToUpper() == "VslTaskToMove".ToUpper())
                {
                    rmStartup.CallHQReviewPage();
                }
                else
                {
                    rmStartup.CallRMRegisterPage();
                }

                isDoneAnyChanges = rmStartup.isDoneAnyChanges;
            }
            finally
            {
                rmStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_RISKASSEMENTS;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }

        private void CallTaskListApplication(int vesselID, string addlParameter, bool isToRefresh, bool isHQAccess)
        {
            TaskList.Taskstartup taskStartup;
            bool isDoneAnyChanges = false;
            try
            {
                string vslFilter = "";
                if (cboVslFilter.SelectedValue != null) vslFilter = cboVslFilter.SelectedValue.ToString();

                string sx = "|Marine";

                string arg = Environment.GetCommandLineArgs()[0] + " " + GetParam(vesselID, isHQAccess) + " " + addlParameter.Trim() + "|" + vslFilter + sx;

                taskStartup = new TaskList.Taskstartup(arg.Split(' '));

                if (!taskStartup.isVslInitSuccessfully)
                {
                    return;
                }

                taskStartup.CallTaskRegisterMainPage();
                isDoneAnyChanges = taskStartup.isDoneAnyChanges;
            }
            finally
            {
                taskStartup = null;
            }

            if (isToRefresh && isDoneAnyChanges)
            {
                calledFrom = PG.REFRESH_CALLEDMODE_MARINE_TASK;
                RefreshHQDashboard(vesselID);
            }
            isDoneAnyChanges = false;
        }
        

        private string GetParam(int vesselID, bool IsHqAccesMode)
        {
            string param = "";
            string HqAccesMode = "NO";
            if (IsHqAccesMode) HqAccesMode = "YES";
            if (PG.isDirectAppCall)
            {
                param = cboCompany_Filter.Text + "|DirectCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd + "|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);

                param = cboCompany_Filter.Text + "|RemoteWebSvc|" + URLString + "|xxxxx|xxxxx|xxx|" + PG.Gb.User.CurWinLoginUserID + "|HQ|" + vesselID + "|" + HqAccesMode + "|NO|HqAsVslMode";
            }
            return param;
        }

        private void BindDashboardDetailsGrid(int vesselID)
        {
            fieldName = "";
            chkShowOnlyActionColumns.Checked = false;
            BindAndFocusSelectedFieldColumn();
            BindTopPanelDashboardData();
            if (vesselID > 0) FocusSelectedVessel(vesselID);
        }

        private void FocusSelectedVessel(int vesselID)
        {
            for (int row = 0; row < fpSpread1.ActiveSheet.RowCount; row++)
            {
                int curVesselID = -1;
                if (fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value != null) curVesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].Value);
                if (curVesselID == vesselID)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(row, 0);
                    int topRow = row;
                    if (topRow > 10) topRow = topRow - 10;
                    fpSpread1.SetViewportTopRow(0, topRow);

                    fpSpread1.ActiveSheet.Rows[row].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    fpSpread1.ActiveSheet.Cells[row, COL_VESSELID].BackColor = fpSpread1.ActiveSheet.SelectionBackColor;
                    break;
                }
            }
        }
        #endregion


        #region Top links

        private void chkShowDashboard_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowDashboard.Checked)
            {
                tableLayoutPanel2.ColumnStyles[0].Width = 336 + 18;
            }
            else
            {
                tableLayoutPanel2.ColumnStyles[0].Width = 0;
            }
        }

        private void chkShowOnlyActionColumns_CheckedChanged(object sender, EventArgs e)
        {
            DataTable dt = GetMarineDashboardDataTable();

            ShowOnlyActionColumns(true, dt);

            ShowMyApproveColumns(dt);
        }

        private void ShowOnlyActionColumns(bool isToClearFieldName, DataTable dt)
        {
            if (!isFormInitialised) return;

            if (chkShowOnlyActionColumns.Checked)
            {
                string xExcludeColList = "," + excludeColList + ",";
                if (isToClearFieldName) fieldName = "";

                for (int colHeaderIndex = COL_FORMS_ODUE; colHeaderIndex < fpSpread1.ActiveSheet.ColumnCount - 1; colHeaderIndex++)
                {
                    string sx1 = "," + colHeaderIndex + ",";
                    if (fpSpread1.ActiveSheet.ColumnHeader.Cells[1, colHeaderIndex].Tag == null
                        && (xExcludeColList.IndexOf(sx1) < 0))
                    {
                        fpSpread1.ActiveSheet.Columns[colHeaderIndex].Visible = false;
                    }
                    else
                    {
                        DataRow[] dr = dt.Select("ColumnNo=" + colHeaderIndex);
                        if (dr != null && dr.Length > 0)
                        {
                            if (dr[0]["IsToHide"].ToString() == "0")
                            {
                                fpSpread1.ActiveSheet.Columns[colHeaderIndex].Visible = true;
                            }
                        }
                    }
                }
            }
            else
            {
                int colNo = fpSpread1.ActiveSheet.ActiveColumnIndex;

                InitialiseHQDashboardFieldSetup(dt);

                if (colNo < fpSpread1.ActiveSheet.ColumnCount)
                {
                    fpSpread1.ActiveSheet.SetActiveCell(0, colNo);
                    fpSpread1.SetViewportTopRow(0, 0);
                    fpSpread1.SetViewportLeftColumn(0, colNo);
                }
            }
        }

        private void chkShowMyApproveColumn_CheckedChanged(object sender, EventArgs e)
        {
            DataTable dt = GetMarineDashboardDataTable();
            
            ShowMyApproveColumns(dt);
        }

        private void ShowMyApproveColumns(DataTable dt)
        {
            if (chkShowMyApproveColumn.Checked)
            {
                string colList = "";
                string[] colToHide = PG.showOnlySuptApproveColumns_Marine.Trim().Split(',');
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SUPT" && PG.showOnlySuptApproveColumns_Marine.Trim().Length > 0) colList = colList + "," + PG.showOnlySuptApproveColumns_Marine.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "MANAGER" && PG.showOnlyMgrApproveColumns_Marine.Trim().Length > 0) colList = colList + "," + PG.showOnlyMgrApproveColumns_Marine.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "GENERALMANAGER" && PG.showOnlyGenMgrApproveColumns_Marine.Trim().Length > 0) colList = colList + "," + PG.showOnlyGenMgrApproveColumns_Marine.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "SENIORMANAGER" && PG.showOnlySenMgrApproveColumns_Marine.Trim().Length > 0) colList = colList + "," + PG.showOnlySenMgrApproveColumns_Marine.Trim();
                if (PG.Gb.User.CurrentUserRole.ToUpper() == "DIRECTOR" && PG.showOnlyDirApproveColumns_Marine.Trim().Length > 0) colList = colList + "," + PG.showOnlyDirApproveColumns_Marine.Trim();
                if (colList.Trim().Length > 0)
                {
                    fpSpread1.ActiveSheet.Columns[COL_CERTIFICATE_DUE, COL_ISOFFICEVSL].Visible = false;
                    colToHide = colList.Trim().Split(',');
                    string xExcludeColList = "," + excludeColList + ",";
                    foreach (string str in colToHide)
                    {
                        if (str.Trim().Length > 0)
                        {
                            int col = Convert.ToInt32(str);                            
                            DataRow[] dr = dt.Select("columnno = " + col + " and istohide =0");
                            if (dr.Length > 0)
                            {
                                if (chkShowOnlyActionColumns.Checked && fpSpread1.ActiveSheet.ColumnHeader.Cells[1, col].Tag == null
                                && (xExcludeColList.IndexOf(col.ToString()) < 0))
                                {
                                    fpSpread1.ActiveSheet.Columns[col].Visible = false;
                                }
                                else
                                {
                                    fpSpread1.ActiveSheet.Columns[col].Visible = true;
                                    fpSpread1.ActiveSheet.ColumnHeader.Cells[0, COL_AUDITINSPECTION_RESCHEDULED_TOAPPR].VerticalAlignment = FarPoint.Win.Spread.CellVerticalAlignment.Top;
                                }
                            }
                        }
                    }                    
                }
            }
            else
            {
                ShowOnlyActionColumns(true, dt);
            }
        }
    
        private void btnDMS_Click(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Visible = true; pictureBox1.Left = btnDMS.Left - pictureBox1.Width - 10; pictureBox1.Top = 0;
                PG.CallDMS(cboCompany_Filter.Text);
            }
            finally
            {
                pictureBox1.Visible = false;
                pictureBox1.Left = panelLoading.Left; pictureBox1.Top = panelLoading.Top - 10;
            }
        }

        private void btnTechDashboard_Click(object sender, EventArgs e)
        {
            frmMainForm_Tech objMainFormTech = new frmMainForm_Tech();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objMainFormTech.companyID = companyID;
                objMainFormTech.isToShowSQEDashboard = false;
                objMainFormTech.isToShowCREWDashboard = isToShowCREWDashboard;
                objMainFormTech.ShowDialog();
            }
            finally
            {
                objMainFormTech = null;
            }
        }

        private void btnCrewDashboard_Click(object sender, EventArgs e)
        {
            frmMainForm_Crew objMainFormCrew = new frmMainForm_Crew();
            try
            {
                string companyID = "-99";
                if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                objMainFormCrew.companyID = companyID;
                objMainFormCrew.isToShowTECHDashboard = isToShowTECHDashboard;
                objMainFormCrew.isToShowSQEDashboard = false;
                objMainFormCrew.ShowDialog();

                if (!PG.InitialiseCommonSettings(companyID)) return;
            }
            finally
            {
                objMainFormCrew = null;
            }
        }

        private void btnProcurement_Click(object sender, EventArgs e)
        {
            string exeName = PG.default_ProcAppToCall;
            string param = "";
            if (PG.isDirectAppCall)
            {
                param = "DirectAppCall|" + PG.Gb.ServerName + "|" + PG.Gb.CurrentDBname + "|" + PG.Gb.DbUserId + "|" + PG.Gb.DbPwd;
            }
            else
            {
                string URLString = PG.webSvcURL;
                PG.Decrypt(ref URLString, PG.checkValue);
                param = "RemoteWebSvc " + URLString;
            }

            PG.ExecuteApp(exeName, param);
        }

        private void lnkRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
                Application.DoEvents();

                calledFrom = "";
                RefreshHQDashboard(-1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "lnkRefresh_LinkClicked", err.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
                pictureBox1.Visible = false;
            }
        }

        private void RefreshHQDashboard(int selectedVesselID)
        {
            string script = "";
            DataTable dt = null;
            try
            {
                this.Cursor = Cursors.WaitCursor;

                if (selectedVesselID == -1)
                {
                    #region All vessels refresh
                    string companyID = "-99";
                    if (cboCompany_Filter.SelectedValue != null) companyID = cboCompany_Filter.SelectedValue.ToString();

                    string addlCond = "";
                    if (PG.laidupVessels.Trim().Length > 0)
                    {
                        addlCond = addlCond + "   and V.VslCode not in ('" + PG.laidupVessels.Replace(",", "','") + "')";
                    }
                    if (companyID != "-99") addlCond = addlCond + " and V.C_CompanyID='" + companyID + "'";

                    script = " Select V.VesselID from Dashboard_HQ_Main_Marine_Status S, V_Vessels V " +
                             " Where S.VesselID=V.VesselID " +
                             "   and V.VesselID<>-1" +
                             addlCond;
                    dt = PG.Gb.DBFn.DbRecords(script);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        progressBarRefresh.Visible = true;
                        if (progressBarRefresh.Value > 0) progressBarRefresh.Value = 1;
                        progressBarRefresh.Step = 1;
                        progressBarRefresh.Minimum = 0;
                        progressBarRefresh.Maximum = dt.Rows.Count;
                        Application.DoEvents();

                        foreach (DataRow dr in dt.Rows)
                        {
                            int vesselID = Convert.ToInt32(dr["VesselID"].ToString());

                            RefreshHQDashboardForThisVessel(vesselID);

                            Application.DoEvents();
                            progressBarRefresh.PerformStep();
                        }
                    }
                    #endregion
                }
                else
                {
                    RefreshHQDashboardForThisVessel(selectedVesselID);
                }

                panelLoading.Visible = false;
                Application.DoEvents();

                BindDashboardDetailsGrid(-1);
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForm_Marine.cs", "RefreshHQDashboard", err.Message);
            }
            finally
            {
                panelLoading.Visible = false;
                progressBarRefresh.Visible = false;
                this.Cursor = Cursors.Default;
            }
        }

        private void RefreshHQDashboardForThisVessel(int vesselID)
        {
            try
            {
                if (calledFrom.Trim().Length > 0)
                {
                    PG.Refresh_HQ_Dashboard_Marine(calledFrom, vesselID);
                }
                else
                {
                    PG.Refresh_HQ_Dashboard_Marine(PG.REFRESH_CALLEDMODE_MARINE_ALL, vesselID);
                }
            }
            catch (Exception err)
            {
                PG.AddToGenErrorLog("frmMainForms.cs", "RefreshHQDashboardForThisVessel", err.Message);
            }
        }

        private void lnkReset_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            fieldName = "";
            BindDashBoardGrid();
        }

        private void tsMnuNCRTrending_Click(object sender, EventArgs e)
        {
            string exeName = "HQ_Trendings";
            string param = GetParam(-1, false);
            param = param + " NCRTrending";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tsMnuAwarenessReportTrending_Click(object sender, EventArgs e)
        {
            string exeName = "HQ_Trendings";
            string param = GetParam(-1, false);
            param = param + " AWRTrending";
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tlsMnuRootCauseAnalysisChartSetup_Click(object sender, EventArgs e)
        {
            string exeName = "MSCat_SetUp";
            string param = GetParam(-1, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }

        private void tlsMnuAuditInspectionSetup_Click(object sender, EventArgs e)
        {
            string exeName = "AuditInspectionSetUp";
            string param = GetParam(-1, false);
            Gfn.ExecuteApp(PG.winSdsRootDir, exeName, param, -1, PG.Gb.DBFn);
        }


        private void tsMnuAuditInspection_Click(object sender, EventArgs e)
        {
            int rowIndex = fpSpread1.ActiveSheet.ActiveRowIndex;
            if (rowIndex < 0) return;

            if (fpSpread1.ActiveSheet.ActiveCell == null) return;

            int vesselID = Convert.ToInt32(fpSpread1.ActiveSheet.Cells[rowIndex, COL_VESSELID].Value.ToString());
            if (vesselID == PG.generalFleetVslId)
            {
                Gfn.nWb(" This feature is only available for WinSds System implemented on Vessel.");
                return;
            }
            string addlParameter = "ALL|-1";
            CallAuditInspectionApplication(vesselID, addlParameter, true, false);
        }

        #endregion

        private void tsMnuAbout_Click(object sender, EventArgs e)
        {
            frmAboutBox objAboutBox = new frmAboutBox();
            try
            {
                objAboutBox.ShowDialog();
            }
            finally
            {
                objAboutBox = null;
            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMainForm_Marine_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (isFormInitialised && (isToShowTECHDashboard && isToShowCREWDashboard))
            //{
            //    string msg = "Are you sure you want to exit " + cboCompany_Filter.Text.ToUpper() + "HQ_SDS ?";
            //    if (!Gfn.nConfBox(msg))
            //    {
            //        e.Cancel = true;
            //        return;
            //    }
            //}
            common = null;
        }
    }
}